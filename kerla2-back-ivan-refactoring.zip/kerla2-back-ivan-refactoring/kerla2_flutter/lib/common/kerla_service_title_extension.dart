import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';

extension KerlaServiceTitleExtension on KerlaServiceType {
  String get title {
    return switch (this) {
      KerlaServiceType.turbo => 'Турбо продажа',
      KerlaServiceType.boost => 'Поднятие в ленте',
      KerlaServiceType.stories => 'Stream Stories',
      KerlaServiceType.businessProfile => 'Бизнес профиль',
    };
  }

  String get image {
    return switch (this) {
      KerlaServiceType.turbo => AppAddServicesIconsSvg.rocket,
      KerlaServiceType.boost => AppAddServicesIconsSvg.arrow,
      KerlaServiceType.stories => AppAddServicesIconsSvg.stories,
      KerlaServiceType.businessProfile => AppAddServicesIconsSvg.businessCase,
    };
  }
}
