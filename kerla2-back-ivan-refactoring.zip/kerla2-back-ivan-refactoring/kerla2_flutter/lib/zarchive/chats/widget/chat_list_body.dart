// import 'package:flutter/material.dart';
// import 'package:flutter_riverpod/flutter_riverpod.dart';
// import 'package:kerla2_flutter/ui_kit/ui_kit.dart';

// import '../state/chat_list_state.dart';
// import 'chat_card.dart';

// class ChatListBody extends ConsumerWidget {
//   const ChatListBody({super.key});

//   @override
//   Widget build(BuildContext context, WidgetRef ref) {
//     final state = ref.watch(chatListStateProvider);
//     return state.when(
//       error: (error, stackTrace) => Text('Возникла ошибка: $error'),
//       loading: () => LoadingScreen.chats(),
//       data: (data) {
//         return RefreshIndicator(
//           onRefresh: () async {
//             ref.invalidate(chatListStateProvider);
//           },
//           child: LayoutBuilder(
//             builder: (context, constraints) {
//               if (data.isNotEmpty) {
//                 return ListView.builder(
//                   itemCount: data.length,
//                   itemBuilder: (context, index) {
//                     if (data[index].chatWith?.id == null) {
//                       return const SizedBox.shrink();
//                     }
//                     return Padding(
//                       padding: const EdgeInsets.symmetric(vertical: 4),
//                       child: ChatCard(
//                         index: index,
//                         channel: data[index],
//                       ),
//                     );
//                   },
//                 );
//               } else {
//                 // ListView is needed for RefreshIndicator to work
//                 return ListView(
//                   children: [
//                     ConstrainedBox(
//                       constraints: BoxConstraints(
//                         minHeight: constraints.maxHeight,
//                       ),
//                       child: const Center(
//                         child: Text('У вас нет чатов'),
//                       ),
//                     ),
//                   ],
//                 );
//               }
//             },
//           ),
//         );
//       },
//     );
//   }
// }
