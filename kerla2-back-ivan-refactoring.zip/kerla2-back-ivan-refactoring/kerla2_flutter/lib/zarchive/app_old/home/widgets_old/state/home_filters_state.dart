// import 'package:freezed_annotation/freezed_annotation.dart';
// import 'package:kerla2_client/kerla2_client.dart';
// import 'package:kerla2_flutter/core/core.dart';
// import 'package:riverpod_annotation/riverpod_annotation.dart';

// part 'home_filters_state.freezed.dart';
// part 'home_filters_state.g.dart';

// @Riverpod(keepAlive: true)
// class HomeFiltersState extends _$HomeFiltersState {
//   @override
//   HomeFiltersData build({required bool isProfile}) {
//     return const HomeFiltersData();
//   }

//   void addCategoryStack(AdCategory category) {
//     final currentStack = [...state.categoryStack];
//     currentStack.add(category);
//     state = state.copyWith(
//       categoryStack: currentStack,
//     );
//   }

//   void popCategoryStack() {
//     final currentStack = [...state.categoryStack];
//     currentStack.removeLast();
//     state = state.copyWith(
//       categoryStack: currentStack,
//     );
//   }

//   Future<List<Attribute>> getAttributes() async {
//     if (state.categoryStack.isEmpty) return [];
//     final res = await client.adCategory
//         .getAttributesByCategory(state.categoryStack.last);

//     return res;
//   }

//   void setAttribute<T>(AdAttributeValue attribute) {
//     final updatedAttributes = List<AdAttributeValue>.from(state.attribute);

//     //TODO: handle Region sort

//     if (updatedAttributes.isEmpty) {
//       updatedAttributes.add(attribute);
//     } else {
//       final existingIndex = updatedAttributes
//           .indexWhere((attr) => attr.attributeId == attribute.attributeId);

//       if (existingIndex != -1) {
//         final existingAttribute = updatedAttributes[existingIndex];
//         final updatedAttribute = AdAttributeValue(
//           id: existingAttribute.id,
//           attributeId: existingAttribute.attributeId,
//           value: attribute.value,
//         );
//         if (attribute.value.isEmpty) {
//           updatedAttributes.removeAt(existingIndex);
//         } else {
//           updatedAttributes[existingIndex] = updatedAttribute;
//         }
//       } else {
//         updatedAttributes.add(attribute);
//       }
//     }

//     state = state.copyWith(attribute: updatedAttributes);
//   }

//   void removeAttributes() {
//     state = state.copyWith(attribute: []);
//   }

//   List<Map<int, String>> convertAttributes() {
//     final List<Map<int, String>> outputList = [];

//     final inputList = state.attribute;

//     if (inputList.isNotEmpty) {
//       for (var item in inputList) {
//         final attributeId = item.attributeId;
//         final value = item.value;
//         outputList.add({attributeId: value});
//       }
//     }

//     return outputList;
//   }

//   void removeOneAttribute<T>(
//     int attributeId,
//     bool isSubAttribute,
//   ) {
//     final updatedAttributes = List<AdAttributeValue>.from(state.attribute);

//     if (updatedAttributes.isNotEmpty) {
//       final existingIndex = updatedAttributes
//           .indexWhere((attr) => attr.attributeId == attributeId);

//       if (existingIndex != -1) {
//         updatedAttributes.removeAt(existingIndex);
//       }
//     }

//     // ref.invalidate(
//     //   attributeDropDownValueProvider(attributeId, isSubAttribute),
//     // );

//     state = state.copyWith(attribute: updatedAttributes);
//   }

//   void setSearchQuery(String searchQuery) {
//     state = state.copyWith(searchQuery: searchQuery);
//   }

//   void removeSearchQuery() {
//     state = state.copyWith(searchQuery: null);
//   }
// }

// @freezed
// class HomeFiltersData with _$HomeFiltersData {
//   const factory HomeFiltersData({
//     @Default([]) List<AdCategory> categoryStack,
//     String? searchQuery,
//     @Default([]) List<AdAttributeValue> attribute,
//   }) = _HomeFiltersData;
// }

// @Riverpod(keepAlive: true)
// class AttributeDropDownValue extends _$AttributeDropDownValue {
//   @override
//   AttributeDropDownValueState build(
//     int attributeId,
//     bool isSubAttribute,
//   ) {
//     return AttributeDropDownValueState(
//         // controller: TextEditingController(),
//         );
//   }

//   void setValue(String value) {
//     //pin value here

//     // state.controller.text = value;

//     state = state.copyWith(
//       unsavedValue: value,
//       pinValue: value,
//     );
//   }

//   void setPinValue(String value) {
//     state = state.copyWith(
//       pinValue: value,
//     );
//   }

//   void resetPinValue() {
//     state = state.copyWith(
//       pinValue: state.unsavedValue,
//     );
//   }

//   void resetUnsavedValue() {
//     if (state.savedValue != null) {
//       // state.controller.text = state.savedValue!;
//     } else {
//       // state.controller.text = '';
//     }

//     state = state.copyWith(
//       unsavedValue: state.savedValue,
//       pinValue: state.savedValue,
//     );
//   }

//   // void resetValues() {
//   //   state.controller.text = '';
//   //   state = state.copyWith(
//   //     unsavedValue: null,
//   //     savedValue: null,
//   //   );
//   // }

//   void initState(String value) {
//     state = state.copyWith(
//       savedValue: value,
//       unsavedValue: value,
//       pinValue: value,
//     );
//   }

//   String? saveValue(List<String>? values) {
//     if (values == null) {
//       return null;
//     }

//     if (state.unsavedValue != null) {
//       // state.controller.text = state.unsavedValue!;

//       state = state.copyWith(
//         savedValue: state.unsavedValue,
//         pinValue: state.unsavedValue,
//       );
//       return state.savedValue;
//     } else {
//       debugPrint('there is no unsaved value');
//     }
//     return null;
//   }
// }

// @freezed
// class AttributeDropDownValueState with _$AttributeDropDownValueState {
//   const factory AttributeDropDownValueState({
//     String? savedValue,
//     String? unsavedValue,
//     String? pinValue,
//     // required TextEditingController controller,
//   }) = _AttributeDropDownValueState;
// }

// @Riverpod(keepAlive: true)
// class AttributeRange extends _$AttributeRange {
//   @override
//   AttributeRangeState build(
//     int attributeId,
//   ) {
//     return AttributeRangeState(
//       leftController: TextEditingController(),
//       rightController: TextEditingController(),
//     );
//   }

//   void saveValue() {
//     state = state.copyWith(
//       lSavedValue: state.leftController.text,
//       rSavedValue: state.rightController.text,
//     );
//   }

//   void resetUnsavedValue() {
//     state.leftController.text = state.lSavedValue ?? '';
//     state.rightController.text = state.rSavedValue ?? '';
//   }

//   String? valueToAttribute() {
//     return "${state.lSavedValue?.isEmpty == true ? '-1' : state.lSavedValue}:${state.rSavedValue?.isEmpty == true ? '-1' : state.rSavedValue}";
//   }
// }

// @freezed
// class AttributeRangeState with _$AttributeRangeState {
//   const factory AttributeRangeState({
//     String? lSavedValue,
//     String? rSavedValue,
//     required TextEditingController leftController,
//     required TextEditingController rightController,
//   }) = _AttributeRangeState;
// }
