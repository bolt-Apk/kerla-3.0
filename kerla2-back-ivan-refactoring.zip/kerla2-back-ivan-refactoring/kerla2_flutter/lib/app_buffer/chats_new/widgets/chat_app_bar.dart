import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:kerla2_flutter/app_buffer/profile/profile_image/profile_image.dart';
import 'package:kerla2_flutter/common/user_profile_ref_extensions.dart';
import 'package:kerla2_flutter/router/router.dart';
import 'package:kerla2_shared/kerla2_shared.dart';
import 'package:nit_app/nit_app.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class ChatAppBar extends ConsumerWidget implements PreferredSizeWidget {
  const ChatAppBar({
    super.key,
    required this.chatChannel,
  });

  final NitChatChannel chatChannel;

  @override
  Size get preferredSize => const Size.fromHeight(56);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final userId = ChatChannelNames.extractUserIds(chatChannel.channel)!
        .firstWhere((element) => element != ref.signedInUserId);

    // final chatTheme = ChatTheme.of(context);

    return ref.watchUserProfile(userId).nitWhen(
      childBuilder: (userProfile) {
        return AppBar(
          // leading: BackButton(
          //   color: context.textTheme.bodyLarge?.color,
          // ),
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(
              bottom: Radius.circular(16),
            ),
          ),
          titleSpacing: 0,
          title: InkWell(
            onTap: () => context.pushNamed(
              MainAreaNavigationZone.user.name,
              pathParameters: AppNavigationParams.userId.set(userId),
            ),
            child: Row(
              children: [
                ProfileImage(
                  userId: userId,
                  size: 40,
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 8),
                  child: Text(
                    userProfile.userName ?? '',
                    style:
                        context.textTheme.titleMedium?.copyWith(fontSize: 20),
                  ),
                ),
                // TODO: был онлайн
              ],
            ),
          ),
          elevation: 1,
          iconTheme: context.theme.iconTheme,
          backgroundColor: context.theme.canvasColor,
        );
      },
    );
  }
}
