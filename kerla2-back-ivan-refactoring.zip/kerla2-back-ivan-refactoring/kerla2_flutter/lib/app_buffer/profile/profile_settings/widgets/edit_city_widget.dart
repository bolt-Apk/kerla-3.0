import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/app_buffer/home/filters/list_filter/widgets/home_attribute_dialog.dart';
import 'package:kerla2_flutter/app_buffer/home/filters/list_filter/widgets/home_filter_bottom_sheet.dart';
import 'package:kerla2_flutter/app_buffer/home/filters/list_filter/widgets/home_filter_drop_down_row_widget.dart';
import 'package:kerla2_flutter/common/user_profile_ref_extensions.dart';
import 'package:kerla2_flutter/core/app_sources.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_app/nit_app.dart';

class EditCityWidget extends ConsumerWidget {
  const EditCityWidget({
    super.key,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final userProfile = ref.currentUserProfile!;
    final regions = ref.read(regionsProvider);
    return TextSettingsRow(
      title: 'Город:',
      // textController: state.cityController,
      subtitle: userProfile.city ?? '',
      onTap: (context) {
        showModalBottomSheet(
          context: context,
          isScrollControlled: true,
          builder: (BuildContext context) {
            return HookBuilder(
              builder: (context) {
                final filterValueNotifier = useState('');
                final currentValue = useState(userProfile.city ?? '');
                final List<String> filtredValues = [];
                filtredValues.addAll(
                  regions
                      .where(
                        (element) => element.title.toLowerCase().contains(
                            filterValueNotifier.value.toLowerCase().trim()),
                      )
                      .map((e) => e.title)
                      .toList(),
                );
                return SizedBox(
                  height: MediaQuery.sizeOf(context).height - kToolbarHeight,
                  child: HomeAttributeDialog(
                    onPressed: () {
                      ref.saveModel<UserProfile>(
                        userProfile.copyWith(city: currentValue.value),
                      );
                      Navigator.of(context).pop();
                    },
                    child: FilterBottomSheet(
                      attribute: Attribute(
                        type: AttributeType.valuesDropdown,
                        id: 1,
                        values: regions.map((e) => e.title).toList(),
                        title: 'Город',
                      ),
                      body: SizedBox(
                        height: MediaQuery.sizeOf(context).height -
                            kToolbarHeight -
                            200,
                        child: ListView.builder(
                          itemCount: filtredValues.length,
                          shrinkWrap: true,
                          itemBuilder: (context, index) {
                            return HomeFilterDropDownRow(
                              attribute: Attribute(
                                type: AttributeType.valuesDropdown,
                                id: 1,
                                values: regions.map((e) => e.title).toList(),
                                title: 'Город',
                              ),
                              value: filtredValues[index],
                              values: filtredValues,
                              valueNotifier: currentValue,
                            );
                          },
                        ),
                      ),
                      onReset: () {
                        ref.saveModel<UserProfile>(
                          userProfile.copyWith(city: null),
                        );
                      },
                      filterValueNotifier: filterValueNotifier,
                    ),
                  ),
                );
              },
            );
          },
        );
      },

      // bottomSheetBuilder: () {
      //   state.cityController.text = state.user?.city ?? '';
      //   final regions = ref.watch(regionsProvider);
      //   final regionStrings =
      //       regions.map((e) => e.title).toList();
      //   return HomeAttributeDialog(
      //     onPressed: () {
      //       ref
      //           .read(profileSettingsStateProvider.notifier)
      //           .updateProfileCity();
      //       context.pop();
      //     },
      //     child: FilterBottomSheet(
      //       onReset: () async {
      //         state.cityController.text = '';
      //         await ref
      //             .read(profileSettingsStateProvider.notifier)
      //             .updateProfileCity();
      //       },
      //       attribute: Attribute(
      //         type: AttributeType.valuesDropdown,
      //         id: -1,
      //         values: regionStrings,
      //         title: 'Город',
      //       ),
      //       body: Builder(
      //         builder: (context) {
      //           final filterStr = ref
      //               .watch(dropDownFilterStringProvider(-1))
      //               .text
      //               .toLowerCase()
      //               .trim();

      //           final List<String> filtredList = [];
      //           filtredList.addAll(
      //             regionStrings.where(
      //               (element) => element
      //                   .toLowerCase()
      //                   .contains(filterStr),
      //             ),
      //           );
      //           return SizedBox(
      //             height: 300,
      //             child: ListView.builder(
      //               itemCount: filtredList.length,
      //               shrinkWrap: true,
      //               itemBuilder: (context, index) {
      //                 return HomeFilterDropDownRow(
      //                   attribute: Attribute(
      //                     id: -1,
      //                     values: filtredList,
      //                     type: AttributeType.regionsDropdown,
      //                     title: 'Город',
      //                   ),
      //                   value: filtredList[index],
      //                   values: filtredList,
      //                   textController: state.cityController,
      //                 );
      //               },
      //             ),
      //           );
      //         },
      //       ),
      //       userId: null,
      //     ),
      //   );
      // },
    );
  }
}
