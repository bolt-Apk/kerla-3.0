import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerla2_flutter/common/user_profile_ref_extensions.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_app/nit_app.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class EditUsernameButton extends ConsumerWidget {
  const EditUsernameButton({
    super.key,
    required this.userId,
  });

  final int userId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return ref.watchUserProfile(userId).nitWhen(
          childBuilder: (userProfile) => CommonButton(
            child: Text(
              '@${userProfile.userName}',
              style: Theme.of(context).textTheme.titleMedium,
            ),
            action: () => showModalBottomSheet<void>(
              isScrollControlled: true,
              shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.vertical(
                  top: Radius.circular(10),
                ),
              ),
              context: context,
              builder: (BuildContext context) {
                return Container(
                  margin: EdgeInsets.only(
                    bottom: MediaQuery.of(context).viewInsets.bottom,
                  ),
                  child: TextEditingBottomSheet(
                    initialValue: userProfile.userName ?? '',
                    title: 'Сменить имя пользователя',
                    keyboardType: TextInputType.multiline,
                    maxLength: 30,
                    acceptAction: (String newValue) async =>
                        null !=
                        await ref.saveModel(
                          userProfile.copyWith(userName: newValue),
                        ),
                  ),
                );
              },
            ),
          ),
        );
  }
}
