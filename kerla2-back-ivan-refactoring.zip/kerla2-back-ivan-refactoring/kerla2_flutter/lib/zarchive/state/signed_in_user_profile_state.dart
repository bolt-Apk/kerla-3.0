// import 'package:flutter_riverpod/flutter_riverpod.dart';
// import 'package:kerla2_client/kerla2_client.dart';
// import 'package:nit_app/nit_app.dart';
// import 'package:riverpod_annotation/riverpod_annotation.dart';

// import 'user_profile_state.dart';

// part 'signed_in_user_profile_state.g.dart';

// extension UserProfileRefExtension on Ref {
//   Future<UserGender?> get sessionGender async =>
//       (await watch(signedInUserProfileStateProvider.future))
//           ?.userProfile
//           .gender;
// }

// extension UserProfileWidgetRefExtension on WidgetRef {
//   Future<UserGender?> get sessionGender async =>
//       (await watch(signedInUserProfileStateProvider.future))
//           ?.userProfile
//           .gender;
// }

// @riverpod
// class SignedInUserProfileState extends _$SignedInUserProfileState {
//   @override
//   Future<UserProfileStateModel?> build() async {
//     return ref.signedIn
//         ? await ref.watch(userProfileStateProvider(ref.signedInUserId!).future)
//         : null;
//   }
// }
