/* AUTOMATICALLY GENERATED CODE DO NOT MODIFY */
/*   To generate run: "serverpod generate"    */

// ignore_for_file: implementation_imports
// ignore_for_file: library_private_types_in_public_api
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: public_member_api_docs
// ignore_for_file: type_literal_in_constant_pattern
// ignore_for_file: use_super_parameters

// ignore_for_file: no_leading_underscores_for_library_prefixes
import 'package:serverpod_client/serverpod_client.dart' as _i1;

enum KerlaColors implements _i1.SerializableModel {
  black,
  white,
  grey,
  red,
  blue,
  green,
  yellow,
  orange,
  brown,
  indigo,
  cyan,
  purple,
  teal,
  lime,
  pink;

  static KerlaColors fromJson(int index) {
    switch (index) {
      case 0:
        return black;
      case 1:
        return white;
      case 2:
        return grey;
      case 3:
        return red;
      case 4:
        return blue;
      case 5:
        return green;
      case 6:
        return yellow;
      case 7:
        return orange;
      case 8:
        return brown;
      case 9:
        return indigo;
      case 10:
        return cyan;
      case 11:
        return purple;
      case 12:
        return teal;
      case 13:
        return lime;
      case 14:
        return pink;
      default:
        throw ArgumentError(
            'Value "$index" cannot be converted to "KerlaColors"');
    }
  }

  @override
  int toJson() => index;
  @override
  String toString() => name;
}
