import 'dart:developer';

import 'package:collection/collection.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/app_buffer/home/filters/list_filter/attribute_filter/state/filter_attribute_state.dart';
import 'package:kerla2_flutter/app_buffer/home/widgets/home_app_bar/search/providers.dart';
import 'package:kerla2_flutter/app_buffer/profile/user_profile/widgets/sort/state/ad_sort_state.dart';
import 'package:kerla2_flutter/common/user_profile_ref_extensions.dart';
import 'package:kerla2_flutter/core/core.dart';
import 'package:kerla2_flutter/core/view_session_id.dart';
import 'package:nit_app/nit_app.dart';
// import 'package:onesignal_flutter/onesignal_flutter.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';

part 'ad_list_state.freezed.dart';
part 'ad_list_state.g.dart';

// @freezed
// class AdData with _$AdData {
//   const factory AdData({
//     List<Ad>? ads,
//     @Default(0) int page,
//     @Default(true) bool hasMore,
//   }) = _AdData;
// }

//TODO: transit to crud_config
@riverpod
Future<Ad?> getAdById(Ref ref, int? adId) async {
  if (adId == null) {
    return null;
  }
  final sessionId = ref.read(viewSessionIdProvider);
  if (sessionId != const UuidValue.fromNamespace(Namespace.nil)) {
    client.ad.updateAdCounts(false, adId, sessionId.uuid);
  }
  // ref.cacheFor(const Duration(minutes: 5));
  final res = await ref.watchModelCustom<Ad>(
    backendFilter: NitBackendFilter.value(
      type: NitBackendFilterType.equals,
      fieldValue: adId,
      fieldName: 'id',
    ),
  );
  return res;
}

@Riverpod(keepAlive: false)
class AdListState extends _$AdListState {
  static const int _limit = 10;
  String? searchTerm;

  @override
  AdListData build(GetAdParam params) {
    final PagingController<int, Ad> controller =
        PagingController(firstPageKey: 0);

    ref.onDispose(() {
      log('adlist state disposing ${params.adListType}');
      controller.dispose();
    });

    controller.addPageRequestListener((pageKey) async {
      log('adlist state fetching page $pageKey for ${params.adListType}');
      await _fetchPage(pageKey, params);
    });

    log('building adlist ${params.adListType}');

    ref.listen(filterStateProvider(params.adListType), (previous, next) {
      if (previous != next) {
        refreshState();
      }
    });
    ref.listen(nitSessionStateProvider.select((s) => s.signedInUserId),
        (previous, next) {
      if (previous != next) {
        refreshState();
      }
    });

    ref.listen(isSubscribedAds, (previous, next) {
      if (previous != next) {
        refreshState();
      }
    });

    if (params.adListType == AdListType.profile) {
      ref.listen(adSortProvider(params.id), (previous, next) {
        refreshState();
      });
    }
    if (params.adListType == AdListType.main) {
      ref.keepAlive();
    }

    return AdListData(controller: controller, pageKey: 0);
  }

  void refreshState() {
    log('refreshing adlist ${params.adListType}');
    state = state.copyWith(turboAd: null);
    // state.controller.refresh();
    state.controller.refresh();
  }

  Future<void> _fetchPage(
    int pageKey,
    GetAdParam params,
  ) async {
    try {
      List<Ad> newItems;
      if (params.adListType == AdListType.similarAd) {
        newItems = await client.ad.getAds(
          limit: 10,
          page: 0,
          adType: AdType.ad,
          adOrderBy: AdOrderBy.random,
          categoryIds: [params.id!],
          getSubscribedAds: false,
          gender: ref.readCurrentUserProfile?.gender,
          adListType: params.adListType,
          excludeAdIds: [params.currentAdId!],
        );
      } else if (params.adListType == AdListType.profile) {
        newItems = await getMoreAds(
          pageKey: pageKey,
          adListType: params.adListType,
          userId: params.id,
        );
      } else {
        newItems = await getMoreAds(
          pageKey: pageKey,
          adListType: params.adListType,
          isRand: true,
        );
      }

      // if (params.adListType == AdListType.similarAd) {
      //   newItems.removeWhere((element) => element.id == params.id);
      // }

      if (params.adListType == AdListType.main) {
        final turboAd = newItems.firstWhereOrNull((element) =>
            element.promotions?.firstWhereOrNull(
                (element) => element.type == KerlaServiceType.turbo) !=
            null);
        if (turboAd != null) {
          newItems.removeWhere((element) => element.id == turboAd.id);
          state = state.copyWith(turboAd: turboAd);
        }
      }

      final isLastPage = newItems.isEmpty;
      // log(newItems.length.toString());
      if (isLastPage || params.adListType == AdListType.similarAd) {
        state.controller.appendLastPage(newItems);
      } else {
        state.controller.appendPage(newItems, pageKey + 1);
      }
    } catch (error) {
      state.controller.error = error;
      log(error.toString());
    }
    state = state;
  }

  Future<List<Ad>> getMoreAds({
    int? userId,
    // required bool? isProfilePage,
    required int pageKey,
    required AdListType adListType,
    bool isRand = false,
    // bool isPromotedAds = false,
  }) async {
    final filterState = ref.read(filterStateProvider(adListType));

    final AdCategory? category = filterState.category;

    final List<int> categoryIds = _getAllCategoryIds(category);

    final attributes =
        ref.read(filterStateProvider(adListType).notifier).convertAttributes();

    final getSubscribedAds =
        adListType == AdListType.main && ref.read(isSubscribedAds) == true;

    final AdOrderBy orderBy = ref.read(adSortProvider(userId));
    // final AdOrderBy orderBy = ref.watch(adSortProvider);
    // final orderBy = ref.watch(adSortProvider);

    final List<int> excludeAdIds = [
      ...state.controller.itemList?.map((e) => e.id).nonNulls.toList() ?? [],
    ];
    if (state.turboAd?.id != null) {
      excludeAdIds.add(state.turboAd!.id!);
    }

    final nextPage = await client.ad.getAds(
      userId: userId,
      limit: _limit,
      page: pageKey,
      // isPromotedAds: isPromotedAds,
      categoryIds: categoryIds,
      searchQuery: filterState.searchQuery,
      attributes: attributes,
      adType: AdType.ad,
      adOrderBy: isRand ? null : orderBy,
      getSubscribedAds: getSubscribedAds,
      gender: ref.readCurrentUserProfile?.gender,
      adListType: adListType,
      excludeAdIds: excludeAdIds,
    );

    // if (isPromotedAds) {
    //   var rng = Random();
    //   nextPage.shuffle(rng);
    //   final qweqwe = nextPage;
    //   return qweqwe;
    // }

    return nextPage;
  }

  // Recursive function to get all category IDs including children
  List<int> _getAllCategoryIds(AdCategory? category) {
    if (category == null) return [];
    List<int> ids = [category.id!];
    if (category.children != null) {
      for (var child in category.children!) {
        ids.addAll(_getAllCategoryIds(child));
      }
    }
    return ids;
  }
}

@freezed
class AdListData with _$AdListData {
  const factory AdListData({
    required PagingController<int, Ad> controller,
    Ad? turboAd,
    @Default(0) int pageKey,
  }) = _AdListData;
}

@freezed
class GetAdParam with _$GetAdParam {
  const factory GetAdParam({
    required AdListType adListType,
    int? id,
    int? currentAdId,
  }) = _GetAdParam;
}
