part of '../ui_kit.dart';

class AppImages {
  AppImages._();

  static const String profileBackground =
      'assets/images/profile_background.jpg';
}
