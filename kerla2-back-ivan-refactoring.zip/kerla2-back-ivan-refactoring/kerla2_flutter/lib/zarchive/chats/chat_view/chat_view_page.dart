// import 'package:cached_network_image/cached_network_image.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_riverpod/flutter_riverpod.dart';
// import 'package:kerla2_client/kerla2_client.dart';
// import 'package:kerla2_flutter/app_old/chats/state/chat_controller_state.dart'
//     as chat_controller_state;
// import 'package:kerla2_flutter/router/router.dart';
// import 'package:kerla2_flutter/state/ad/ad_state.dart';
// import 'package:nit_app/nit_app.dart';
// import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
// import 'package:nit_ui_kit/nit_ui_kit.dart';
// import 'package:kerla2_flutter/ui/widgets/ad/ad_price.dart';
// import 'package:nit_router/nit_router.dart';
// import 'package:serverpod_chat_flutter/serverpod_chat_flutter.dart';

// import '../state/chat_list_state.dart';

// class ChatViewPage extends ConsumerStatefulWidget {
//   const ChatViewPage({super.key});

//   @override
//   ConsumerState<ConsumerStatefulWidget> createState() => _ChatViewPageState();
// }

// class _ChatViewPageState extends ConsumerState<ChatViewPage> {
//   Widget adHeader(BuildContext context, ChannelInfo channel, WidgetRef ref) {
//     return InkWell(
//       onTap: () async {
//         final currentContext = context; // Capture the context
//         FocusScope.of(context).unfocus();
//         if (channel.ad?.media?.first.type == MediaType) {
//           return;
//         }
//         if (channel.adId != null) {
//           if (context.mounted) {
//             currentContext.pushNamed(
//               AdNavigationZone.adPage.name,
//               pathParameters: AppNavigationParams.adId.set(adId!),
//               extra: channel.ad,
//             );
//           }
//         } else {
//           debugPrint("adasdasdasdasdas");
//         }
//       },
//       child: Column(
//         mainAxisSize: MainAxisSize.min,
//         children: [
//           const Divider(
//             thickness: 0.3,
//           ),
//           Container(
//             height: 105,
//             color: context.theme.canvasColor,
//             padding: const EdgeInsets.all(12),
//             child: Row(
//               children: [
//                 if (channel.ad?.media?.first.publicUrl != null &&
//                     channel.ad?.media?.first.type == MediaType.image)
//                   ClipRRect(
//                     borderRadius: BorderRadius.circular(8.0),
//                     child: CachedNetworkImage(
//                       imageUrl: channel.ad?.media?.first.publicUrl ?? '',
//                       fit: BoxFit.fitWidth,
//                       width: 80,
//                     ),
//                   ),
//                 const SizedBox(
//                   width: 12,
//                 ),
//                 Flexible(
//                   child: Column(
//                     // mainAxisAlignment:
//                     //     MainAxisAlignment.spaceBetween,
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       Text(
//                         '${channel.ad?.title}',
//                         style: context.textTheme.bodyMedium,
//                         overflow: TextOverflow.ellipsis,
//                         maxLines: 2,
//                       ),
//                       Text(
//                         channel.ad?.price.priceFormat() ?? '',
//                         style: context.textTheme.headlineLarge?.copyWith(
//                           fontWeight: FontWeight.bold,
//                         ),
//                       ),
//                     ],
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ],
//       ),
//     );
//   }

//   @override
//   void dispose() {
//     // ref.invalidate(startChatProvider(chatWithId, adId, channelId));
//     // if (channel != null) {
//     //   ref.invalidate(chatControllerStateProvider(channel!));
//     // }
//     // print('123123');
//     super.dispose();
//   }

//   int? adId;
//   int? chatWithId;
//   int? channelId;
//   String? channel;
//   ChannelInfo? savedChannelInfo;

//   @override
//   Widget build(BuildContext context) {
//     // final params = ref.watch(navigationPathParametersProvider);

//     adId = ref.watchNavigationParam(AppNavigationParams.adId);
//     chatWithId = ref.watchNavigationParam(AppNavigationParams.userId);
//     channelId = ref.watchNavigationParam(AppNavigationParams.channelId);
//     final isReady = true;

//     // ref.watch(
//     //   nitSessionStateProvider.select(
//     //     (s) => s.websocketStatus == StreamingConnectionStatus.connected,
//     //   ),
//     // );

//     final theme = Theme.of(context);

//     return PopScope(
//       onPopInvoked: (didPop) {
//         ScaffoldMessenger.of(context).hideCurrentSnackBar();
//       },
//       child: Scaffold(
//         appBar: (!isReady && savedChannelInfo == null)
//             ? AppBar(backgroundColor: theme.scaffoldBackgroundColor)
//             : null,
//         backgroundColor: theme.scaffoldBackgroundColor,
//         bottomNavigationBar: AnimatedContainer(
//           duration: const Duration(milliseconds: 300),
//           curve: Curves.easeInOut,
//           color: ThemePrimaryColors.primary,
//           height: isReady ? 0 : 60,
//           child: const Center(
//             child: Text(
//               "Нет соединения с сервером",
//               style: TextStyle(color: Colors.white),
//             ),
//           ),
//         ),
//         body: ref.watch(startChatProvider(chatWithId, adId, channelId)).when(
//               skipLoadingOnReload: true,
//               data: (channelInfo) {
//                 return Builder(
//                   builder: (context) {
//                     if (channelInfo != null) {
//                       savedChannelInfo = channelInfo;
//                     }

//                     ref.watch(chat_controller_state
//                         .chatControllerStateProvider(savedChannelInfo!.channel)
//                         .select((s) => s.isLoading));

//                     final controllerState = ref.read(
//                         chat_controller_state.chatControllerStateProvider(
//                             savedChannelInfo!.channel));
//                     channel = savedChannelInfo!.channel;

//                     return controllerState.when(
//                       skipLoadingOnReload: true,
//                       data: (data) {
//                         // ref
//                         //     .watch(
//                         //         startChatProvider(chatWithId, adId, channelId))
//                         //     .isReloading;
//                         return ChatViewWidget(
//                           serverpodController: data.controller,
//                           chatWithUserInfo: savedChannelInfo!.chatWith!,
//                           onTitleTap: () {
//                             context.pushNamed(
//                               MainAreaNavigationZone.user.name,
//                               pathParameters: {
//                                 'id': savedChannelInfo!.chatWith!.id.toString(),
//                               },
//                             );
//                           },
//                           appBarBottomWidget: adId != null
//                               ? adHeader(context, savedChannelInfo!, ref)
//                               : null,
//                           getCustomModelViewFunction: (int adId) async {
//                             final ad =
//                                 await ref.read(getAdByIdProvider(adId).future);
//                             if (ad == null) return null;

//                             return ChatCustomMessageModel(
//                               title: ad.title,
//                               imageUrl: ad.media!.first.publicUrl,
//                               price: ad.price,
//                               onTap: () {
//                                 context.pushNamed(
//                                   AdNavigationZone.adPage.name,
//                                   pathParameters:
//                                       AppNavigationParams.adId.set(ad.id!),
//                                 );
//                               },
//                               titleTextStyle: context.textTheme.bodyMedium,
//                               priceTextStyle:
//                                   context.textTheme.headlineLarge?.copyWith(
//                                 fontWeight: FontWeight.bold,
//                               ),
//                             );
//                           },
//                         );
//                       },
//                       error: (Object error, StackTrace stackTrace) {
//                         return Scaffold(
//                           appBar: AppBar(),
//                           body: Center(
//                             child: Text(error.toString()),
//                           ),
//                         );
//                       },
//                       loading: () {
//                         return Container();
//                       },
//                     );
//                   },
//                 );
//               },
//               error: (Object error, StackTrace stackTrace) {
//                 return Scaffold(
//                   appBar: AppBar(),
//                 );
//               },
//               loading: () => const Center(
//                 child: CircularProgressIndicator(),
//               ),
//             ),
//       ),
//     );
//   }
// }
