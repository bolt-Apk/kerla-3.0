import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/core/core.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';

part 'categories_provider.g.dart';

// final categoriesProvider = Provider((ref) => AppSources.instance.categories);

@riverpod
Future<List<AdCategory>> profileAdCategories(
  ProfileAdCategoriesRef ref,
  int userId,
) async {
  final res = await client.adCategory.getAdCategoriesForProfile(userId);
  return res;
}
