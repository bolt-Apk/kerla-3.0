import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kerla2_flutter/common/user_profile_extension.dart';
import 'package:kerla2_flutter/common/user_profile_ref_extensions.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class BackgroundImageWidget extends ConsumerWidget {
  const BackgroundImageWidget({
    super.key,
    required this.userId,
  });

  final int userId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return ref.watchUserProfileCustom(userId).nitWhen(
      childBuilder: (userProfile) {
        return userProfile.backgroundImageUrl != null &&
                userProfile.isBusiness(ref)
            ? CachedNetworkImage(
                imageUrl: userProfile.backgroundImageUrl!,
                fit: BoxFit.cover,
              )
            : DecoratedBox(
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.2),
                ),
                child: Image.asset(
                  AppImages.profileBackground,
                  fit: BoxFit.cover,
                ),
              );
      },
    );
  }
}
