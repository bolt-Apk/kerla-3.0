// import 'package:flutter_riverpod/flutter_riverpod.dart';
// import 'package:serverpod_auth_client/module.dart';

// import 'app_session_state.dart';

// extension AppSessionStateExtension on WidgetRef {
//   UserInfo? get signedInUser => watch(appSessionStateProvider).signedInUser;
// }

// extension AppSessionStateRefExtension on Ref {
//   UserInfo? get signedInUser => watch(appSessionStateProvider).signedInUser;
// }

// extension AppUserInfoExtension on UserInfo {
//   bool get isAdminGetter {
//     return scopeNames.contains('serverpod.admin');
//   }
// }
