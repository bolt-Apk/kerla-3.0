import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerla2_flutter/app/favorites/widgets/favorites_list_view.dart';
import 'package:kerla2_flutter/core/app_scaffold.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class FavoritePage extends ConsumerWidget {
  const FavoritePage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return AppScaffold(
      backgroundColor: context.theme.scaffoldBackgroundColor,
      // extendBodyBehindAppBar: true,
      appBar: AppBar(
        titleSpacing: 0,
        leading: BackButton(
          color: context.theme.iconTheme.color,
        ),
        backgroundColor: context.theme.canvasColor,
        title: Text(
          'Избранное',
          style: context.textTheme.headlineMedium,
        ),
      ),
      body: SingleChildScrollView(
        child: DecoratedBox(
          decoration: BoxDecoration(
            color: context.theme.scaffoldBackgroundColor,
          ),
          child: const FavoritesListView(),
        ),
      ),
    );
  }
}
