/* AUTOMATICALLY GENERATED CODE DO NOT MODIFY */
/*   To generate run: "serverpod generate"    */

// ignore_for_file: implementation_imports
// ignore_for_file: library_private_types_in_public_api
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: public_member_api_docs
// ignore_for_file: type_literal_in_constant_pattern
// ignore_for_file: use_super_parameters

// ignore_for_file: no_leading_underscores_for_library_prefixes
import 'package:serverpod_client/serverpod_client.dart' as _i1;
import '../protocol.dart' as _i2;

/// Users notification permission
abstract class NotificationPermission implements _i1.SerializableModel {
  NotificationPermission._({
    this.id,
    required this.userId,
    required this.permissionList,
  });

  factory NotificationPermission({
    int? id,
    required int userId,
    required List<_i2.NotificationPermissionType> permissionList,
  }) = _NotificationPermissionImpl;

  factory NotificationPermission.fromJson(
      Map<String, dynamic> jsonSerialization) {
    return NotificationPermission(
      id: jsonSerialization['id'] as int?,
      userId: jsonSerialization['userId'] as int,
      permissionList: (jsonSerialization['permissionList'] as List)
          .map((e) => _i2.NotificationPermissionType.fromJson((e as int)))
          .toList(),
    );
  }

  /// The database id, set if the object has been inserted into the
  /// database or if it has been fetched from the database. Otherwise,
  /// the id will be null.
  int? id;

  int userId;

  List<_i2.NotificationPermissionType> permissionList;

  NotificationPermission copyWith({
    int? id,
    int? userId,
    List<_i2.NotificationPermissionType>? permissionList,
  });
  @override
  Map<String, dynamic> toJson() {
    return {
      if (id != null) 'id': id,
      'userId': userId,
      'permissionList': permissionList.toJson(valueToJson: (v) => v.toJson()),
    };
  }

  @override
  String toString() {
    return _i1.SerializationManager.encode(this);
  }
}

class _Undefined {}

class _NotificationPermissionImpl extends NotificationPermission {
  _NotificationPermissionImpl({
    int? id,
    required int userId,
    required List<_i2.NotificationPermissionType> permissionList,
  }) : super._(
          id: id,
          userId: userId,
          permissionList: permissionList,
        );

  @override
  NotificationPermission copyWith({
    Object? id = _Undefined,
    int? userId,
    List<_i2.NotificationPermissionType>? permissionList,
  }) {
    return NotificationPermission(
      id: id is int? ? id : this.id,
      userId: userId ?? this.userId,
      permissionList:
          permissionList ?? this.permissionList.map((e0) => e0).toList(),
    );
  }
}
