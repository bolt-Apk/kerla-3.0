import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/core/app_backend_filters.dart';
import 'package:nit_app/nit_app.dart';

extension BusinessExtension on WidgetRef {
  DateTime? businessEndsAt(int userId) {
    return watchEntityListAsync<KerlaService>(
      backendFilter: NitBackendFilter.and([
        AppBackendFilter.userId.equals(userId),
        AppBackendFilter.type.equals(
          KerlaServiceType.businessProfile,
        ),
        AppBackendFilter.isApproved.equals(true),
        // AppBackendFilter.endsAt.greaterThanOrEquals(
        //   DateTime.now(),
        // ),
      ]),
    ).whenData((data) {
      debugPrint(data.toString());
      return data.firstOrNull?.endsAt;
    }).valueOrNull;
  }
}
