import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/app_buffer/home/stories/story_view/widgets/story_item.dart';
import 'package:story_view/story_view.dart' as story_view;

class StoryViewer extends HookConsumerWidget {
  const StoryViewer({
    super.key,
    required this.users,
    this.initialIndex = 0,
    this.singleStoryId, // Add optional initialStoryId parameter
  });

  final List<UserProfile> users;
  final int initialIndex;
  final int? singleStoryId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final pageController = usePageController(initialPage: initialIndex);
    final storyController = useMemoized(() => story_view.StoryController());

    useEffect(() {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        pageController.jumpToPage(initialIndex);
      });
      return () {
        storyController.dispose();
      };
    }, const []);

    return PopScope(
      canPop: false,
      child: Scaffold(
        backgroundColor: Colors.black,
        body: PageView.builder(
          controller: pageController,
          itemCount: users.length,
          itemBuilder: (context, index) {
            final user = users[index];
            return UserStoryItem(
              key: ValueKey(user.userId),
              user: user,
              storyController: storyController,
              onNextPage: () {
                if (pageController.page == users.length - 1) {
                  context.pop();
                  return;
                }
                pageController.nextPage(
                  duration: const Duration(milliseconds: 300),
                  curve: Curves.easeInOut,
                );
              },
              onPreviousPage: () {
                pageController.previousPage(
                  duration: const Duration(milliseconds: 300),
                  curve: Curves.easeInOut,
                );
              },
              singleStoryId: singleStoryId,
            );
          },
        ),
      ),
    );
  }
}
