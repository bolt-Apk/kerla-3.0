import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerla2_flutter/auth/state/auth_page_state.dart';
import 'package:nit_app/nit_app.dart';

import '../../ui_kit/ui_kit.dart';

class EmailInputWidget extends ConsumerWidget {
  const EmailInputWidget({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(authPageStateProvider);
    return TextEntryField.email(
      autofillHints: const [AutofillHints.username],
      controller: state.emailController,
      readOnly: ref.signedIn,
      validator: (email) {
        if (email == null || email.isEmpty) {
          return 'Почта не может быть пустой';
        }
        if (!RegExp(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')
            .hasMatch(email)) {
          return 'Неверный формат почты';
        }
        log(email, name: 'validator');
        return null;
      },
      label: 'Email',
    );
  }
}
