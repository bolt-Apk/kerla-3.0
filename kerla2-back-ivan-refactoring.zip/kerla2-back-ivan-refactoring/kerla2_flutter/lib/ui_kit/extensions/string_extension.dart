part of '../ui_kit.dart';

extension Emoji on String {
  String get emoji => ' $this ';
}

extension PhoneExtension on String {
  String? get unmaskPhone {
    String str = replaceAll('+', '')
        .replaceAll('(', '')
        .replaceAll(')', '')
        .replaceAll('-', '')
        .replaceAll(' ', '');

    return str.length == 11 ? str : null;
  }

  // Применение маски к номеру телефона
  String? get maskedPhone => length == 11
      ? "+7 (${substring(1, 4)}) "
          "${substring(4, 7)}-${substring(7, 9)}-"
          "${substring(9)}"
      : null;

  bool get isValidPhone {
    return startsWith('7') && length == 11;
  }
}

extension FormatNumber on String? {
  String formatNumber() {
    if (this == null) {
      return '';
    }
    // Проверяем, является ли строка числом
    if (int.tryParse(this!) != null) {
      // Форматируем число с разделителями тысяч, используя пробел
      var formatter = intl.NumberFormat('#,###', 'ru_RU');
      return formatter.format(int.parse(this!));
    } else {
      // Если строка не является числом, возвращаем её без изменений
      return this!;
    }
  }
}
