import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kerla2_flutter/app_buffer/home/widgets/home_app_bar/home_app_bar.dart';
import 'package:kerla2_flutter/core/app_scaffold.dart';
import 'package:nit_app/nit_app.dart';
import '../home_body.dart';

class HomePage extends HookConsumerWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    useEffect(() {
      WidgetsBinding.instance.addPostFrameCallback((_) async {
        ref
            .read(firebaseNotificationServiceProvider.notifier)
            .handleTerminatedMessage();
      });
      return () {};
    }, []);
    return const AppScaffold(
      appBar: HomeAppBar(),
      body: HomeBody(),
    );
  }
}
