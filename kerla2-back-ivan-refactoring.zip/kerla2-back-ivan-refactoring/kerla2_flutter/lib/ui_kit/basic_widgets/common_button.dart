part of '../ui_kit.dart';

class CommonButton extends StatelessWidget {
  const CommonButton({
    super.key,
    required this.child,
    this.backgroundColor = Colors.transparent,
    this.buttonContainerWidth,
    this.margin,
    this.action,
    this.borderRadius,
    this.width,
    this.height,
  });

  final Function()? action;
  final Widget child;
  final BorderRadius? borderRadius;
  final Color backgroundColor;
  final double? width;
  final double? height;
  final EdgeInsetsGeometry? margin;
  final double? buttonContainerWidth;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: height,
      width: width,
      child: Material(
        color: backgroundColor,
        borderOnForeground: false,
        borderRadius: borderRadius,
        child: InkWell(
          borderRadius: borderRadius,
          onTap: action,
          child: child,
        ),
      ),
    );
  }
}
