import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/router/router.dart';
import 'package:nit_router/nit_router.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class AdMessage extends ConsumerWidget {
  const AdMessage({
    super.key,
    required this.ad,
  });
  final Ad ad;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final imageUrl = ad.media?.firstOrNull?.publicUrl;

    return InkWell(
      onTap: () => context.pushNamed(
        AdNavigationZone.adPage.name,
        pathParameters: AppNavigationParams.adId.set(ad.id!),
      ),
      child: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 8,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: SizedBox(
                height: 160,
                child: imageUrl != null
                    ? CachedNetworkImage(
                        imageUrl: imageUrl,
                        width: double.infinity,
                        fit: BoxFit.cover,
                        placeholder: (context, url) => Container(
                          color: Colors.grey[200],
                          child: const Center(
                              child: CircularProgressIndicator(strokeWidth: 2)),
                        ),
                        errorWidget: (context, url, error) => Container(
                          color: Colors.grey[200],
                          child: const Icon(Icons.broken_image,
                              size: 48, color: Colors.grey),
                        ),
                      )
                    : Container(
                        width: double.infinity,
                        color: Colors.grey[200],
                        child: const Icon(Icons.image,
                            size: 48, color: Colors.grey),
                      ),
              ),
            ),
            const SizedBox(height: 8),
            Text(
              ad.title,
              style: context.textTheme.bodyMedium,
            ),
            const SizedBox(height: 4),
            Text(
              '${ad.price} ₽',
              style: context.theme.textTheme.bodyMedium?.copyWith(
                color: context.theme.colorScheme.primary,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
