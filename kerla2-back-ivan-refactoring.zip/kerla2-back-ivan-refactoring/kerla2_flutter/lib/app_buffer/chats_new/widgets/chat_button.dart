import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kerla2_flutter/app_buffer/chats_new/widgets/chat_list_card.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:kerla2_shared/kerla2_shared.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class ChatButton extends ConsumerWidget {
  const ChatButton({
    super.key,
    required this.userId,
    required this.chatChannelType,
    this.adId,
  })  : wrapInCommonButton = false,
        wrapInFloatingActionButton = false,
        size = 25,
        secondChildColor = null;

  const ChatButton.wrappedInCommonButton({
    super.key,
    required this.userId,
    required this.chatChannelType,
    this.adId,
  })  : wrapInCommonButton = true,
        wrapInFloatingActionButton = false,
        size = 25,
        secondChildColor = null;

  const ChatButton.wrappedInFloatingActionButton({
    super.key,
    required this.userId,
    required this.chatChannelType,
    this.adId,
  })  : wrapInCommonButton = false,
        wrapInFloatingActionButton = true,
        size = 25,
        secondChildColor = null;

  final int userId;

  final ChatChannelType chatChannelType;
  final int? adId;

  final double? size;
  final bool wrapInCommonButton;
  final bool wrapInFloatingActionButton;

  final Color? secondChildColor;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    if (chatChannelType == ChatChannelType.ad && adId == null) {
      return const SizedBox.shrink();
    }
    void onPressed() async {
      final channelId = chatChannelType == ChatChannelType.personal
          ? await ref.getPersonalChannel(userId)
          : await ref.getAdChannel(adId!, userId);
      if (channelId != null && context.mounted) {
        context.goToChatByChannelId(channelId: channelId);
      }
    }

    return wrapInFloatingActionButton
        ? FloatingActionButton(
            heroTag: '1',
            backgroundColor: Theme.of(context).scaffoldBackgroundColor,
            mini: true,
            onPressed: onPressed,
            child: SvgPicture.asset(
              AppIconsSvg.chats,
              height: 20,
              width: 20,
              colorFilter: ColorFilter.mode(
                Theme.of(context).iconTheme.color!,
                BlendMode.srcIn,
              ),
            ),
          )
        : IconButton(
            onPressed: onPressed,
            icon: SvgPicture.asset(
              AppIconsSvg.chats,
              colorFilter: ColorFilter.mode(
                context.theme.iconTheme.color!,
                BlendMode.srcIn,
              ),
            ),
          );
  }
}
