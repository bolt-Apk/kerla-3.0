import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

import '../state/auth_mode_enum.dart';
import '../state/auth_page_state.dart';

class AuthHeaderWidget extends ConsumerWidget {
  const AuthHeaderWidget({
    super.key,
    required this.mode,
  });

  final AuthModeEnum mode;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.read(authPageStateProvider);
    return SizedBox(
      height: 50,
      child: Stack(
        children: [
          if (state.pastPart != null)
            Align(
              alignment: Alignment.centerLeft,
              child: BackButton(
                onPressed: () => ref
                    .read(authPageStateProvider.notifier)
                    .setPage(state.pastPart!),
              ),
            ),
          Center(
            child: Text(
              switch (mode) {
                AuthModeEnum.signIn => 'Вход',
                AuthModeEnum.registration ||
                AuthModeEnum.oauth =>
                  'Регистрация',
                AuthModeEnum.recover => 'Восстановление пароля',
                // AuthModeEnum.change => 'Изменение пароля',
                // TODO: Handle this case.
              },
              style: context.textTheme.titleLarge,
            ),
          ),
        ],
      ),
    );
  }
}
