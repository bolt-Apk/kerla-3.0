import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_svg/svg.dart';
import 'package:go_router/go_router.dart';
import 'package:kerla2_flutter/common/user_profile_ref_extensions.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class ShowPhoneIcon extends ConsumerWidget {
  const ShowPhoneIcon({
    super.key,
    required this.userId,
  });

  final int userId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return ref.watchUserProfile(userId).nitWhen(
      childBuilder: (userProfile) {
        if (userProfile.phoneNumber == null || userProfile.showPhone != true) {
          return const SizedBox.shrink();
        }
        return IconButton(
          visualDensity: VisualDensity.compact,
          icon: SvgPicture.asset(
            AppIconsSvg.phone,
            height: 20,
            width: 20,
            colorFilter: ColorFilter.mode(
              context.theme.iconTheme.color ?? Colors.black,
              BlendMode.srcIn,
            ),
          ),
          onPressed: () {
            showDialog(
              context: context,
              builder: (context) {
                return Dialog(
                  child: Container(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        InkWell(
                          onTap: () => {
                            Clipboard.setData(
                              ClipboardData(
                                text: userProfile.phoneNumber!,
                              ),
                            ),
                            context.pop(),
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text(
                                  'Номер телефона скопирован',
                                ),
                              ),
                            ),
                          },
                          child: Text(
                            userProfile.phoneNumber!.maskedPhone!,
                            style: context.textTheme.headlineMedium,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            );
          },
        );
      },
    );
  }
}
