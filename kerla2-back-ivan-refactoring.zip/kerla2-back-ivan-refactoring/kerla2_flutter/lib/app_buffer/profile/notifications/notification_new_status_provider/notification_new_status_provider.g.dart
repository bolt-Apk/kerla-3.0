// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'notification_new_status_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$notificationNewStatusHash() =>
    r'33607800ce857901255ca18665cee3293fbc09df';

/// See also [notificationNewStatus].
@ProviderFor(notificationNewStatus)
final notificationNewStatusProvider = AutoDisposeProvider<int>.internal(
  notificationNewStatus,
  name: r'notificationNewStatusProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$notificationNewStatusHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef NotificationNewStatusRef = AutoDisposeProviderRef<int>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
