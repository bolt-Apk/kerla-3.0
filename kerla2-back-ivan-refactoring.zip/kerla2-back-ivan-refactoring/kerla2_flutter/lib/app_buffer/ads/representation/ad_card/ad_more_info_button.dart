import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/app_buffer/ads/utils/ad_share.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_app/nit_app.dart';
import 'package:nit_router/nit_router.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

import '../../../profile/categories/state/categories_provider.dart';
import '../ad_list/state/ad_list_state.dart';
import 'report_ad.dart';

class AdMoreInfoButton extends ConsumerWidget {
  const AdMoreInfoButton({
    super.key,
    required this.ad,
    this.icon = Icons.more_horiz,
    this.size = 20,
  });
  final Ad ad;
  final IconData icon;
  final double? size;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final userId = ref.signedInUserId;
    final isOwner = ad.userId == userId;

    return CommonButton(
      borderRadius: BorderRadius.circular(5),
      buttonContainerWidth: 25,
      child: Icon(
        icon,
        size: size,
        color: context.theme.iconTheme.color,
      ),
      action: () {
        showModalBottomSheet<void>(
          context: context,
          builder: (BuildContext context) {
            return MainBottomSheet(
              color: context.colorScheme.surface,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  const LittleDivider(),
                  const Divider(
                    height: 1,
                  ),
                  // if (ref.readSession.isAdminGetter)
                  //   NavigationButton(
                  //     buttonText: ad.status == AdStatus.active
                  //         ? "Заблокировать"
                  //         : "Разблокировать",
                  //     imageAsset: AppIconsSvg.warning,
                  //     onTap: () async {
                  //       await ref.readSession.client.admin
                  //           .changeAdBlockStatus(ad.id!);
                  //       ref.invalidate(adListStateProvider);
                  //       if (context.mounted) {
                  //         context.goNamed(MainAreaNavigationZone.homePage.name);
                  //       }
                  //     },
                  //     alignment: Alignment.center,
                  //     imageSize: 20,
                  //     fontSize: 16,
                  //     fontColor: Colors.red,
                  //   ),
                  NavigationButton(
                    buttonText: "Поделиться",
                    imageAsset: AppIconsSvg.upload,
                    fontColor: context.theme.iconTheme.color ?? Colors.black,
                    imageColor: context.theme.iconTheme.color,
                    onTap: () => AdShareState(context, ad.id!)
                        .showGeneralShareBottomSheet(),
                    alignment: Alignment.center,
                    imageSize: 20,
                    fontSize: 16,
                  ),
                  const Divider(
                    height: 1,
                  ),
                  NavigationButton(
                    buttonText: "Пожаловаться",
                    imageAsset: AppIconsSvg.warning,
                    onTap: () {
                      showModalBottomSheet(
                        context: context,
                        isScrollControlled: true,
                        builder: (BuildContext context) {
                          return ReportAdWidget(adId: ad.id!);
                        },
                      );
                    },
                    alignment: Alignment.center,
                    imageSize: 20,
                    fontSize: 16,
                    fontColor: Colors.red,
                  ),
                  if (isOwner) const Divider(height: 1),
                  if (isOwner)
                    NavigationButton(
                      buttonText: "Удалить",
                      imageAsset: AppIconsSvg.delete,
                      onTap: () async {
                        await ref.deleteModel<Ad>(ad);

                        if (context.mounted && context.canPop()) {
                          ref.invalidate(
                            adListStateProvider(
                              GetAdParam(
                                adListType: AdListType.profile,
                                id: userId,
                              ),
                            ),
                          );
                          // ref.invalidate(userProvider);
                          ref.invalidate(profileAdCategoriesProvider);
                          // ref.invalidate(
                          //   homeFiltersStateProvider(isProfile: true),
                          // );

                          context.pop();
                        }
                      },
                      alignment: Alignment.center,
                      imageSize: 20,
                      fontSize: 16,
                      fontColor: Colors.red,
                    ),
                  const SizedBox(height: 20),
                ],
              ),
            );
          },
        );
      },
    );
  }
}
