part of '../router.dart';

enum AdNavigationZone implements NavigationZoneRoute {
  createAd(
    SimpleNavigationRouteDescriptor(
      page: CreateAdPage(),
    ),
  ),

  chooseCategoryCreateAd(
    SimpleNavigationRouteDescriptor(
      page: ChooseCategoryPage(adType: AdType.ad),
    ),
  ),
  chooseAttribute(
    SimpleNavigationRouteDescriptor(
      page: ChooseAttributePage(),
      parent: chooseCategoryCreateAd,
    ),
  ),
  adPage(
    ParameterizedNavigationRouteDescriptor(
      page: AdDetailPage(),
      parameter: AppNavigationParams.adId,
      pathSegmentTemplate: 'ad/$nitParameterSubstitutionPattern',
    ),
  ),
  edit(
    SimpleNavigationRouteDescriptor(
      page: AdEditPage(),
      parent: adPage,
    ),
  ),
  chooseCategoryEditAd(
    SimpleNavigationRouteDescriptor(
      page: ChooseCategoryPage(adType: AdType.ad),
      parent: edit,
    ),
  ),
  addService(
    ParameterizedNavigationRouteDescriptor(
      page: AddServicesPage(),
      parameter: AppNavigationParams.adId,
      pathSegmentTemplate: 'addService/$nitParameterSubstitutionPattern',

      // parent: adPage,
      // parent: homePage,
    ),
  ),
  updateService(
    SimpleNavigationRouteDescriptor(
      page: AddServicesPage(isUpdateService: true),
      parent: adPage,
    ),
  ),
  // chat(
  //   ParameterizedNavigationRouteDescriptor(
  //     page: ChatViewPage(),
  //     parameter: AppNavigationParams.userId,
  //     parent: adPage,
  //     pathSegmentTemplate: 'chat/$nitParameterSubstitutionPattern',
  //   ),
  // ),
  createStory(
    SimpleNavigationRouteDescriptor(
      page: CreateStoryPage(),
    ),
  ),
  chooseCategoryCreateStory(
    SimpleNavigationRouteDescriptor(
      page: ChooseCategoryPage(adType: AdType.story),
    ),
  ),
  confirmStory(
    ParameterizedNavigationRouteDescriptor(
      page: ConfirmStoryPage(), parameter: AppNavigationParams.adId,
      pathSegmentTemplate: 'confirm_story/$nitParameterSubstitutionPattern',
      // parent: adPage,
    ),
  ),
  ;

  @override
  final NavigationRouteDescriptor descriptor;

  const AdNavigationZone(this.descriptor);

  @override
  String get root => '';
}
