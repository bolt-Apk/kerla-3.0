import 'package:flutter/widgets.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/app_buffer/home/filters/list_filter/widgets/home_radio_button.dart';

class FilterCategoryWidget extends HookConsumerWidget {
  const FilterCategoryWidget({
    super.key,
    required this.items,
    required this.onTap,
  });
  final List<AdCategory> items;
  final Function(AdCategory) onTap;
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return SizedBox(
      height: 40,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: items.length,
        itemBuilder: (context, index) {
          return Padding(
            padding: const EdgeInsets.only(right: 10),
            child: HomeRadioButton(
              text: items[index].title,
              isSelected: false,
              onTap: () => onTap(items[index]),
            ),
          );
        },
      ),
    );
  }
}
