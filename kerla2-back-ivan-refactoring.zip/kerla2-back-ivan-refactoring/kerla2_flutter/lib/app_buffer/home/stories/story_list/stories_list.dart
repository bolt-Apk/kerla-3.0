import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kerla2_flutter/app_buffer/home/stories/story_list/state/story_list_state.dart';
import 'package:kerla2_flutter/router/router.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class StoriesList extends HookConsumerWidget {
  const StoriesList({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return ref.watch(storyListStateProvider).nitWhen(
      childBuilder: (users) {
        if (users.isEmpty) {
          return const SizedBox.shrink();
        }

        return SizedBox(
          height: 120,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
            itemCount: users.length,
            itemBuilder: (context, index) {
              final user = users[index];
              // const bool hasUnseenStory = true; хз зачем это нужно, но пусть пока будет
              return GestureDetector(
                onTap: () {
                  context.pushNamed(
                    MainAreaNavigationZone.userStoriesByUserId.name,
                    pathParameters: AppNavigationParams.userId.set(user.userId),
                  );
                },
                child: Container(
                  margin: const EdgeInsets.symmetric(horizontal: 8),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(2),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              context.colorScheme.primary,
                              context.colorScheme.secondary,
                              context.colorScheme.tertiary,
                            ],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          shape: BoxShape.circle,
                        ),
                        child: Container(
                          padding: const EdgeInsets.all(2),
                          decoration: BoxDecoration(
                            color: context.colorScheme.surface,
                            shape: BoxShape.circle,
                          ),
                          child: CircleAvatar(
                            radius: 32,
                            backgroundColor: context.colorScheme.surface,
                            backgroundImage: user.imageUrl != null
                                ? CachedNetworkImageProvider(user.imageUrl!)
                                : null,
                            child: user.imageUrl == null
                                ? const Icon(Icons.person, size: 32)
                                : null,
                          ),
                        ),
                      ),
                      const SizedBox(height: 4),
                      SizedBox(
                        width: 70,
                        child: Text(
                          user.userName ?? 'User',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.center,
                          style: context.textTheme.bodyMedium,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        );
      },
    );
  }
}
