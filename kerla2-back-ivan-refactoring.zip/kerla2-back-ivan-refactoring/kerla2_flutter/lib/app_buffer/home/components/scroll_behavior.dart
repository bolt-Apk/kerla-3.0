import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_hooks/flutter_hooks.dart';

/// Custom hook to handle scroll behavior and filter visibility

(bool, bool) useScrollBehavior(ScrollController scrollController) {
  final showFilters = useState(false);
  final isScrollingDown = useState(false);

  void onScroll() {
    if (scrollController.position.userScrollDirection ==
        ScrollDirection.reverse) {
      if (!isScrollingDown.value) {
        isScrollingDown.value = true;
        if (showFilters.value) {
          showFilters.value = false;
        }
        return;
      }
    }

    if (scrollController.offset <= 200) {
      if (showFilters.value) {
        showFilters.value = false;
      }
      return;
    }

    if (scrollController.position.userScrollDirection ==
        ScrollDirection.forward) {
      isScrollingDown.value = false;
      if (!showFilters.value) {
        showFilters.value = true;
      }
    }
  }

  useEffect(() {
    scrollController.addListener(onScroll);
    return () => scrollController.removeListener(onScroll);
  }, [scrollController]);

  return (showFilters.value, isScrollingDown.value);
}
