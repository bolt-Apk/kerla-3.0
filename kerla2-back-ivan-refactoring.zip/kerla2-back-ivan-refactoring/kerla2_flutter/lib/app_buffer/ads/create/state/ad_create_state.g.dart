// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'ad_create_state.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$attributeStateHash() => r'3bf39ea19ca489150171ee45584d81010062b3ca';

/// Copied from Dart SDK
class _SystemHash {
  _SystemHash._();

  static int combine(int hash, int value) {
    // ignore: parameter_assignments
    hash = 0x1fffffff & (hash + value);
    // ignore: parameter_assignments
    hash = 0x1fffffff & (hash + ((0x0007ffff & hash) << 10));
    return hash ^ (hash >> 6);
  }

  static int finish(int hash) {
    // ignore: parameter_assignments
    hash = 0x1fffffff & (hash + ((0x03ffffff & hash) << 3));
    // ignore: parameter_assignments
    hash = hash ^ (hash >> 11);
    return 0x1fffffff & (hash + ((0x00003fff & hash) << 15));
  }
}

abstract class _$AttributeState
    extends BuildlessAutoDisposeAsyncNotifier<List<Attribute>> {
  late final AdCategory? subcategory;

  FutureOr<List<Attribute>> build(
    AdCategory? subcategory,
  );
}

/// See also [AttributeState].
@ProviderFor(AttributeState)
const attributeStateProvider = AttributeStateFamily();

/// See also [AttributeState].
class AttributeStateFamily extends Family<AsyncValue<List<Attribute>>> {
  /// See also [AttributeState].
  const AttributeStateFamily();

  /// See also [AttributeState].
  AttributeStateProvider call(
    AdCategory? subcategory,
  ) {
    return AttributeStateProvider(
      subcategory,
    );
  }

  @override
  AttributeStateProvider getProviderOverride(
    covariant AttributeStateProvider provider,
  ) {
    return call(
      provider.subcategory,
    );
  }

  static const Iterable<ProviderOrFamily>? _dependencies = null;

  @override
  Iterable<ProviderOrFamily>? get dependencies => _dependencies;

  static const Iterable<ProviderOrFamily>? _allTransitiveDependencies = null;

  @override
  Iterable<ProviderOrFamily>? get allTransitiveDependencies =>
      _allTransitiveDependencies;

  @override
  String? get name => r'attributeStateProvider';
}

/// See also [AttributeState].
class AttributeStateProvider extends AutoDisposeAsyncNotifierProviderImpl<
    AttributeState, List<Attribute>> {
  /// See also [AttributeState].
  AttributeStateProvider(
    AdCategory? subcategory,
  ) : this._internal(
          () => AttributeState()..subcategory = subcategory,
          from: attributeStateProvider,
          name: r'attributeStateProvider',
          debugGetCreateSourceHash:
              const bool.fromEnvironment('dart.vm.product')
                  ? null
                  : _$attributeStateHash,
          dependencies: AttributeStateFamily._dependencies,
          allTransitiveDependencies:
              AttributeStateFamily._allTransitiveDependencies,
          subcategory: subcategory,
        );

  AttributeStateProvider._internal(
    super._createNotifier, {
    required super.name,
    required super.dependencies,
    required super.allTransitiveDependencies,
    required super.debugGetCreateSourceHash,
    required super.from,
    required this.subcategory,
  }) : super.internal();

  final AdCategory? subcategory;

  @override
  FutureOr<List<Attribute>> runNotifierBuild(
    covariant AttributeState notifier,
  ) {
    return notifier.build(
      subcategory,
    );
  }

  @override
  Override overrideWith(AttributeState Function() create) {
    return ProviderOverride(
      origin: this,
      override: AttributeStateProvider._internal(
        () => create()..subcategory = subcategory,
        from: from,
        name: null,
        dependencies: null,
        allTransitiveDependencies: null,
        debugGetCreateSourceHash: null,
        subcategory: subcategory,
      ),
    );
  }

  @override
  AutoDisposeAsyncNotifierProviderElement<AttributeState, List<Attribute>>
      createElement() {
    return _AttributeStateProviderElement(this);
  }

  @override
  bool operator ==(Object other) {
    return other is AttributeStateProvider && other.subcategory == subcategory;
  }

  @override
  int get hashCode {
    var hash = _SystemHash.combine(0, runtimeType.hashCode);
    hash = _SystemHash.combine(hash, subcategory.hashCode);

    return _SystemHash.finish(hash);
  }
}

mixin AttributeStateRef
    on AutoDisposeAsyncNotifierProviderRef<List<Attribute>> {
  /// The parameter `subcategory` of this provider.
  AdCategory? get subcategory;
}

class _AttributeStateProviderElement
    extends AutoDisposeAsyncNotifierProviderElement<AttributeState,
        List<Attribute>> with AttributeStateRef {
  _AttributeStateProviderElement(super.provider);

  @override
  AdCategory? get subcategory => (origin as AttributeStateProvider).subcategory;
}

String _$createAdStateHash() => r'49eed69237319f6580cf4b1a64414c8abd386d76';

abstract class _$CreateAdState extends BuildlessAutoDisposeNotifier<Ad> {
  late final AdType adType;
  late final int? adId;

  Ad build(
    AdType adType, {
    int? adId,
  });
}

/// See also [CreateAdState].
@ProviderFor(CreateAdState)
const createAdStateProvider = CreateAdStateFamily();

/// See also [CreateAdState].
class CreateAdStateFamily extends Family<Ad> {
  /// See also [CreateAdState].
  const CreateAdStateFamily();

  /// See also [CreateAdState].
  CreateAdStateProvider call(
    AdType adType, {
    int? adId,
  }) {
    return CreateAdStateProvider(
      adType,
      adId: adId,
    );
  }

  @override
  CreateAdStateProvider getProviderOverride(
    covariant CreateAdStateProvider provider,
  ) {
    return call(
      provider.adType,
      adId: provider.adId,
    );
  }

  static const Iterable<ProviderOrFamily>? _dependencies = null;

  @override
  Iterable<ProviderOrFamily>? get dependencies => _dependencies;

  static const Iterable<ProviderOrFamily>? _allTransitiveDependencies = null;

  @override
  Iterable<ProviderOrFamily>? get allTransitiveDependencies =>
      _allTransitiveDependencies;

  @override
  String? get name => r'createAdStateProvider';
}

/// See also [CreateAdState].
class CreateAdStateProvider
    extends AutoDisposeNotifierProviderImpl<CreateAdState, Ad> {
  /// See also [CreateAdState].
  CreateAdStateProvider(
    AdType adType, {
    int? adId,
  }) : this._internal(
          () => CreateAdState()
            ..adType = adType
            ..adId = adId,
          from: createAdStateProvider,
          name: r'createAdStateProvider',
          debugGetCreateSourceHash:
              const bool.fromEnvironment('dart.vm.product')
                  ? null
                  : _$createAdStateHash,
          dependencies: CreateAdStateFamily._dependencies,
          allTransitiveDependencies:
              CreateAdStateFamily._allTransitiveDependencies,
          adType: adType,
          adId: adId,
        );

  CreateAdStateProvider._internal(
    super._createNotifier, {
    required super.name,
    required super.dependencies,
    required super.allTransitiveDependencies,
    required super.debugGetCreateSourceHash,
    required super.from,
    required this.adType,
    required this.adId,
  }) : super.internal();

  final AdType adType;
  final int? adId;

  @override
  Ad runNotifierBuild(
    covariant CreateAdState notifier,
  ) {
    return notifier.build(
      adType,
      adId: adId,
    );
  }

  @override
  Override overrideWith(CreateAdState Function() create) {
    return ProviderOverride(
      origin: this,
      override: CreateAdStateProvider._internal(
        () => create()
          ..adType = adType
          ..adId = adId,
        from: from,
        name: null,
        dependencies: null,
        allTransitiveDependencies: null,
        debugGetCreateSourceHash: null,
        adType: adType,
        adId: adId,
      ),
    );
  }

  @override
  AutoDisposeNotifierProviderElement<CreateAdState, Ad> createElement() {
    return _CreateAdStateProviderElement(this);
  }

  @override
  bool operator ==(Object other) {
    return other is CreateAdStateProvider &&
        other.adType == adType &&
        other.adId == adId;
  }

  @override
  int get hashCode {
    var hash = _SystemHash.combine(0, runtimeType.hashCode);
    hash = _SystemHash.combine(hash, adType.hashCode);
    hash = _SystemHash.combine(hash, adId.hashCode);

    return _SystemHash.finish(hash);
  }
}

mixin CreateAdStateRef on AutoDisposeNotifierProviderRef<Ad> {
  /// The parameter `adType` of this provider.
  AdType get adType;

  /// The parameter `adId` of this provider.
  int? get adId;
}

class _CreateAdStateProviderElement
    extends AutoDisposeNotifierProviderElement<CreateAdState, Ad>
    with CreateAdStateRef {
  _CreateAdStateProviderElement(super.provider);

  @override
  AdType get adType => (origin as CreateAdStateProvider).adType;
  @override
  int? get adId => (origin as CreateAdStateProvider).adId;
}
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
