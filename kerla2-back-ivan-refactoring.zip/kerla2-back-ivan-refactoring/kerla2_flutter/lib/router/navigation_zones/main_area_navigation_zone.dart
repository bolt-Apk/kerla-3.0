part of '../router.dart';

enum MainAreaNavigationZone implements NavigationZoneRoute {
  // main navbar
  homePage(
    SimpleNavigationRouteDescriptor(
      page: HomePage(),
    ),
  ),
  // stories(
  //   SimpleNavigationRouteDescriptor(
  //     page: StoriesPage(
  //       isSingleStory: false,
  //     ),
  //   ),
  // ),
  // chats(
  //   SimpleNavigationRouteDescriptor(
  //     page: ChatListPage(),
  //   ),
  // ),
  // chatView(
  //   ParameterizedNavigationRouteDescriptor(
  //     page: ChatListPage(),
  //     parameter: AppNavigationParams.chatId,
  //     parent: chats,
  //   ),
  // ),
  profile(
    SimpleNavigationRouteDescriptor(
      page: UserProfilePage(),
    ),
  ),
  // singleUserStorie(
  //   ParameterizedNavigationRouteDescriptor(
  //     page: StoriesPage(
  //       isSingleStory: true,
  //     ),
  //     parameter: AppNavigationParams.userId,
  //     parent: stories,
  //     pathSegmentTemplate: 'singleUserStorie/$nitParameterSubstitutionPattern',
  //   ),
  // ),
  userStoriesByUserId(
    ParameterizedNavigationRouteDescriptor(
      page: StoriesPage(),
      parameter: AppNavigationParams.userId,
      parent: homePage,
      pathSegmentTemplate:
          'userStoriesByUserId/$nitParameterSubstitutionPattern',
    ),
  ),
  userStoriesByStoryId(
    ParameterizedNavigationRouteDescriptor(
      page: StoriesPage(),
      parameter: AppNavigationParams.storyId,
      parent: homePage,
      pathSegmentTemplate:
          'userStoriesByStoryId/$nitParameterSubstitutionPattern',
    ),
  ),
  // userChat(
  //   ParameterizedNavigationRouteDescriptor(
  //     page: ChatViewPage(),
  //     parameter: AppNavigationParams.userId,
  //     parent: chats,
  //     pathSegmentTemplate: 'u/$nitParameterSubstitutionPattern',
  //   ),
  // ),

  settings(
    SimpleNavigationRouteDescriptor(
      page: ProfileSettingsPage(),
      parent: profile,
    ),
  ),
  notification(
    SimpleNavigationRouteDescriptor(
      page: NotificationPage(),
      parent: homePage,
    ),
  ),
  user(
    ParameterizedNavigationRouteDescriptor(
      page: UserProfilePage(),
      parameter: AppNavigationParams.userId,
      parent: homePage,
      pathSegmentTemplate: 'users/$nitParameterSubstitutionPattern',
    ),
  ),
  subsribers(
    ParameterizedNavigationRouteDescriptor(
      page: SubscriberListPage.subscribers(),
      // parent: user,
      parameter: AppNavigationParams.userId,
      pathSegmentTemplate: 'subscribers/$nitParameterSubstitutionPattern',
    ),
  ),
  subscriptions(
    ParameterizedNavigationRouteDescriptor(
      page: SubscriberListPage.subscriptions(),
      // parent: user,
      parameter: AppNavigationParams.userId,
      pathSegmentTemplate: 'subscriptions/$nitParameterSubstitutionPattern',
    ),
  ),

  favorites(
    SimpleNavigationRouteDescriptor(
      page: FavoritePage(),
      parent: homePage,
    ),
  ),

  // chooseFilters(
  //   SimpleNavigationRouteDescriptor(
  //     page: ChooseFiltersPage(),
  //   ),
  // ),
  // moreFilters(
  //   SimpleNavigationRouteDescriptor(
  //     page: ChooseFiltersPage(
  //       isMoreFilterPage: true,
  //     ),
  //     parent: MainAreaNavigationZone.chooseFilters,
  //   ),
  // ),

  // paymentsStatus(
  //   SimpleNavigationRouteDescriptor(
  //     page: PaymentsStausPage(),
  //     parent: settings,
  //   ),
  // ),
  businessProfile(
    SimpleNavigationRouteDescriptor(
      page: ConnectBusinessProfileService(),
    ),
  );

  @override
  final NavigationRouteDescriptor descriptor;

  const MainAreaNavigationZone(this.descriptor);

  @override
  String get root => '';

  // TODO: вернуть
  // @override
  // Page<dynamic> pageBuilder(BuildContext context, GoRouterState state) {
  //   return navigationPageBuilder(
  //     context: context,
  //     state: state,
  //     route: route,
  //     wrapper: (Widget child) => DoubleBackToExit(
  //       enabled: route.parent == null && !Platform.isIOS,
  //       snackBarMessage: 'Нажмите ещё раз, чтобы выйти',
  //       child: child,
  //     ),
  //   );
  // }
}
