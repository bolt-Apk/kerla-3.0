import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/app_buffer/profile/subscribers/widgets/counter_button.dart';
import 'package:kerla2_flutter/app_buffer/profile/subscribers/widgets/subscribe_button.dart';
import 'package:kerla2_flutter/core/app_backend_filters.dart';
import 'package:kerla2_flutter/router/router.dart';
import 'package:nit_app/nit_app.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class SubscribersWidget extends ConsumerWidget {
  const SubscribersWidget({
    super.key,
    required this.userId,
  });

  final int userId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isMyProfile = userId == ref.signedInUserId;
    final widgetUserId = isMyProfile ? ref.signedInUserId! : userId;

    return DecoratedBox(
      decoration: BoxDecoration(color: context.theme.canvasColor),
      child: Padding(
        padding: const EdgeInsets.only(top: 8.0),
        child: Column(
          children: [
            SizedBox(
              width: double.infinity,
              child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  child:
                      // ref
                      //     .watchEntityListAsync<UserSubscription>(
                      //       backendFilter: NitBackendFilter.or(
                      //         [
                      //           AppBackendFilter.subscriberId.equals(widgetUserId),
                      //           AppBackendFilter.userId.equals(widgetUserId),
                      //         ],
                      //       ),
                      //     )
                      //     .whenData((s) => s)
                      //     .nitWhen(childBuilder: (subs) {
                      //   return
                      Row(
                    children: [
                      Consumer(
                        builder: (context, ref, child) => ref
                            .watchEntityCountAsync<UserSubscription>(
                                backendFilter: AppBackendFilter.userId
                                    .equals(widgetUserId))
                            .nitWhen(
                              childBuilder: (subs) => CounterButton(
                                count: subs,
                                label: 'Подписчиков',
                                routeName:
                                    MainAreaNavigationZone.subscriptions.name,
                                pathParameters: AppNavigationParams.userId
                                    .set(widgetUserId),
                              ),
                            ),
                      ),
                      const Gap(8),
                      Consumer(
                        builder: (context, ref, child) => ref
                            .watchEntityCountAsync<UserSubscription>(
                                backendFilter: AppBackendFilter.subscriberId
                                    .equals(widgetUserId))
                            .nitWhen(
                              childBuilder: (subs) => CounterButton(
                                count: subs,
                                label: 'Подписок',
                                routeName:
                                    MainAreaNavigationZone.subsribers.name,
                                pathParameters: AppNavigationParams.userId
                                    .set(widgetUserId),
                              ),
                            ),
                      ),
                      // IconButton(
                      //   onPressed: () => ref
                      //       .read(globalRefreshTriggerProvider.notifier)
                      //       .state = DateTime.now(),
                      //   icon: const Icon(Icons.refresh),
                      // ),
                      // CounterButton(
                      //   count: subs
                      //       .where((e) => e.subscriberId == widgetUserId)
                      //       .length,
                      //   label: 'Подписок',
                      //   routeName: MainAreaNavigationZone.subsribers.name,
                      //   pathParameters:
                      //       AppNavigationParams.userId.set(widgetUserId),
                      // ),
                      const Spacer(),
                      if (ref.signedIn && !isMyProfile)
                        SubscribeButton(userId: widgetUserId),
                    ],
                  )
                  // }),
                  ),
            ),
          ],
        ),
      ),
    );
  }
}
