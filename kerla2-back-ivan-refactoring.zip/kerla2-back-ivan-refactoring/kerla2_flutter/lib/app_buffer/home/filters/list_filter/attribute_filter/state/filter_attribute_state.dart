import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';

part 'filter_attribute_state.g.dart';
part 'filter_attribute_state.freezed.dart';

// @riverpod
// class FilterAttributeState extends _$FilterAttributeState {
//   @override
//   List<AdAttributeValue> build() {
//     return [];
//   }
// }

@riverpod
class FilterState extends _$FilterState {
  @override
  FilterStateModel build(AdListType adListType) {
    ref.onDispose(() {
      print('disposing $adListType');
    });
    return const FilterStateModel(
      attributes: [],
      searchQuery: '',
      category: null,
    );
  }

  void updateSearchString(String value) {
    state = state.copyWith(searchQuery: value);
  }

  void updateCategory(AdCategory? category) {
    state = state.copyWith(category: category);
  }

  void upsertAttribute(AdAttributeValue attributeValue) {
    final value = attributeValue.value;
    final existing = state.attributes
        .indexWhere((e) => e.attributeId == attributeValue.attributeId);
    if (value.isEmpty) {
      // Remove from state if exists
      if (existing != -1) {
        state = state.copyWith(attributes: [
          ...state.attributes.sublist(0, existing),
          ...state.attributes.sublist(existing + 1),
        ]);
      }
    } else {
      // Upsert as before
      if (existing != -1) {
        state = state.copyWith(attributes: [
          ...state.attributes.sublist(0, existing),
          attributeValue,
          ...state.attributes.sublist(existing + 1),
        ]);
      } else {
        state =
            state.copyWith(attributes: [...state.attributes, attributeValue]);
      }
    }
  }

  List<Map<int, String>> convertAttributes() {
    final List<Map<int, String>> outputList = [];

    final inputList = state.attributes;

    if (inputList.isNotEmpty) {
      for (var item in inputList) {
        final attributeId = item.attributeId;
        final value = item.value;
        outputList.add({attributeId: value});
      }
    }
    return outputList;
  }
}

@freezed
class FilterStateModel with _$FilterStateModel {
  const factory FilterStateModel({
    required List<AdAttributeValue> attributes,
    required String searchQuery,
    required AdCategory? category,
  }) = _FilterStateModel;
}
