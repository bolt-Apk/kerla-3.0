// part of '../app_routing_tools.dart';

import 'package:kerla2_flutter/auth/code_page.dart';
import 'package:kerla2_flutter/auth/enter_user_profile_page.dart';
import 'package:kerla2_flutter/auth/reset_email_page.dart';
import 'package:kerla2_flutter/auth/state/auth_mode_enum.dart';
import 'package:nit_router/nit_router.dart';

import '../../auth/auth_page.dart';
import '../../auth/enter_auth_password_page.dart';
import '../../auth/terms_of_use/terms_of_use_page.dart';

enum AuthAreaNavigationZone implements NavigationZoneRoute {
  termsOfUse(
    SimpleNavigationRouteDescriptor(
      // path: 'terms_of_use',
      page: TermsOfUsePage(),
    ),
  ),

  auth(
    SimpleNavigationRouteDescriptor(
      // path: 'signIn',
      page: AuthPage(),
    ),
  ),
  signInPassword(
    SimpleNavigationRouteDescriptor(
      // path: 'password',
      page: EnterAuthPasswordPage(
        mode: AuthModeEnum.signIn,
      ),
      parent: AuthAreaNavigationZone.auth,
    ),
  ),

  recover(
    SimpleNavigationRouteDescriptor(
      // path: 'recover',
      page: RecoverPage(),
      parent: AuthAreaNavigationZone.auth,
    ),
  ),
  recoverPassword(
    SimpleNavigationRouteDescriptor(
      // path: 'password',
      page: EnterAuthPasswordPage(
        mode: AuthModeEnum.recover,
      ),
      parent: AuthAreaNavigationZone.recover,
    ),
  ),
  recoverCode(
    SimpleNavigationRouteDescriptor(
      // path: 'code',
      page: CodePage(
        mode: AuthModeEnum.recover,
      ),
      parent: AuthAreaNavigationZone.recover,
    ),
  ),

  registrationPassword(
    SimpleNavigationRouteDescriptor(
      // path: 'password',
      page: EnterAuthPasswordPage(
        mode: AuthModeEnum.registration,
      ),
      parent: AuthAreaNavigationZone.fillUserProfile,
    ),
  ),
  registrationCode(
    SimpleNavigationRouteDescriptor(
      // path: 'code',
      page: CodePage(
        mode: AuthModeEnum.registration,
      ),
      parent: AuthAreaNavigationZone.registrationPassword,
    ),
  ),

  // // should be here?
  // changePasswordCode(
  //   SimpleNavigationRouteDescriptor(
  //     page: CodePage(mode: AuthModeEnum.change),
  //   ),
  // ),
  // changePassword(
  //   SimpleNavigationRouteDescriptor(
  //     page: EnterAuthPasswordPage(mode: AuthModeEnum.change),
  //   ),
  // ),
  fillUserProfile(
    SimpleNavigationRouteDescriptor(
      // path: 'password',
      page: EnterUserProfilePage(
        mode: AuthModeEnum.registration,
      ),
      parent: AuthAreaNavigationZone.auth,
    ),
  ),
  ;

  const AuthAreaNavigationZone(this.descriptor);

  @override
  final NavigationRouteDescriptor descriptor;

  @override
  String get root => '';
}

// enum AuthNavigationZone implements NavigationZoneRoute {
//   //auth pages
//   login(
//     SimpleNavigationRouteDescriptor(
//       page: LoginPage(),
//     ),
//   ),
//   enterRegisterCode(
//     SimpleNavigationRouteDescriptor(
//       page: EnterCodePage(),
//       parent: register,
//     ),
//   ),
//   register(
//     SimpleNavigationRouteDescriptor(
//       page: RegisterPage(),
//       parent: login,
//     ),
//   ),
//   chooseGender(
//     SimpleNavigationRouteDescriptor(
//       page: ChooseGenderPage(),
//       parent: enterRegisterCode,
//     ),
//   ),
//   privatePolicy(
//     SimpleNavigationRouteDescriptor(
//       page: PrivacyPolicyPage(),
//       parent: login,
//     ),
//   ),
//   //reset password pages
//   resetPassword(
//     SimpleNavigationRouteDescriptor(
//       page: ResetPasswordPage(),
//       parent: login,
//     ),
//   ),
//   enterResetPasswordCode(
//     SimpleNavigationRouteDescriptor(
//       page: EnterCodePage(),
//       parent: resetPassword,
//     ),
//   ),
//   // setPhoneNumber(
//   //   NavigationRoute(
//   //     path: 'setPhoneNumber',
//   //     page: ChooseGenderPage(),
//   //     parent: enterRegisterCode,
//   //   ),
//   // ),
//   newPassword(
//     SimpleNavigationRouteDescriptor(
//       page: NewPasswordPage(),
//       parent: enterResetPasswordCode,
//     ),
//   );

//   @override
//   final NavigationRouteDescriptor descriptor;

//   const AuthNavigationZone(this.descriptor);

//   @override
//   String get root => 'auth';
// }
