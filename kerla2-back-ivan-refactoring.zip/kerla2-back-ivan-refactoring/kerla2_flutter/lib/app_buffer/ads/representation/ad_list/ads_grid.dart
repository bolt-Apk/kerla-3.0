import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_svg/svg.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/common/is_my_profile.dart';
import 'package:kerla2_flutter/common/widgets/no_ads_widget.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';

import 'state/ad_list_state.dart';
import '../ad_card/ad.dart';

class AdsGrid extends ConsumerWidget {
  const AdsGrid({
    super.key,
    required this.params,
    this.physics,
    this.isSliver,
  });

  final ScrollPhysics? physics;
  final GetAdParam params;
  final bool? isSliver;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(adListStateProvider(params));

    // if (isSliver != true && state.controller.itemList?.isEmpty == true) {
    //   return SizedBox.shrink();
    // }

    if (isSliver != true) {
      return DecoratedBox(
        decoration:
            BoxDecoration(color: Theme.of(context).scaffoldBackgroundColor),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              if (params.adListType == AdListType.similarAd)
                Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: Text(
                    'Подобные объявления',
                    style: Theme.of(context).textTheme.headlineLarge,
                  ),
                ),
              // if (similarAdCategory != null) const SizedBox(height: 10),
              PagedGridView<int, Ad>(
                physics: physics,
                shrinkWrap: true,
                primary: false,
                padding: EdgeInsets.only(
                  bottom: (state.controller.itemList?.isEmpty == true ||
                          state.controller.itemList?.isEmpty == null)
                      ? 100
                      : ((state.controller.itemList?.length ?? 0) < 3) &&
                              params.adListType != AdListType.similarAd
                          ? 300
                          : 0,
                ),
                pagingController: state.controller,
                builderDelegate: PagedChildBuilderDelegate<Ad>(
                  animateTransitions: true,
                  transitionDuration: const Duration(milliseconds: 500),
                  itemBuilder: (context, item, index) {
                    return AdWidget(
                      ad: item,
                    );
                  },
                  noItemsFoundIndicatorBuilder: (context) => Padding(
                    padding: const EdgeInsets.only(top: 16),
                    child: Center(
                      child: (params.adListType == AdListType.profile &&
                              ref.isMyProfile(params.id))
                          ? const NoAdsWidget()
                          : Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                if (params.adListType != AdListType.similarAd)
                                  SvgPicture.asset(
                                    AppIconsSvg.bell,
                                  ),
                                const SizedBox(height: 8),
                                Text('Ничего не найдено',
                                    style: Theme.of(context)
                                        .textTheme
                                        .headlineSmall),
                              ],
                            ),
                    ),
                  ),
                ),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 8,
                  mainAxisSpacing: 8,
                  mainAxisExtent: 322,
                ),
              ),
            ],
          ),
        ),
      );
    }
    return SliverPadding(
      padding: const EdgeInsets.all(8),
      sliver: PagedSliverGrid<int, Ad>(
        pagingController: state.controller,
        builderDelegate: PagedChildBuilderDelegate<Ad>(
          animateTransitions: true,
          transitionDuration: const Duration(milliseconds: 500),
          itemBuilder: (context, item, index) {
            return AdWidget(
              ad: item,
            );
          },
          noItemsFoundIndicatorBuilder: (context) => Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if (params.adListType != AdListType.similarAd)
                  SvgPicture.asset(
                    AppIconsSvg.bell,
                  ),
                const SizedBox(height: 8),
                Text('Ничего не найдено',
                    style: Theme.of(context).textTheme.bodyMedium),
              ],
            ),
          ),
        ),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: 8,
          mainAxisSpacing: 8,
          mainAxisExtent: 327,
        ),
      ),
    );
  }
}
