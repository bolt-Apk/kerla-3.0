// import 'package:flutter/material.dart' hide Route;

// import 'package:hooks_riverpod/hooks_riverpod.dart';
// import 'package:kerla2_client/kerla2_client.dart';
// import 'package:kerla2_flutter/app_buffer/ads/service/payment/payment/init_payment_call.dart';
// import 'package:kerla2_flutter/common/kerla_service_title_extension.dart';
// import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
// import 'package:nit_ui_kit/nit_ui_kit.dart';

// class PaymentWidget extends HookConsumerWidget {
//   const PaymentWidget({
//     super.key,
//     // required this.amount,
//     required this.promotions,
//   });

//   // final int amount;
//   final List<KerlaService> promotions;

//   // int get days {
//   //   if (promotions.isEmpty) return 0;
//   //   return promotions.first.endsAt
//   //       .difference(
//   //         DateTime.now().subtract(
//   //           const Duration(minutes: 10),
//   //         ),
//   //       )
//   //       .inDays;
//   // }

//   @override
//   Widget build(BuildContext context, WidgetRef ref) {
//     // final payment = ref.watch(paymentStateProvider);
//     final themeButtonStyle = ThemeButtonStyle();
//     // TODO: ВАНЯ - это зачем? можем заменить на nit_riverpod_notifications?
//     // useFlashErrorNotifier(ref);

//     return DecoratedBox(
//       decoration: BoxDecoration(color: context.theme.scaffoldBackgroundColor),
//       child: Padding(
//         padding: const EdgeInsets.all(16.0),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: <Widget>[
//             RichText(
//               text: TextSpan(
//                 children: [
//                   TextSpan(
//                     text: 'Приобретение услуг',
//                     style: TextStyle(
//                       color: context.theme.primaryColorDark,
//                       fontSize: 12,
//                       fontWeight: FontWeight.w300,
//                     ),
//                   ),
//                   TextSpan(
//                     text: ' › ',
//                     style: TextStyle(
//                       color: context.theme.primaryColorDark,
//                       fontSize: 15,
//                       fontWeight: FontWeight.w300,
//                     ),
//                   ),
//                   TextSpan(
//                     text: promotions.map((e) => e.type.title).join(', '),
//                     style: TextStyle(
//                       color: context.theme.primaryColorDark,
//                       fontSize: 15,
//                       fontWeight: FontWeight.w500,
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//             const SizedBox(
//               height: 16,
//             ),
//             RichText(
//               text: TextSpan(
//                 children: [
//                   TextSpan(
//                     text:
//                         '${promotions.map((e) => e.price).reduce((a, b) => a! + b!)}₽',
//                     style: TextStyle(
//                       color: context.theme.iconTheme.color?.withOpacity(0.7),
//                       fontSize: 35,
//                       fontWeight: FontWeight.w900,
//                     ),
//                   ),
//                   // TextSpan(
//                   //   text: ' за ',
//                   //   style: TextStyle(
//                   //     color: context.theme.primaryColorDark,
//                   //     fontSize: 15,
//                   //     fontWeight: FontWeight.w300,
//                   //   ),
//                   // ),
//                   // TextSpan(
//                   //   text: '$days ${day(days)}',
//                   //   style: TextStyle(
//                   //     color: context.theme.primaryColorDark,
//                   //     fontSize: 15,
//                   //     fontWeight: FontWeight.w500,
//                   //   ),
//                   // ),
//                 ],
//               ),
//             ),
//             const SizedBox(
//               height: 16,
//             ),
//             // const CardWidget(),
//             const Padding(padding: EdgeInsets.only(bottom: 16)),
//             Button(
//               onPressed: () => ref.initPayment(services: promotions),
//               child: const Text('Оплатить'),
//             ),
//             // GuardedElevatedButton(
//             //   guard:
//             //       Guard(minProcessingTime: const Duration(milliseconds: 1500)),
//             //   onPressed: payment.canContinue
//             //       ? () async {
//             //           ref
//             //               .read(paymentStateProvider.notifier)
//             //               .canContinueHandle(false);
//             //           final success = await ref
//             //               .read(paymentStateProvider.notifier)
//             //               .pay(context, ref, amount, promotions);
//             //           ref
//             //               .read(paymentStateProvider.notifier)
//             //               .canContinueHandle(true);
//             //           if (!success && context.mounted) {
//             //             context.showDefaultErrorFlash(
//             //               'Ошибка оплаты',
//             //             );
//             //           }
//             //           if (success && context.mounted) {
//             //             ref
//             //                 .read(creditCardDataProvider.notifier)
//             //                 .saveCreditCard(
//             //                   payment.cardPanController.text,
//             //                   payment.cardExpDateController.text,
//             //                 );
//             //             context.pop(success);
//             //           }
//             //         }
//             //       : null,
//             //   style: themeButtonStyle.buttonStyle,
//             //   child: Text('Оплатить',
//             //       style: TextStyle(color: context.theme.dialogBackgroundColor)),
//             // ),
//             const Padding(padding: EdgeInsets.only(bottom: 16)),
//             // Text(payment.error ?? ''),
//           ],
//         ),
//       ),
//     );
//   }
// }

// // class CardWidget extends ConsumerWidget {
// //   const CardWidget({super.key});

// //   @override
// //   Widget build(BuildContext context, WidgetRef ref) {
// //     final payment = ref.watch(paymentStateProvider);
// //     final cardState = ref.watch(creditCardDataProvider);
// //     return cardState.when(
// //       data: (CreditCard data) {
// //         final cardNumberController = payment.cardPanController;
// //         if (cardNumberController.text.isEmpty) {
// //           cardNumberController.text = data.cardNumber;
// //         }

// //         final cardExpDateController = payment.cardExpDateController;
// //         if (cardExpDateController.text.isEmpty) {
// //           cardExpDateController.text = data.creationDate;
// //         }
// //         final isCardSaved = data.isCardSaved;
// //         return Container(
// //           decoration: BoxDecoration(
// //             color: context.theme.canvasColor,
// //             border: Border.all(
// //               color: const Color(0xFFF2F2F2),
// //               width: 2,
// //             ),
// //             borderRadius: const BorderRadius.all(
// //               Radius.circular(16),
// //             ),
// //           ),
// //           child: Column(
// //             children: [
// //               const SizedBox(
// //                 height: 16,
// //                 width: double.infinity,
// //               ),
// //               const SizedBox(
// //                 height: 40,
// //                 width: double.infinity,
// //                 child: ColoredBox(color: ThemePrimaryColors.primary),
// //               ),
// //               const SizedBox(height: 16),
// //               CardInputTextField(
// //                 controller: cardNumberController,
// //                 hint: 'Номер карты',
// //                 additionalFormatters: [
// //                   LengthLimitingTextInputFormatter(16),
// //                   CreditCardNumberFormater(),
// //                 ],
// //               ),
// //               Row(
// //                 children: [
// //                   Expanded(
// //                     flex: 4,
// //                     child: CardInputTextField(
// //                       controller: cardExpDateController,
// //                       hint: 'Срок действия',
// //                       additionalFormatters: [
// //                         LengthLimitingTextInputFormatter(4),
// //                         CreditCardDateFormater(),
// //                       ],
// //                     ),
// //                   ),
// //                   const Spacer(),
// //                   Expanded(
// //                     flex: 3,
// //                     child: CardInputTextField(
// //                       controller: payment.cardCvvController,
// //                       hint: 'CVC/CVV',
// //                       obscureText: true,
// //                       additionalFormatters: [
// //                         LengthLimitingTextInputFormatter(3),
// //                       ],
// //                     ),
// //                   ),
// //                 ],
// //               ),
// //               Row(
// //                 children: [
// //                   Checkbox(
// //                     value: isCardSaved,
// //                     onChanged: (_) {
// //                       ref.read(creditCardDataProvider.notifier).isCardSaved =
// //                           !data.isCardSaved;
// //                     },
// //                   ),
// //                   const SizedBox(width: 4),
// //                   const Text(
// //                     'Запомнить карту',
// //                   ),
// //                 ],
// //               ),
// //             ],
// //           ),
// //         );
// //       },
// //       error: (Object error, StackTrace stackTrace) {
// //         debugPrint(error.toString());
// //         return Text(error.toString());
// //       },
// //       loading: () => const CircularProgressIndicator(),
// //     );
// //   }
// // }
