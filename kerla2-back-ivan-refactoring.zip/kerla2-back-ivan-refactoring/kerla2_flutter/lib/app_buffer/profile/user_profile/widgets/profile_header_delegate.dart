import 'package:flutter/material.dart';
import 'package:kerla2_flutter/app_buffer/profile/background_image_widget.dart';

import 'pre_body_profile_widget.dart';
import 'profile_app_bar.dart';
import 'profile_description_widget.dart';

class ProfileHeaderDelegate extends SliverPersistentHeaderDelegate {
  ProfileHeaderDelegate({
    required this.userId,
    required this.maxExtent,
    required this.minExtent,
  });

  @override
  bool shouldRebuild(covariant SliverPersistentHeaderDelegate oldDelegate) =>
      true;

  @override
  final double maxExtent;

  @override
  final double minExtent;

  final int userId;

  double calculateMainInfoOpacity(double progress) {
    if (progress < 0.45) {
      return 1.0;
    } else if (progress >= 0.45 && progress < 0.55) {
      return 1.0 - ((progress - 0.45) / 0.1);
    } else {
      return 0.0;
    }
  }

  @override
  Widget build(
    BuildContext context,
    double shrinkOffset,
    bool overlapsContent,
  ) {
    final progress = shrinkOffset / maxExtent;
    final double expandedHeight = MediaQuery.sizeOf(context).height * 0.35;
    final mainInfoOpacity = calculateMainInfoOpacity(progress);
    // final appBarSize = expandedHeight - shrinkOffset;

    final safeAreaPadding =
        EdgeInsets.only(top: MediaQuery.paddingOf(context).top);

    return Material(
      child: Stack(
        fit: StackFit.expand,
        children: [
          shrinkOffset > expandedHeight
              ? Padding(
                  padding: safeAreaPadding,
                  child: Opacity(
                    opacity: progress,
                    child: ProfileAppbar.withProfileImage(
                      userId: userId,
                    ),
                  ),
                )
              : Opacity(
                  opacity: mainInfoOpacity,
                  child: SizedBox(
                    height: expandedHeight,
                    child: BackgroundImageWidget(userId: userId),
                  ),
                ),
          if (shrinkOffset <= expandedHeight)
            Padding(
              padding: safeAreaPadding,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: ProfileAppbar.withoutProfileImage(
                  userId: userId,
                ),
              ),
            ),
          if (shrinkOffset <= expandedHeight)
            PositionedDirectional(
              start: 0.0,
              end: 0.0,
              bottom: 0,
              child: Opacity(
                opacity: mainInfoOpacity,
                child: Column(
                  children: [
                    ProfileDescriptionWidget(
                      userId: userId,
                    ),
                    PreBodyProfileWidget(
                      userId: userId,
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}
