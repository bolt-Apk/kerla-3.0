/* AUTOMATICALLY GENERATED CODE DO NOT MODIFY */
/*   To generate run: "serverpod generate"    */

// ignore_for_file: implementation_imports
// ignore_for_file: library_private_types_in_public_api
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: public_member_api_docs
// ignore_for_file: type_literal_in_constant_pattern
// ignore_for_file: use_super_parameters

// ignore_for_file: no_leading_underscores_for_library_prefixes
import 'package:serverpod_client/serverpod_client.dart' as _i1;
import '../protocol.dart' as _i2;

abstract class KerlaServiceInfo implements _i1.SerializableModel {
  KerlaServiceInfo._({
    this.id,
    required this.type,
    required this.cost,
    required this.title,
    this.description,
    this.endsAt,
    this.freeEndsAt,
  });

  factory KerlaServiceInfo({
    int? id,
    required _i2.KerlaServiceType type,
    required int cost,
    required String title,
    String? description,
    DateTime? endsAt,
    DateTime? freeEndsAt,
  }) = _KerlaServiceInfoImpl;

  factory KerlaServiceInfo.fromJson(Map<String, dynamic> jsonSerialization) {
    return KerlaServiceInfo(
      id: jsonSerialization['id'] as int?,
      type:
          _i2.KerlaServiceType.fromJson((jsonSerialization['type'] as String)),
      cost: jsonSerialization['cost'] as int,
      title: jsonSerialization['title'] as String,
      description: jsonSerialization['description'] as String?,
      endsAt: jsonSerialization['endsAt'] == null
          ? null
          : _i1.DateTimeJsonExtension.fromJson(jsonSerialization['endsAt']),
      freeEndsAt: jsonSerialization['freeEndsAt'] == null
          ? null
          : _i1.DateTimeJsonExtension.fromJson(jsonSerialization['freeEndsAt']),
    );
  }

  /// The database id, set if the object has been inserted into the
  /// database or if it has been fetched from the database. Otherwise,
  /// the id will be null.
  int? id;

  _i2.KerlaServiceType type;

  int cost;

  String title;

  String? description;

  DateTime? endsAt;

  DateTime? freeEndsAt;

  KerlaServiceInfo copyWith({
    int? id,
    _i2.KerlaServiceType? type,
    int? cost,
    String? title,
    String? description,
    DateTime? endsAt,
    DateTime? freeEndsAt,
  });
  @override
  Map<String, dynamic> toJson() {
    return {
      if (id != null) 'id': id,
      'type': type.toJson(),
      'cost': cost,
      'title': title,
      if (description != null) 'description': description,
      if (endsAt != null) 'endsAt': endsAt?.toJson(),
      if (freeEndsAt != null) 'freeEndsAt': freeEndsAt?.toJson(),
    };
  }

  @override
  String toString() {
    return _i1.SerializationManager.encode(this);
  }
}

class _Undefined {}

class _KerlaServiceInfoImpl extends KerlaServiceInfo {
  _KerlaServiceInfoImpl({
    int? id,
    required _i2.KerlaServiceType type,
    required int cost,
    required String title,
    String? description,
    DateTime? endsAt,
    DateTime? freeEndsAt,
  }) : super._(
          id: id,
          type: type,
          cost: cost,
          title: title,
          description: description,
          endsAt: endsAt,
          freeEndsAt: freeEndsAt,
        );

  @override
  KerlaServiceInfo copyWith({
    Object? id = _Undefined,
    _i2.KerlaServiceType? type,
    int? cost,
    String? title,
    Object? description = _Undefined,
    Object? endsAt = _Undefined,
    Object? freeEndsAt = _Undefined,
  }) {
    return KerlaServiceInfo(
      id: id is int? ? id : this.id,
      type: type ?? this.type,
      cost: cost ?? this.cost,
      title: title ?? this.title,
      description: description is String? ? description : this.description,
      endsAt: endsAt is DateTime? ? endsAt : this.endsAt,
      freeEndsAt: freeEndsAt is DateTime? ? freeEndsAt : this.freeEndsAt,
    );
  }
}
