part of '../ui_kit.dart';

class AuthExpandedElevatedButton extends StatelessWidget {
  final Widget child;
  final Function()? onPressed;
  final Guard? guard;
  final double height;
  final double borderRadius;

  const AuthExpandedElevatedButton({
    required this.child,
    required this.onPressed,
    this.guard,
    this.height = 40,
    this.borderRadius = 4,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    final ButtonStyle style = ElevatedButton.styleFrom(
      backgroundColor: ThemePrimaryColors.primary,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(borderRadius),
      ),
    );

    return SizedBox(
      height: height,
      width: double.infinity,
      child: guard != null
          ? GuardedElevatedButton(
              guard: guard,
              onPressed: onPressed,
              style: style,
              child: child,
            )
          : ElevatedButton(
              onPressed: onPressed,
              style: style,
              child: child,
            ),
    );
  }
}
