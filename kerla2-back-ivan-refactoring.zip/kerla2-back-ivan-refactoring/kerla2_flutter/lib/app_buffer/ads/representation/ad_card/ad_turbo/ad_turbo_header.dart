import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';

import '../../../../profile/profile_image/profile_image.dart';
import '../ad_more_info_button.dart';

class AdTurboHeader extends ConsumerWidget {
  const AdTurboHeader({
    super.key,
    required this.ad,
  });

  final Ad ad;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);

    return Container(
      decoration: BoxDecoration(
          borderRadius: const BorderRadiusDirectional.only(
            topStart: Radius.circular(6),
            topEnd: Radius.circular(6),
          ),
          color: theme.canvasColor),
      width: double.infinity,
      height: 52,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 9),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Flexible(
              child: Row(
                children: [
                  ProfileImage(
                    userId: ad.userId!,
                    size: 40,
                    // TODO: Ваня - что должен делать этот параметр?
                    // isShrinkImage: true,
                  ),
                  Flexible(
                    child: Padding(
                      padding: const EdgeInsets.only(left: 10),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            ad.title,
                            style: Theme.of(context)
                                .textTheme
                                .displayLarge
                                ?.copyWith(
                                  fontSize: 16,
                                ),
                            overflow: TextOverflow.ellipsis,
                            maxLines: 1,
                          ),
                          Row(
                            children: [
                              const Icon(
                                Icons.location_on,
                                size: 10,
                              ),
                              const SizedBox(width: 4),
                              Text(
                                ad.region!.title,
                                style: TextStyle(
                                  fontSize: 10,
                                  color: Theme.of(context).primaryColorDark,
                                ),
                              ),
                              Padding(
                                padding:
                                    const EdgeInsets.symmetric(horizontal: 5),
                                child: Text(
                                  '-',
                                  style: TextStyle(
                                    color: Theme.of(context).primaryColorDark,
                                  ),
                                ),
                              ),
                              Text(
                                ad.createdAt.formatDate,
                                style: TextStyle(
                                  fontSize: 10,
                                  color: Theme.of(context).primaryColorDark,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            AdMoreInfoButton(
              ad: ad,
              icon: Icons.more_vert,
              size: 25,
            ),
          ],
        ),
      ),
    );
  }
}
