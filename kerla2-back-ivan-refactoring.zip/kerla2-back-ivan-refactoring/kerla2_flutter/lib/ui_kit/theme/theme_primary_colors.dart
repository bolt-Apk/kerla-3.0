part of '../ui_kit.dart';

class ThemePrimaryColors {
  ThemePrimaryColors._();

  static const Color primary = Color.fromRGBO(1, 150, 162, 1);
  static const Color white = Color(0xFFFFFFFF);
  static const Color filledStar = Color.fromARGB(255, 255, 153, 0);
  static const Color background = Color(0xFF000000);
  static const Color grey = Color(0xFFF3F3F3);
  static const Color darkGrey = Color.fromRGBO(33, 33, 33, 1);
  static const Color warning = Colors.red;
  static const Color boxColor = Color.fromARGB(255, 20, 20, 18);
  static const Color scaffoldBackgroundColor = Color.fromARGB(255, 38, 38, 36);
  static final Color floatingActionButtonColor =
      const Color(0xFF2E3137).withOpacity(0.9);
}
