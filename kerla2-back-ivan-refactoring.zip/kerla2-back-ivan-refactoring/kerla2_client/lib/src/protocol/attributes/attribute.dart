/* AUTOMATICALLY GENERATED CODE DO NOT MODIFY */
/*   To generate run: "serverpod generate"    */

// ignore_for_file: implementation_imports
// ignore_for_file: library_private_types_in_public_api
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: public_member_api_docs
// ignore_for_file: type_literal_in_constant_pattern
// ignore_for_file: use_super_parameters

// ignore_for_file: no_leading_underscores_for_library_prefixes
import 'package:serverpod_client/serverpod_client.dart' as _i1;
import '../protocol.dart' as _i2;

abstract class Attribute implements _i1.SerializableModel {
  Attribute._({
    this.id,
    this.title,
    this.suffixText,
    this.values,
    required this.type,
    this.hasSubAttribute,
    this.subAttributeId,
    this.min,
    this.max,
    this.order,
    this.showOnHome,
  });

  factory Attribute({
    int? id,
    String? title,
    String? suffixText,
    List<String>? values,
    required _i2.AttributeType type,
    bool? hasSubAttribute,
    int? subAttributeId,
    int? min,
    int? max,
    int? order,
    bool? showOnHome,
  }) = _AttributeImpl;

  factory Attribute.fromJson(Map<String, dynamic> jsonSerialization) {
    return Attribute(
      id: jsonSerialization['id'] as int?,
      title: jsonSerialization['title'] as String?,
      suffixText: jsonSerialization['suffixText'] as String?,
      values: (jsonSerialization['values'] as List?)
          ?.map((e) => e as String)
          .toList(),
      type: _i2.AttributeType.fromJson((jsonSerialization['type'] as int)),
      hasSubAttribute: jsonSerialization['hasSubAttribute'] as bool?,
      subAttributeId: jsonSerialization['subAttributeId'] as int?,
      min: jsonSerialization['min'] as int?,
      max: jsonSerialization['max'] as int?,
      order: jsonSerialization['order'] as int?,
      showOnHome: jsonSerialization['showOnHome'] as bool?,
    );
  }

  /// The database id, set if the object has been inserted into the
  /// database or if it has been fetched from the database. Otherwise,
  /// the id will be null.
  int? id;

  String? title;

  String? suffixText;

  List<String>? values;

  _i2.AttributeType type;

  bool? hasSubAttribute;

  int? subAttributeId;

  int? min;

  int? max;

  int? order;

  bool? showOnHome;

  Attribute copyWith({
    int? id,
    String? title,
    String? suffixText,
    List<String>? values,
    _i2.AttributeType? type,
    bool? hasSubAttribute,
    int? subAttributeId,
    int? min,
    int? max,
    int? order,
    bool? showOnHome,
  });
  @override
  Map<String, dynamic> toJson() {
    return {
      if (id != null) 'id': id,
      if (title != null) 'title': title,
      if (suffixText != null) 'suffixText': suffixText,
      if (values != null) 'values': values?.toJson(),
      'type': type.toJson(),
      if (hasSubAttribute != null) 'hasSubAttribute': hasSubAttribute,
      if (subAttributeId != null) 'subAttributeId': subAttributeId,
      if (min != null) 'min': min,
      if (max != null) 'max': max,
      if (order != null) 'order': order,
      if (showOnHome != null) 'showOnHome': showOnHome,
    };
  }

  @override
  String toString() {
    return _i1.SerializationManager.encode(this);
  }
}

class _Undefined {}

class _AttributeImpl extends Attribute {
  _AttributeImpl({
    int? id,
    String? title,
    String? suffixText,
    List<String>? values,
    required _i2.AttributeType type,
    bool? hasSubAttribute,
    int? subAttributeId,
    int? min,
    int? max,
    int? order,
    bool? showOnHome,
  }) : super._(
          id: id,
          title: title,
          suffixText: suffixText,
          values: values,
          type: type,
          hasSubAttribute: hasSubAttribute,
          subAttributeId: subAttributeId,
          min: min,
          max: max,
          order: order,
          showOnHome: showOnHome,
        );

  @override
  Attribute copyWith({
    Object? id = _Undefined,
    Object? title = _Undefined,
    Object? suffixText = _Undefined,
    Object? values = _Undefined,
    _i2.AttributeType? type,
    Object? hasSubAttribute = _Undefined,
    Object? subAttributeId = _Undefined,
    Object? min = _Undefined,
    Object? max = _Undefined,
    Object? order = _Undefined,
    Object? showOnHome = _Undefined,
  }) {
    return Attribute(
      id: id is int? ? id : this.id,
      title: title is String? ? title : this.title,
      suffixText: suffixText is String? ? suffixText : this.suffixText,
      values: values is List<String>?
          ? values
          : this.values?.map((e0) => e0).toList(),
      type: type ?? this.type,
      hasSubAttribute:
          hasSubAttribute is bool? ? hasSubAttribute : this.hasSubAttribute,
      subAttributeId:
          subAttributeId is int? ? subAttributeId : this.subAttributeId,
      min: min is int? ? min : this.min,
      max: max is int? ? max : this.max,
      order: order is int? ? order : this.order,
      showOnHome: showOnHome is bool? ? showOnHome : this.showOnHome,
    );
  }
}
