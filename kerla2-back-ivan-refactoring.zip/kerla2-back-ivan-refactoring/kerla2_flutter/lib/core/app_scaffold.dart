import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:nit_riverpod_notifications/nit_riverpod_notifications.dart';
import 'package:nit_router/nit_router.dart';
import 'package:vpn_connection_detector/vpn_connection_detector.dart';

import '../router/router.dart';

bool _isVpnNotificationDismissed = false;

class AppScaffold extends StatefulWidget {
  const AppScaffold({
    super.key,
    required this.body,
    this.appBar,
    this.showBottomNavBar = true,
    this.extendBodyBehindAppBar = false,
    this.backgroundColor,
    this.resizeToAvoidBottomInset = false,
    this.floatingActionButton,
    this.floatingActionButtonLocation,
    this.floatingActionButtonAnimator,
    this.enableNotificationListeners = true,
  });

  final Widget body;
  final PreferredSizeWidget? appBar;
  final bool showBottomNavBar;
  final bool extendBodyBehindAppBar;
  final Color? backgroundColor;
  final bool resizeToAvoidBottomInset;
  final Widget? floatingActionButton;
  final FloatingActionButtonLocation? floatingActionButtonLocation;
  final FloatingActionButtonAnimator? floatingActionButtonAnimator;
  final bool enableNotificationListeners;

  @override
  State<AppScaffold> createState() => _AppScaffoldState();
}

class _AppScaffoldState extends State<AppScaffold> {
  bool _isVpnConnected = false;

  final vpnDetector = VpnConnectionDetector();

  @override
  void initState() {
    super.initState();
    _checkVpnConnection();
  }

  Future<void> _checkVpnConnection() async {
    _isVpnConnected = await VpnConnectionDetector.isVpnActive();
    vpnDetector.vpnConnectionStream.listen((state) {
      if (state == VpnConnectionState.connected) {
        log("VPN connected.");
        setState(() {
          _isVpnConnected = true;
          _isVpnNotificationDismissed = false;
        });
      } else {
        log("VPN disconnected.");
        setState(() {
          _isVpnConnected = false;
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: widget.backgroundColor,
      extendBodyBehindAppBar: widget.extendBodyBehindAppBar,
      appBar: widget.appBar,
      body: Stack(
        children: [
          NitNotificationListenerWidget(
            notificationPresenter: NitNotification.showNotificationFlash,
            showNotifications: widget.enableNotificationListeners,
            child: widget.body,
          ),
          if (_isVpnConnected && !_isVpnNotificationDismissed)
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: Material(
                color: Colors.red.withOpacity(0.8),
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 16.0, vertical: 8.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Expanded(
                        child: Text(
                          'Мы заметили что вы используете VPN. VPN может повлиять на работу приложения. Пожалуйста отключите его для корректного использования.',
                          style: TextStyle(
                            fontSize: 14,
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.close, color: Colors.white),
                        onPressed: () {
                          setState(() {
                            _isVpnNotificationDismissed = true;
                          });
                        },
                      ),
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
      bottomNavigationBar: widget.showBottomNavBar
          ? NitBottomNavigationBar(
              menuItems: MainMenu.items,
              itemBuilder: (ref, item, isActive) =>
                  MainMenu.bottomNavBarItemBuilder(
                      context, ref, item, isActive),
              type: BottomNavigationBarType.fixed,
              showSelectedLabels: false,
              showUnselectedLabels: false,
            )
          : null,
      resizeToAvoidBottomInset: widget.resizeToAvoidBottomInset,
      floatingActionButton: widget.floatingActionButton,
      floatingActionButtonLocation: widget.floatingActionButtonLocation,
      floatingActionButtonAnimator: widget.floatingActionButtonAnimator,
    );
  }
}
