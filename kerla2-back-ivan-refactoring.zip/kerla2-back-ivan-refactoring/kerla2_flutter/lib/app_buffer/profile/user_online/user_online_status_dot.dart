import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerla2_flutter/common/user_profile_ref_extensions.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class UserOnlineStatusDot extends ConsumerWidget {
  const UserOnlineStatusDot({
    super.key,
    required this.userId,
    this.size = 20,
    this.borderThickness = 5,
  });

  final int userId;
  final double size;
  final double borderThickness;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return ref.watchUserProfileCustom(userId).nitWhen(
          childBuilder: (userProfile) => StatusDot(
            size: size,
            borderThickness: borderThickness,
            iconColor: userProfile.isOnline ? Colors.green : Colors.red,
            borderColor: Colors.white, //
          ),
        );
  }
}
