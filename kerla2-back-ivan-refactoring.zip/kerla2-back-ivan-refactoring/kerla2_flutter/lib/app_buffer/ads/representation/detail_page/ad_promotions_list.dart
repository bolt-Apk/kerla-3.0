import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/app_buffer/ads/service/widget/service_row.dart';
import 'package:kerla2_flutter/router/router.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_app/nit_app.dart';
import 'package:nit_router/nit_router.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class AdPromotionList extends HookConsumerWidget {
  final List<KerlaService>? promotionList;
  final int adId;
  const AdPromotionList({
    super.key,
    required this.promotionList,
    required this.adId,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final List<KerlaService> currentPromotionList = [];
    promotionList?.forEach((element) {
      if (currentPromotionList
          .where((currentElem) => currentElem.type == element.type)
          .isEmpty) {
        currentPromotionList.add(element);
      }
    });

    return Column(
      children: [
        if (currentPromotionList.isNotEmpty)
          ExpansionTile(
            collapsedBackgroundColor: context.theme.canvasColor,
            collapsedIconColor: context.theme.iconTheme.color,
            iconColor: context.theme.iconTheme.color,
            backgroundColor: context.theme.canvasColor,
            title: const Text('Подключенные услуги'),
            children: [
              ListView.builder(
                shrinkWrap: true,
                itemCount: currentPromotionList.length,
                physics: const NeverScrollableScrollPhysics(),
                itemBuilder: (context, index) {
                  final promotion = currentPromotionList[index];

                  return ref
                      .watchMaybeModelCustomAsync<KerlaServiceInfo>(
                    backendFilter: NitBackendFilter.value(
                      type: NitBackendFilterType.equals,
                      fieldName: 'type',
                      fieldValue: promotion.type,
                    ),
                  )
                      .nitWhen(
                    childBuilder: (serviceInfo) {
                      if (promotion.endsAt
                              .toLocal()
                              .getRemainingTimeDescription() ==
                          null) {
                        return const SizedBox.shrink();
                      }
                      return ServiceRow.notToggleable(
                        adId: adId,
                        serviceInfo:
                            serviceInfo!.copyWith(endsAt: promotion.endsAt),
                      );
                    },
                  );
                },
              ),
            ],
          ),
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: MainButton(
            buttonText: 'Подключить услуги',
            onTap: () => context.pushNamed(
              AdNavigationZone.updateService.name,
              pathParameters: AppNavigationParams.adId.set(adId),
            ),
            // color: ref.theme.colorPrimary,
          ),
        )
      ],
    );
  }
}
