import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/common/user_profile_ref_extensions.dart';
import 'package:mime/mime.dart';
import 'package:nit_app/nit_app.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:video_compress/video_compress.dart';
import 'package:wechat_assets_picker/wechat_assets_picker.dart';

part 'selected_media_state.freezed.dart';
part 'selected_media_state.g.dart';

@Riverpod(keepAlive: true)
class AdMediaState extends _$AdMediaState {
  final limit = 7;
  @override
  AdMediaStateModel build({int? adId}) {
    final List<MediaOrAssetWrapper> initMedias = [];
    if (adId != null) {
      initMedias.addAll(
        ref
                .readModel<Ad>(adId)
                .media
                ?.map((e) => MediaOrAssetWrapper(e))
                .toList() ??
            [],
      );
    }
    return AdMediaStateModel(
      items: initMedias,
      isUploading: false,
    );
  }

  Future<bool> openMediaPicker(BuildContext context, AdType adType) async {
    const textDelegate = RussianAssetPickerTextDelegate();

    final List<AssetEntity>? result = await AssetPicker.pickAssets(
      context,
      pickerConfig: AssetPickerConfig(
        selectedAssets: state.items
            .where((e) => e.isAsset)
            .map((e) => e.asAsset())
            .toList(),
        maxAssets: adType == AdType.story ? 1 : limit,
        requestType:
            adType == AdType.ad ? RequestType.image : RequestType.common,
        gridCount: 3,
        pageSize: 120,
        pickerTheme: AssetPicker.themeData(
          const Color(0xFF0196A2),
        ),
        textDelegate: textDelegate,
        filterOptions: FilterOptionGroup(
          videoOption: const FilterOption(
            durationConstraint: DurationConstraint(
              max: Duration(seconds: 60),
            ),
          ),
        ),
      ),
    );
    final media = state.items.where((e) => e.isMedia).toList();

    if (result != null) {
      state = state.copyWith(
        items: [...media, ...result.map((e) => MediaOrAssetWrapper(e))],
      );
    }
    return result != null && result.isNotEmpty;
  }

  Future<void> startUploadMedia() async {
    state = state.copyWith(isUploading: true);

    try {
      final assetsToUpload =
          state.items.where((e) => e.isAsset || e.isBytes).toList();

      for (var item in assetsToUpload) {
        await _uploadSingleAsset(item);
      }
    } catch (e) {
      print('Ошибка при загрузке медиа: $e');
    } finally {
      state = state.copyWith(isUploading: false);
    }
  }

  Future<void> _uploadSingleAsset(MediaOrAssetWrapper item) async {
    try {
      Uint8List? bytes;
      String? mimeType;
      int? duration;
      if (item.isBytes) {
        // edited image
        bytes = item.asBytes()!;
        mimeType = 'image/jpeg';
      } else {
        final asset = item.asAsset();

        final file = await asset.file;

        if (asset.type == AssetType.video) {
          final info = await VideoCompress.compressVideo(
            file!.path,
            quality: VideoQuality.Res1280x720Quality,
            deleteOrigin: false,
          );
          bytes = await info!.file!.readAsBytes();
          mimeType = lookupMimeType(info.file!.path);
        } else {
          bytes = await file!.readAsBytes();
          mimeType = lookupMimeType(file.path);
        }

        duration = asset.type == AssetType.video
            ? asset.duration * 1000
            : asset.duration;
      }

      final nitMedia = await ref.uploadXFileToServer(
          xFile: XFile.fromData(bytes, mimeType: mimeType),
          duration: duration,
          path: 'ad_new/${ref.readCurrentUserProfile?.userId}/story');

      state = state.copyWith(
        loadedCount: (state.loadedCount ?? 0) + 1,
        items: state.items
            .map((e) => e == item ? MediaOrAssetWrapper(nitMedia) : e)
            .toList(),
      );
    } catch (e) {
      print('Ошибка при загрузке ассета: $e');
    }
  }

  // Future<void> compressAndUpload(String videoPath) async {}

  Future<void> setBytes(Uint8List bytes) async {
    state = state.copyWith(items: [
      MediaOrAssetWrapper(bytes),
    ]);
  }

  void reorderItems(int oldIndex, int newIndex) {
    final List<MediaOrAssetWrapper> items = state.items;

    if (newIndex > oldIndex) newIndex -= 1;

    final List<MediaOrAssetWrapper> updatedItems = List.from(items);

    final movedItem = updatedItems.removeAt(oldIndex);
    updatedItems.insert(newIndex, movedItem);

    // Обновляем состояние
    state = state.copyWith(items: updatedItems);
  }

  void toggleItem(MediaOrAssetWrapper item) {
    final items = state.items;
    final index = items.indexWhere(
      (e) =>
          (e.isAsset && e.asAsset().id == item.asAsset().id) ||
          (e.isMedia && e.asMedia().id == item.asMedia().id),
    );
    if (index == -1 && items.length >= limit) {
      return;
    }
    if (index == -1) {
      state = state.copyWith(
        items: [...items, item],
      );
    } else if (index != -1) {
      state = state.copyWith(
        items: [...items.sublist(0, index), ...items.sublist(index + 1)],
      );
    }
  }

  List<NitMedia> getNitMediaList() {
    return state.items.where((e) => e.isMedia).map((e) => e.asMedia()).toList();
  }
}

@freezed
class AdMediaStateModel with _$AdMediaStateModel {
  const factory AdMediaStateModel({
    required List<MediaOrAssetWrapper> items,
    @Default(false) bool isUploading,
    int? loadedCount,
  }) = _AdMediaStateModel;
}

class MediaOrAssetWrapper {
  final Object item;

  MediaOrAssetWrapper(this.item);

  bool get isMedia => item is NitMedia;
  bool get isAsset => item is AssetEntity;
  bool get isBytes => item is Uint8List;

  NitMedia asMedia() => item as NitMedia;
  AssetEntity asAsset() => item as AssetEntity;
  Uint8List? asBytes() => item is Uint8List ? item as Uint8List : null;
}
