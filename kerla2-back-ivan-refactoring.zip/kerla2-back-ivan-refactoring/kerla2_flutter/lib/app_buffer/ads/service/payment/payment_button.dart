import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:guarded_button/guarded_button.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/app/profile/settings/widgets/edit_phone_widget.dart';
import 'package:kerla2_flutter/app_buffer/ads/service/payment/payment/init_payment_call.dart';
import 'package:kerla2_flutter/common/user_profile_ref_extensions.dart';
import 'package:kerla2_flutter/router/router.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_router/nit_router.dart';

class PaymentButton extends ConsumerWidget {
  const PaymentButton({
    super.key,
    required this.amount,
    required this.onSuccess,
    required this.promotions,
    this.buttonText,
    this.isLoading = false,
  });

  final int amount;
  final List<KerlaService> promotions;
  final String? buttonText;
  final VoidCallback onSuccess;

  final bool isLoading;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final themeButtonStyle = ThemeButtonStyle();

    return GuardedElevatedButton(
      guard: Guard(),
      onPressed: isLoading || promotions.isEmpty
          ? null
          : () async {
              // if (amount == 0) {
              //   onSuccess();
              //   return;
              // }
              final phoneNumber = ref.readCurrentUserProfile?.phoneNumber;
              if (phoneNumber == null) {
                showModalBottomSheet(
                    context: context,
                    builder: (context) {
                      return const PhoneEditBottomSheet();
                    });
                return;
              }
              await ref.initPayment(services: promotions);

              // final success = await showModalBottomSheet<bool>(
              //   context: context,
              //   useSafeArea: true,
              //   isScrollControlled: true,
              //   builder: (context) {
              //     return Padding(
              //       padding: EdgeInsets.only(
              //         bottom: MediaQuery.of(context).viewInsets.bottom,
              //       ),
              //       child: SingleChildScrollView(
              //         child: PaymentWidget(
              //           promotions: promotions,
              //         ),
              //       ),
              //     );
              //   },
              // );
              onSuccess();
              if (context.mounted) {
                context.goNamed(
                  MainAreaNavigationZone.homePage.name,
                );
              }
            },
      style: themeButtonStyle.buttonStyle,
      child: isLoading
          ? const CircularProgressIndicator()
          : Text(
              buttonText ?? 'Оплатить',
              style: const TextStyle(
                color: Colors.white,
              ),
            ),
    );
  }
}
