part of '../ui_kit.dart';

class RecommendMessage extends StatelessWidget {
  const RecommendMessage({
    super.key,
    required this.boldText,
    required this.text,
    this.containerColor = Colors.blue,
    this.textColor = Colors.black,
  });

  final String boldText;
  final String text;
  final Color containerColor;
  final Color textColor;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 24, bottom: 12),
      child: Container(
        decoration: BoxDecoration(
          color: containerColor,
          borderRadius: BorderRadius.circular(10),
        ),
        padding: const EdgeInsets.all(12),
        child: RichText(
          text: TextSpan(
            children: <TextSpan>[
              TextSpan(
                text: "$boldText ",
                style: TextStyle(
                  color: textColor,
                  fontWeight: FontWeight.bold,
                ),
              ),
              TextSpan(
                text: text,
                style: TextStyle(
                  color: textColor,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
