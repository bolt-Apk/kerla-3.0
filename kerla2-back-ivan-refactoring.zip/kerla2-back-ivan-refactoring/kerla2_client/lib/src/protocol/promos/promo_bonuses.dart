/* AUTOMATICALLY GENERATED CODE DO NOT MODIFY */
/*   To generate run: "serverpod generate"    */

// ignore_for_file: implementation_imports
// ignore_for_file: library_private_types_in_public_api
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: public_member_api_docs
// ignore_for_file: type_literal_in_constant_pattern
// ignore_for_file: use_super_parameters

// ignore_for_file: no_leading_underscores_for_library_prefixes
import 'package:serverpod_client/serverpod_client.dart' as _i1;
import '../protocol.dart' as _i2;

/// Activations of bonusus
abstract class PromoBonuses implements _i1.SerializableModel {
  PromoBonuses._({
    this.id,
    required this.userId,
    required this.bonusType,
    required this.endsAt,
  });

  factory PromoBonuses({
    int? id,
    required int userId,
    required _i2.KerlaServiceType bonusType,
    required DateTime endsAt,
  }) = _PromoBonusesImpl;

  factory PromoBonuses.fromJson(Map<String, dynamic> jsonSerialization) {
    return PromoBonuses(
      id: jsonSerialization['id'] as int?,
      userId: jsonSerialization['userId'] as int,
      bonusType: _i2.KerlaServiceType.fromJson(
          (jsonSerialization['bonusType'] as String)),
      endsAt: _i1.DateTimeJsonExtension.fromJson(jsonSerialization['endsAt']),
    );
  }

  /// The database id, set if the object has been inserted into the
  /// database or if it has been fetched from the database. Otherwise,
  /// the id will be null.
  int? id;

  int userId;

  _i2.KerlaServiceType bonusType;

  DateTime endsAt;

  PromoBonuses copyWith({
    int? id,
    int? userId,
    _i2.KerlaServiceType? bonusType,
    DateTime? endsAt,
  });
  @override
  Map<String, dynamic> toJson() {
    return {
      if (id != null) 'id': id,
      'userId': userId,
      'bonusType': bonusType.toJson(),
      'endsAt': endsAt.toJson(),
    };
  }

  @override
  String toString() {
    return _i1.SerializationManager.encode(this);
  }
}

class _Undefined {}

class _PromoBonusesImpl extends PromoBonuses {
  _PromoBonusesImpl({
    int? id,
    required int userId,
    required _i2.KerlaServiceType bonusType,
    required DateTime endsAt,
  }) : super._(
          id: id,
          userId: userId,
          bonusType: bonusType,
          endsAt: endsAt,
        );

  @override
  PromoBonuses copyWith({
    Object? id = _Undefined,
    int? userId,
    _i2.KerlaServiceType? bonusType,
    DateTime? endsAt,
  }) {
    return PromoBonuses(
      id: id is int? ? id : this.id,
      userId: userId ?? this.userId,
      bonusType: bonusType ?? this.bonusType,
      endsAt: endsAt ?? this.endsAt,
    );
  }
}
