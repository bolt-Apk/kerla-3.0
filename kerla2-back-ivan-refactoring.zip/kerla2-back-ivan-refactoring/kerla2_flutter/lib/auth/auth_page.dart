import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerla2_flutter/auth/state/auth_page_state.dart';
import 'package:kerla2_flutter/auth/widgets/email_input_widget.dart';
import 'package:kerla2_flutter/auth/widgets/oauth_providers_widget.dart';
import 'package:kerla2_flutter/router/navigation_zones/auth_navigation_zone.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

import 'state/auth_mode_enum.dart';
import 'widgets/auth_header_widget.dart';
import 'widgets/password_input_widget copy.dart';
import 'widgets/process_password_button.dart';

class AuthPage extends ConsumerWidget {
  const AuthPage({
    super.key,
    // required this.mode,
  });

  // final AuthModeEnum mode;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Form(
      child: Column(
        children: [
          const AuthHeaderWidget(
            mode: AuthModeEnum.signIn,
          ),
          const Gap(16),
          const EmailInputWidget(),
          const Gap(16),
          const PasswordInputWidget(),
          const Padding(
            padding: EdgeInsets.only(top: 12, bottom: 2),
            child: ProcessPasswordButton(
              mode: AuthModeEnum.signIn,
            ),
          ),
          Button.outlined(
            title: 'Зарегистрироваться',
            onPressed: () {
              ref
                  .read(authPageStateProvider.notifier)
                  .setPage(AuthAreaNavigationZone.fillUserProfile);
            },
          ),
          Button.text(
            title: 'Забыли пароль? ',
            onPressed: () {
              ref
                  .read(authPageStateProvider.notifier)
                  .setPage(AuthAreaNavigationZone.recover);
            },
          ),
          if (!kIsWeb) const OauthProvidersWidget(),

          // MainButton(
          //   buttonText: 'Зарегистрироваться',
          //   onTap: () {
          //     ref
          //         .read(authPageStateProvider.notifier)
          //         .setPage(AuthAreaNavigationZone.registration);
          //   },
          // ),
          const Gap(10),
          // const OauthProvidersWidget(),
        ],
      ),
    );
  }
}
