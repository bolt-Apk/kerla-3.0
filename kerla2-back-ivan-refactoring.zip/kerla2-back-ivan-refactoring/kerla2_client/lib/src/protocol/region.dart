/* AUTOMATICALLY GENERATED CODE DO NOT MODIFY */
/*   To generate run: "serverpod generate"    */

// ignore_for_file: implementation_imports
// ignore_for_file: library_private_types_in_public_api
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: public_member_api_docs
// ignore_for_file: type_literal_in_constant_pattern
// ignore_for_file: use_super_parameters

// ignore_for_file: no_leading_underscores_for_library_prefixes
import 'package:serverpod_client/serverpod_client.dart' as _i1;

abstract class Region implements _i1.SerializableModel {
  Region._({
    this.id,
    required this.title,
    required this.latitude,
    required this.longitude,
    required this.radius,
  });

  factory Region({
    int? id,
    required String title,
    required double latitude,
    required double longitude,
    required double radius,
  }) = _RegionImpl;

  factory Region.fromJson(Map<String, dynamic> jsonSerialization) {
    return Region(
      id: jsonSerialization['id'] as int?,
      title: jsonSerialization['title'] as String,
      latitude: (jsonSerialization['latitude'] as num).toDouble(),
      longitude: (jsonSerialization['longitude'] as num).toDouble(),
      radius: (jsonSerialization['radius'] as num).toDouble(),
    );
  }

  /// The database id, set if the object has been inserted into the
  /// database or if it has been fetched from the database. Otherwise,
  /// the id will be null.
  int? id;

  String title;

  double latitude;

  double longitude;

  double radius;

  Region copyWith({
    int? id,
    String? title,
    double? latitude,
    double? longitude,
    double? radius,
  });
  @override
  Map<String, dynamic> toJson() {
    return {
      if (id != null) 'id': id,
      'title': title,
      'latitude': latitude,
      'longitude': longitude,
      'radius': radius,
    };
  }

  @override
  String toString() {
    return _i1.SerializationManager.encode(this);
  }
}

class _Undefined {}

class _RegionImpl extends Region {
  _RegionImpl({
    int? id,
    required String title,
    required double latitude,
    required double longitude,
    required double radius,
  }) : super._(
          id: id,
          title: title,
          latitude: latitude,
          longitude: longitude,
          radius: radius,
        );

  @override
  Region copyWith({
    Object? id = _Undefined,
    String? title,
    double? latitude,
    double? longitude,
    double? radius,
  }) {
    return Region(
      id: id is int? ? id : this.id,
      title: title ?? this.title,
      latitude: latitude ?? this.latitude,
      longitude: longitude ?? this.longitude,
      radius: radius ?? this.radius,
    );
  }
}
