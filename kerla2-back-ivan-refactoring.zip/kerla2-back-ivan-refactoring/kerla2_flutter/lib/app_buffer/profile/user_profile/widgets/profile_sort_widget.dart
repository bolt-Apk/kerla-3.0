import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_svg/svg.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';

import 'sort_bottom_sheet.dart';

class ProfileSortWidget extends ConsumerWidget {
  const ProfileSortWidget({super.key, required this.userId});
  final int userId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    return CommonButton(
      backgroundColor: theme.canvasColor,
      action: () {
        showModalBottomSheet<void>(
          isScrollControlled: true,
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(
              top: Radius.circular(10),
            ),
          ),
          context: context,
          builder: (BuildContext context) {
            return Container(
              margin: EdgeInsets.only(
                bottom: MediaQuery.of(context).viewInsets.bottom,
              ),
              height: 300,
              child: SortBottomSheet(
                userId: userId,
              ),
            );
          },
        );
      },
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            Row(
              children: [
                // TODO: вернуть
                // Text(
                //   '${user.adCount.toString()} ${ads(user.adCount!)}',
                //   style: Theme.of(context).textTheme.headlineMedium,
                // ),
                // const Spacer(),
                Padding(
                  padding: const EdgeInsets.only(right: 4),
                  child: SvgPicture.asset(
                    AppIconsSvg.sort,
                    color: theme.iconTheme.color,
                    height: 18,
                    width: 18,
                  ),
                ),
                const Text(
                  'Сортировка',
                ),
              ],
            ),
            // TODO: вернуть
            // if (user.city != null && user.city!.isNotEmpty)
            //   Row(
            //     children: [
            //       const Icon(
            //         Icons.radio_button_checked,
            //         size: 12,
            //       ),
            //       Padding(
            //         padding: const EdgeInsets.symmetric(horizontal: 4),
            //         child: Text(user.city!),
            //       ),
            //     ],
            //   ),
          ],
        ),
      ),
    );
  }
}
