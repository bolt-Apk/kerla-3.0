part of '../ui_kit.dart';

class MainBottomSheet extends StatelessWidget {
  const MainBottomSheet({
    super.key,
    required this.child,
    this.color = Colors.white,
  });

  final Color color;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(8),
          topRight: Radius.circular(8),
        ),
        color: color,
      ),
      child: child,
    );
  }
}
