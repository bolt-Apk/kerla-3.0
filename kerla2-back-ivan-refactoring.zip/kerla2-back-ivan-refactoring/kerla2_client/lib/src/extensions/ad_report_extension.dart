import 'package:kerla2_client/kerla2_client.dart';

extension AdReportReasonExtension on AdReportReason {
  String get title {
    switch (this) {
      case AdReportReason.wrongCategory:
        return 'Неверная категория';
      case AdReportReason.prohibitedGoods:
        return 'Запрещенный товар';
      case AdReportReason.obsceneContent:
        return 'Непристойное содержание';
      case AdReportReason.scam:
        return 'Мошенничество';
      case AdReportReason.spam:
        return 'Спам';
      case AdReportReason.other:
        return 'Другое';
    }
  }

  String get description {
    switch (this) {
      case AdReportReason.wrongCategory:
        return 'Объявление находится в неверной категории';
      case AdReportReason.prohibitedGoods:
        return 'Наркотическая и табачная продукция, алкоголь и другие запрещенные товары';
      case AdReportReason.obsceneContent:
        return 'Порнографическое, экстремистское, эротическое, нецензурное содержание';
      case AdReportReason.scam:
        return 'Обман, вымогательство, незаконные операции с целью наживы';
      case AdReportReason.spam:
        return 'Повторное размещение объявления о продаже одного и того же товара, рассылка рекламы и.т д';
      case AdReportReason.other:
        return 'Иная причина нарушения размещения объявления';
    }
  }
}
