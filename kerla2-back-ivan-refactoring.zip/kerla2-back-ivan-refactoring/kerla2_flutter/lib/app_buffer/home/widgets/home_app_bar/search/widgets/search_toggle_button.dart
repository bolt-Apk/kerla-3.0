import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/app_buffer/home/filters/list_filter/attribute_filter/state/filter_attribute_state.dart';
import 'package:kerla2_flutter/app_buffer/home/widgets/home_app_bar/search/providers.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';

class SearchToggleButton extends ConsumerWidget {
  const SearchToggleButton({
    super.key,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isSearchFieldVisibleValue = ref.watch(isSearchFieldVisible);

    return InkWell(
      onTap: () {
        ref.read(isSearchFieldVisible.notifier).state =
            !isSearchFieldVisibleValue;
        ref.read(searchTabState.notifier).state = SearchState.ads;
        ref.read(searchString.notifier).state = "";

        if (isSearchFieldVisibleValue) {
          ref
              .read(filterStateProvider(AdListType.main).notifier)
              .updateSearchString('');
        }
      },
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: AnimatedSwitcher(
          duration: const Duration(milliseconds: 100),
          child: isSearchFieldVisibleValue
              ? Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: SvgPicture.asset(
                    AppIconsSvg.close,
                    colorFilter: ColorFilter.mode(
                      Theme.of(context).iconTheme.color ?? Colors.black,
                      BlendMode.srcIn,
                    ),
                    height: 18,
                    width: 18,
                  ),
                )
              : SvgPicture.asset(
                  AppIconsSvg.search,
                  colorFilter: ColorFilter.mode(
                    Theme.of(context).iconTheme.color ?? Colors.black,
                    BlendMode.srcIn,
                  ),
                  height: 18,
                  width: 18,
                ),
        ),
      ),
    );
  }
}
