part of '../ui_kit.dart';

class StatusDot extends StatelessWidget {
  const StatusDot({
    super.key,
    required this.size,
    required this.iconColor,
    required this.borderColor,
    required this.borderThickness,

    // this.isShrinkImage = false,
    // this.isIconStatusDot = false,
  });

  final double size;
  final Color iconColor;
  final Color borderColor;
  final double borderThickness;

  @override
  Widget build(BuildContext context) {
    return CircleAvatar(
      backgroundColor: borderColor,
      radius: size / 2,
      child: CircleAvatar(
        backgroundColor: iconColor,
        radius: size / 2 - borderThickness,
      ),
    );
  }
}
