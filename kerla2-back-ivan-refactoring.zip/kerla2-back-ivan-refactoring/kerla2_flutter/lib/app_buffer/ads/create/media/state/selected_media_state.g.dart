// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'selected_media_state.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$adMediaStateHash() => r'a61c28811331d2ec8a044bc6aeaeec7c6abed41b';

/// Copied from Dart SDK
class _SystemHash {
  _SystemHash._();

  static int combine(int hash, int value) {
    // ignore: parameter_assignments
    hash = 0x1fffffff & (hash + value);
    // ignore: parameter_assignments
    hash = 0x1fffffff & (hash + ((0x0007ffff & hash) << 10));
    return hash ^ (hash >> 6);
  }

  static int finish(int hash) {
    // ignore: parameter_assignments
    hash = 0x1fffffff & (hash + ((0x03ffffff & hash) << 3));
    // ignore: parameter_assignments
    hash = hash ^ (hash >> 11);
    return 0x1fffffff & (hash + ((0x00003fff & hash) << 15));
  }
}

abstract class _$AdMediaState extends BuildlessNotifier<AdMediaStateModel> {
  late final int? adId;

  AdMediaStateModel build({
    int? adId,
  });
}

/// See also [AdMediaState].
@ProviderFor(AdMediaState)
const adMediaStateProvider = AdMediaStateFamily();

/// See also [AdMediaState].
class AdMediaStateFamily extends Family<AdMediaStateModel> {
  /// See also [AdMediaState].
  const AdMediaStateFamily();

  /// See also [AdMediaState].
  AdMediaStateProvider call({
    int? adId,
  }) {
    return AdMediaStateProvider(
      adId: adId,
    );
  }

  @override
  AdMediaStateProvider getProviderOverride(
    covariant AdMediaStateProvider provider,
  ) {
    return call(
      adId: provider.adId,
    );
  }

  static const Iterable<ProviderOrFamily>? _dependencies = null;

  @override
  Iterable<ProviderOrFamily>? get dependencies => _dependencies;

  static const Iterable<ProviderOrFamily>? _allTransitiveDependencies = null;

  @override
  Iterable<ProviderOrFamily>? get allTransitiveDependencies =>
      _allTransitiveDependencies;

  @override
  String? get name => r'adMediaStateProvider';
}

/// See also [AdMediaState].
class AdMediaStateProvider
    extends NotifierProviderImpl<AdMediaState, AdMediaStateModel> {
  /// See also [AdMediaState].
  AdMediaStateProvider({
    int? adId,
  }) : this._internal(
          () => AdMediaState()..adId = adId,
          from: adMediaStateProvider,
          name: r'adMediaStateProvider',
          debugGetCreateSourceHash:
              const bool.fromEnvironment('dart.vm.product')
                  ? null
                  : _$adMediaStateHash,
          dependencies: AdMediaStateFamily._dependencies,
          allTransitiveDependencies:
              AdMediaStateFamily._allTransitiveDependencies,
          adId: adId,
        );

  AdMediaStateProvider._internal(
    super._createNotifier, {
    required super.name,
    required super.dependencies,
    required super.allTransitiveDependencies,
    required super.debugGetCreateSourceHash,
    required super.from,
    required this.adId,
  }) : super.internal();

  final int? adId;

  @override
  AdMediaStateModel runNotifierBuild(
    covariant AdMediaState notifier,
  ) {
    return notifier.build(
      adId: adId,
    );
  }

  @override
  Override overrideWith(AdMediaState Function() create) {
    return ProviderOverride(
      origin: this,
      override: AdMediaStateProvider._internal(
        () => create()..adId = adId,
        from: from,
        name: null,
        dependencies: null,
        allTransitiveDependencies: null,
        debugGetCreateSourceHash: null,
        adId: adId,
      ),
    );
  }

  @override
  NotifierProviderElement<AdMediaState, AdMediaStateModel> createElement() {
    return _AdMediaStateProviderElement(this);
  }

  @override
  bool operator ==(Object other) {
    return other is AdMediaStateProvider && other.adId == adId;
  }

  @override
  int get hashCode {
    var hash = _SystemHash.combine(0, runtimeType.hashCode);
    hash = _SystemHash.combine(hash, adId.hashCode);

    return _SystemHash.finish(hash);
  }
}

mixin AdMediaStateRef on NotifierProviderRef<AdMediaStateModel> {
  /// The parameter `adId` of this provider.
  int? get adId;
}

class _AdMediaStateProviderElement
    extends NotifierProviderElement<AdMediaState, AdMediaStateModel>
    with AdMediaStateRef {
  _AdMediaStateProviderElement(super.provider);

  @override
  int? get adId => (origin as AdMediaStateProvider).adId;
}
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
