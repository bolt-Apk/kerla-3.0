/* AUTOMATICALLY GENERATED CODE DO NOT MODIFY */
/*   To generate run: "serverpod generate"    */

// ignore_for_file: implementation_imports
// ignore_for_file: library_private_types_in_public_api
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: public_member_api_docs
// ignore_for_file: type_literal_in_constant_pattern
// ignore_for_file: use_super_parameters

// ignore_for_file: no_leading_underscores_for_library_prefixes
import 'package:serverpod_client/serverpod_client.dart' as _i1;
import '../protocol.dart' as _i2;

/// Static table of promocode levels
abstract class PromoLevel implements _i1.SerializableModel {
  PromoLevel._({
    this.id,
    required this.serviceId,
    required this.duration,
    required this.requiredInvites,
  });

  factory PromoLevel({
    int? id,
    required List<_i2.KerlaServiceType> serviceId,
    required int duration,
    required int requiredInvites,
  }) = _PromoLevelImpl;

  factory PromoLevel.fromJson(Map<String, dynamic> jsonSerialization) {
    return PromoLevel(
      id: jsonSerialization['id'] as int?,
      serviceId: (jsonSerialization['serviceId'] as List)
          .map((e) => _i2.KerlaServiceType.fromJson((e as String)))
          .toList(),
      duration: jsonSerialization['duration'] as int,
      requiredInvites: jsonSerialization['requiredInvites'] as int,
    );
  }

  /// The database id, set if the object has been inserted into the
  /// database or if it has been fetched from the database. Otherwise,
  /// the id will be null.
  int? id;

  List<_i2.KerlaServiceType> serviceId;

  /// Duration of the promo level in minutes
  int duration;

  /// Number of people who need be invited for this level
  int requiredInvites;

  PromoLevel copyWith({
    int? id,
    List<_i2.KerlaServiceType>? serviceId,
    int? duration,
    int? requiredInvites,
  });
  @override
  Map<String, dynamic> toJson() {
    return {
      if (id != null) 'id': id,
      'serviceId': serviceId.toJson(valueToJson: (v) => v.toJson()),
      'duration': duration,
      'requiredInvites': requiredInvites,
    };
  }

  @override
  String toString() {
    return _i1.SerializationManager.encode(this);
  }
}

class _Undefined {}

class _PromoLevelImpl extends PromoLevel {
  _PromoLevelImpl({
    int? id,
    required List<_i2.KerlaServiceType> serviceId,
    required int duration,
    required int requiredInvites,
  }) : super._(
          id: id,
          serviceId: serviceId,
          duration: duration,
          requiredInvites: requiredInvites,
        );

  @override
  PromoLevel copyWith({
    Object? id = _Undefined,
    List<_i2.KerlaServiceType>? serviceId,
    int? duration,
    int? requiredInvites,
  }) {
    return PromoLevel(
      id: id is int? ? id : this.id,
      serviceId: serviceId ?? this.serviceId.map((e0) => e0).toList(),
      duration: duration ?? this.duration,
      requiredInvites: requiredInvites ?? this.requiredInvites,
    );
  }
}
