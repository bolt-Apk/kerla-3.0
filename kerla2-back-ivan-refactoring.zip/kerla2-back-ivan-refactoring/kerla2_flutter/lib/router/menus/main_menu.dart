part of '../router.dart';

class MainMenu {
  static final items = [
    const NitMenuItem.svg(
      route: MainAreaNavigationZone.homePage,
      displayTitle: 'Лента',
      svgIcon: AppNavigationIconsSvg.kerlaHome,
    ),
    // NitMenuItem.svg(
    //   route: MainAreaNavigationZone.stories,
    //   displayTitle: 'Stories',
    //   svgIcon: AppNavigationIconsSvg.stories,
    // ),
    NitMenuItem.svg(
      route: AdNavigationZone.adPage,
      customOnPressed: (ref) => _showPublicationBottomSheet(ref.context, ref),
      displayTitle: 'Добавить',
      svgIcon: AppNavigationIconsSvg.addPublication,
    ),
    NitMenuItem.svg(
      route: ChatNavigationZone.chats,
      customOnPressed: (ref) => _pushPageOrShowLoginBottomSheet(
          ref.context, ref, ChatNavigationZone.chats),
      displayTitle: 'Чаты',
      svgIcon: AppNavigationIconsSvg.chats,
      displayProvider: hasUnreadChatProvider,
    ),
    NitMenuItem.svg(
      route: MainAreaNavigationZone.profile,
      customOnPressed: (ref) => _pushPageOrShowLoginBottomSheet(
          ref.context, ref, MainAreaNavigationZone.profile),
      displayTitle: 'Профиль',
      svgIcon: AppNavigationIconsSvg.profile,
    ),
  ];

  static void _showPublicationBottomSheet(BuildContext context, WidgetRef ref) {
    if (ref.signedIn) {
      // final callerIndex = state.items.indexWhere(
      //   (item) => item.onPressed == _showPublicationBottomSheet,
      // );

      // if (state.activeIndex == callerIndex) {
      //   ref.read(nitMenuProvider(items).notifier).setActiveIndex(
      //         state.previousIndex ?? state.defaultIndex,
      //         savePrevious: false,
      //       );

      //   if (context.canPop()) context.pop();

      //   return;
      // }

      // ref.read(nitMenuProvider(items).notifier).setActiveIndex(callerIndex);

      // Scaffold.of(context).showBottomSheet(
      //   (context) => const PublicationBottomSheet(
      //     maxCount: maxCount,
      //   ),
      //   enableDrag: false,
      // );

      showModalBottomSheet(
        useRootNavigator: true,
        context: context,
        builder: (context) => DecoratedBox(
          decoration: BoxDecoration(color: context.theme.canvasColor),
          child: SafeArea(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const PublicationBottomSheet(),
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: IconButton(
                    onPressed: () => context.pop(),
                    icon: AnimatedRotation(
                      turns: 0.125,
                      duration: const Duration(milliseconds: 200),
                      child: SvgPicture.asset(
                        AppNavigationIconsSvg.addPublication,
                        colorFilter: ColorFilter.mode(
                          context.theme.iconTheme.color ?? Colors.black,
                          BlendMode.srcIn,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        enableDrag: false,
        useSafeArea: true,
      );
    } else {
      _pushPageOrShowLoginBottomSheet(
          context, ref, MainAreaNavigationZone.homePage);
    }
  }

  static void _pushPageOrShowLoginBottomSheet(
    BuildContext context,
    WidgetRef ref,
    NavigationZoneRoute zone,
  ) {
    // TODO: вернуть и переделать
    final isAuth = ref.signedIn;

    // final callerIndex = state.items.indexWhere(
    //   (item) => item.onPressed == _pushPageOrShowLoginBottomSheet,
    // );

    if (isAuth) {
      context.goNamed(zone.name);
      // ref.read(nitMenuProvider(items).notifier).setActiveIndex(callerIndex);
    } else {
      if (Navigator.canPop(context)) {
        Navigator.pop(context);
        return;
      }
      // ref.read(nitMenuProvider(items).notifier).setActiveIndex(callerIndex);
      context.showAuthBottomSheet();
    }
  }

  static BottomNavigationBarItem bottomNavBarItemBuilder(
    BuildContext context,
    WidgetRef ref,
    NitMenuItem item,
    bool isActive,
  ) {
    int? badgeProvider;
    if (item.displayProvider != null) {
      badgeProvider = ref.watch(item.displayProvider!) as int;
    }
    return BottomNavigationBarItem(
      icon: Stack(
        children: [
          Badge(
            isLabelVisible: badgeProvider != null && badgeProvider > 0,
            label: Builder(
              builder: (context) {
                return Text(
                  '$badgeProvider',
                  style: context.textTheme.labelSmall!.copyWith(
                    color: context.colorScheme.onError,
                  ),
                );
              },
            ),
            child: item.svgIcon != null
                ? SvgPicture.asset(
                    item.svgIcon!,
                    // width: isActive ? 32 : 24,
                    height: isActive ? 32 : 24,
                    colorFilter: ColorFilter.mode(
                      item.route == MainAreaNavigationZone.homePage
                          ? context.colorScheme.primary
                          : isActive
                              ? context.colorScheme.primary
                              : context.theme.iconTheme.color ?? Colors.black,
                      BlendMode.srcIn,
                    ),
                  )
                : Icon(item.iconData),
          ),
        ],
      ),
      label: item.displayTitle,
    );
  }
}
