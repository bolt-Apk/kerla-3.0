import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerla2_flutter/common/user_profile_ref_extensions.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_app/nit_app.dart';

class EditProfileDescriptionWidget extends ConsumerWidget {
  const EditProfileDescriptionWidget({
    super.key,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final userProfile = ref.currentUserProfile!;

    return TextSettingsRow(
      title: 'О себе',
      subtitle: userProfile.profileDescription ?? '',
      editingBottomSheet: TextEditingBottomSheet(
        initialValue: userProfile.profileDescription ?? '',
        title: 'О себе',
        keyboardType: TextInputType.multiline,
        maxLength: 3000,
        maxLines: 5,
        acceptAction: (String newValue) async =>
            null !=
            await ref.saveModel(
              userProfile.copyWith(profileDescription: newValue),
            ),
      ),
    );
  }
}
