import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/common/user_profile_ref_extensions.dart';

import 'package:nit_app/nit_app.dart';

extension AdUtils on WidgetRef {
  bool isAdAllowed(Ad ad) {
    final userId = read(nitSessionStateProvider).signedInUserId;
    return ad.onlyForGender == null ||
        (userId != null && ad.onlyForGender == currentUserProfile?.gender);
  }
}
