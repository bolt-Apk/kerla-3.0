import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerla2_flutter/auth/state/auth_page_state.dart';

import '../../ui_kit/ui_kit.dart';

class PasswordInputWidget extends ConsumerWidget {
  const PasswordInputWidget({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(authPageStateProvider);
    return TextEntryField.password(
        controller: state.passwordController,
        validator: (value) {
          if (value == null || value.isEmpty) {
            return 'Поле не может быть пустым';
          }
          return null;
        },
        label: 'Пароль');
  }
}
