import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/core/app_backend_filters.dart';
import 'package:nit_app/nit_app.dart';

extension FavoritesExtension on WidgetRef {
  AsyncValue<List<FavouriteAd>> get watchFavorites =>
      watchEntityListAsync<FavouriteAd>(
          backendFilter: AppBackendFilter.userId.equals(signedInUserId!));
}

extension UserExtension on WidgetRef {
  AsyncValue<UserProfile> get watchUser => watchModelCustomAsync<UserProfile>(
        backendFilter: AppBackendFilter.userId.equals(signedInUserId!),
      );

  // AsyncValue<UserProfile> get readUser => readModelCustomAsync<UserProfile>(
  //       backendFilter: AppBackendFilter.userId.equals(signedInUserId!),
  //     );
}
