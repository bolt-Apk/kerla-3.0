import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';

class HomeFilterDropDownRow extends HookConsumerWidget {
  final Attribute attribute;

  final String value;

  final List<String> values;
  final ValueNotifier<String> valueNotifier;

  const HomeFilterDropDownRow({
    super.key,
    required this.attribute,
    required this.value,
    required this.values,
    required this.valueNotifier,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return InkWell(
      onTap: () => valueNotifier.value = value,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10),
        child: SizedBox(
          height: 30,
          child: Row(
            children: [
              CustomCheckBox(
                value: valueNotifier.value == value,
              ),
              const SizedBox(width: 7),
              Text(
                value,
                style: Theme.of(context).textTheme.titleMedium,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
