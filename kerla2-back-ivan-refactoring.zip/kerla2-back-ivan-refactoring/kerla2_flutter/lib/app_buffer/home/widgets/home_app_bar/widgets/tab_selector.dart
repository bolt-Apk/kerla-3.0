import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kerla2_flutter/app_buffer/home/widgets/home_app_bar/search/providers.dart';
import 'package:nit_app/nit_app.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class TabSelector extends ConsumerWidget {
  const TabSelector({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isSubscribedAdsValue = ref.watch(isSubscribedAds);

    return Row(
      children: [
        _buildTab(
          context,
          'Для вас',
          !isSubscribedAdsValue,
          onTap: () => ref.read(isSubscribedAds.notifier).state = false,
        ),
        const SizedBox(width: 16),
        if (ref.signedIn)
          _buildTab(
            context,
            'Подписки',
            isSubscribedAdsValue,
            onTap: () => ref.read(isSubscribedAds.notifier).state = true,
          ),
      ],
    );
  }

  Widget _buildTab(
    BuildContext context,
    String text,
    bool isActive, {
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Text(
        text,
        style: isActive
            ? context.textTheme.titleLarge
            : context.textTheme.titleLarge?.copyWith(
                color: context.colorScheme.onSurface.withOpacity(0.7),
                fontSize: 16,
              ),
      ),
    );
  }
}
