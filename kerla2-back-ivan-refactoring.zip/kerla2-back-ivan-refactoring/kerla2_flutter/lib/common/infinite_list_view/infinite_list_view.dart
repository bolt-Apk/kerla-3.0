import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:nit_app/nit_app.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

sealed class InfiniteListViewGroupedItem {}

class InfiniteListViewGroupHeader extends InfiniteListViewGroupedItem {
  final Widget widget;
  InfiniteListViewGroupHeader(this.widget);
}

class InfiniteListViewModel<Entity extends SerializableModel>
    extends InfiniteListViewGroupedItem {
  final Entity model;
  InfiniteListViewModel(this.model);
}

class InfiniteListView<Entity extends SerializableModel>
    extends StatefulHookConsumerWidget {
  const InfiniteListView({
    super.key,
    required this.listViewConfig,
    required this.listTileBuilder,
    this.separatorBuilder,
    this.onFirstLoadTrigger,
    this.emptyListPlaceHolder = const SizedBox.shrink(),
    this.groupBy,
    this.groupDivider,
  });

  final EntityListConfig<Entity> listViewConfig;
  final Widget Function(BuildContext context, int index)? separatorBuilder;
  final Widget Function(BuildContext context, Entity model) listTileBuilder;
  final Function(WidgetRef ref, List<Entity> models)? onFirstLoadTrigger;
  final Widget emptyListPlaceHolder;
  final List<dynamic> Function(WidgetRef ref, List<Entity> items)? groupBy;
  final Widget? groupDivider;

  @override
  ConsumerState<ConsumerStatefulWidget> createState() => _State<Entity>();

  static List<InfiniteListViewGroupedItem>
      groupByDate<Entity extends SerializableModel>(
    WidgetRef ref,
    List<Entity> items,
    DateTime Function(Entity item) groupingFieldGetter,
    Widget Function(WidgetRef ref, DateTime date) groupHeaderBuilder,
  ) {
    items.sort(
      (a, b) => groupingFieldGetter(b).compareTo(
        groupingFieldGetter(a),
      ),
    );

    final grouped = <InfiniteListViewGroupedItem>[];
    DateTime? lastDate;

    for (final item in items) {
      final timestamp = groupingFieldGetter(item);
      final date = DateTime(timestamp.year, timestamp.month, timestamp.day);

      if (lastDate == null || lastDate != date) {
        grouped.add(
          InfiniteListViewGroupHeader(groupHeaderBuilder(ref, date)),
        );
        lastDate = date;
      }

      grouped.add(InfiniteListViewModel(item));
    }
    return grouped;
  }
}

class _State<Entity extends SerializableModel>
    extends ConsumerState<InfiniteListView<Entity>> {
  bool isLoadingMore = false;
  bool hasMaybeMore = true;
  bool isFirstLoadTriggered = false;

  @override
  Widget build(BuildContext context) {
    final asyncList = ref.watchEntityListCustomizedAsync<Entity>(
      entityListConfig: widget.listViewConfig,
    );

    return asyncList.nitWhenList(
      loadingItemsCount: 5,
      childBuilder: (items) {
        if (asyncList.hasValue &&
            widget.onFirstLoadTrigger != null &&
            !isFirstLoadTriggered) {
          widget.onFirstLoadTrigger?.call(ref, items);
          isFirstLoadTriggered = true;
        }

        final displayItems = widget.groupBy != null
            ? widget.groupBy!(ref, items) // сгруппированные
            : items; // плоский список

        Widget _itemBuilder(BuildContext context, int index) {
          final item = displayItems[index];

          if (item is InfiniteListViewGroupHeader) {
            final isFirstHeader = index == 0;

            if (isFirstHeader || widget.groupDivider == null) {
              return item.widget;
            } else {
              return Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  widget.groupDivider!, // 👈 вставляем перед заголовком
                  item.widget,
                ],
              );
            }
          } else if (item is InfiniteListViewModel) {
            return widget.listTileBuilder(context, item.model as Entity);
          } else if (item is Entity) {
            return widget.listTileBuilder(context, item);
          }

          return const SizedBox.shrink();
        }

        return NotificationListener<ScrollNotification>(
          onNotification: (scrollInfo) {
            if (hasMaybeMore &&
                !isLoadingMore &&
                scrollInfo.metrics.pixels >=
                    scrollInfo.metrics.maxScrollExtent - 200) {
              setState(() => isLoadingMore = true);

              ref
                  .loadNextPageForCustomizedEntityListMore<Entity>(
                entityListConfig: widget.listViewConfig,
              )
                  .then((res) {
                if (mounted) {
                  setState(() {
                    hasMaybeMore = res;
                    isLoadingMore = false;
                  });
                }
              });
            }
            return false;
          },
          child: displayItems.isEmpty
              ? widget.emptyListPlaceHolder
              : widget.separatorBuilder != null
                  ? ListView.separated(
                      itemCount: displayItems.length,
                      itemBuilder: _itemBuilder,
                      separatorBuilder: widget.separatorBuilder!)
                  : ListView.builder(
                      itemCount: displayItems.length,
                      itemBuilder: _itemBuilder,
                    ),
        );
      },
    );
  }
}
