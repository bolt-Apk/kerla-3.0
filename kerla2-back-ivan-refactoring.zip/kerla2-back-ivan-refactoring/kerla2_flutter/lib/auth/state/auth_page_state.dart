import 'dart:developer';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/auth/state/auth_mode_enum.dart';
import 'package:kerla2_flutter/common/user_profile_ref_extensions.dart';
import 'package:kerla2_flutter/core/core.dart';
import 'package:kerla2_flutter/router/navigation_zones/auth_navigation_zone.dart';
import 'package:nit_app/nit_app.dart';
import 'package:nit_riverpod_notifications/nit_riverpod_notifications.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:serverpod_auth_email_flutter/serverpod_auth_email_flutter.dart';

part 'auth_page_state.freezed.dart';
part 'auth_page_state.g.dart';

@freezed
class AuthPageStateModel with _$AuthPageStateModel {
  factory AuthPageStateModel({
    required TextEditingController emailController,
    required TextEditingController passwordController,
    required TextEditingController confirmPasswordController,
    required TextEditingController codeController,
    required TextEditingController usernameController,
    required AuthAreaNavigationZone currentPart,
    required AuthAreaNavigationZone? pastPart,
    required ValueNotifier<UserGender?> genderNotifier,
  }) = _AuthPageStateModel;
}

@riverpod
class AuthPageState extends _$AuthPageState {
  final _authController = EmailAuthController(client.modules.auth);
  int? signedUserId;

  @override
  AuthPageStateModel build() {
    signedUserId = ref.signedInUserId;
    String? userEmail = ref.readCurrentUserProfile?.email;

    // if (signedUserId != null) {
    //   userEmail = ref.readModel<UserInfo>(signedUserId!)?.email;
    // }

    return AuthPageStateModel(
      emailController: TextEditingController(
          text: userEmail ?? (kDebugMode ? 'test@mail.ru' : '')),
      passwordController:
          TextEditingController(text: kDebugMode ? '12345678' : ''),
      confirmPasswordController:
          TextEditingController(text: kDebugMode ? '12345678' : ''),
      codeController: TextEditingController(),
      currentPart: AuthAreaNavigationZone.auth,
      usernameController: TextEditingController(),
      genderNotifier: ValueNotifier(null),
      pastPart: null,
    );
  }

  void setPage(AuthAreaNavigationZone pageEnum) {
    state = state.copyWith(
      pastPart: (pageEnum.descriptor.parent == AuthAreaNavigationZone.auth &&
              signedUserId != null)
          ? null
          : pageEnum.descriptor.parent as AuthAreaNavigationZone?,
      currentPart: pageEnum,
    );
  }

  Future<bool> processEmail(
    AuthModeEnum mode,
    // String? email,
  ) async {
    // if (email != null) {
    //   state.emailController.text = email;
    // }
    final email = state.emailController.text;
    log('processEmail: $email');

    final userExists = await client.userAuth.verifyEmail(email);
    log('userExists: $userExists');
    if (!userExists && mode != AuthModeEnum.registration) {
      ref.notifyUser(
        NitNotification.error('Эта почта не зарегистрирована'),
      );
      return false;
    }

    if (userExists && mode == AuthModeEnum.registration) {
      ref.notifyUser(
        NitNotification.error('Пользователь с таким email уже существует'),
      );

      return false;
    }

    if (mode == AuthModeEnum.recover) {
      log('initiatePasswordReset: $email');
      return _authController.initiatePasswordReset(email);
    }

    return true;
  }

  Future<bool> processPassword(AuthModeEnum mode) async {
    switch (mode) {
      case AuthModeEnum.recover:
        {
          await _authController.resetPassword(
            state.emailController.text,
            state.codeController.text,
            state.passwordController.text,
          );
          return await _signIn();
        }
      case AuthModeEnum.registration:
        return _authController.createAccountRequest(
          state.usernameController.text,
          state.emailController.text,
          state.passwordController.text,
        );
      case AuthModeEnum.signIn:
        return await _signIn();
      // case AuthModeEnum.change:
      //   return _authController.resetPassword(
      //     state.emailController.text,
      //     state.codeController.text,
      //     state.passwordController.text,
      //   );
      default:
        throw UnimplementedError();
    }
  }

  Future<bool> sendValidationCode(AuthModeEnum mode) async {
    switch (mode) {
      case AuthModeEnum.registration:
        return _authController.createAccountRequest(
          state.usernameController.text,
          // _prepareLogin(state.emailController.text, DateTime.now()),
          state.emailController.text,
          state.passwordController.text,
        );
      case AuthModeEnum.recover:
        return _authController
            .initiatePasswordReset(state.emailController.text);
      // case AuthModeEnum.change:
      //   return _authController
      //       .initiatePasswordReset(state.emailController.text);
      default:
        throw UnimplementedError();
    }
  }

  // String _prepareLogin(String email, DateTime time) =>
  //     email.substring(0, email.indexOf('@')) +
  //     time.millisecondsSinceEpoch
  //         .toString()
  //         .substring(time.millisecondsSinceEpoch.toString().length - 4);

  Future<bool> processVerificationCode(AuthModeEnum mode) async {
    bool codeIsOk;

    switch (mode) {
      case AuthModeEnum.recover:
        codeIsOk = await client.userAuth.verifyResetCode(
          state.emailController.text,
          state.codeController.text,
        );

      // case AuthModeEnum.change:
      //   codeIsOk = await client.userAuth.verifyResetCode(
      //     state.emailController.text,
      //     state.codeController.text,
      //   );

      case AuthModeEnum.registration:
        final userInfo = await _authController.validateAccount(
            state.emailController.text, state.codeController.text,
            extraData: {
              'userGender': state.genderNotifier.value!.name,
            });

        codeIsOk = userInfo != null;

        if (codeIsOk) {
          await _signIn();
          // !!! Ваня в этот момент с высокой вероятностью профиль уже будет создан и его нужно не создавать, а обновить
          // Я все пофиксил, этот код больше не нужен
          // ref.userProfile - можно использовать
          // final profile = await ref.readOrFetchModel(
          //     userInfo.id!, AppRepository.userProfileByUserId.descriptor);

          // final res = await ref.saveModel(
          //   profile.copyWith(
          //     gender: state.genderNotifier.value,
          //   ),

          // UserProfile(
          //   userId: userInfo.id!,
          //   gender: state.genderNotifier.value,
          //   isOnline: false,
          //   isAdmin: false,
          // ),
          // );

          return true;
        }
      default:
        return false;
    }

    if (!codeIsOk) {
      ref.notifyUser(
        NitNotification.error(
          'Неправильно введённый код',
        ),
      );
      state.codeController.clear();
      return false;
    }

    return codeIsOk;
  }

  Future<bool> _signIn() async {
    return null !=
        await _authController.signIn(
          state.emailController.text,
          state.passwordController.text,
        );
    // await ref.read(authRepositoryProvider.notifier).signIn(
    //       state.emailController.text,
    //       state.passwordController.text,
    //     );
    // return ref.signedIn;
  }

  Future<bool> validateUsername() async {
    final error = await client.userAuth.validateUsername(
      state.usernameController.text,
    );
    if (error == null) {
      return true;
    } else {
      //TODO: implement error handling

      ref.notifyUser(
        NitNotification.error(
          error,
        ),
      );
      return false;
    }
  }

  Future<bool> oauthRegistration() async {
    final newProfileId = await ref.saveModel(ref.readCurrentUserProfile!
        .copyWith(
            gender: state.genderNotifier.value,
            userName: state.usernameController.text));
    return newProfileId != null;
  }
}
