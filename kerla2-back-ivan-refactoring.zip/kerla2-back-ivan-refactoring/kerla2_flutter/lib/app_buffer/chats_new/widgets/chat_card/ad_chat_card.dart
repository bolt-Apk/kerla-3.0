import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/app_buffer/ads/utils/ad_price_extencion.dart';
import 'package:kerla2_flutter/app_buffer/chats_new/widgets/chat_card/message_counter.dart';
import 'package:kerla2_flutter/app_buffer/chats_new/widgets/chat_list_card.dart';
import 'package:kerla2_flutter/app_buffer/profile/profile_image/profile_image.dart';
import 'package:kerla2_flutter/ui_kit/basic_widgets/image_or_video_thumbnail_widget.dart';
import 'package:nit_app/nit_app.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class ChatCardWithAd extends ConsumerWidget {
  const ChatCardWithAd({
    super.key,
    required this.chatParticipant,
    required this.userProfile,
    required this.adId,
  });

  final NitChatParticipant chatParticipant;
  final UserProfile userProfile;
  final int adId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return ref.watchOrFetchMaybeModelAsync<Ad>(adId).nitWhen(
          loadingValue: NitDefaultModelsRepository.get<Ad>(),
          errorWidget: const Text('Не удалось загрузить объявление'),
          childBuilder: (ad) {
            if (ad == null) {
              return const SizedBox.shrink();
            }
            return InkWell(
              onTap: () {
                context.goToChatByChannelId(
                  channelId: chatParticipant.chatChannelId,
                );
                // if (chatParticipant.unreadCount > 0) {
                //   ref.saveModel(chatParticipant.copyWith(unreadCount: 0));
                // }
              },
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Stack(
                      clipBehavior: Clip.none,
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(14),
                          child: SizedBox(
                            width: 90,
                            height: 70,
                            child: ImageOrVideoThumbnailWidget(
                              url: ad.media?.firstOrNull?.publicUrl ?? '',
                              type: ad.media?.firstOrNull?.type ??
                                  MediaType.image,
                            ),
                          ),
                        ),
                        Positioned(
                          top: -6,
                          left: -6,
                          child: CircleAvatar(
                            radius: 19,
                            backgroundColor: context.theme.canvasColor,
                            child: ProfileImage(
                              userId: userProfile.userId,
                              size: 32,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        children: [
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Flexible(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      ad.title.isEmpty
                                          ? ad.description
                                          : ad.title,
                                      style: context.textTheme.titleMedium
                                          ?.copyWith(
                                        fontWeight: FontWeight.bold,
                                      ),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                    // Text(
                                    //   ad.description,
                                    //   style: context.textTheme.bodyMedium,
                                    //   maxLines: 1,
                                    //   overflow: TextOverflow.clip,
                                    // ),
                                    Text(
                                      chatParticipant.lastMessage ?? '',
                                      style: context.textTheme.bodyMedium
                                          ?.copyWith(
                                        color: context.theme.hintColor,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              if (chatParticipant.lastMessageSentAt != null)
                                Column(
                                  children: [
                                    Text(
                                      DateFormat('d MMMM', 'ru').format(
                                        chatParticipant.lastMessageSentAt!
                                            .toLocal(),
                                      ),
                                      style: context.textTheme.labelSmall
                                          ?.copyWith(
                                        fontSize: 14,
                                        color: context.theme.primaryColorDark,
                                      ),
                                    ),
                                    const Gap(30),
                                    Text(
                                      ad.formattedPrice,
                                      style: context.textTheme.displayLarge
                                          ?.copyWith(
                                        fontSize: 16,
                                      ),
                                    ),
                                  ],
                                ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    NewMessageCounter(chatParticipant: chatParticipant),
                  ],
                ),
              ),
            );
          },
        );
  }
}
