import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/app_buffer/ads/service/state/service_state.dart';
import 'package:nit_app/nit_app.dart';

class DefaultModels {
  static initRepository() {
    NitDefaultModelsRepository.putOtherObject(0);

    NitDefaultModelsRepository.putSerializableModel<UserProfile>(
      UserProfile(
        userId: NitDefaultModelsRepository.mockModelId,
        isAdmin: false,
        gender: UserGender.male,
        // businessEndsAt: DateTime.now(),
        isOnline: false,
        lastTimeOnline: DateTime.now(),
      ),
    );
    NitDefaultModelsRepository.putSerializableModel<NotificationPermission>(
      NotificationPermission(
        id: NitDefaultModelsRepository.mockModelId,
        userId: NitDefaultModelsRepository.mockModelId,
        permissionList: NotificationPermissionType.values,
      ),
    );
    NitDefaultModelsRepository.putSerializableModel<NitChatMessage>(
      NitChatMessage(
        id: NitDefaultModelsRepository.mockModelId,
        chatChannelId: NitDefaultModelsRepository.mockModelId,
        userId: NitDefaultModelsRepository.mockModelId,
        text: 'message',
        sentAt: DateTime.now(),
      ),
    );

    NitDefaultModelsRepository.putSerializableModel<NitAppNotification>(
      NitAppNotification(
        id: NitDefaultModelsRepository.mockModelId,
        toUserId: NitDefaultModelsRepository.mockModelId,
        title: 'title',
        body: 'body',
        timestamp: DateTime.now(),
      ),
    );

    NitDefaultModelsRepository.putSerializableModel<Region>(
      Region(title: '', latitude: 0, longitude: 0, radius: 0),
    );
    NitDefaultModelsRepository.putSerializableModel<AdCategory>(
      AdCategory(title: ''),
    );
    NitDefaultModelsRepository.putSerializableModel<Ad>(
      Ad(
        title: '',
        price: 0,
        description: '',
        status: AdStatus.active,
        adType: AdType.ad,
        media: [
          NitMedia(
            type: MediaType.image,
            createdAt: DateTime.now(),
            publicUrl:
                'https://avatars.mds.yandex.net/i?id=d5ad704472a1cf4b5cbd97b1ab0a25b41a44c480-10233716-images-thumbs&n=13',
          )
        ],
      ),
    );
    NitDefaultModelsRepository.putSerializableModel<NitChatChannel>(
      NitChatChannel(channel: 'personal-1-1'),
    );
    NitDefaultModelsRepository.putSerializableModel<KerlaServiceInfo>(
      KerlaServiceInfo(
        id: NitDefaultModelsRepository.mockModelId,
        type: KerlaServiceType.boost,
        title: 'title',
        description: 'description',
        cost: 0,
      ),
    );
    NitDefaultModelsRepository.putSerializableModel<FavouriteAd>(
      FavouriteAd(userId: 0, adId: 0),
    );
    NitDefaultModelsRepository.putSerializableModel<AdAttributeValue>(
      AdAttributeValue(
        attributeId: NitDefaultModelsRepository.mockModelId,
        value: '',
      ),
    );
    NitDefaultModelsRepository.putSerializableModel<NitChatParticipant>(
      NitChatParticipant(
        userId: NitDefaultModelsRepository.mockModelId,
        chatChannelId: NitDefaultModelsRepository.mockModelId,
        lastMessageId: NitDefaultModelsRepository.mockModelId,
        lastReadMessageId: NitDefaultModelsRepository.mockModelId,
        lastMessage: 'lastMessage',
        lastMessageSentAt: DateTime.now(),
        unreadCount: 0,
      ),
    );
    NitDefaultModelsRepository.putSerializableModel<NitMedia>(
      NitMedia(
        id: NitDefaultModelsRepository.mockModelId,
        type: MediaType.image,
        createdAt: DateTime.now(),
        publicUrl: '',
      ),
    );
    NitDefaultModelsRepository.putSerializableModel<KerlaService>(
      KerlaService(
        id: NitDefaultModelsRepository.mockModelId,
        type: KerlaServiceType.boost,
        endsAt: DateTime.now(),
      ),
    );

    NitDefaultModelsRepository.putSerializableModel(
      UserSubscription(
        userId: NitDefaultModelsRepository.mockModelId,
        subscriberId: NitDefaultModelsRepository.mockModelId,
        created: DateTime.now(),
      ),
    );

    NitDefaultModelsRepository.putOtherObject<List<int>>(
      List<int>.filled(2, NitDefaultModelsRepository.mockModelId),
    );

    NitDefaultModelsRepository.putOtherObject(
      List<Attribute>.filled(
          2,
          Attribute(
            id: NitDefaultModelsRepository.mockModelId,
            type: AttributeType.decimal,
          )),
    );
    NitDefaultModelsRepository.putOtherObject(
      const ServiceStateModel(
        payableServices: [],
        freeServices: [],
      ),
    );
    NitDefaultModelsRepository.putOtherObject(
      List<FavouriteAd>.empty(),
    );
    NitDefaultModelsRepository.putOtherObject(
      List<UserProfile>.empty(),
    );
    NitDefaultModelsRepository.putOtherObject(
      List<AdCategory>.empty(),
    );
    NitDefaultModelsRepository.putOtherObject(
      List<UserSubscription>.empty(),
    );
    NitDefaultModelsRepository.putOtherObject(
      List<Ad>.empty(),
    );
    NitDefaultModelsRepository.putOtherObject(
      List<NitChatParticipant>.empty(),
    );
    NitDefaultModelsRepository.putOtherObject(
      List<NitChatChannel>.empty(),
    );
    NitDefaultModelsRepository.putOtherObject(
      List<NitMedia>.empty(),
    );
    NitDefaultModelsRepository.putOtherObject(
      List<UserProfile>.empty(),
    );
    NitDefaultModelsRepository.putOtherObject(
      List<KerlaService>.empty(),
    );
    NitDefaultModelsRepository.putOtherObject(
      ServiceStateModel(
        payableServices: [
          KerlaServiceInfo(
            id: NitDefaultModelsRepository.mockModelId,
            type: KerlaServiceType.boost,
            title: 'title',
            description: 'description',
            cost: 0,
          ),
        ],
        freeServices: [
          KerlaServiceInfo(
            id: NitDefaultModelsRepository.mockModelId,
            type: KerlaServiceType.turbo,
            title: 'title',
            description: 'description',
            cost: 0,
          ),
        ],
      ),
    );

    // NitDefaultModelsRepository.put(
    //   UserProfileStateModel(
    //     userProfile: NitDefaultModelsRepository.get<UserProfile>(),
    //     userInfo: NitDefaultModelsRepository.get<UserInfo>(),
    //   ),
    // );
  }

  // static final userProfile = UserProfile(
  //   userInfoId: DefaultModelsRepository.mockModelId,
  //   isAdmin: false,
  //   gender: UserGender.male,
  //   businessEndsAt: DateTime.now(),
  //   isOnline: false,
  //   lastTimeOnline: DateTime.now(),
  // );

  // static final userInfo = UserInfo(
  //   userIdentifier: 'User Identifier',
  //   userName: 'Username',
  //   fullName: 'Username Surname',
  //   email: 'random_user@email.com',
  //   created: DateTime.now(),
  //   blocked: false,
  //   scopeNames: [],
  // );
}
