import 'package:kerla2_client/kerla2_client.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:shared_preferences_riverpod/shared_preferences_riverpod.dart';

late SharedPreferences prefs;

final viewSessionIdProvider = createMapPrefProvider<UuidValue>(
  prefs: (_) => prefs,
  prefKey: 'viewSessionId',
  mapFrom: (v) => v == null
      ? const UuidValue.fromNamespace(Namespace.nil)
      : UuidValue.fromString(v),
  mapTo: (v) => v.uuid,
);
