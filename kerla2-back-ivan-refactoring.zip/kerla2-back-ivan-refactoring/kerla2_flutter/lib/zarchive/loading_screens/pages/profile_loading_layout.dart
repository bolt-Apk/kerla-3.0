// part of '../../ui_kit.dart';

// class ProfileLoadingLayout extends StatelessWidget {
//   const ProfileLoadingLayout({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return ListView(
//       children: [
//         const ShimmerHeader(
//           height: 250,
//         ),
//         const SizedBox(
//           height: 10,
//         ),
//         const ShimmerListTile(height: 70),
//         const ShimmerListTile(height: 70),
//         Row(
//           mainAxisAlignment: MainAxisAlignment.spaceAround,
//           children: [
//             ...List.generate(
//                 5, (i) => const ShimmerListTile(height: 30, width: 65))
//           ],
//         ),
//         Wrap(
//           children: [
//             ...List.generate(
//                 6, (i) => const ShimmerListTile(height: 250, width: 190))
//           ],
//         )
//       ],
//     );
//   }
// }
