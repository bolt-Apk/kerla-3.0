import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/app_buffer/ads/representation/detail_page/widgets/ad_characteristic_row.dart';
import 'package:kerla2_flutter/domain/model_extansions/ad_extensions.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

import '/ui_kit/ui_kit.dart';

class AdCharacteristics extends ConsumerWidget {
  const AdCharacteristics({
    super.key,
    required this.ad,
  });

  final Ad ad;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final characteristics = ad.adCharacteristicList;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10),
      decoration: BoxDecoration(
        color: context.theme.canvasColor,
      ),
      child: ReadMore(
        title: "Характеристики",
        contentText: "",
        collapsWidget: AdCharacteristicRow(
            characteristics: characteristics.take(3).toList()),
        expandWidget: AdCharacteristicRow(characteristics: characteristics),
        titleStyle: context.textTheme.headlineMedium
            ?.copyWith(fontSize: 20, fontWeight: FontWeight.bold),
        expandText: "Показать еще",
        collapsText: "Скрыть",
        descriptionStyle: context.textTheme.bodyMedium?.copyWith(
          fontSize: 16,
          fontWeight: FontWeight.w800,
        ),
        showExpandButton: characteristics.length > 3,
      ),
    );
  }
}
