import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/core/app_backend_filters.dart';
import 'package:kerla2_flutter/core/app_scaffold.dart';
import 'package:nit_app/nit_app.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

import '../payment/slider_value_provider.dart';
import '../payment_button.dart';
import 'month_service_slider.dart';

class ConnectBusinessProfileService extends ConsumerWidget {
  const ConnectBusinessProfileService({super.key});

  String month(int value) {
    if (value == 1) return "месяц";
    if (value >= 2 && value <= 4) return "месяца";
    return "месяцев";
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final sliderValue = ref.watch(sliderValueProvider);

    return ref
        .watchModelCustomAsync<KerlaServiceInfo>(
      backendFilter: NitBackendFilter.value(
        type: NitBackendFilterType.equals,
        fieldName: AppBackendFilter.type.name,
        fieldValue: KerlaServiceType.businessProfile,
      ),
    )
        .nitWhen(
      childBuilder: (bpInfo) {
        final costRubles = (bpInfo.cost ~/ 100) * sliderValue;
        return PopScope(
          canPop: false,
          child: AppScaffold(
            backgroundColor: context.colorScheme.surface,
            appBar: AppBar(
              automaticallyImplyLeading: false,
              elevation: 0,
              backgroundColor: context.colorScheme.surface,
              title: Text(
                "Подключение бизнес профиля",
                style: context.textTheme.titleMedium?.copyWith(
                  color: context.colorScheme.onSurface,
                ),
              ),
            ),
            body: SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 10),
                child: Container(
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: context.colorScheme.surface,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Column(
                    children: [
                      const _BusinessProfileAdditionalInfo(),
                      const Gap(20),
                      Text(
                        "Подключение услуг",
                        style: context.textTheme.titleMedium?.copyWith(
                          color: context.colorScheme.onSurface,
                        ),
                      ),
                      const Gap(10),
                      Text(
                        "Выберите срок оплаты",
                        style: context.textTheme.bodyMedium?.copyWith(
                          color: context.colorScheme.onSurface.withOpacity(0.3),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(12.0),
                        child: MonthServiceSlider(
                          height: 15,
                          width: MediaQuery.sizeOf(context).width - 60,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(12.0),
                        child: Container(
                          padding: const EdgeInsets.all(10),
                          width: double.infinity,
                          decoration: BoxDecoration(
                            color: context.colorScheme.surface,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                              color: context.colorScheme.onSurface
                                  .withOpacity(0.1),
                            ),
                          ),
                          child: Align(
                            child: RichText(
                              text: TextSpan(
                                children: [
                                  TextSpan(
                                    text: "Стоимость ",
                                    style: TextStyle(
                                      color: context.colorScheme.onSurface
                                          .withOpacity(0.3),
                                    ),
                                  ),
                                  TextSpan(
                                    text: " $costRubles ₽",
                                    style:
                                        context.textTheme.bodyMedium?.copyWith(
                                      fontWeight: FontWeight.bold,
                                      color: context.colorScheme.onSurface,
                                    ),
                                  ),
                                  TextSpan(
                                    text: "   за ${sliderValue * 30} дней",
                                    style:
                                        context.textTheme.bodyMedium?.copyWith(
                                      color: context.colorScheme.onSurface
                                          .withOpacity(0.3),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 60,
                          vertical: 20,
                        ),
                        child: PaymentButton(
                          amount: costRubles,
                          promotions: [
                            KerlaService(
                              type: KerlaServiceType.businessProfile,
                              endsAt: DateTime.now()
                                  .add(Duration(days: sliderValue * 30)),
                              daysCount: sliderValue * 30,
                              price: bpInfo.cost,
                            ),
                          ],
                          onSuccess: () {
                            ref
                                .read(globalRefreshTriggerProvider.notifier)
                                .state = DateTime.now();
                          },
                        ),
                      ),
                      const Gap(32),
                      GestureDetector(
                        onTap: () {
                          context.pop();
                        },
                        child: Text(
                          "Продолжить без изменений",
                          style: TextStyle(
                            color: context.theme.textTheme.titleLarge?.color,
                            fontSize: 18,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

class _BusinessProfileAdditionalInfo extends StatelessWidget {
  const _BusinessProfileAdditionalInfo();

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 16),
          child: Container(
            width: double.infinity,
            decoration: BoxDecoration(
              color: context.colorScheme.primary.withOpacity(0.07),
              borderRadius: BorderRadius.circular(16),
            ),
            padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(Icons.star,
                        color: context.colorScheme.primary, size: 28),
                    const Gap(8),
                    Text(
                      "Преимущества бизнес-профиля",
                      style: context.textTheme.titleMedium?.copyWith(
                        color: context.colorScheme.primary,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                const Gap(12),
                Row(
                  children: [
                    Icon(Icons.check_circle,
                        color: context.colorScheme.primary, size: 20),
                    const Gap(8),
                    Expanded(
                      child: Text(
                        "Бесплатные публикации сторис",
                        style: context.textTheme.bodyMedium,
                      ),
                    ),
                  ],
                ),
                const Gap(8),
                Row(
                  children: [
                    Icon(Icons.check_circle,
                        color: context.colorScheme.primary, size: 20),
                    const Gap(8),
                    Expanded(
                      child: Text(
                        "Возможность изменить обложку профиля",
                        style: context.textTheme.bodyMedium,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 4),
          child: Container(
            width: double.infinity,
            decoration: BoxDecoration(
              color: context.colorScheme.secondary.withOpacity(0.07),
              borderRadius: BorderRadius.circular(12),
            ),
            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 14),
            child: Row(
              children: [
                Icon(Icons.info_outline,
                    color: context.colorScheme.secondary, size: 22),
                const Gap(8),
                Expanded(
                  child: Text(
                    "Если у вас уже подключён бизнес-профиль, вы можете продлить его действие здесь.",
                    style: context.textTheme.bodySmall?.copyWith(
                      color: context.colorScheme.onSurface.withOpacity(0.7),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
