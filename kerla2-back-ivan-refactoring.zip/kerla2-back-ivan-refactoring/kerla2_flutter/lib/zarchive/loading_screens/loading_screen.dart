// part of '../ui_kit.dart';

// class LoadingScreen extends StatelessWidget {
//   const LoadingScreen({super.key, required this.shimmerLayout});

//   factory LoadingScreen.profile() {
//     return const LoadingScreen(shimmerLayout: ProfileLoadingLayout());
//   }
//   factory LoadingScreen.home() {
//     return const LoadingScreen(shimmerLayout: HomeLoadingLayout());
//   }
//   factory LoadingScreen.chats() {
//     return const LoadingScreen(shimmerLayout: ChatsLoadingLayout());
//   }

//   final Widget shimmerLayout;
//   @override
//   Widget build(BuildContext context) {
//     return Shimmer.fromColors(
//         baseColor: context.theme.canvasColor,
//         highlightColor: Colors.grey[100]!,
//         child: shimmerLayout);
//   }
// }
