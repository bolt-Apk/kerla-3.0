// import 'package:freezed_annotation/freezed_annotation.dart';
// import 'package:kerla2_client/kerla2_client.dart';
// import 'package:nit_app/nit_app.dart';
// import 'package:riverpod_annotation/riverpod_annotation.dart';
// import 'package:serverpod_auth_client/serverpod_auth_client.dart';

// part 'user_profile_state.freezed.dart';
// part 'user_profile_state.g.dart';


// @freezed
// abstract class UserProfileStateModel with _$UserProfileStateModel {
//   const factory UserProfileStateModel({
//     required UserProfile userProfile,
//     required UserInfo userInfo,
//   }) = _UserProfileStateModel;
// }

// @riverpod
// class SignedInUserProfileState extends _$SignedInUserProfileState {
//   @override
//   Future<UserProfileStateModel?> build() async {
//     return ref.signedIn
//         ? await ref.watch(userProfileStateProvider(ref.signedInUserId!).future)
//         : null;
//   }
// }

// @riverpod
// class UserProfileState extends _$UserProfileState {
//   @override
//   Future<UserProfileStateModel> build(int userId) async {
//     final userProfileId =
//         await ref.watch(singleItemCustomProvider<UserProfile>()(
//       SingleItemCustomProviderConfig(
//         backendFilters: [
//           NitBackendFilter(
//             fieldName: 'userId',
//             equalsTo: userId.toString(),
//           )
//         ],
//       ),
//     ).future);

//     return UserProfileStateModel(
//       // Мы предполагаем, что UserInfo должен приехать вместе с UserProfile
//       userInfo: ref.watchModel<UserInfo>(userId)!,
//       userProfile: ref.watchModel<UserProfile>(userProfileId!)!,
//     );
//   }
// }
