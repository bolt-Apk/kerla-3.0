import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:nit_app/nit_app.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class NewMessageCounter extends ConsumerWidget {
  const NewMessageCounter({super.key, required this.chatParticipant});

  final NitChatParticipant chatParticipant;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    if (chatParticipant.unreadCount > 0) {
      return Padding(
        padding: const EdgeInsets.only(left: 4),
        child: Container(
          width: 24,
          height: 24,
          decoration: BoxDecoration(
            color: context.colorScheme.error,
            borderRadius: BorderRadius.circular(16),
          ),
          child: Center(
            child: Text(
              '${chatParticipant.unreadCount}',
              style: context.textTheme.labelSmall!.copyWith(
                color: context.colorScheme.onError,
              ),
            ),
          ),
        ),
      );
    }
    return const SizedBox.shrink();
  }
}
