import 'package:kerla2_client/kerla2_client.dart';
import 'package:nit_app/nit_app.dart';

enum AppRepository<T extends SerializableModel, K> {
  userProfileByUserId(
    descriptor: NitRepositoryDescriptor<UserProfile, int>(
      fieldName: 'userId',
    ),
  ),
  notificationPermissionByUserId(
    descriptor: NitRepositoryDescriptor<NotificationPermission, int>(
      fieldName: 'userId',
    ),
  ),
  nitChannelByChannelName(
    descriptor: NitRepositoryDescriptor<NitChatChannel, String>(
      fieldName: 'channel',
    ),
  ),
  kerlaServiceInfoByType(
    descriptor: NitRepositoryDescriptor<KerlaServiceInfo, String>(
      fieldName: 'type',
    ),
  ),
  // userSubscriptionByUserIdAndSubscriberId(
  //   descriptor: NitRepositoryDescriptor<UserSubscription, int>(
  //     fieldName: 'userId',
  //   ),
  // ),
  ;

  const AppRepository({
    required this.descriptor,
  });

  final NitRepositoryDescriptor<T, K> descriptor;
}
