import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerla2_flutter/router/router.dart';
import 'package:nit_router/nit_router.dart';

import '../../media/state/selected_media_state.dart';
import 'asset_item.dart';

class CreateAdAsset extends ConsumerWidget {
  const CreateAdAsset({
    super.key,
    required this.media,
  });

  final MediaOrAssetWrapper media;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final int? adId = ref.watchNavigationParam(AppNavigationParams.adId);

    return Stack(
      children: [
        if (media.isMedia)
          ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: CachedNetworkImage(
              imageUrl: media.asMedia().publicUrl,
              fit: BoxFit.cover,
              width: double.infinity,
              height: double.infinity,
            ),
          ),
        if (media.isAsset) AssetItem(assetEntity: media.asAsset()),
        Positioned.fill(
          child: Align(
            alignment: Alignment.bottomRight,
            child: Padding(
              padding: const EdgeInsets.all(2.0),
              child: GestureDetector(
                onTap: () {
                  ref
                      .watch(
                        adMediaStateProvider(adId: adId).notifier,
                      )
                      .toggleItem(media);
                },
                child: Container(
                  width: 25,
                  height: 25,
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.circle,
                  ),
                  child: const Center(
                    child: Icon(
                      Icons.delete_outline,
                      color: Colors.red,
                      size: 20,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
        // Positioned.fill(
        //   child: Align(
        //     alignment: Alignment.topLeft,
        //     child: Padding(
        //       padding: const EdgeInsets.all(2.0),
        //       child: GestureDetector(
        //         onTap: () {},
        //         child: Container(
        //           width: 25,
        //           height: 25,
        //           decoration: const BoxDecoration(
        //             color: Colors.white,
        //             shape: BoxShape.circle,
        //           ),
        //           child: const Center(
        //             child: Icon(
        //               Icons.border_clear,
        //               color: Colors.black,
        //               size: 18,
        //             ),
        //           ),
        //         ),
        //       ),
        //     ),
        //   ),
        // ),
      ],
    );
  }
}
