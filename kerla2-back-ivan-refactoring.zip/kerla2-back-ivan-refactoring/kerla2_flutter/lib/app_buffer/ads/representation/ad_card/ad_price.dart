import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class AdPrice extends StatelessWidget {
  const AdPrice({
    super.key,
    required this.price,
    this.fontSize,
    this.textColor,
  });

  final int price;
  final double? fontSize;
  final Color? textColor;

  @override
  Widget build(BuildContext context) {
    return Text(
      price.priceFormat(),
      style: context.textTheme.titleLarge?.copyWith(
        fontSize: fontSize,
        color: textColor,
      ),
    );
  }
}

extension PriceFormat on int {
  String priceFormat() {
    final million = this ~/ 1000000;
    if (million > 0) {
      final mlnFormatter = NumberFormat("###.0");
      return '${mlnFormatter.format(this / 1000000)} млн ₽';
    }
    final formatter = NumberFormat('#,###');
    return '${formatter.format(this).replaceAll(',', ' ')} ₽';
  }
}
