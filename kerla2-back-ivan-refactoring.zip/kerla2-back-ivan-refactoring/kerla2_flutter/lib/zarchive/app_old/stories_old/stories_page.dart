// import 'dart:async';
// import 'dart:ui';

// import 'package:flutter/material.dart';
// import 'package:flutter_riverpod/flutter_riverpod.dart';
// import 'package:kerla2_client/kerla2_client.dart';
// import 'package:kerla2_flutter/core/core.dart';
// import 'package:kerla2_flutter/router/router.dart';
// import 'package:nit_app/nit_app.dart';
// import 'package:nit_router/nit_router.dart';
// import 'package:onesignal_flutter/onesignal_flutter.dart';
// import 'package:serverpod_auth_client/module.dart';
// import 'package:story_view/story_view.dart';

// import '../../../core/app_scaffold.dart';
// import '../../../zarchive/stories/state/stories_providers.dart';

// class StoriesPage extends ConsumerStatefulWidget {
//   const StoriesPage({
//     super.key,
//     this.isSingleStory = false,
//   });
//   final bool isSingleStory;

//   @override
//   ConsumerState<ConsumerStatefulWidget> createState() => _StoriesPageState();
// }

// class _StoriesPageState extends ConsumerState<StoriesPage> {
//   final storyController = StoryController();
//   late PageController pageController;
//   late StreamSubscription<PlaybackState> subscription;

//   @override
//   void initState() {
//     super.initState();
//     pageController = PageController();
//   }

//   @override
//   void didChangeDependencies() {
//     super.didChangeDependencies();
//     final userId = ref.signedInUserId;
//     if (userId != null) {}
//   }

//   void updateStoriesCounts(int adId) async {
//     final sessionId = await OneSignal.User.getOnesignalId();
//     if (sessionId != null) {
//       client.ad.updateAdCounts(true, adId, sessionId);
//     }
//   }

//   @override
//   void dispose() {
//     storyController.dispose();
//     pageController.dispose();
//     super.dispose();
//   }

//   StoryItem customStoryItem({
//     required NitMedia media,
//     required StoryController controller,
//     required Ad story,
//     required UserInfoPublic user,
//     BoxFit imageFit = BoxFit.fitWidth,
//   }) {
//     //TODO: make to extension
//     // final bool allowedAd = story.onlyForGender == ref.signedInUser?.gender ||
//     //     story.onlyForGender == null;

//     return StoryItem(
//       Container(
//         color: Colors.black,
//         child: Stack(
//           children: <Widget>[
//             if (media.type == MediaType.image)
//               StoryImage.url(
//                 media.publicUrl,
//                 controller: controller,
//                 fit: imageFit,
//               ),
//             if (media.type == MediaType.video)
//               StoryVideo.url(
//                 media.publicUrl,
//                 controller: controller,
//               ),
//             // TODO: переделать и вернуть
//             // if (!allowedAd)
//             if (true)
//               SizedBox(
//                 height: double.infinity,
//                 width: double.infinity,
//                 child: ImageFiltered(
//                   imageFilter: ImageFilter.blur(
//                     sigmaX: 30,
//                     sigmaY: 30,
//                     tileMode: TileMode.repeated,
//                   ),
//                   child: media.type == MediaType.image
//                       ? StoryImage.url(
//                           media.publicUrl,
//                           controller: controller,
//                           fit: imageFit,
//                         )
//                       : StoryVideo.url(
//                           media.publicUrl,
//                           controller: controller,
//                         ),
//                 ),
//               ),
//           ],
//         ),
//       ),
//       // TODO: вернуть
//       // hapticContent: CustomStoryItemHapticContent(
//       //   story: story,
//       //   user: user,
//       //   storyController: storyController,
//       // ),
//       duration: media.duration == 0 || media.duration == null
//           ? const Duration(seconds: 15)
//           : Duration(seconds: media.duration!),
//       id: story.id,
//     );
//   }

//   @override
//   Widget build(BuildContext context) {
//     final userId = ref.watchNavigationParam(AppNavigationParams.userId);

//     return AppScaffold(
//       backgroundColor: Colors.black,
//       body: ref.watch(usersWithStoriesProvider).when(
//             error: (_, __) =>
//                 const Center(child: Text('Возникла какая-то ошибка')),
//             loading: () => const Center(
//               child: CircularProgressIndicator(color: Colors.white),
//             ),
//             data: (usersData) {
//               if (userId != null) {
//                 final pageIndex = usersData.indexWhere((u) => u.id == userId);
//                 pageController = PageController(initialPage: pageIndex);
//               } else {
//                 pageController = PageController();
//               }

//               if (usersData.isEmpty) {
//                 return const DecoratedBox(
//                   decoration: BoxDecoration(color: Colors.white),
//                   child: Center(
//                     child: Text(
//                       'Нет историй',
//                       style: TextStyle(color: Colors.black),
//                     ),
//                   ),
//                 );
//               }

//               return SafeArea(
//                 child: Builder(
//                   builder: (context) {
//                     return PageView.builder(
//                       itemCount: widget.isSingleStory ? 1 : usersData.length,
//                       controller: pageController,
//                       itemBuilder: (context, index) {
//                         final userStories = ref.watch(
//                           userStoriesProvider(
//                             id: widget.isSingleStory
//                                 ? userId!
//                                 : usersData[index].id!,
//                           ),
//                         );

//                         return userStories.when(
//                           error: (_, __) => const Center(
//                               child: Text('Возникла какая-то ошибка')),
//                           loading: () => const Center(
//                             child:
//                                 CircularProgressIndicator(color: Colors.white),
//                           ),
//                           data: (stories) {
//                             final sList = stories
//                                 .where((a) => a.media?.isNotEmpty == true);

//                             return StoryView(
//                               storyItems: sList
//                                   .map(
//                                     (s) => customStoryItem(
//                                       story: s,
//                                       user: widget.isSingleStory
//                                           ? usersData
//                                               .firstWhere((u) => u.id == userId)
//                                           : usersData[index],
//                                       media: s.media!.first,
//                                       controller: storyController,
//                                     ),
//                                   )
//                                   .toList(),
//                               controller: storyController,
//                               onComplete: () => pageController.nextPage(
//                                 duration: const Duration(microseconds: 300),
//                                 curve: Curves.linear,
//                               ),
//                               onStoryViewed: (int? storyId) {
//                                 if (storyId != null) {
//                                   updateStoriesCounts(storyId);
//                                 }
//                               },
//                               onVerticalSwipeComplete: (direction) {
//                                 if (direction == Direction.down) {
//                                   if (context.canPop()) {
//                                     context.pop(context);
//                                   } else {
//                                     //TODO: navigate to home
//                                   }
//                                 }
//                               },
//                             );
//                           },
//                         );
//                       },
//                     );
//                   },
//                 ),
//               );
//             },
//           ),
//     );
//   }
// }
