import 'package:flutter/material.dart';
import 'package:flutter_multi_formatter/utils/unfocuser.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_router/nit_router.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class FilterBottomSheet extends ConsumerWidget {
  final Attribute attribute;
  final Widget body;
  final VoidCallback? onReset;
  final ValueNotifier<String> filterValueNotifier;

  const FilterBottomSheet({
    super.key,
    required this.attribute,
    required this.body,
    this.onReset,
    required this.filterValueNotifier,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return DecoratedBox(
      decoration: BoxDecoration(color: context.theme.canvasColor),
      child: Column(
        children: [
          const LittleDivider(),
          Padding(
            padding: const EdgeInsets.symmetric(
              vertical: 3,
              horizontal: 16,
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    InkWell(
                      onTap: () {
                        context.pop();
                      },
                      child: const Icon(Icons.close),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      attribute.title ?? "NO NAME",
                    ),
                  ],
                ),
                InkWell(
                  onTap: () {
                    if (onReset != null) {
                      onReset!();
                    }

                    context.pop();
                  },
                  child: const Row(
                    children: [
                      Icon(Icons.replay),
                      SizedBox(width: 8),
                      Text("Сбросить"),
                    ],
                  ),
                ),
              ],
            ),
          ),
          if (attribute.type == AttributeType.valuesDropdown ||
              attribute.type == AttributeType.regionsDropdown)
            Unfocuser(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: TextField(
                  textCapitalization: TextCapitalization.sentences,
                  style: context.textTheme.labelLarge?.copyWith(
                    fontSize: 16,
                  ),
                  decoration: InputDecoration(
                    hintText: 'Поиск',
                    hintStyle: context.textTheme.labelMedium?.copyWith(
                      fontSize: 16,
                    ),
                  ),
                  onChanged: (value) {
                    filterValueNotifier.value = value;
                  },

                  // controller: ref.read(
                  //   dropDownFilterStringProvider(attribute.id!),
                  // ),
                ),
              ),
            ),
          const Divider(
            height: 2,
          ),
          const SizedBox(height: 8),
          body,
        ],
      ),
    );
  }
}
