// import 'dart:async';

// import 'package:connectivity_plus/connectivity_plus.dart';
// import 'package:freezed_annotation/freezed_annotation.dart';
// import 'package:kerla2_flutter/state/notification_state/notification_state.dart';
// import 'package:onesignal_flutter/onesignal_flutter.dart';
// import 'package:riverpod_annotation/riverpod_annotation.dart';
// import 'package:serverpod_auth_client/module.dart';

// import 'package:flutter/material.dart';
// import 'serverpod_client.dart';

// part 'app_session_state.g.dart';
// part 'app_session_state.freezed.dart';

// @Riverpod(keepAlive: true)
// class AppSessionState extends _$AppSessionState {
//   late final StreamingConnectionHandler _connectionHandler;
//   late final StreamSubscription<List<ConnectivityResult>> subscription;

//   //TODO: обсудить с Женей

//   @override
//   AppSessionStateModel build() {
//     ref.onDispose(() {
//       _connectionHandler.close();
//       subscription.cancel();
//     });
//     _connectionHandler = StreamingConnectionHandler(
//       client: client,
//       listener: (connectionState) async {
//         debugPrint('listener called ${connectionState.status}');
//         _updateConnectionStatus(connectionState.status);
//       },
//     );
//     if (sessionManager.isSignedIn) {
//       _connectionHandler.connect();
//       ref.read(appNotificationStateProvider);
//     }
//     _setOneSignalToken(sessionManager.signedInUser?.id);

//     subscription = Connectivity()
//         .onConnectivityChanged
//         .listen((List<ConnectivityResult> result) {
//       if (result.contains(ConnectivityResult.mobile)) {
//         if (state.networkStatus == false) {
//           state = state.copyWith(networkStatus: true);
//         }
//       } else if (result.contains(ConnectivityResult.wifi)) {
//         if (state.networkStatus == false) {
//           state = state.copyWith(networkStatus: true);
//         }
//       } else if (result.contains(ConnectivityResult.ethernet)) {
//         if (state.networkStatus == false) {
//           state = state.copyWith(networkStatus: true);
//         }
//       } else if (result.contains(ConnectivityResult.none)) {
//         if (state.networkStatus == true) {
//           state = state.copyWith(networkStatus: false);
//         }
//       }
//     });

//     return AppSessionStateModel(
//       signedInUser: sessionManager.signedInUser,
//       websocketStatus: StreamingConnectionStatus.disconnected,
//       sessionReady: false,
//       networkStatus: true,
//     );
//   }

//   Future<void> _setOneSignalToken(int? userId) async {
//     if (userId != null) {
//       await OneSignal.login(userId.toString());
//       debugPrint('OneSignal login: $userId');
//     }
//   }

//   Future<bool> signOut() async {
//     await OneSignal.logout();
//     if (await sessionManager.signOut()) {
//       setUser(sessionManager.signedInUser);
//       return true;
//     }

//     return false;
//   }

//   setUser(UserInfo? user) {
//     _setOneSignalToken(user?.id);
//     _refresh(
//       state.websocketStatus,
//       user: user,
//     );
//   }

//   _updateConnectionStatus(StreamingConnectionStatus status) {
//     _refresh(
//       status,
//       // state.signedInUser,
//     );
//   }

//   _refresh(StreamingConnectionStatus status, {UserInfo? user}) {
//     var userInfo = user ?? sessionManager.signedInUser;
//     debugPrint('Session refresh: ${userInfo?.id ?? 'null'} - ${status.name}');
//     state = AppSessionStateModel(
//       signedInUser: userInfo,
//       websocketStatus: status,
//       networkStatus: state.networkStatus,
//       sessionReady: switch (status) {
//         StreamingConnectionStatus.connected =>
//           (userInfo != null && state.networkStatus) ? true : false,
//         StreamingConnectionStatus.connecting => false,
//         StreamingConnectionStatus.waitingToRetry => false,
//         StreamingConnectionStatus.disconnected => userInfo == null ? true : false,
//       },
//     );

//     if (userInfo == null) {
//       _connectionHandler.close();

//       return;
//     }

//     if (_connectionHandler.status.status ==
//         StreamingConnectionStatus.disconnected) {
//       _connectionHandler.connect();
//     }
//   }
// }

// @freezed
// class AppSessionStateModel with _$AppSessionStateModel {
//   const factory AppSessionStateModel({
//     required UserInfo? signedInUser,
//     required StreamingConnectionStatus websocketStatus,
//     required bool sessionReady,
//     required bool networkStatus,
//   }) = _AppSessionStateModel;
// }
