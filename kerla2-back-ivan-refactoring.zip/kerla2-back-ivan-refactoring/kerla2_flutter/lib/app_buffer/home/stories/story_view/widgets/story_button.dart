import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';

class StoryFAB extends StatelessWidget {
  const StoryFAB({
    super.key,
    required this.icon,
    required this.tag,
    required this.onTap,
  });

  final String icon;
  final Object tag;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return FloatingActionButton(
      heroTag: tag,
      backgroundColor: const Color(0xFF2E3137).withOpacity(0.9),
      mini: true,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
      onPressed: onTap,
      child: SvgPicture.asset(
        icon,
        colorFilter: const ColorFilter.mode(Colors.white, BlendMode.srcIn),
      ),
    );
  }
}
