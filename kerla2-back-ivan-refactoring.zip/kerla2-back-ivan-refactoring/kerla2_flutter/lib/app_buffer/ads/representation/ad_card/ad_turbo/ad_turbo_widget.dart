import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/app/favorites/favorite_button.dart';
import 'package:kerla2_flutter/app_buffer/chats_new/widgets/chat_button.dart';
import 'package:kerla2_flutter/common/ad_utils.dart';
import 'package:kerla2_flutter/router/router.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:kerla2_shared/kerla2_shared.dart';
import 'package:nit_app/nit_app.dart';

import '../ad_price.dart';
import 'ad_turbo_header.dart';

class AdTurboWidget extends ConsumerWidget {
  const AdTurboWidget({
    super.key,
    required this.ad,
  });

  final Ad? ad;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    if (ad == null) {
      return const SizedBox.shrink();
    }


    final bool allowedAd = ref.isAdAllowed(ad!);
    final isUserLoggedIn = ref.signedIn;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8),
      child: CommonButton(
        backgroundColor: Theme.of(context).canvasColor,
        borderRadius: BorderRadius.circular(6),
        action: () {
          if (allowedAd) {
            context.pushNamed(
              AdNavigationZone.adPage.name,
              pathParameters: AppNavigationParams.adId.set(ad!.id!),
            );
          } else {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                showCloseIcon: true,
                content: Text(
                  "Зарегистрируйтесь или войдите в аккаунт, чтобы просматривать объявления",
                ),
              ),
            );
          }
        },
        child: DecoratedBox(
          decoration: BoxDecoration(
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.3),
                blurRadius: 2.0,
                offset: const Offset(0, 2),
              ),
            ],
            color: Colors.white,
            borderRadius: const BorderRadius.all(Radius.circular(6)),
          ),
          child: Column(
            children: [
              AdTurboHeader(
                ad: ad!,
              ),
              Stack(
                children: [
                  AdImageCarousel(
                    needBlur: !allowedAd,
                    borderRadius: const BorderRadiusDirectional.only(
                      bottomStart: Radius.circular(6),
                      bottomEnd: Radius.circular(6),
                    ),
                    imageHeight: 256,
                    urls: ad!.media!,
                  ),
                  Positioned.directional(
                    bottom: 7,
                    start: 10,
                    textDirection: TextDirection.ltr,
                    child: AdPrice(
                      price: ad!.price,
                      fontSize: 20,
                      textColor: Colors.white,
                    ),
                  ),
                  Positioned.directional(
                    bottom: 7,
                    end: 10,
                    textDirection: TextDirection.ltr,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        // Padding(
                        //   padding: const EdgeInsets.only(right: 5),
                        //   child: AdDistance(
                        //     textColor: Colors.white,
                        //     backgroundColor: Colors.black.withOpacity(0.5),
                        //   ),
                        // ),
                        Column(
                          children: [
                            if (isUserLoggedIn)
                              ChatButton.wrappedInFloatingActionButton(
                                chatChannelType: ChatChannelType.ad,
                                adId: ad!.id,
                                userId: ad!.userId!,
                              ),
                            if (isUserLoggedIn)
                              FloatingActionButton(
                                heroTag: '2',
                                backgroundColor:
                                    Theme.of(context).scaffoldBackgroundColor,
                                mini: true,
                                onPressed: () {},
                                child: SvgPicture.asset(
                                  AppIconsSvg.comment,
                                  height: 20,
                                  width: 20,
                                  colorFilter: ColorFilter.mode(
                                    Theme.of(context).iconTheme.color!,
                                    BlendMode.srcIn,
                                  ),
                                ),
                              ),
                            if (isUserLoggedIn)
                              FavoriteButton.wrappedInFloatingActionButton(
                                adId: ad!.id!,
                              ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
