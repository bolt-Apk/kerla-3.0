import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:go_router/go_router.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:intl/intl.dart';
import 'package:kerla2_flutter/router/router.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:story_view/controller/story_controller.dart';

class StoryDescription extends HookWidget {
  const StoryDescription({
    super.key,
    required this.story,
    required this.storyController,
    // this.onExpandChanged,
    required this.isExpandedNotifier,
  });

  final Ad story;
  final StoryController storyController;
  // final ValueChanged<bool>? onExpandChanged;
  final ValueNotifier<bool> isExpandedNotifier;

  @override
  Widget build(BuildContext context) {
    final isExpanded = isExpandedNotifier;
    final numberFormatter = NumberFormat('#,###');
    final theme = Theme.of(context);
    final textTheme = theme.textTheme;

    if (story.description.isEmpty && story.price <= 0) {
      return const SizedBox.shrink();
    }
    bool isAdButtonVisible = story.adType == AdType.ad && !isExpanded.value;

    return GestureDetector(
      // behavior: HitTestBehavior.opaque, хз нужно или
      onTap: () {
        if (story.description.length > 80) {
          isExpanded.value = !isExpanded.value;
          // onExpandChanged?.call(isExpanded.value);
        }
        if (isExpanded.value) {
          storyController.pause();
        } else {
          storyController.play();
        }
      },
      child: Container(
        width: double.infinity,
        decoration: BoxDecoration(
          color: isExpanded.value
              ? Colors.black.withOpacity(0.3)
              : Colors.transparent,
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              AnimatedOpacity(
                opacity: isAdButtonVisible ? 1.0 : 0.0,
                duration: const Duration(milliseconds: 300),
                curve: Curves.easeInOut,
                child: isAdButtonVisible
                    ? Padding(
                        padding: const EdgeInsets.only(bottom: 8.0),
                        child: SizedBox(
                          width: 205,
                          child: Button.secondary(
                            title: 'Перейти к объявлению',
                            onPressed: () async {
                              storyController.pause();
                              await context.pushNamed(
                                AdNavigationZone.adPage.name,
                                pathParameters:
                                    AppNavigationParams.adId.set(story.id!),
                              );
                              storyController.play();
                            },
                          ),
                        ),
                      )
                    : const SizedBox.shrink(),
              ),
              if (story.price > 0)
                Text(
                  '${story.price >= 1000 ? numberFormatter.format(story.price) : story.price} ₽',
                  style: textTheme.headlineLarge?.copyWith(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    shadows: [
                      Shadow(
                        color: Colors.black.withOpacity(1),
                        offset: const Offset(1, 1),
                        blurRadius: 4,
                      )
                    ],
                  ),
                ),
              if (story.description.isNotEmpty) ...[
                if (story.price > 0) const SizedBox(height: 8),
                AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  height: isExpanded.value ? 250 : 50,
                  child: SingleChildScrollView(
                    child: Text(
                      story.description,
                      style: textTheme.headlineMedium?.copyWith(
                        color: Colors.white,
                        shadows: [
                          Shadow(
                            color: Colors.black.withOpacity(1),
                            offset: const Offset(1, 1),
                            blurRadius: 4,
                          )
                        ],
                      ),
                      overflow: TextOverflow.ellipsis,
                      maxLines: isExpanded.value ? 99 : 2,
                    ),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
