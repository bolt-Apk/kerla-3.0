part of '../ui_kit.dart';

class TextSettingsRow extends StatelessWidget {
  const TextSettingsRow({
    super.key,
    required this.title,
    this.subtitle,
    this.editingBottomSheet,
    this.endWidget,
    this.useDivider = true,
    this.subtitleColor,
    // this.textController,
    this.boxColor,
    this.titelFontSize,
    this.subtitleFontSize,
    this.iconSize,
    this.borderRadius,
    this.dividerThickness,
    this.columnPadding,
    this.spaceBetweenObjects,
    this.iconEnd,
    this.endSizedBoxWidth,
    this.onTap,
  });

  final String title;
  final String? subtitle;

  final Widget? editingBottomSheet;
  final Widget? endWidget;

  final double? titelFontSize;
  final double? iconSize;
  final double? subtitleFontSize;
  final double? dividerThickness;
  final double? spaceBetweenObjects;
  final double? endSizedBoxWidth;

  final EdgeInsetsGeometry? columnPadding;

  final IconData? iconEnd;

  // final TextEditingController? textController;

  final Color? boxColor;
  final Color? subtitleColor;
  final BorderRadiusGeometry? borderRadius;

  final bool useDivider;
  final void Function(BuildContext context)? onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        onTap != null ? onTap!(context) : null;
        if (editingBottomSheet != null) {
          showModalBottomSheet<void>(
            isScrollControlled: true,
            shape: const RoundedRectangleBorder(
              borderRadius: BorderRadius.vertical(
                top: Radius.circular(10),
              ),
            ),
            context: context,
            builder: (BuildContext context) {
              return SafeArea(
                child: Padding(
                  padding: EdgeInsets.only(
                    bottom: MediaQuery.of(context).viewInsets.bottom,
                  ),
                  child: editingBottomSheet,
                  //  bottomSheetBuilder(context),
                ),
              );
            },
          );
        }
        // .then(
        //   (value) {
        // print('closed');
        // textController?.clear();
        // ref
        //     .read(
        //       attributeDropDownValueProvider(
        //         -1,
        //         false,
        //       ).notifier,
        //     )
        //     .resetPinValue();
        // },
        // );
      },
      child: DecoratedBox(
        decoration: BoxDecoration(
            color: boxColor ?? context.theme.canvasColor,
            borderRadius: borderRadius),
        child: Column(
          children: [
            Padding(
              padding: columnPadding ??
                  const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              child: Row(
                children: [
                  Text(
                    title,
                    style: context.textTheme.displayLarge?.copyWith(
                      fontSize: titelFontSize,
                    ),
                  ),
                  if (subtitle != null) ...[
                    SizedBox(width: spaceBetweenObjects ?? 28),
                    Expanded(
                      child: Text(
                        subtitle!,
                        overflow: TextOverflow.ellipsis,
                        maxLines: 1,
                        style: (subtitleColor != null)
                            ? context.textTheme.displayLarge?.copyWith(
                                color: subtitleColor,
                                fontSize: subtitleFontSize)
                            : context.textTheme.displayLarge
                                ?.copyWith(fontSize: subtitleFontSize),
                      ),
                    ),
                  ],
                  SizedBox(width: spaceBetweenObjects ?? 28),
                  endWidget ?? Icon(
                    iconEnd ?? Icons.chevron_right,
                    color: context.theme.iconTheme.color,
                    size: iconSize,
                  ),
                  SizedBox(width: endSizedBoxWidth)
                ],
              ),
            ),
            useDivider
                ? Divider(
                    height: 0,
                    thickness: dividerThickness,
                  )
                : const SizedBox(),
          ],
        ),
      ),
    );
  }
}
