import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/app_buffer/home/widgets/home_app_bar/search/providers.dart';
import 'package:kerla2_flutter/core/core.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';

part 'user_search_state.g.dart';

@riverpod
FutureOr<List<UserProfile>> userSearchState(Ref ref) async {
  final userName = ref.watch(searchString);
  final result = await client.users.getUserListByNick(userName);
  return result;
}
