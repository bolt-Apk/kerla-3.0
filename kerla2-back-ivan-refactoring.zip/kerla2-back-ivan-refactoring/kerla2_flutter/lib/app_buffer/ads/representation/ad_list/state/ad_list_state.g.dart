// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'ad_list_state.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$getAdByIdHash() => r'21a054b5da110ea61ed251cee313eb2e585b905f';

/// Copied from Dart SDK
class _SystemHash {
  _SystemHash._();

  static int combine(int hash, int value) {
    // ignore: parameter_assignments
    hash = 0x1fffffff & (hash + value);
    // ignore: parameter_assignments
    hash = 0x1fffffff & (hash + ((0x0007ffff & hash) << 10));
    return hash ^ (hash >> 6);
  }

  static int finish(int hash) {
    // ignore: parameter_assignments
    hash = 0x1fffffff & (hash + ((0x03ffffff & hash) << 3));
    // ignore: parameter_assignments
    hash = hash ^ (hash >> 11);
    return 0x1fffffff & (hash + ((0x00003fff & hash) << 15));
  }
}

/// See also [getAdById].
@ProviderFor(getAdById)
const getAdByIdProvider = GetAdByIdFamily();

/// See also [getAdById].
class GetAdByIdFamily extends Family<AsyncValue<Ad?>> {
  /// See also [getAdById].
  const GetAdByIdFamily();

  /// See also [getAdById].
  GetAdByIdProvider call(
    int? adId,
  ) {
    return GetAdByIdProvider(
      adId,
    );
  }

  @override
  GetAdByIdProvider getProviderOverride(
    covariant GetAdByIdProvider provider,
  ) {
    return call(
      provider.adId,
    );
  }

  static const Iterable<ProviderOrFamily>? _dependencies = null;

  @override
  Iterable<ProviderOrFamily>? get dependencies => _dependencies;

  static const Iterable<ProviderOrFamily>? _allTransitiveDependencies = null;

  @override
  Iterable<ProviderOrFamily>? get allTransitiveDependencies =>
      _allTransitiveDependencies;

  @override
  String? get name => r'getAdByIdProvider';
}

/// See also [getAdById].
class GetAdByIdProvider extends AutoDisposeFutureProvider<Ad?> {
  /// See also [getAdById].
  GetAdByIdProvider(
    int? adId,
  ) : this._internal(
          (ref) => getAdById(
            ref as GetAdByIdRef,
            adId,
          ),
          from: getAdByIdProvider,
          name: r'getAdByIdProvider',
          debugGetCreateSourceHash:
              const bool.fromEnvironment('dart.vm.product')
                  ? null
                  : _$getAdByIdHash,
          dependencies: GetAdByIdFamily._dependencies,
          allTransitiveDependencies: GetAdByIdFamily._allTransitiveDependencies,
          adId: adId,
        );

  GetAdByIdProvider._internal(
    super._createNotifier, {
    required super.name,
    required super.dependencies,
    required super.allTransitiveDependencies,
    required super.debugGetCreateSourceHash,
    required super.from,
    required this.adId,
  }) : super.internal();

  final int? adId;

  @override
  Override overrideWith(
    FutureOr<Ad?> Function(GetAdByIdRef provider) create,
  ) {
    return ProviderOverride(
      origin: this,
      override: GetAdByIdProvider._internal(
        (ref) => create(ref as GetAdByIdRef),
        from: from,
        name: null,
        dependencies: null,
        allTransitiveDependencies: null,
        debugGetCreateSourceHash: null,
        adId: adId,
      ),
    );
  }

  @override
  AutoDisposeFutureProviderElement<Ad?> createElement() {
    return _GetAdByIdProviderElement(this);
  }

  @override
  bool operator ==(Object other) {
    return other is GetAdByIdProvider && other.adId == adId;
  }

  @override
  int get hashCode {
    var hash = _SystemHash.combine(0, runtimeType.hashCode);
    hash = _SystemHash.combine(hash, adId.hashCode);

    return _SystemHash.finish(hash);
  }
}

mixin GetAdByIdRef on AutoDisposeFutureProviderRef<Ad?> {
  /// The parameter `adId` of this provider.
  int? get adId;
}

class _GetAdByIdProviderElement extends AutoDisposeFutureProviderElement<Ad?>
    with GetAdByIdRef {
  _GetAdByIdProviderElement(super.provider);

  @override
  int? get adId => (origin as GetAdByIdProvider).adId;
}

String _$adListStateHash() => r'9d23607f838f83216903077135b5fecd592e4f8a';

abstract class _$AdListState extends BuildlessAutoDisposeNotifier<AdListData> {
  late final GetAdParam params;

  AdListData build(
    GetAdParam params,
  );
}

/// See also [AdListState].
@ProviderFor(AdListState)
const adListStateProvider = AdListStateFamily();

/// See also [AdListState].
class AdListStateFamily extends Family<AdListData> {
  /// See also [AdListState].
  const AdListStateFamily();

  /// See also [AdListState].
  AdListStateProvider call(
    GetAdParam params,
  ) {
    return AdListStateProvider(
      params,
    );
  }

  @override
  AdListStateProvider getProviderOverride(
    covariant AdListStateProvider provider,
  ) {
    return call(
      provider.params,
    );
  }

  static const Iterable<ProviderOrFamily>? _dependencies = null;

  @override
  Iterable<ProviderOrFamily>? get dependencies => _dependencies;

  static const Iterable<ProviderOrFamily>? _allTransitiveDependencies = null;

  @override
  Iterable<ProviderOrFamily>? get allTransitiveDependencies =>
      _allTransitiveDependencies;

  @override
  String? get name => r'adListStateProvider';
}

/// See also [AdListState].
class AdListStateProvider
    extends AutoDisposeNotifierProviderImpl<AdListState, AdListData> {
  /// See also [AdListState].
  AdListStateProvider(
    GetAdParam params,
  ) : this._internal(
          () => AdListState()..params = params,
          from: adListStateProvider,
          name: r'adListStateProvider',
          debugGetCreateSourceHash:
              const bool.fromEnvironment('dart.vm.product')
                  ? null
                  : _$adListStateHash,
          dependencies: AdListStateFamily._dependencies,
          allTransitiveDependencies:
              AdListStateFamily._allTransitiveDependencies,
          params: params,
        );

  AdListStateProvider._internal(
    super._createNotifier, {
    required super.name,
    required super.dependencies,
    required super.allTransitiveDependencies,
    required super.debugGetCreateSourceHash,
    required super.from,
    required this.params,
  }) : super.internal();

  final GetAdParam params;

  @override
  AdListData runNotifierBuild(
    covariant AdListState notifier,
  ) {
    return notifier.build(
      params,
    );
  }

  @override
  Override overrideWith(AdListState Function() create) {
    return ProviderOverride(
      origin: this,
      override: AdListStateProvider._internal(
        () => create()..params = params,
        from: from,
        name: null,
        dependencies: null,
        allTransitiveDependencies: null,
        debugGetCreateSourceHash: null,
        params: params,
      ),
    );
  }

  @override
  AutoDisposeNotifierProviderElement<AdListState, AdListData> createElement() {
    return _AdListStateProviderElement(this);
  }

  @override
  bool operator ==(Object other) {
    return other is AdListStateProvider && other.params == params;
  }

  @override
  int get hashCode {
    var hash = _SystemHash.combine(0, runtimeType.hashCode);
    hash = _SystemHash.combine(hash, params.hashCode);

    return _SystemHash.finish(hash);
  }
}

mixin AdListStateRef on AutoDisposeNotifierProviderRef<AdListData> {
  /// The parameter `params` of this provider.
  GetAdParam get params;
}

class _AdListStateProviderElement
    extends AutoDisposeNotifierProviderElement<AdListState, AdListData>
    with AdListStateRef {
  _AdListStateProviderElement(super.provider);

  @override
  GetAdParam get params => (origin as AdListStateProvider).params;
}
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
