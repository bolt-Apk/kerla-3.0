import 'package:flutter/material.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class DeleteChatBottomSheet extends StatelessWidget {
  const DeleteChatBottomSheet({
    required this.onDelete,
    super.key,
  });

  final VoidCallback onDelete;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
        decoration: BoxDecoration(
          color: context.theme.canvasColor,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 42,
              height: 4,
              margin: const EdgeInsets.only(bottom: 24),
              decoration: BoxDecoration(
                color: context.theme.dividerColor,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            Icon(Icons.delete_forever_rounded,
                size: 48, color: context.colorScheme.error),
            const SizedBox(height: 16),
            Text(
              'Удалить чат?',
              style: context.textTheme.titleMedium
                  ?.copyWith(fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 8),
            Text(
              'История переписки будет безвозвратно\nудалена',
              textAlign: TextAlign.center,
              style: context.textTheme.bodyMedium,
            ),
            const SizedBox(height: 32),
            SizedBox(
              width: double.infinity,
              child: Button.secondary(
                onPressed: () {
                  Navigator.of(context).pop(); // close sheet
                  onDelete(); // trigger deletion
                },
                child: const Text('Удалить чат'),
              ),
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: Button.text(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text('Отмена'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
