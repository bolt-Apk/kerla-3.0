part of '../ui_kit.dart';

class CustomCheckBox extends StatelessWidget {
  const CustomCheckBox({
    super.key,
    this.value = false,
  });

  final bool value;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 14,
      height: 14,
      decoration: ShapeDecoration(
        color: value ? const Color(0xFF0196A2) : Colors.grey[300],
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5)),
      ),
    );
  }
}
