part of '../ui_kit.dart';

class ReadMore extends StatefulWidget {
  const ReadMore({
    super.key,
    required this.expandWidget,
    required this.collapsWidget,
    required this.contentText,
    this.title,
    this.expandText = "Show more",
    this.collapsText = "Collapse",
    this.showExpandButton = false,
    this.maxLines = 2,
    this.softwrap = true,
    this.expandedIcon = const Icon(Icons.expand_more),
    this.overflow = TextOverflow.ellipsis,
    this.descriptionStyle,
    this.titleStyle,
    this.titleAlignment = Alignment.centerLeft,
    this.descriptionAlignment = Alignment.centerLeft,
    this.expandTextAlignment = MainAxisAlignment.end,
    this.collapsedMaxLines,
    this.contentStyle,
  });

  final Widget expandWidget;
  final Widget collapsWidget;
  final String contentText;
  final String? title;
  final String expandText;
  final String? collapsText;
  final bool showExpandButton;
  final int maxLines;
  final bool softwrap;
  final Icon expandedIcon;
  final TextOverflow overflow;
  final TextStyle? titleStyle;
  final TextStyle? descriptionStyle;
  final Alignment titleAlignment;
  final Alignment descriptionAlignment;
  final MainAxisAlignment expandTextAlignment;
  final int? collapsedMaxLines;
  final TextStyle? contentStyle;

  @override
  State<ReadMore> createState() => _ReadMoreState();
}

class _ReadMoreState extends State<ReadMore> {
  bool _isExpanded = false;

  @override
  Widget build(BuildContext context) {
    bool isOverflow = false;
    if (widget.contentText.isNotEmpty &&
        widget.collapsedMaxLines != null &&
        widget.contentStyle != null) {
      final span =
          TextSpan(text: widget.contentText, style: widget.contentStyle);
      final tp = TextPainter(
        text: span,
        maxLines: widget.collapsedMaxLines,
        textDirection: TextDirection.ltr,
      );
      tp.layout(maxWidth: MediaQuery.of(context).size.width);
      isOverflow = tp.didExceedMaxLines;
    }

    bool shouldShowButton = isOverflow || widget.showExpandButton;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(height: 12),
        if (widget.title != null)
          Align(
            alignment: widget.titleAlignment,
            child: Text(
              widget.title!,
              style: widget.titleStyle,
            ),
          ),
        const SizedBox(height: 10),
        AnimatedCrossFade(
          duration: const Duration(milliseconds: 200),
          crossFadeState: _isExpanded
              ? CrossFadeState.showSecond
              : CrossFadeState.showFirst,
          firstChild: Align(
            alignment: widget.descriptionAlignment,
            child: widget.collapsWidget,
          ),
          secondChild: Align(
            alignment: widget.descriptionAlignment,
            child: widget.expandWidget,
          ),
        ),
        if (shouldShowButton)
          Padding(
            padding: const EdgeInsets.only(top: 8.0),
            child: InkWell(
              onTap: () {
                setState(() {
                  _isExpanded = !_isExpanded;
                });
              },
              child: Row(
                mainAxisAlignment: widget.expandTextAlignment,
                children: [
                  Text(
                    _isExpanded ? widget.collapsText! : widget.expandText,
                    style: TextStyle(
                      color: Theme.of(context).primaryColorDark,
                    ),
                  ),
                  const SizedBox(width: 4),
                  AnimatedRotation(
                    turns: _isExpanded ? 0.5 : 0,
                    duration: const Duration(milliseconds: 200),
                    child: Icon(
                      widget.expandedIcon.icon,
                      color: Theme.of(context).primaryColorDark,
                    ),
                  ),
                ],
              ),
            ),
          ),
        const SizedBox(height: 12),
      ],
    );
  }
}

