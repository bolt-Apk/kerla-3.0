import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/app_buffer/ads/representation/ad_list/state/ad_list_state.dart';
import 'package:kerla2_flutter/app_buffer/home/filters/list_filter/list_filter_widget.dart';
import 'package:kerla2_flutter/app_buffer/profile/categories/state/categories_provider.dart';
import 'package:kerla2_flutter/app_buffer/profile/subscribers/subscribers_widget.dart';
import 'package:kerla2_flutter/router/router.dart';
import 'package:nit_app/nit_app.dart';
import 'package:nit_router/nit_router.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

import '../../ads/representation/ad_list/ads_grid.dart';
import '../../../core/app_scaffold.dart';
import 'widgets/profile_header_delegate.dart';
import 'widgets/profile_sort_widget.dart';

class UserProfilePage extends ConsumerWidget {
  const UserProfilePage({
    super.key,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final userId = ref.watchNavigationParam(AppNavigationParams.userId) ??
        ref.signedInUserId!;

    return AppScaffold(
      extendBodyBehindAppBar: true,
      body: RefreshIndicator(
        onRefresh: () async {
          ref.read(globalRefreshTriggerProvider.notifier).state =
              DateTime.now();
        },
        child: CustomScrollView(
          controller: ScrollController(
            keepScrollOffset: false,
            initialScrollOffset: 100,
          ),
          physics: const ClampingScrollPhysics(),
          slivers: [
            SliverPersistentHeader(
              pinned: true,
              delegate: ProfileHeaderDelegate(
                maxExtent: MediaQuery.sizeOf(context).height * 0.55,
                minExtent: MediaQuery.paddingOf(context).top + kToolbarHeight,
                userId: userId,
              ),
            ),
            SliverToBoxAdapter(
              child: Column(
                children: [
                  SubscribersWidget(userId: userId),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: ProfileSortWidget(userId: userId),
                  ),
                  Consumer(
                    builder: (context, ref, child) {
                      return ref
                          .watch(profileAdCategoriesProvider(userId))
                          .nitWhen(
                            childBuilder: (categories) => ListFilterWidget(
                              adListType: AdListType.profile,
                              categories: categories,
                            ),
                          );
                    },
                  ),
                ],
              ),
            ),
            AdsGrid(
              isSliver: true,
              physics: const NeverScrollableScrollPhysics(),
              params: GetAdParam(
                adListType: AdListType.profile,
                id: userId,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
