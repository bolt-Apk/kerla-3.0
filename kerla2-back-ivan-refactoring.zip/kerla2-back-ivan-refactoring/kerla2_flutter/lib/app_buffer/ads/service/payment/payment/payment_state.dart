// import 'dart:async';

// import 'package:flutter/material.dart';
// import 'package:flutter_riverpod/flutter_riverpod.dart';
// import 'package:freezed_annotation/freezed_annotation.dart';
// import 'package:kerla2_client/kerla2_client.dart';
// import 'package:kerla2_flutter/core/core.dart';
// import 'package:riverpod_annotation/riverpod_annotation.dart';
// import 'package:tinkoff_acquiring/tinkoff_acquiring.dart';
// import 'package:tinkoff_acquiring/tinkoff_acquiring_utils.dart';
// import 'package:tinkoff_acquiring_flutter/tinkoff_acquiring_flutter.dart';

// part 'payment_state.g.dart';
// part 'payment_state.freezed.dart';

// const String _publicKey =
//     'MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAv5yse9ka3ZQE0feuGtemYv3IqOlLck8zHUM7lTr0za6lXTszRSXfUO7jMb+L5C7e2QNFs+7sIX2OQJ6a+HG8kr+jwJ4tS3cVsWtd9NXpsU40PE4MeNr5RqiNXjcDxA+L4OsEm/BlyFOEOh2epGyYUd5/iO3OiQFRNicomT2saQYAeqIwuELPs1XpLk9HLx5qPbm8fRrQhjeUD5TLO8b+4yCnObe8vy/BMUwBfq+ieWADIjwWCMp2KTpMGLz48qnaD9kdrYJ0iyHqzb2mkDhdIzkim24A3lWoYitJCBrrB2xM05sm9+OdCI1f7nPNJbl5URHobSwR94IRGT7CJcUjvwIDAQAB';

// @riverpod
// class PaymentState extends _$PaymentState {
//   @override
//   PaymentStateData build() {
//     ref.onDispose(() {
//       state.cardPanController.dispose();
//       state.cardExpDateController.dispose();
//       state.cardCvvController.dispose();
//     });

//     return PaymentStateData.init();
//   }

//   void resetError() {
//     state = state.copyWith(
//       error: '',
//     );
//   }

//   bool _checkError(AcquiringResponse response) {
//     if (response.success == false && response.errorCode != null) {
//       _notifyAboutError(
//         '''
// errorCode: ${response.errorCode}
// status: ${response.status}
// message: ${response.message}
// details: ${response.details}
// ''',
//       );
//       return true;
//     }

//     return false;
//   }

//   void _notifyAboutError(String? error) {
//     state = state.copyWith(
//       error: error,
//     );
//   }

//   void canContinueNotifier() {
//     final canContinue = state.cardPanController.text.length == 19 &&
//         state.cardExpDateController.text.length == 5 &&
//         state.cardCvvController.text.length == 3;
//     canContinueHandle(canContinue);
//   }

//   void canContinueHandle(bool canCont) {
//     if (state.canContinue != canCont) {
//       state = state.copyWith(canContinue: canCont);
//     }
//   }

//   // TODO: не передавать amount, а считать все исходя из promotions.
//   // Мб на сервере
//   Future<bool> pay(
//     BuildContext context,
//     WidgetRef ref,
//     int amount,
//     List<KerlaService> promotions,
//   ) async {
//     resetError();

//     final cardNumber = state.cardPanController.text.replaceAll(' ', '');
//     final cardExpDate = state.cardExpDateController.text.replaceAll('/', '');

//     if (!CardValidator.validateCardNumber(cardNumber)) {
//       _notifyAboutError('Введен некорректный номер карты');
//       return false;
//     }
//     if (!CardValidator.validateExpireDate(cardExpDate)) {
//       _notifyAboutError('Введена некорректная дата');
//       return false;
//     }
//     if (!CardValidator.validateSecurityCode(state.cardCvvController.text)) {
//       _notifyAboutError('Введен некорректный трехзначный код');
//       return false;
//     }
//     // Тк amount в копейках
//     amount = amount * 100;

//     final String cardData = CardData(
//       pan: cardNumber,
//       expDate: cardExpDate,
//       cvv: state.cardCvvController.text,
//     ).encode(_publicKey);

//     final InitResponse init = await client.acquiring.init(
//       InitRequest(
//         orderId:
//             '${DateTime.now().millisecondsSinceEpoch.toString()}_kerla_userId',
//         description: 'Услуги продвижения объявления',
//         amount: amount,
//         language: Language.ru,
//         payType: PayType.one,
//       ),
//       promotions,
//     );

//     if (_checkError(init)) return false;

//     final Check3DSVersionResponse check3DSVersion =
//         await client.acquiring.check3DSVersion(
//       Check3DSVersionRequest(
//         paymentId: int.parse(init.paymentId!),
//         cardData: cardData,
//       ),
//     );

//     if (_checkError(check3DSVersion)) return false;

//     final Completer<Map<String, String>> data =
//         Completer<Map<String, String>>();
//     if (check3DSVersion.is3DsVersion2) {
//       if (context.mounted) {
//         CollectData(
//           context: context,
//           config: state.acquiring.config,
//           serverTransId: check3DSVersion.serverTransId!,
//           threeDsMethodUrl: check3DSVersion.threeDsMethodUrl!,
//           onFinished: (Map<String, String> v) {
//             data.complete(v);
//           },
//         );
//       }
//     } else {
//       data.complete(<String, String>{});
//     }

//     final FinishAuthorizeResponse fa = await client.acquiring.finishAuthorize(
//       FinishAuthorizeRequest(
//         paymentId: int.parse(init.paymentId!),
//         cardData: cardData,
//         data: await data.future,
//         ip: await getIpAddress(),
//       ),
//     );

//     if (_checkError(fa)) return false;

//     final Completer<Submit3DSAuthorizationResponse?> webView =
//         Completer<Submit3DSAuthorizationResponse?>();
//     if (fa.status == Status.threeDsChecking) {
//       if (context.mounted) {
//         Navigator.of(context)
//             .push(
//           MaterialPageRoute<void>(
//             builder: (BuildContext context) => SafeArea(
//               child: Scaffold(
//                 body: WebView3DS(
//                   config: state.acquiring.config,
//                   is3DsVersion2:
//                       fa.is3DsVersion2 || check3DSVersion.is3DsVersion2,
//                   serverTransId:
//                       fa.tdsServerTransId ?? check3DSVersion.serverTransId,
//                   acsUrl: fa.acsUrl!,
//                   md: fa.md,
//                   paReq: fa.paReq,
//                   acsTransId: fa.acsTransId,
//                   version: check3DSVersion.version,
//                   onLoad: ({required bool isLoading}) {
//                     debugPrint('WebView load: $isLoading');
//                   },
//                   onFinished: (Submit3DSAuthorizationResponse? v) {
//                     Navigator.of(context).pop();
//                     webView.complete(v);
//                   },
//                 ),
//               ),
//             ),
//           ),
//         )
//             .then((value) {
//           canContinueHandle(true);
//         });
//       }
//     } else {
//       webView.complete(null);
//     }

//     return await webView.future
//         .then<bool>((Submit3DSAuthorizationResponse? s) async {
//       final GetStateResponse getState = await client.acquiring.getState(
//         GetStateRequest(
//           paymentId: int.parse(
//             s?.paymentId ?? fa.paymentId ?? init.paymentId!,
//           ),
//         ),
//       );

//       if (_checkError(getState)) return false;

//       if (getState.status == Status.confirmed ||
//           getState.status == Status.authorized) {
//         return true;
//       }

//       return false;
//     });
//   }

//   Future<bool> cancle(WidgetRef ref, int paymentId) async {
//     final cancle = await client.acquiring.cancel(
//       CancelRequest(
//         paymentId: paymentId,
//       ),
//     );

//     return cancle.success ?? false;
//   }
// }

// @freezed
// class PaymentStateData with _$PaymentStateData {
//   const factory PaymentStateData({
//     required TextEditingController cardPanController,
//     required TextEditingController cardExpDateController,
//     required TextEditingController cardCvvController,
//     @Default(false) bool canContinue,
//     @protected required TinkoffAcquiring acquiring,
//     String? error,
//   }) = _PaymentStateData;

//   factory PaymentStateData.init() => _PaymentStateData(
//         cardPanController: TextEditingController(),
//         cardExpDateController: TextEditingController(),
//         cardCvvController: TextEditingController(),
//         acquiring: TinkoffAcquiring(
//           TinkoffAcquiringConfig.proxy(
//             proxyDomain: '91.142.73.206:8080',
//             proxyPath: '/acquiring',
//             isDebugMode: false,
//           ),
//         ),
//       );
// }
