import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class SubscriptionBottomSheet extends ConsumerStatefulWidget {
  const SubscriptionBottomSheet({
    super.key,
    // required this.user,
  });

  // final UserInfoPublic user;
  @override
  ConsumerState<ConsumerStatefulWidget> createState() =>
      _SubscriptionBottomSheetState();
}

class _SubscriptionBottomSheetState
    extends ConsumerState<SubscriptionBottomSheet> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Align(
            alignment: Alignment.center,
            child: LittleDivider(),
          ),
          // TextSettingsRow(
          //   title: 'Беззвучный режим',
          //   subtitle: '',
          //   bottomSheetBuilder: (){
          //     return const ProfileMuteBottomSheet();
          //   },
          //   dividerThickness: 0.4,
          // ),
          // TextSettingsRow(
          //   title: 'Ограничить',
          //   subtitle: '',
          //   bottomSheetBuilder: (){
          //     return const ProfileMuteBottomSheet();
          //   },
          //   dividerThickness: 0.4,
          // ),
          InkWell(
            onTap: () async {
              // TODO: вернуть
              // await client.subscription.unsubscribe(userId: widget.user.id!);
              // ref.invalidate(userProvider);
              Navigator.pop(context);
            },
            child: Container(
              height: 50,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                  color: context.theme.secondaryHeaderColor,
                  borderRadius: BorderRadius.circular(10)),
              child: Text(
                'Отписаться',
                style:
                    context.textTheme.titleLarge?.copyWith(color: Colors.red),
              ),
            ),
          )
        ],
      ),
    );
  }
}
