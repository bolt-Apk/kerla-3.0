import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerla2_flutter/router/router.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_router/nit_router.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

import 'media/widgets/main_photos_carousel.dart';

class PublicationBottomSheet extends ConsumerWidget {
  const PublicationBottomSheet({
    super.key,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return MainBottomSheet(
      color: context.theme.canvasColor,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          const MainPhotosCarousel(imageSize: 130),
          NavigationButton(
            imageAsset: AppIconsSvg.chooseFromGalary,
            imageColor: context.theme.iconTheme.color ?? Colors.black,
            buttonText: "Создать объявление",
            fontColor: context.theme.iconTheme.color ?? Colors.black,
            onTap: () {
              Navigator.pop(context);
              context.pushNamed(
                AdNavigationZone.createAd.name,
                // extra: maxCount,
              );
            },
          ),
          const Divider(
            height: 1,
          ),
          NavigationButton(
            imageAsset: AppNavigationIconsSvg.stories,
            imageColor: Theme.of(context).iconTheme.color ?? Colors.black,
            buttonText: "Создать фото-видео сторис",
            fontColor: Theme.of(context).iconTheme.color ?? Colors.black,
            onTap: () async {
              Navigator.pop(context);
              context.pushNamed(
                AdNavigationZone.createStory.name,
              );
            },
          ),
          const Divider(
            height: 1,
          ),
        ],
      ),
    );
  }
}
