// import 'package:flutter/material.dart';
// import 'package:flutter_riverpod/flutter_riverpod.dart';
// import 'package:kerla2_client/kerla2_client.dart';

// import '../../ad/state/ad/ad_state.dart';
// import '../state/home_filters_state.dart';
// import 'home_filters_inline_render.dart';
// import '../list_filter/widgets/home_radio_button.dart';

// class HomeSelectAttributes extends ConsumerWidget {
//   const HomeSelectAttributes({
//     super.key,
//     this.userId,
//   });

//   final int? userId;

//   @override
//   Widget build(BuildContext context, WidgetRef ref) {
//     return FutureBuilder(
//       future: ref
//           .read(homeFiltersStateProvider(isProfile: userId != null).notifier)
//           .getAttributes(),
//       builder: (context, snapshot) {
//         if (snapshot.connectionState != ConnectionState.done) {
//           return const Center(
//             child: CircularProgressIndicator(),
//           );
//         }

//         if (snapshot.data == null || snapshot.data!.isEmpty) {
//           return Row(
//             children: [
//               Padding(
//                 padding: const EdgeInsets.only(right: 10),
//                 child: SizedBox(
//                   height: 40,
//                   child: HomeRadioButton(
//                     isSelected: true,
//                     onTap: () {
//                       ref
//                           .read(
//                             homeFiltersStateProvider(
//                               isProfile: userId != null,
//                             ).notifier,
//                           )
//                           .popCategoryStack();
//                       // ref.invalidate(
//                       //   adListStateProvider(userId: userId),
//                       // );
//                     },
//                   ),
//                 ),
//               ),
//               const Center(
//                 child: Text(
//                   "Нет атрибутов",
//                 ),
//               ),
//             ],
//           );
//         }
//         final filteredData = snapshot.data!
//             .where((item) => item.type != AttributeType.regionsDropdown)
//             .toList();
//         return Row(
//           children: [
//             SizedBox(
//               height: 40,
//               child: HomeRadioButton(
//                 isSelected: true,
//                 onTap: () {
//                   ref
//                       .read(
//                         homeFiltersStateProvider(isProfile: userId != null)
//                             .notifier,
//                       )
//                       .popCategoryStack();
//                   ref
//                       .read(
//                         homeFiltersStateProvider(isProfile: userId != null)
//                             .notifier,
//                       )
//                       .removeAttributes();
//                   // ref.invalidate(
//                   //   adListStateProvider(userId: userId),
//                   // );
//                   // ref.invalidate(attributeDropDownValueProvider);
//                 },
//               ),
//             ),
//             const SizedBox(width: 10),
//             Expanded(
//               child: ListView.builder(
//                 scrollDirection: Axis.horizontal,
//                 itemCount: filteredData.length,
//                 itemBuilder: (context, index) {
//                   return Padding(
//                     padding: const EdgeInsets.only(right: 8),
//                     child: HomeFiltersInlineRender(
//                       attributeValue: filteredData[index],
//                       userId: userId,
//                       onSave: (value) {},
//                     ),
//                   );
//                 },
//               ),
//             ),
//           ],
//         );
//       },
//     );
//   }
// }
