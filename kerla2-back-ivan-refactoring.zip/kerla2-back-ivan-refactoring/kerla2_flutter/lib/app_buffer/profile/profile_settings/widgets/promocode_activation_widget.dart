import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerla2_flutter/core/core.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_riverpod_notifications/nit_riverpod_notifications.dart';

class PromocodeActivationWidget extends ConsumerWidget {
  const PromocodeActivationWidget({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return TextSettingsRow(
      title: 'Промокод',
      subtitle: '',
      editingBottomSheet: TextEditingBottomSheet(
        initialValue: '',
        title: 'Введите промокод',
        keyboardType: TextInputType.text,
        maxLength: 20,
        showCounter: false,
        acceptAction: (String newValue) async {
          final error = await client.promocode.acceptPromocode(newValue);
          if (error != null) {
            ref.notifyUser(NitNotification.error(
              error,
            ));
            return false;
          }

          ref.notifyUser(NitNotification.success(
            'Промокод активирован',
          ));
          return true;
        },
      ),
    );
  }
}
