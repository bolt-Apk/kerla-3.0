import 'package:kerla2_client/kerla2_client.dart';

late final Client client;
