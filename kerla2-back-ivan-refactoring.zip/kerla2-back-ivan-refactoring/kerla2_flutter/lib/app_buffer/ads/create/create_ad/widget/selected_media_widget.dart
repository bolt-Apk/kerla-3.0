import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_svg/svg.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/router/router.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_router/nit_router.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

import '../../media/state/selected_media_state.dart';
import 'create_ad_asset.dart';

class AdSelectedMediaWidget extends ConsumerWidget {
  const AdSelectedMediaWidget({
    super.key,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final int? adId = ref.watchNavigationParam(AppNavigationParams.adId);
    final state = ref.watch(adMediaStateProvider(adId: adId)).items;

    return Column(
      children: [
        Text(
          'Выберите фотографии',
          style: context.textTheme.headlineMedium,
        ),
        const SizedBox(height: 10),
        SvgPicture.asset(AppIconsSvg.arrowForAdPage),
        const SizedBox(height: 10),
        SizedBox(
          height: 100,
          width: double.infinity,
          child: state.isNotEmpty
              ? ReorderableListView.builder(
                  shrinkWrap: true,
                  physics: const BouncingScrollPhysics(),
                  scrollDirection: Axis.horizontal,
                  onReorder: (int oldIndex, int newIndex) {
                    ref
                        .read(adMediaStateProvider(adId: adId).notifier)
                        .reorderItems(oldIndex, newIndex);
                  },
                  itemCount: state.length,
                  itemBuilder: (context, index) {
                    return Padding(
                      key: ValueKey(state[index].item),
                      padding: const EdgeInsets.all(2),
                      child: ConstrainedBox(
                        constraints: const BoxConstraints(maxWidth: 100),
                        child: CreateAdAsset(
                          media: state[index],
                        ),
                      ),
                    );
                  },
                )
              : Center(
                  child: Column(
                    children: [
                      Text(
                        "Фотографии не выбраны",
                        style: context.textTheme.bodyMedium,
                      ),
                      TextButton(
                        onPressed: () => ref
                            .read(
                              adMediaStateProvider(adId: adId).notifier,
                            )
                            .openMediaPicker(context, AdType.ad),
                        child: const Text('Выбрать'),
                      ),
                    ],
                  ),
                ),
        ),
        GestureDetector(
          key: const ValueKey('add_button'),
          onTap: () async {
            FocusManager.instance.primaryFocus?.unfocus();
            ref
                .read(
                  adMediaStateProvider(adId: adId).notifier,
                )
                .openMediaPicker(context, AdType.ad);
          },
          child: const Center(
            child: Icon(
              Icons.add_photo_alternate_rounded,
              size: 64.0,
            ),
          ),
        )
      ],
    );
  }
}




// class AdSelectedMediaWidget extends ConsumerWidget {
//   const AdSelectedMediaWidget({
//     super.key,
//     this.initMedias,
//   });

//   final List<Media>? initMedias;

//   @override
//   Widget build(BuildContext context, WidgetRef ref) {
//     final List<AssetEntity> selectedAssets =
//         ref.watch(selectedMediaStateProvider(initMedias: initMedias));

//     final List<Object> allAssets = [];

//     allAssets.addAll(initMedias ?? []);
//     allAssets.addAll(selectedAssets);
//     final theme = Theme.of(context);
//     return Column(
//       children: [
//         Text(
//           'Выберите фотографии',
//           style: theme.textTheme.headlineMedium,
//         ),
//         const SizedBox(
//           height: 10,
//         ),
//         SvgPicture.asset(AppIconsSvg.arrowForAdPage),
//         const SizedBox(
//           height: 10,
//         ),
//         ConstrainedBox(
//           constraints: const BoxConstraints(maxHeight: 260),
//           child: allAssets.isNotEmpty
//               ? GridView.builder(
//                   shrinkWrap: true,
//                   physics: const BouncingScrollPhysics(),
//                   itemCount: allAssets.length + 1,
//                   gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
//                     crossAxisCount: 3,
//                   ),
//                   itemBuilder: (context, index) {
//                     if (index == allAssets.length) {
//                       return GestureDetector(
//                         onTap: () async {
//                           FocusManager.instance.primaryFocus?.unfocus();
//                           ref
//                               .watch(
//                                 selectedMediaStateProvider(
//                                   initMedias: initMedias,
//                                 ).notifier,
//                               )
//                               .openMediaPicker(context);
//                         },
//                         child: const Center(
//                           child: Icon(
//                             Icons.photo_size_select_actual_rounded,
//                             size: 64.0,
//                           ),
//                         ),
//                       );
//                     }
//                     return Padding(
//                       padding: const EdgeInsets.all(2),
//                       child: CreateAdAsset(
//                         initMedias: initMedias,
//                         initMedia: allAssets[index] is Media
//                             ? allAssets[index] as Media
//                             : null,
//                         assetEntity: allAssets[index] is AssetEntity
//                             ? allAssets[index] as AssetEntity
//                             : null,
//                       ),
//                     );
//                   },
//                 )
//               : SizedBox(
//                   width: 600,
//                   height: 75,
//                   child: Column(
//                     children: [
//                       Center(
//                         child: Text(
//                           "Фотографии не выбраны",
//                           style: theme.textTheme.bodyMedium,
//                           ),
//                       ),
//                       TextButton(
//                         onPressed: () => ref
//                             .watch(
//                               selectedMediaStateProvider(initMedias: initMedias)
//                                   .notifier,
//                             )
//                             .openMediaPicker(context),
//                         child: const Text('Выбрать'),
//                       ),
//                     ],
//                   ),
//                 ),
//         ),
//       ],
//     );
//   }
// }
