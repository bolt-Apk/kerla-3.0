import 'package:flutter/material.dart';
import 'package:flutter_multi_formatter/formatters/phone_input_formatter.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerla2_flutter/common/user_profile_ref_extensions.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_app/nit_app.dart';

class EditPhoneWidget extends ConsumerWidget {
  const EditPhoneWidget({
    super.key,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final userProfile = ref.currentUserProfile!;
    return TextSettingsRow(
      title: 'Номер телефона:',
      subtitle: userProfile.phoneNumber?.maskedPhone ?? 'Номер не задан',
      editingBottomSheet: const PhoneEditBottomSheet(),
    );
  }
}

class PhoneEditBottomSheet extends ConsumerWidget {
  const PhoneEditBottomSheet({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final userProfile = ref.currentUserProfile!;

    return TextEditingBottomSheet(
      initialValue: userProfile.phoneNumber?.maskedPhone ?? '',
      title: 'Номер телефона:',
      keyboardType: TextInputType.phone,
      maxLength: 20,
      showCounter: false,
      inputFormatter: PhoneInputFormatter(),
      acceptAction: (String newValue) async {
        final phone = newValue.unmaskPhone;
        if (phone == null) {
          return false;
        }
        return null !=
            (await ref.saveModel(
              userProfile.copyWith(phoneNumber: phone),
            ));
      },
    );
  }
}
