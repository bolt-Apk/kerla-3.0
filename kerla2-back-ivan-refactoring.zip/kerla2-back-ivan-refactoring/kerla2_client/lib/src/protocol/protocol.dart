/* AUTOMATICALLY GENERATED CODE DO NOT MODIFY */
/*   To generate run: "serverpod generate"    */

// ignore_for_file: implementation_imports
// ignore_for_file: library_private_types_in_public_api
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: public_member_api_docs
// ignore_for_file: type_literal_in_constant_pattern
// ignore_for_file: use_super_parameters

library protocol; // ignore_for_file: no_leading_underscores_for_library_prefixes

import 'package:serverpod_client/serverpod_client.dart' as _i1;
import 'ads/ad.dart' as _i2;
import 'ads/ad_attribute_value.dart' as _i3;
import 'ads/ad_category.dart' as _i4;
import 'ads/ad_list_type.dart' as _i5;
import 'ads/ad_report.dart' as _i6;
import 'ads/ad_report_reason.dart' as _i7;
import 'ads/ad_sort_by_values.dart' as _i8;
import 'ads/ad_status.dart' as _i9;
import 'ads/ad_type.dart' as _i10;
import 'ads/ad_view_count.dart' as _i11;
import 'attributes/attribute.dart' as _i12;
import 'attributes/attribute_type.dart' as _i13;
import 'attributes/colors.dart' as _i14;
import 'attributes/sub_attribute.dart' as _i15;
import 'cache/cached_attribute_list.dart' as _i16;
import 'favourite_ad.dart' as _i17;
import 'kerla_services/kerla_service.dart' as _i18;
import 'kerla_services/kerla_service_info.dart' as _i19;
import 'kerla_services/kerla_service_type.dart' as _i20;
import 'notifications/app_notification.dart' as _i21;
import 'notifications/notification_permission.dart' as _i22;
import 'notifications/notification_permission_type.dart' as _i23;
import 'notifications/notification_type.dart' as _i24;
import 'promos/promo_activations.dart' as _i25;
import 'promos/promo_bonuses.dart' as _i26;
import 'promos/promo_level.dart' as _i27;
import 'promos/promo_level_activation.dart' as _i28;
import 'region.dart' as _i29;
import 'user_profile/user_gender.dart' as _i30;
import 'user_profile/user_profile.dart' as _i31;
import 'user_profile/user_subscription.dart' as _i32;
import 'protocol.dart' as _i33;
import 'package:nit_tools_client/nit_tools_client.dart' as _i34;
import 'package:kerla2_client/src/protocol/kerla_services/kerla_service.dart'
    as _i35;
import 'package:kerla2_client/src/protocol/ads/ad.dart' as _i36;
import 'package:kerla2_client/src/protocol/user_profile/user_profile.dart'
    as _i37;
import 'package:kerla2_client/src/protocol/kerla_services/kerla_service_info.dart'
    as _i38;
import 'package:kerla2_client/src/protocol/ads/ad_category.dart' as _i39;
import 'package:kerla2_client/src/protocol/attributes/attribute.dart' as _i40;
import 'package:kerla2_client/src/protocol/attributes/sub_attribute.dart'
    as _i41;
import 'package:kerla2_client/src/protocol/notifications/app_notification.dart'
    as _i42;
import 'package:tinkoff_acquiring/src/core/models/init/init_response.dart'
    as _i43;
import 'package:tinkoff_acquiring/src/core/models/init/init_request.dart'
    as _i44;
import 'package:tinkoff_acquiring/src/core/models/check_3ds_version/check_3ds_version_response.dart'
    as _i45;
import 'package:tinkoff_acquiring/src/core/models/check_3ds_version/check_3ds_version_request.dart'
    as _i46;
import 'package:tinkoff_acquiring/src/core/models/finish_authorize/finish_authorize_response.dart'
    as _i47;
import 'package:tinkoff_acquiring/src/core/models/finish_authorize/finish_authorize_request.dart'
    as _i48;
import 'package:tinkoff_acquiring/src/core/models/cancel/cancel_response.dart'
    as _i49;
import 'package:tinkoff_acquiring/src/core/models/cancel/cancel_request.dart'
    as _i50;
import 'package:tinkoff_acquiring/src/core/models/get_state/get_state_response.dart'
    as _i51;
import 'package:tinkoff_acquiring/src/core/models/get_state/get_state_request.dart'
    as _i52;
import 'package:tinkoff_acquiring/src/core/models/charge/charge_response.dart'
    as _i53;
import 'package:tinkoff_acquiring/src/core/models/charge/charge_request.dart'
    as _i54;
import 'package:dartway_tinkoff_serverpod_client/dartway_tinkoff_serverpod_client.dart'
    as _i55;
import 'package:serverpod_auth_client/serverpod_auth_client.dart' as _i56;
export 'ads/ad.dart';
export 'ads/ad_attribute_value.dart';
export 'ads/ad_category.dart';
export 'ads/ad_list_type.dart';
export 'ads/ad_report.dart';
export 'ads/ad_report_reason.dart';
export 'ads/ad_sort_by_values.dart';
export 'ads/ad_status.dart';
export 'ads/ad_type.dart';
export 'ads/ad_view_count.dart';
export 'attributes/attribute.dart';
export 'attributes/attribute_type.dart';
export 'attributes/colors.dart';
export 'attributes/sub_attribute.dart';
export 'cache/cached_attribute_list.dart';
export 'favourite_ad.dart';
export 'kerla_services/kerla_service.dart';
export 'kerla_services/kerla_service_info.dart';
export 'kerla_services/kerla_service_type.dart';
export 'notifications/app_notification.dart';
export 'notifications/notification_permission.dart';
export 'notifications/notification_permission_type.dart';
export 'notifications/notification_type.dart';
export 'promos/promo_activations.dart';
export 'promos/promo_bonuses.dart';
export 'promos/promo_level.dart';
export 'promos/promo_level_activation.dart';
export 'region.dart';
export 'user_profile/user_gender.dart';
export 'user_profile/user_profile.dart';
export 'user_profile/user_subscription.dart';
export 'client.dart';

class Protocol extends _i1.SerializationManager {
  Protocol._();

  factory Protocol() => _instance;

  static final Protocol _instance = Protocol._();

  @override
  T deserialize<T>(
    dynamic data, [
    Type? t,
  ]) {
    t ??= T;
    if (t == _i2.Ad) {
      return _i2.Ad.fromJson(data) as T;
    }
    if (t == _i3.AdAttributeValue) {
      return _i3.AdAttributeValue.fromJson(data) as T;
    }
    if (t == _i4.AdCategory) {
      return _i4.AdCategory.fromJson(data) as T;
    }
    if (t == _i5.AdListType) {
      return _i5.AdListType.fromJson(data) as T;
    }
    if (t == _i6.AdReport) {
      return _i6.AdReport.fromJson(data) as T;
    }
    if (t == _i7.AdReportReason) {
      return _i7.AdReportReason.fromJson(data) as T;
    }
    if (t == _i8.AdOrderBy) {
      return _i8.AdOrderBy.fromJson(data) as T;
    }
    if (t == _i9.AdStatus) {
      return _i9.AdStatus.fromJson(data) as T;
    }
    if (t == _i10.AdType) {
      return _i10.AdType.fromJson(data) as T;
    }
    if (t == _i11.AdViewCount) {
      return _i11.AdViewCount.fromJson(data) as T;
    }
    if (t == _i12.Attribute) {
      return _i12.Attribute.fromJson(data) as T;
    }
    if (t == _i13.AttributeType) {
      return _i13.AttributeType.fromJson(data) as T;
    }
    if (t == _i14.KerlaColors) {
      return _i14.KerlaColors.fromJson(data) as T;
    }
    if (t == _i15.SubAttribute) {
      return _i15.SubAttribute.fromJson(data) as T;
    }
    if (t == _i16.CachableAttributeList) {
      return _i16.CachableAttributeList.fromJson(data) as T;
    }
    if (t == _i17.FavouriteAd) {
      return _i17.FavouriteAd.fromJson(data) as T;
    }
    if (t == _i18.KerlaService) {
      return _i18.KerlaService.fromJson(data) as T;
    }
    if (t == _i19.KerlaServiceInfo) {
      return _i19.KerlaServiceInfo.fromJson(data) as T;
    }
    if (t == _i20.KerlaServiceType) {
      return _i20.KerlaServiceType.fromJson(data) as T;
    }
    if (t == _i21.AppNotification) {
      return _i21.AppNotification.fromJson(data) as T;
    }
    if (t == _i22.NotificationPermission) {
      return _i22.NotificationPermission.fromJson(data) as T;
    }
    if (t == _i23.NotificationPermissionType) {
      return _i23.NotificationPermissionType.fromJson(data) as T;
    }
    if (t == _i24.NotificationType) {
      return _i24.NotificationType.fromJson(data) as T;
    }
    if (t == _i25.PromoActivation) {
      return _i25.PromoActivation.fromJson(data) as T;
    }
    if (t == _i26.PromoBonuses) {
      return _i26.PromoBonuses.fromJson(data) as T;
    }
    if (t == _i27.PromoLevel) {
      return _i27.PromoLevel.fromJson(data) as T;
    }
    if (t == _i28.PromoLevelActivation) {
      return _i28.PromoLevelActivation.fromJson(data) as T;
    }
    if (t == _i29.Region) {
      return _i29.Region.fromJson(data) as T;
    }
    if (t == _i30.UserGender) {
      return _i30.UserGender.fromJson(data) as T;
    }
    if (t == _i31.UserProfile) {
      return _i31.UserProfile.fromJson(data) as T;
    }
    if (t == _i32.UserSubscription) {
      return _i32.UserSubscription.fromJson(data) as T;
    }
    if (t == _i1.getType<_i2.Ad?>()) {
      return (data != null ? _i2.Ad.fromJson(data) : null) as T;
    }
    if (t == _i1.getType<_i3.AdAttributeValue?>()) {
      return (data != null ? _i3.AdAttributeValue.fromJson(data) : null) as T;
    }
    if (t == _i1.getType<_i4.AdCategory?>()) {
      return (data != null ? _i4.AdCategory.fromJson(data) : null) as T;
    }
    if (t == _i1.getType<_i5.AdListType?>()) {
      return (data != null ? _i5.AdListType.fromJson(data) : null) as T;
    }
    if (t == _i1.getType<_i6.AdReport?>()) {
      return (data != null ? _i6.AdReport.fromJson(data) : null) as T;
    }
    if (t == _i1.getType<_i7.AdReportReason?>()) {
      return (data != null ? _i7.AdReportReason.fromJson(data) : null) as T;
    }
    if (t == _i1.getType<_i8.AdOrderBy?>()) {
      return (data != null ? _i8.AdOrderBy.fromJson(data) : null) as T;
    }
    if (t == _i1.getType<_i9.AdStatus?>()) {
      return (data != null ? _i9.AdStatus.fromJson(data) : null) as T;
    }
    if (t == _i1.getType<_i10.AdType?>()) {
      return (data != null ? _i10.AdType.fromJson(data) : null) as T;
    }
    if (t == _i1.getType<_i11.AdViewCount?>()) {
      return (data != null ? _i11.AdViewCount.fromJson(data) : null) as T;
    }
    if (t == _i1.getType<_i12.Attribute?>()) {
      return (data != null ? _i12.Attribute.fromJson(data) : null) as T;
    }
    if (t == _i1.getType<_i13.AttributeType?>()) {
      return (data != null ? _i13.AttributeType.fromJson(data) : null) as T;
    }
    if (t == _i1.getType<_i14.KerlaColors?>()) {
      return (data != null ? _i14.KerlaColors.fromJson(data) : null) as T;
    }
    if (t == _i1.getType<_i15.SubAttribute?>()) {
      return (data != null ? _i15.SubAttribute.fromJson(data) : null) as T;
    }
    if (t == _i1.getType<_i16.CachableAttributeList?>()) {
      return (data != null ? _i16.CachableAttributeList.fromJson(data) : null)
          as T;
    }
    if (t == _i1.getType<_i17.FavouriteAd?>()) {
      return (data != null ? _i17.FavouriteAd.fromJson(data) : null) as T;
    }
    if (t == _i1.getType<_i18.KerlaService?>()) {
      return (data != null ? _i18.KerlaService.fromJson(data) : null) as T;
    }
    if (t == _i1.getType<_i19.KerlaServiceInfo?>()) {
      return (data != null ? _i19.KerlaServiceInfo.fromJson(data) : null) as T;
    }
    if (t == _i1.getType<_i20.KerlaServiceType?>()) {
      return (data != null ? _i20.KerlaServiceType.fromJson(data) : null) as T;
    }
    if (t == _i1.getType<_i21.AppNotification?>()) {
      return (data != null ? _i21.AppNotification.fromJson(data) : null) as T;
    }
    if (t == _i1.getType<_i22.NotificationPermission?>()) {
      return (data != null ? _i22.NotificationPermission.fromJson(data) : null)
          as T;
    }
    if (t == _i1.getType<_i23.NotificationPermissionType?>()) {
      return (data != null
          ? _i23.NotificationPermissionType.fromJson(data)
          : null) as T;
    }
    if (t == _i1.getType<_i24.NotificationType?>()) {
      return (data != null ? _i24.NotificationType.fromJson(data) : null) as T;
    }
    if (t == _i1.getType<_i25.PromoActivation?>()) {
      return (data != null ? _i25.PromoActivation.fromJson(data) : null) as T;
    }
    if (t == _i1.getType<_i26.PromoBonuses?>()) {
      return (data != null ? _i26.PromoBonuses.fromJson(data) : null) as T;
    }
    if (t == _i1.getType<_i27.PromoLevel?>()) {
      return (data != null ? _i27.PromoLevel.fromJson(data) : null) as T;
    }
    if (t == _i1.getType<_i28.PromoLevelActivation?>()) {
      return (data != null ? _i28.PromoLevelActivation.fromJson(data) : null)
          as T;
    }
    if (t == _i1.getType<_i29.Region?>()) {
      return (data != null ? _i29.Region.fromJson(data) : null) as T;
    }
    if (t == _i1.getType<_i30.UserGender?>()) {
      return (data != null ? _i30.UserGender.fromJson(data) : null) as T;
    }
    if (t == _i1.getType<_i31.UserProfile?>()) {
      return (data != null ? _i31.UserProfile.fromJson(data) : null) as T;
    }
    if (t == _i1.getType<_i32.UserSubscription?>()) {
      return (data != null ? _i32.UserSubscription.fromJson(data) : null) as T;
    }
    if (t == _i1.getType<List<_i33.AdAttributeValue>?>()) {
      return (data != null
          ? (data as List)
              .map((e) => deserialize<_i33.AdAttributeValue>(e))
              .toList()
          : null) as dynamic;
    }
    if (t == _i1.getType<List<_i34.NitMedia>?>()) {
      return (data != null
          ? (data as List).map((e) => deserialize<_i34.NitMedia>(e)).toList()
          : null) as dynamic;
    }
    if (t == _i1.getType<List<_i33.KerlaService>?>()) {
      return (data != null
          ? (data as List)
              .map((e) => deserialize<_i33.KerlaService>(e))
              .toList()
          : null) as dynamic;
    }
    if (t == _i1.getType<List<_i33.AdCategory>?>()) {
      return (data != null
          ? (data as List).map((e) => deserialize<_i33.AdCategory>(e)).toList()
          : null) as dynamic;
    }
    if (t == _i1.getType<List<String>?>()) {
      return (data != null
          ? (data as List).map((e) => deserialize<String>(e)).toList()
          : null) as dynamic;
    }
    if (t == _i1.getType<List<String>?>()) {
      return (data != null
          ? (data as List).map((e) => deserialize<String>(e)).toList()
          : null) as dynamic;
    }
    if (t == List<_i33.Attribute>) {
      return (data as List).map((e) => deserialize<_i33.Attribute>(e)).toList()
          as dynamic;
    }
    if (t == List<_i33.NotificationPermissionType>) {
      return (data as List)
          .map((e) => deserialize<_i33.NotificationPermissionType>(e))
          .toList() as dynamic;
    }
    if (t == List<_i33.KerlaServiceType>) {
      return (data as List)
          .map((e) => deserialize<_i33.KerlaServiceType>(e))
          .toList() as dynamic;
    }
    if (t == List<_i35.KerlaService>) {
      return (data as List)
          .map((e) => deserialize<_i35.KerlaService>(e))
          .toList() as dynamic;
    }
    if (t == List<_i36.Ad>) {
      return (data as List).map((e) => deserialize<_i36.Ad>(e)).toList()
          as dynamic;
    }
    if (t == List<int>) {
      return (data as List).map((e) => deserialize<int>(e)).toList() as dynamic;
    }
    if (t == _i1.getType<List<int>?>()) {
      return (data != null
          ? (data as List).map((e) => deserialize<int>(e)).toList()
          : null) as dynamic;
    }
    if (t == _i1.getType<List<Map<int, String>>?>()) {
      return (data != null
          ? (data as List).map((e) => deserialize<Map<int, String>>(e)).toList()
          : null) as dynamic;
    }
    if (t == Map<int, String>) {
      return Map.fromEntries((data as List).map((e) =>
              MapEntry(deserialize<int>(e['k']), deserialize<String>(e['v']))))
          as dynamic;
    }
    if (t == List<_i37.UserProfile>) {
      return (data as List)
          .map((e) => deserialize<_i37.UserProfile>(e))
          .toList() as dynamic;
    }
    if (t == List<_i38.KerlaServiceInfo>) {
      return (data as List)
          .map((e) => deserialize<_i38.KerlaServiceInfo>(e))
          .toList() as dynamic;
    }
    if (t == List<_i39.AdCategory>) {
      return (data as List).map((e) => deserialize<_i39.AdCategory>(e)).toList()
          as dynamic;
    }
    if (t == List<_i40.Attribute>) {
      return (data as List).map((e) => deserialize<_i40.Attribute>(e)).toList()
          as dynamic;
    }
    if (t == List<_i41.SubAttribute>) {
      return (data as List)
          .map((e) => deserialize<_i41.SubAttribute>(e))
          .toList() as dynamic;
    }
    if (t == List<_i42.AppNotification>) {
      return (data as List)
          .map((e) => deserialize<_i42.AppNotification>(e))
          .toList() as dynamic;
    }
    if (t == _i43.InitResponse) {
      return _i43.InitResponse.fromJson(data) as T;
    }
    if (t == _i44.InitRequest) {
      return _i44.InitRequest.fromJson(data) as T;
    }
    if (t == _i45.Check3DSVersionResponse) {
      return _i45.Check3DSVersionResponse.fromJson(data) as T;
    }
    if (t == _i46.Check3DSVersionRequest) {
      return _i46.Check3DSVersionRequest.fromJson(data) as T;
    }
    if (t == _i47.FinishAuthorizeResponse) {
      return _i47.FinishAuthorizeResponse.fromJson(data) as T;
    }
    if (t == _i48.FinishAuthorizeRequest) {
      return _i48.FinishAuthorizeRequest.fromJson(data) as T;
    }
    if (t == _i49.CancelResponse) {
      return _i49.CancelResponse.fromJson(data) as T;
    }
    if (t == _i50.CancelRequest) {
      return _i50.CancelRequest.fromJson(data) as T;
    }
    if (t == _i51.GetStateResponse) {
      return _i51.GetStateResponse.fromJson(data) as T;
    }
    if (t == _i52.GetStateRequest) {
      return _i52.GetStateRequest.fromJson(data) as T;
    }
    if (t == _i53.ChargeResponse) {
      return _i53.ChargeResponse.fromJson(data) as T;
    }
    if (t == _i54.ChargeRequest) {
      return _i54.ChargeRequest.fromJson(data) as T;
    }
    if (t == _i1.getType<_i43.InitResponse?>()) {
      return (data != null ? _i43.InitResponse.fromJson(data) : null) as T;
    }
    if (t == _i1.getType<_i44.InitRequest?>()) {
      return (data != null ? _i44.InitRequest.fromJson(data) : null) as T;
    }
    if (t == _i1.getType<_i45.Check3DSVersionResponse?>()) {
      return (data != null ? _i45.Check3DSVersionResponse.fromJson(data) : null)
          as T;
    }
    if (t == _i1.getType<_i46.Check3DSVersionRequest?>()) {
      return (data != null ? _i46.Check3DSVersionRequest.fromJson(data) : null)
          as T;
    }
    if (t == _i1.getType<_i47.FinishAuthorizeResponse?>()) {
      return (data != null ? _i47.FinishAuthorizeResponse.fromJson(data) : null)
          as T;
    }
    if (t == _i1.getType<_i48.FinishAuthorizeRequest?>()) {
      return (data != null ? _i48.FinishAuthorizeRequest.fromJson(data) : null)
          as T;
    }
    if (t == _i1.getType<_i49.CancelResponse?>()) {
      return (data != null ? _i49.CancelResponse.fromJson(data) : null) as T;
    }
    if (t == _i1.getType<_i50.CancelRequest?>()) {
      return (data != null ? _i50.CancelRequest.fromJson(data) : null) as T;
    }
    if (t == _i1.getType<_i51.GetStateResponse?>()) {
      return (data != null ? _i51.GetStateResponse.fromJson(data) : null) as T;
    }
    if (t == _i1.getType<_i52.GetStateRequest?>()) {
      return (data != null ? _i52.GetStateRequest.fromJson(data) : null) as T;
    }
    if (t == _i1.getType<_i53.ChargeResponse?>()) {
      return (data != null ? _i53.ChargeResponse.fromJson(data) : null) as T;
    }
    if (t == _i1.getType<_i54.ChargeRequest?>()) {
      return (data != null ? _i54.ChargeRequest.fromJson(data) : null) as T;
    }
    try {
      return _i55.Protocol().deserialize<T>(data, t);
    } on _i1.DeserializationTypeNotFoundException catch (_) {}
    try {
      return _i56.Protocol().deserialize<T>(data, t);
    } on _i1.DeserializationTypeNotFoundException catch (_) {}
    try {
      return _i34.Protocol().deserialize<T>(data, t);
    } on _i1.DeserializationTypeNotFoundException catch (_) {}
    return super.deserialize<T>(data, t);
  }

  @override
  String? getClassNameForObject(Object? data) {
    String? className = super.getClassNameForObject(data);
    if (className != null) return className;
    if (data is _i43.InitResponse) {
      return 'InitResponse';
    }
    if (data is _i44.InitRequest) {
      return 'InitRequest';
    }
    if (data is _i45.Check3DSVersionResponse) {
      return 'Check3DSVersionResponse';
    }
    if (data is _i46.Check3DSVersionRequest) {
      return 'Check3DSVersionRequest';
    }
    if (data is _i47.FinishAuthorizeResponse) {
      return 'FinishAuthorizeResponse';
    }
    if (data is _i48.FinishAuthorizeRequest) {
      return 'FinishAuthorizeRequest';
    }
    if (data is _i49.CancelResponse) {
      return 'CancelResponse';
    }
    if (data is _i50.CancelRequest) {
      return 'CancelRequest';
    }
    if (data is _i51.GetStateResponse) {
      return 'GetStateResponse';
    }
    if (data is _i52.GetStateRequest) {
      return 'GetStateRequest';
    }
    if (data is _i53.ChargeResponse) {
      return 'ChargeResponse';
    }
    if (data is _i54.ChargeRequest) {
      return 'ChargeRequest';
    }
    if (data is _i2.Ad) {
      return 'Ad';
    }
    if (data is _i3.AdAttributeValue) {
      return 'AdAttributeValue';
    }
    if (data is _i4.AdCategory) {
      return 'AdCategory';
    }
    if (data is _i5.AdListType) {
      return 'AdListType';
    }
    if (data is _i6.AdReport) {
      return 'AdReport';
    }
    if (data is _i7.AdReportReason) {
      return 'AdReportReason';
    }
    if (data is _i8.AdOrderBy) {
      return 'AdOrderBy';
    }
    if (data is _i9.AdStatus) {
      return 'AdStatus';
    }
    if (data is _i10.AdType) {
      return 'AdType';
    }
    if (data is _i11.AdViewCount) {
      return 'AdViewCount';
    }
    if (data is _i12.Attribute) {
      return 'Attribute';
    }
    if (data is _i13.AttributeType) {
      return 'AttributeType';
    }
    if (data is _i14.KerlaColors) {
      return 'KerlaColors';
    }
    if (data is _i15.SubAttribute) {
      return 'SubAttribute';
    }
    if (data is _i16.CachableAttributeList) {
      return 'CachableAttributeList';
    }
    if (data is _i17.FavouriteAd) {
      return 'FavouriteAd';
    }
    if (data is _i18.KerlaService) {
      return 'KerlaService';
    }
    if (data is _i19.KerlaServiceInfo) {
      return 'KerlaServiceInfo';
    }
    if (data is _i20.KerlaServiceType) {
      return 'KerlaServiceType';
    }
    if (data is _i21.AppNotification) {
      return 'AppNotification';
    }
    if (data is _i22.NotificationPermission) {
      return 'NotificationPermission';
    }
    if (data is _i23.NotificationPermissionType) {
      return 'NotificationPermissionType';
    }
    if (data is _i24.NotificationType) {
      return 'NotificationType';
    }
    if (data is _i25.PromoActivation) {
      return 'PromoActivation';
    }
    if (data is _i26.PromoBonuses) {
      return 'PromoBonuses';
    }
    if (data is _i27.PromoLevel) {
      return 'PromoLevel';
    }
    if (data is _i28.PromoLevelActivation) {
      return 'PromoLevelActivation';
    }
    if (data is _i29.Region) {
      return 'Region';
    }
    if (data is _i30.UserGender) {
      return 'UserGender';
    }
    if (data is _i31.UserProfile) {
      return 'UserProfile';
    }
    if (data is _i32.UserSubscription) {
      return 'UserSubscription';
    }
    className = _i55.Protocol().getClassNameForObject(data);
    if (className != null) {
      return 'dartway_tinkoff_serverpod.$className';
    }
    className = _i56.Protocol().getClassNameForObject(data);
    if (className != null) {
      return 'serverpod_auth.$className';
    }
    className = _i34.Protocol().getClassNameForObject(data);
    if (className != null) {
      return 'nit_tools.$className';
    }
    return null;
  }

  @override
  dynamic deserializeByClassName(Map<String, dynamic> data) {
    if (data['className'] == 'InitResponse') {
      return deserialize<_i43.InitResponse>(data['data']);
    }
    if (data['className'] == 'InitRequest') {
      return deserialize<_i44.InitRequest>(data['data']);
    }
    if (data['className'] == 'Check3DSVersionResponse') {
      return deserialize<_i45.Check3DSVersionResponse>(data['data']);
    }
    if (data['className'] == 'Check3DSVersionRequest') {
      return deserialize<_i46.Check3DSVersionRequest>(data['data']);
    }
    if (data['className'] == 'FinishAuthorizeResponse') {
      return deserialize<_i47.FinishAuthorizeResponse>(data['data']);
    }
    if (data['className'] == 'FinishAuthorizeRequest') {
      return deserialize<_i48.FinishAuthorizeRequest>(data['data']);
    }
    if (data['className'] == 'CancelResponse') {
      return deserialize<_i49.CancelResponse>(data['data']);
    }
    if (data['className'] == 'CancelRequest') {
      return deserialize<_i50.CancelRequest>(data['data']);
    }
    if (data['className'] == 'GetStateResponse') {
      return deserialize<_i51.GetStateResponse>(data['data']);
    }
    if (data['className'] == 'GetStateRequest') {
      return deserialize<_i52.GetStateRequest>(data['data']);
    }
    if (data['className'] == 'ChargeResponse') {
      return deserialize<_i53.ChargeResponse>(data['data']);
    }
    if (data['className'] == 'ChargeRequest') {
      return deserialize<_i54.ChargeRequest>(data['data']);
    }
    if (data['className'] == 'Ad') {
      return deserialize<_i2.Ad>(data['data']);
    }
    if (data['className'] == 'AdAttributeValue') {
      return deserialize<_i3.AdAttributeValue>(data['data']);
    }
    if (data['className'] == 'AdCategory') {
      return deserialize<_i4.AdCategory>(data['data']);
    }
    if (data['className'] == 'AdListType') {
      return deserialize<_i5.AdListType>(data['data']);
    }
    if (data['className'] == 'AdReport') {
      return deserialize<_i6.AdReport>(data['data']);
    }
    if (data['className'] == 'AdReportReason') {
      return deserialize<_i7.AdReportReason>(data['data']);
    }
    if (data['className'] == 'AdOrderBy') {
      return deserialize<_i8.AdOrderBy>(data['data']);
    }
    if (data['className'] == 'AdStatus') {
      return deserialize<_i9.AdStatus>(data['data']);
    }
    if (data['className'] == 'AdType') {
      return deserialize<_i10.AdType>(data['data']);
    }
    if (data['className'] == 'AdViewCount') {
      return deserialize<_i11.AdViewCount>(data['data']);
    }
    if (data['className'] == 'Attribute') {
      return deserialize<_i12.Attribute>(data['data']);
    }
    if (data['className'] == 'AttributeType') {
      return deserialize<_i13.AttributeType>(data['data']);
    }
    if (data['className'] == 'KerlaColors') {
      return deserialize<_i14.KerlaColors>(data['data']);
    }
    if (data['className'] == 'SubAttribute') {
      return deserialize<_i15.SubAttribute>(data['data']);
    }
    if (data['className'] == 'CachableAttributeList') {
      return deserialize<_i16.CachableAttributeList>(data['data']);
    }
    if (data['className'] == 'FavouriteAd') {
      return deserialize<_i17.FavouriteAd>(data['data']);
    }
    if (data['className'] == 'KerlaService') {
      return deserialize<_i18.KerlaService>(data['data']);
    }
    if (data['className'] == 'KerlaServiceInfo') {
      return deserialize<_i19.KerlaServiceInfo>(data['data']);
    }
    if (data['className'] == 'KerlaServiceType') {
      return deserialize<_i20.KerlaServiceType>(data['data']);
    }
    if (data['className'] == 'AppNotification') {
      return deserialize<_i21.AppNotification>(data['data']);
    }
    if (data['className'] == 'NotificationPermission') {
      return deserialize<_i22.NotificationPermission>(data['data']);
    }
    if (data['className'] == 'NotificationPermissionType') {
      return deserialize<_i23.NotificationPermissionType>(data['data']);
    }
    if (data['className'] == 'NotificationType') {
      return deserialize<_i24.NotificationType>(data['data']);
    }
    if (data['className'] == 'PromoActivation') {
      return deserialize<_i25.PromoActivation>(data['data']);
    }
    if (data['className'] == 'PromoBonuses') {
      return deserialize<_i26.PromoBonuses>(data['data']);
    }
    if (data['className'] == 'PromoLevel') {
      return deserialize<_i27.PromoLevel>(data['data']);
    }
    if (data['className'] == 'PromoLevelActivation') {
      return deserialize<_i28.PromoLevelActivation>(data['data']);
    }
    if (data['className'] == 'Region') {
      return deserialize<_i29.Region>(data['data']);
    }
    if (data['className'] == 'UserGender') {
      return deserialize<_i30.UserGender>(data['data']);
    }
    if (data['className'] == 'UserProfile') {
      return deserialize<_i31.UserProfile>(data['data']);
    }
    if (data['className'] == 'UserSubscription') {
      return deserialize<_i32.UserSubscription>(data['data']);
    }
    if (data['className'].startsWith('dartway_tinkoff_serverpod.')) {
      data['className'] = data['className'].substring(26);
      return _i55.Protocol().deserializeByClassName(data);
    }
    if (data['className'].startsWith('serverpod_auth.')) {
      data['className'] = data['className'].substring(15);
      return _i56.Protocol().deserializeByClassName(data);
    }
    if (data['className'].startsWith('nit_tools.')) {
      data['className'] = data['className'].substring(10);
      return _i34.Protocol().deserializeByClassName(data);
    }
    return super.deserializeByClassName(data);
  }
}
