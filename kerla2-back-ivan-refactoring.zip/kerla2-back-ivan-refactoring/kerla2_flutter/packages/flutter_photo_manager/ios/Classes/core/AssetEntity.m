//
//  AssetEntity.m
//  photo_manager
//

#import "AssetEntity.h"

@implementation AssetEntity

@end
