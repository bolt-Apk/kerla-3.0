import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/app_buffer/home/widgets/home_app_bar/search/user_search/user_search_item.dart';
import 'package:kerla2_flutter/core/app_backend_filters.dart';
import 'package:kerla2_flutter/router/router.dart';
import 'package:nit_app/nit_app.dart';
import 'package:nit_router/nit_router.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class SubscriberListPage extends ConsumerWidget {
  const SubscriberListPage.subscribers({
    super.key,
  }) : isSubscriptionPage = true;

  const SubscriberListPage.subscriptions({
    super.key,
  }) : isSubscriptionPage = false;

  final bool isSubscriptionPage;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final userId = ref.watchNavigationParam(AppNavigationParams.userId) ??
        ref.signedInUserId!;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: context.theme.canvasColor,
        title: Text(isSubscriptionPage ? 'Подписки' : 'Подписчики'),
      ),
      body: ref
          .watchEntityListAsync<UserSubscription>(
            backendFilter: (isSubscriptionPage
                ? AppBackendFilter.subscriberId.equals
                : AppBackendFilter.userId.equals)(userId),
            // frontendFilter: (model) => isSubscriptionPage
            //     ? model.subscriberId == userId
            //     : model.userId == userId,
          )
          .nitWhenList(
            loadingItemsCount: 1,
            childBuilder: (list) {
              if (list.isEmpty) {
                return Center(
                  child: Text(
                    isSubscriptionPage ? 'Нет подписок' : 'Нет подписчиков',
                  ),
                );
              }
              return ListView.builder(
                itemCount: list.length,
                itemBuilder: (context, index) {
                  final user = list[index];
                  return UserSearchItem(
                    key: ValueKey(user.userId),
                    userId:
                        isSubscriptionPage ? user.userId : user.subscriberId,
                  );
                },
              );
            },
          ),
    );
  }
}
