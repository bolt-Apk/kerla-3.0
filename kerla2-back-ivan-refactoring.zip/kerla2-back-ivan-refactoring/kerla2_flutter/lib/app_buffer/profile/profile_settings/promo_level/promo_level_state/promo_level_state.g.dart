// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'promo_level_state.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$promoLevelStateHash() => r'08e1313035c69110e0c92b5b683d8b7cdb270d71';

/// See also [PromoLevelState].
@ProviderFor(PromoLevelState)
final promoLevelStateProvider =
    AutoDisposeAsyncNotifierProvider<PromoLevelState, PromoLevelModel>.internal(
  PromoLevelState.new,
  name: r'promoLevelStateProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$promoLevelStateHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$PromoLevelState = AutoDisposeAsyncNotifier<PromoLevelModel>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
