#!/bin/sh

rm macos
cp -r ios macos
git rm --cached macos