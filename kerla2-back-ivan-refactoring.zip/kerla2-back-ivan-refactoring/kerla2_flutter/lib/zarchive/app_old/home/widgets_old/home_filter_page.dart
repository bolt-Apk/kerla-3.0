// import 'package:flutter/material.dart';
// import 'package:flutter_riverpod/flutter_riverpod.dart';
// import 'package:kerla2_client/kerla2_client.dart';
// import 'package:kerla2_flutter/router/router.dart';
// import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
// import 'package:nit_router/nit_router.dart';
// import 'package:nit_ui_kit/nit_ui_kit.dart';

// import '../../common/regions_provider.dart';
// import 'state/home_filters_state.dart';
// import 'widgets/home_filters_render.dart';

// class ChooseFiltersPage extends ConsumerWidget {
//   final bool isMoreFilterPage;
//   const ChooseFiltersPage({
//     super.key,
//     this.isMoreFilterPage = false,
//   });

//   void saveDropDownAttribute({
//     required WidgetRef ref,
//     required Attribute attribute,
//     required String? savedValue,
//     int? userId,
//     int? adId,
//     bool isFilter = false,
//     bool isRegionDropDown = false,
//   }) {
//     if (savedValue != null) {
// //edit ad
//       if (adId != null) {
//         // ref.read(adEditStateProvider(adId: adId).notifier).updateAttributeValue(
//         //       attribute.id!,
//         //       attribute.subAttributeId != null,
//         //       savedValue,
//         //     );
//         //filter ads
//       } else if (isFilter) {
//         ref
//             .read(
//               homeFiltersStateProvider(
//                 isProfile: userId != null,
//               ).notifier,
//             )
//             .setAttribute<String>(
//               AdAttributeValue(
//                 attributeId: attribute.id!,
//                 value: savedValue,
//               ),
//             );
//       }
//       //create ad
//       else {
//         // ref
//         //     .read(
//         //       adCreateStateProvider(isStory: false).notifier,
//         //     )
//         //     .setAttribute(
//         //       attribute,
//         //       savedValue,
//         //     );
//       }
//     } else {
//       debugPrint('nothing to save');
//     }
//   }

//   @override
//   Widget build(BuildContext context, WidgetRef ref) {
//     final userId = ref.watchNavigationParam(AppNavigationParams.userId);
//     final filterState =
//         ref.read(homeFiltersStateProvider(isProfile: userId != null));
//     return FutureBuilder(
//       future: ref
//           .read(homeFiltersStateProvider(isProfile: userId != null).notifier)
//           .getAttributes(),
//       builder: (context, snapshot) {
//         return Scaffold(
//           backgroundColor: context.theme.scaffoldBackgroundColor,
//           appBar: AppBar(
//             automaticallyImplyLeading: false,
//             elevation: 0,
//             backgroundColor: context.theme.appBarTheme.backgroundColor,
//             leading: IconButton(
//               icon: Icon(
//                 Icons.arrow_back,
//                 color: context.theme.iconTheme.color,
//               ),
//               onPressed: () {
//                 Navigator.pop(context);
//               },
//             ),
//             title: Text(
//               isMoreFilterPage ? 'Ещё фильтры' : 'Уточнить',
//               style: const TextStyle(color: Colors.black, fontSize: 17),
//             ),
//           ),
//           body: Padding(
//             padding: const EdgeInsets.symmetric(horizontal: 12),
//             child: Builder(
//               builder: (contextt) {
//                 if (snapshot.connectionState != ConnectionState.done) {
//                   return const Center(
//                     child: CircularProgressIndicator(),
//                   );
//                 }

//                 if (snapshot.data == null || snapshot.data!.isEmpty) {
//                   return const Center(
//                     child: Text(
//                       "Нет атрибутов",
//                     ),
//                   );
//                 }

//                 final filteredData = snapshot.data!
//                     .where(
//                       (item) =>
//                           item.showOnHome == isMoreFilterPage ? false : true,
//                     )
//                     .toList();

//                 return ListView.builder(
//                   itemCount: filteredData.length,
//                   padding: const EdgeInsets.only(bottom: 70),
//                   itemBuilder: (context, index) {
//                     if (index == 0) {
//                       return Column(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         children: [
//                           Padding(
//                             padding: const EdgeInsets.only(top: 8),
//                             child: Text(
//                               filterState.categoryStack
//                                   .map((e) => e.title)
//                                   .join('/'),
//                             ),
//                           ),
//                           FilterRender(
//                             attributeValue: AdAttributeValue(
//                               attribute: filteredData[index],
//                               attributeId: filteredData[index].id!,
//                               value: '',
//                             ),
//                             userId: userId,
//                             onFilterSave: (attribute) {
//                               ref
//                                   .read(
//                                     homeFiltersStateProvider(
//                                       isProfile: userId != null,
//                                     ).notifier,
//                                   )
//                                   .setAttribute<String>(attribute);
//                               // ref.invalidate(
//                               //   adListStateProvider(userId: userId),
//                               // );
//                             },
//                           ),
//                         ],
//                       );
//                     }
//                     return FilterRender(
//                       attributeValue: AdAttributeValue(
//                         attribute: filteredData[index],
//                         attributeId: filteredData[index].id!,
//                         value: '',
//                       ),
//                       userId: userId,
//                       onFilterSave: (attribute) {
//                         ref
//                             .read(
//                               homeFiltersStateProvider(
//                                 isProfile: userId != null,
//                               ).notifier,
//                             )
//                             .setAttribute<String>(attribute);
//                         // ref.invalidate(
//                         //   adListStateProvider(userId: userId),
//                         // );
//                       },
//                     );
//                   },
//                 );
//               },
//             ),
//           ),
//           resizeToAvoidBottomInset: true,
//           floatingActionButton: Column(
//             mainAxisSize: MainAxisSize.min,
//             children: [
//               if (!isMoreFilterPage)
//                 TextButton(
//                   onPressed: () => context
//                       .pushNamed(MainAreaNavigationZone.moreFilters.name),
//                   child: const Text('Еще фильтры'),
//                 ),
//               Padding(
//                 padding: const EdgeInsets.all(8.0),
//                 child: MainButton(
//                   buttonText: isMoreFilterPage ? 'Применить' : 'Найти',
//                   onTap: () {
//                     snapshot.data?.forEach((attribute) {
//                       if (attribute.type == AttributeType.regionsDropdown ||
//                           attribute.type == AttributeType.valuesDropdown ||
//                           attribute.type == AttributeType.radioButton) {
//                         final List<String>? values =
//                             attribute.type == AttributeType.regionsDropdown
//                                 ? ref
//                                     .read(regionsProvider)
//                                     .map((e) => e.title)
//                                     .toList()
//                                 : attribute.values;

//                         // final savedValue = ref
//                         //     .read(
//                         //       attributeDropDownValueProvider(
//                         //         attribute.id!,
//                         //         attribute.subAttributeId != null,
//                         //       ).notifier,
//                         //     )
//                         //     .saveValue(values);

//                         // if (savedValue != null) {
//                         //   saveDropDownAttribute(
//                         //     ref: ref,
//                         //     attribute: attribute,
//                         //     userId: userId,
//                         //     savedValue: savedValue,
//                         //     isFilter: true,
//                         //   );
//                         // }
//                       }

//                       // save range attribute

//                       if (attribute.type == AttributeType.number ||
//                           attribute.type == AttributeType.decimal) {
//                         // ref
//                         //     .read(
//                         //       attributeRangeProvider(attribute.id!).notifier,
//                         //     )
//                         //     .saveValue();

//                         // final String? valueToAttribute = ref
//                         //     .read(
//                         //       attributeRangeProvider(attribute.id!).notifier,
//                         //     )
//                         //     .valueToAttribute();

//                         // if (valueToAttribute != null) {
//                         //   ref
//                         //       .read(
//                         //         homeFiltersStateProvider(
//                         //           isProfile: userId != null,
//                         //         ).notifier,
//                         //       )
//                         //       .setAttribute<String>(
//                         //         AdAttributeValue(
//                         //           attributeId: attribute.id!,
//                         //           value: valueToAttribute,
//                         //         ),
//                         //       );
//                         // }
//                       }
//                     });

//                     if (!isMoreFilterPage) {
//                       // ref.invalidate(adListStateProvider(userId: userId));
//                     }

//                     Navigator.pop(context);
//                   },
//                 ),
//               ),
//             ],
//           ),
//           floatingActionButtonLocation:
//               FloatingActionButtonLocation.centerDocked,
//           floatingActionButtonAnimator: FloatingActionButtonAnimator.scaling,
//         );
//       },
//     );
//   }
// }
