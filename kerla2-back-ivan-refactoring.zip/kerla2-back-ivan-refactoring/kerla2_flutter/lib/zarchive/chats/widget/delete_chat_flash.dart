// import 'package:flash/flash.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_riverpod/flutter_riverpod.dart';
// import 'package:nit_ui_kit/nit_ui_kit.dart';

// class DeleteChatFlash extends ConsumerWidget {
//   final FlashController controller;
//   final FlashPosition position;

//   const DeleteChatFlash({
//     required this.controller,
//     this.position = FlashPosition.top,
//     super.key,
//   });

//   @override
//   Widget build(BuildContext context, WidgetRef ref) {
//     return Theme(
//       data: Theme.of(context).copyWith(
//         extensions: const [
//           FlashBarTheme(
//             elevation: 0,
//             backgroundColor: Color(0xFFE4E3E5),
//           ),
//         ],
//       ),
//       child: GestureDetector(
//         onTap: () {
//           // print('Функция вернуть чат');
//         },
//         child: FlashBar(
//           margin: const EdgeInsets.symmetric(
//             vertical: 16,
//             horizontal: 32,
//           ),
//           position: position,
//           controller: controller,
//           behavior: FlashBehavior.floating,
//           shape: const RoundedRectangleBorder(
//             borderRadius: BorderRadius.all(Radius.circular(8)),
//           ),
//           clipBehavior: Clip.antiAlias,
//           contentTextStyle: context.textTheme.bodyMedium
//               ?.copyWith(height: 1), //TODO potential issue
//           content: Row(
//             mainAxisAlignment: MainAxisAlignment.center,
//             children: [
//               const Padding(
//                 padding: EdgeInsets.only(right: 10),
//                 child: Icon(
//                   Icons.refresh,
//                   size: 20,
//                 ),
//               ),
//               Text(
//                 'Отменить удаление чата',
//                 style: Theme.of(context).textTheme.bodyMedium,
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }
