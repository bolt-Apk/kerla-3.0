import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kerla2_flutter/core/app_backend_filters.dart';
import 'package:nit_app/nit_app.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';

part 'chat_unread_provider.g.dart';

@riverpod
int hasUnreadChat(Ref ref) {
  int count = 0;
  final signedUserId = ref.signedInUserId;
  if (signedUserId == null) return 0;
  return ref
          .watchEntityListCustomizedAsync<NitChatParticipant>(
        // backendFilter: AppBackendFilter.userId.equals(ref.signedInUserId!),
        entityListConfig: EntityListConfig(
            backendFilter: NitBackendFilter.and([
          AppBackendFilter.userId.equals(ref.signedInUserId!),
          AppBackendFilter.lastMessage.equals(null, negate: true),
          AppBackendFilter.isDeleted.equals(false),
          // AppBackendFilter.lastMessage.equals(null, negate: true),
        ])),
      )
          .whenData((data) {
        for (var element in data) {
          count += element.unreadCount;
        }
        return count;
      }).value ??
      0;
}
