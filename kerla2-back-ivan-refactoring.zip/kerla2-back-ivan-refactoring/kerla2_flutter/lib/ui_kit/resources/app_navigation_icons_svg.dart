part of '../ui_kit.dart';

class AppNavigationIconsSvg {
  AppNavigationIconsSvg._();

  static const String addPublication =
      'assets/icons/navigation/add_publication.svg';
  static const String chats = 'assets/icons/navigation/chats.svg';
  static const String kerlaHome = 'assets/icons/navigation/kerla_home.svg';
  static const String profile = 'assets/icons/navigation/profile.svg';
  static const String stories = 'assets/icons/navigation/stories.svg';
}
