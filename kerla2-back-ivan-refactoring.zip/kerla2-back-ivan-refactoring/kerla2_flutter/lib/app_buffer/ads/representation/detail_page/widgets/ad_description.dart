import 'package:flutter/material.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class AdDescription extends StatelessWidget {
  const AdDescription({
    super.key,
    required this.ad,
  });

  final Ad ad;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 10),
      decoration: BoxDecoration(
        color: Theme.of(context).canvasColor,
      ),
      child: ReadMore(
        contentText: ad.description,
        title: "Описание",
        expandWidget: Text(
          ad.description,
          style: context.textTheme.displayLarge?.copyWith(fontSize: 16),
        ),
        collapsWidget: Text(
          ad.description,
          style: context.textTheme.displayLarge?.copyWith(fontSize: 16),
          overflow: TextOverflow.ellipsis,
          maxLines: 3,
        ),
        titleStyle: context.textTheme.headlineMedium
            ?.copyWith(fontWeight: FontWeight.bold),
        expandText: "Показать еще",
        collapsText: "Скрыть",
        descriptionStyle:
            Theme.of(context).textTheme.bodyMedium?.copyWith(fontSize: 16),
        collapsedMaxLines: 3,
        contentStyle: context.textTheme.displayLarge?.copyWith(fontSize: 16),
        showExpandButton: false,
      ),
    );
  }
}
