// import 'package:flutter/material.dart';
// import 'package:flutter_riverpod/flutter_riverpod.dart';

// class SubscriptionDropdown extends ConsumerStatefulWidget {
//   // final List<String> items;
//   // final String value;
//   final ValueChanged<String?>? onChanged;

//   const SubscriptionDropdown({
//     super.key,
//     // required this.items,
//     // required this.value,
//     this.onChanged,
//   });

//   @override
//   ConsumerState<SubscriptionDropdown> createState() =>
//       _SubscriptionDropdownState();
// }

// class _SubscriptionDropdownState extends ConsumerState<SubscriptionDropdown> {
//   late String dropdownValue;

//   @override
//   void initState() {
//     super.initState();
//     dropdownValue = widget.value;
//   }

//   @override
//   void didUpdateWidget(covariant SubscriptionDropdown oldWidget) {
//     super.didUpdateWidget(oldWidget);
//     if (oldWidget.value != widget.value) {
//       setState(() {
//         dropdownValue = widget.value;
//       });
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     final theme = Theme.of(context);

//     return DropdownButton<String>(
//       value: dropdownValue,
//       icon: const Icon(Icons.arrow_drop_down_outlined),
//       iconEnabledColor: theme.iconTheme.color,
//       elevation: 16,
//       style: theme.textTheme.bodySmall,
//       underline: Container(height: 0),
//       onChanged: (String? value) {
//         if (value != null) {
//           setState(() {
//             dropdownValue = value;
//           });
//           widget.onChanged?.call(value);
//         }
//       },
//       items: widget.items.map<DropdownMenuItem<String>>((String value) {
//         return DropdownMenuItem<String>(
//           value: value,
//           child: Text(value),
//         );
//       }).toList(),
//     );
//   }
// }
