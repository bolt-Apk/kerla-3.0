import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/app_buffer/ads/representation/ad_card/ad_turbo/ad_turbo_widget.dart';
import 'package:kerla2_flutter/app_buffer/ads/representation/ad_list/ads_grid.dart';
import 'package:kerla2_flutter/app_buffer/ads/representation/ad_list/state/ad_list_state.dart';
import 'package:kerla2_flutter/app_buffer/home/components/filter_component.dart';
import 'package:kerla2_flutter/app_buffer/home/components/scroll_behavior.dart';
import 'package:kerla2_flutter/app_buffer/home/filters/list_filter/list_filter_widget.dart';
import 'package:kerla2_flutter/app_buffer/home/stories/story_list/state/story_list_state.dart';
import 'package:kerla2_flutter/app_buffer/home/stories/story_list/stories_list.dart';
import 'package:kerla2_flutter/app_buffer/home/widgets/home_app_bar/search/providers.dart';
import 'package:kerla2_flutter/app_buffer/home/widgets/home_app_bar/search/user_search/search_query_users.dart';

class HomeBody extends HookConsumerWidget {
  const HomeBody({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final scrollController = useScrollController();
    final isAccountSearching = ref.watch(isSearchFieldVisible);
    final searchTabStateValue = ref.watch(searchTabState);
    // final v = useState(false);

    // Extract scroll behavior logic to a custom hook
    final (showFilters, _) = useScrollBehavior(scrollController);

    Future<void> handleRefresh() async {
      ref
          .read(
              adListStateProvider(const GetAdParam(adListType: AdListType.main))
                  .notifier)
          .refreshState();
      ref.invalidate(storyListStateProvider);
    }

    return RefreshIndicator(
      onRefresh: handleRefresh,
      child: Stack(
        children: [
          // Main content
          CustomScrollView(
            controller: scrollController,
            slivers: [
              const SliverToBoxAdapter(child: StoriesList()),
              const SliverToBoxAdapter(child: SizedBox(height: 8)),
              const SliverAppBar(
                automaticallyImplyLeading: false,
                backgroundColor: Colors.transparent,
                collapsedHeight: 0,
                toolbarHeight: 0,
                expandedHeight: 50,
                flexibleSpace: ListFilterWidget(adListType: AdListType.main),
              ),
              SliverToBoxAdapter(
                child: AdTurboWidget(
                  ad: ref
                      .watch(adListStateProvider(
                          const GetAdParam(adListType: AdListType.main)))
                      .turboAd,
                ),
              ),
              const AdsGrid(
                physics: NeverScrollableScrollPhysics(),
                // withTurboCard: true,
                isSliver: true,
                params: GetAdParam(adListType: AdListType.main),
              ),
            ],
          ),

          if (isAccountSearching && searchTabStateValue == SearchState.account)
            const SearchQueryUsers(),

          // Filter bar (only shown when not searching)
          if (!isAccountSearching) FilterComponent(showFilters: showFilters),
        ],
      ),
    );
  }
}
