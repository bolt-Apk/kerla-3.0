import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerla2_flutter/auth/state/auth_mode_enum.dart';
import 'package:kerla2_flutter/auth/widgets/auth_header_widget.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

import 'widgets/email_input_widget.dart';
import 'widgets/process_email_button.dart';

class RecoverPage extends ConsumerWidget {
  const RecoverPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return const Form(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          AuthHeaderWidget(
            mode: AuthModeEnum.recover,
          ),
          Gap(8),
          EmailInputWidget(),
          Gap(16),
          ProcessEmailButton(
            mode: AuthModeEnum.recover,
          ),
        ],
      ),
    );
  }
}
