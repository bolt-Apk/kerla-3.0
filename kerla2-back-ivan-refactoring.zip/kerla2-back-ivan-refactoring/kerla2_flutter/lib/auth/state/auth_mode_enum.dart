enum AuthModeEnum {
  signIn,
  registration,
  recover,
  oauth,
  ;
  // change;
}
