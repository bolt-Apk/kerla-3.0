part of '../ui_kit.dart';

class SwitchSettingsRow extends StatefulWidget {
  final String title;
  final bool isActive;

  const SwitchSettingsRow({
    super.key,
    required this.title,
    required this.isActive,
  });

  @override
  State<SwitchSettingsRow> createState() => _SwitchSettingsRowState();
}

class _SwitchSettingsRowState extends State<SwitchSettingsRow> {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          child: Row(
            children: [
              Expanded(
                child: Text(
                  widget.title,
                  overflow: TextOverflow.ellipsis,
                  maxLines: 1,
                  style: Theme.of(context).textTheme.displayLarge,
                ),
              ),
              const SizedBox(width: 28),
              SwitchWidget(
                isActive: widget.isActive,
              ),
            ],
          ),
        ),
        const Divider(height: 0),
      ],
    );
  }
}
