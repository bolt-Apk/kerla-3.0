import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/app_buffer/home/stories/story_list/state/story_list_state.dart';
import 'package:kerla2_flutter/app_buffer/home/stories/story_view/widgets/story_viewer.dart';
import 'package:kerla2_flutter/router/router.dart';
import 'package:nit_app/nit_app.dart';
import 'package:nit_router/nit_router.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class StoriesPage extends ConsumerWidget {
  const StoriesPage({
    super.key,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final storiesAsync = ref.watch(storyListStateProvider);
    final userId = ref.readNavigationParam<int>(AppNavigationParams.userId);

    final storyId = ref.readNavigationParam<int>(AppNavigationParams.storyId);

    return storiesAsync.nitWhen(
      childBuilder: (users) {
        int getInitialIndex(int? funcUserId) {
          if (funcUserId != null) {
            return users.indexWhere((user) => user.userId == funcUserId);
          }
          return 0;
        }

        if (users.isEmpty) {
          return const Center(child: Text('No stories available'));
        }

        if (storyId != null) {
          return ref.watchOrFetchMaybeModelAsync<Ad>(storyId).nitWhen(
              childBuilder: (ad) {
            return StoryViewer(
              users: users,
              initialIndex: getInitialIndex(ad?.userId),
              singleStoryId: storyId,
            );
          });
        } else {
          return StoryViewer(
            users: users,
            initialIndex: getInitialIndex(userId),
            singleStoryId: storyId,
          );
        }
      },
    );
  }
}
