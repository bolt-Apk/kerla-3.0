import 'package:app_badge_plus/app_badge_plus.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerla2_flutter/core/app_backend_filters.dart';
import 'package:nit_app/nit_app.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';

part 'notification_new_status_provider.g.dart';

@riverpod
int notificationNewStatus(Ref ref) {
  final signedUserId = ref.signedInUserId;
  if (signedUserId == null) return 0;
  return ref
          .watchEntityListAsync<NitAppNotification>(
        backendFilter: NitBackendFilter.and(
          [
            AppBackendFilter.toUserId.equals(signedUserId),
            AppBackendFilter.isRead.equals(false),
          ],
        ),
        frontendFilter: (notification) => !notification.isRead,
      )
          .whenData((data) {
            
        AppBadgePlus.updateBadge(data.length);
        return data.length;
      }).value ??
      0;
}

//TODO: Женя. 
// @riverpod
// int notificationNewStatus(Ref ref) {
//   final signedUserId = ref.signedInUserId;
//   if (signedUserId == null) return 0;
//   return ref
//           .watchEntityCountAsync<NitAppNotification>(
//               backendFilter: NitBackendFilter.and([
//         AppBackendFilter.toUserId.equals(signedUserId),
//         AppBackendFilter.isRead.equals(false),
//       ]))
//           .whenData((data) {
//         return data;
//       }).value ??
//       0;
// }

