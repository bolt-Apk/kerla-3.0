import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:wechat_assets_picker/wechat_assets_picker.dart';

class AssetItem extends ConsumerWidget {
  const AssetItem({
    super.key,
    required this.assetEntity,
  });

  final AssetEntity assetEntity;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Stack(
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(10),
          child: AssetEntityImage(
            assetEntity,
            isOriginal: false,
            thumbnailSize: const ThumbnailSize.square(250),
            fit: BoxFit.cover,
            errorBuilder: (context, error, stackTrace) {
              return const Center(
                child: Icon(
                  Icons.error,
                  color: Colors.red,
                ),
              );
            },
            width: double.infinity,
            height: double.infinity,
          ),
        ),
        if (assetEntity.type == AssetType.video)
          const Positioned.fill(
            child: Align(
              child: Padding(
                padding: EdgeInsets.all(10),
                child: Icon(
                  Icons.play_arrow,
                  color: Colors.white,
                  size: 40,
                ),
              ),
            ),
          ),
      ],
    );
  }
}
