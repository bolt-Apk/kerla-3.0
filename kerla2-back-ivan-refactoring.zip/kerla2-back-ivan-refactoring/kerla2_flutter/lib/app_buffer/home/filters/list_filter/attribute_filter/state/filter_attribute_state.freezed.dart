// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'filter_attribute_state.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$FilterStateModel {
  List<AdAttributeValue> get attributes => throw _privateConstructorUsedError;
  String get searchQuery => throw _privateConstructorUsedError;
  AdCategory? get category => throw _privateConstructorUsedError;

  /// Create a copy of FilterStateModel
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $FilterStateModelCopyWith<FilterStateModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $FilterStateModelCopyWith<$Res> {
  factory $FilterStateModelCopyWith(
          FilterStateModel value, $Res Function(FilterStateModel) then) =
      _$FilterStateModelCopyWithImpl<$Res, FilterStateModel>;
  @useResult
  $Res call(
      {List<AdAttributeValue> attributes,
      String searchQuery,
      AdCategory? category});
}

/// @nodoc
class _$FilterStateModelCopyWithImpl<$Res, $Val extends FilterStateModel>
    implements $FilterStateModelCopyWith<$Res> {
  _$FilterStateModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of FilterStateModel
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? attributes = null,
    Object? searchQuery = null,
    Object? category = freezed,
  }) {
    return _then(_value.copyWith(
      attributes: null == attributes
          ? _value.attributes
          : attributes // ignore: cast_nullable_to_non_nullable
              as List<AdAttributeValue>,
      searchQuery: null == searchQuery
          ? _value.searchQuery
          : searchQuery // ignore: cast_nullable_to_non_nullable
              as String,
      category: freezed == category
          ? _value.category
          : category // ignore: cast_nullable_to_non_nullable
              as AdCategory?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$FilterStateModelImplCopyWith<$Res>
    implements $FilterStateModelCopyWith<$Res> {
  factory _$$FilterStateModelImplCopyWith(_$FilterStateModelImpl value,
          $Res Function(_$FilterStateModelImpl) then) =
      __$$FilterStateModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {List<AdAttributeValue> attributes,
      String searchQuery,
      AdCategory? category});
}

/// @nodoc
class __$$FilterStateModelImplCopyWithImpl<$Res>
    extends _$FilterStateModelCopyWithImpl<$Res, _$FilterStateModelImpl>
    implements _$$FilterStateModelImplCopyWith<$Res> {
  __$$FilterStateModelImplCopyWithImpl(_$FilterStateModelImpl _value,
      $Res Function(_$FilterStateModelImpl) _then)
      : super(_value, _then);

  /// Create a copy of FilterStateModel
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? attributes = null,
    Object? searchQuery = null,
    Object? category = freezed,
  }) {
    return _then(_$FilterStateModelImpl(
      attributes: null == attributes
          ? _value._attributes
          : attributes // ignore: cast_nullable_to_non_nullable
              as List<AdAttributeValue>,
      searchQuery: null == searchQuery
          ? _value.searchQuery
          : searchQuery // ignore: cast_nullable_to_non_nullable
              as String,
      category: freezed == category
          ? _value.category
          : category // ignore: cast_nullable_to_non_nullable
              as AdCategory?,
    ));
  }
}

/// @nodoc

class _$FilterStateModelImpl implements _FilterStateModel {
  const _$FilterStateModelImpl(
      {required final List<AdAttributeValue> attributes,
      required this.searchQuery,
      required this.category})
      : _attributes = attributes;

  final List<AdAttributeValue> _attributes;
  @override
  List<AdAttributeValue> get attributes {
    if (_attributes is EqualUnmodifiableListView) return _attributes;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_attributes);
  }

  @override
  final String searchQuery;
  @override
  final AdCategory? category;

  @override
  String toString() {
    return 'FilterStateModel(attributes: $attributes, searchQuery: $searchQuery, category: $category)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$FilterStateModelImpl &&
            const DeepCollectionEquality()
                .equals(other._attributes, _attributes) &&
            (identical(other.searchQuery, searchQuery) ||
                other.searchQuery == searchQuery) &&
            (identical(other.category, category) ||
                other.category == category));
  }

  @override
  int get hashCode => Object.hash(runtimeType,
      const DeepCollectionEquality().hash(_attributes), searchQuery, category);

  /// Create a copy of FilterStateModel
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$FilterStateModelImplCopyWith<_$FilterStateModelImpl> get copyWith =>
      __$$FilterStateModelImplCopyWithImpl<_$FilterStateModelImpl>(
          this, _$identity);
}

abstract class _FilterStateModel implements FilterStateModel {
  const factory _FilterStateModel(
      {required final List<AdAttributeValue> attributes,
      required final String searchQuery,
      required final AdCategory? category}) = _$FilterStateModelImpl;

  @override
  List<AdAttributeValue> get attributes;
  @override
  String get searchQuery;
  @override
  AdCategory? get category;

  /// Create a copy of FilterStateModel
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$FilterStateModelImplCopyWith<_$FilterStateModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
