part of '../router.dart';

void deeplinksHandler(WidgetRef ref, String link) {
  final id = int.tryParse(link.split('/').last.replaceAll(":", ''));
  // Discuss - debug info
  debugPrint("id $id");

  if (id == null) {
    ref.context.goNamed(MainAreaNavigationZone.homePage.name);
  } else {
    if (link.contains('/ad/')) {
      // TODO: зачем так сложно? Можно же просто переходить на целевую страницу, home
      // ref.context.goNamed(
      //   MainAreaNavigationZone.homePage.name,
      // );
      ref.context.goNamed(
        AdNavigationZone.adPage.name,
        pathParameters: AppNavigationParams.adId.set(id),
        // {
        //   CommonNavigationParameters.id.name: id,
        // },
      );
      return;
    }
    if (link.contains('/profile/')) {
      // ref.context.goNamed(
      //   MainAreaNavigationZone.homePage.name,
      // );
      ref.context.goNamed(
        MainAreaNavigationZone.user.name,
        pathParameters: AppNavigationParams.userId.set(id),
        //  {
        //   CommonNavigationParameters.id.name: id,
        // },
      );
      return;
    }
    if (link.contains('/stories/')) {
      // TODO: вернуть
      // ref.context.goNamed(
      //   MainAreaNavigationZone.userStories.name,
      //   pathParameters: AppNavigationParams.userId.set(id),
      //   // {
      //   //   CommonNavigationParameters.id.name: id,
      //   // },
      // );
      return;
    }
  }
}
