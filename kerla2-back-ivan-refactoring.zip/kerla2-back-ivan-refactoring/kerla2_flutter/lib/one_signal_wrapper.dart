// import 'package:flutter/material.dart';
// import 'package:flutter_riverpod/flutter_riverpod.dart';
// import 'package:kerla2_client/kerla2_client.dart';
// import 'package:kerla2_flutter/router/router.dart';
// import 'package:onesignal_flutter/onesignal_flutter.dart';

// class OneSignalWapper {
//   static void init(BuildContext context, WidgetRef ref) async {
//     _listenForForeground();
//     _handleClickNotification(context, ref);
//   }

//   static void _listenForForeground() {
//     OneSignal.Notifications.addForegroundWillDisplayListener((event) {
//       event.notification.display();
//     });
//   }

//   static void _handleClickNotification(
//       BuildContext context, WidgetRef ref) async {
//     OneSignal.Notifications.addClickListener((OSNotificationClickEvent event) {
//       WidgetsBinding.instance.addPostFrameCallback((_) {
//         final router = ref.read(routerProvider);

//         final jsonString = event.notification.rawPayload?['custom'];
//         final Map<String, dynamic> map = jsonString.cast<String, dynamic>();

//         final Map<String, dynamic> data = map['a'];

//         // TODO: Проверить, что все норм приходит
//         final int? adId = data['ad_id'] as int?; //?.toString();
//         final int? toUserId = data['to_user_id'] as int?; //?.toString();
//         final int? fromUserId = data['from_user_id'] as int?; //?.toString();

//         final NotificationType? type = (data['type'] as int?) != null
//             ? NotificationType.values[data['type'] as int]
//             : null;

//         switch (type) {
//           case NotificationType.ad:
//             if (adId == null) {
//               router.goNamed(MainAreaNavigationZone.homePage.name);
//             } else {
//               router.goNamed(
//                 AdNavigationZone.adPage.name,
//                 pathParameters: AppNavigationParams.adId.set(adId),
//               );
//             }
//             break;
//           case NotificationType.newSubscriber:
//             if (fromUserId == null) {
//               router.goNamed(MainAreaNavigationZone.homePage.name);
//             } else {
//               router.goNamed(
//                 MainAreaNavigationZone.user.name,
//                 pathParameters: AppNavigationParams.userId.set(fromUserId),
//               );
//             }
//             break;
//           case NotificationType.story:
//             if (adId == null) {
//               router.goNamed(MainAreaNavigationZone.homePage.name);
//             } else {
//               // router.goNamed(
//               //   MainAreaNavigationZone.userStories.name,
//               //   pathParameters: AppNavigationParams.adId.set(adId),
//               // );
//             }
//             break;
//           case NotificationType.message:
//             final Map<String, String> params = {
//               if (fromUserId != null)
//                 ...AppNavigationParams.userId.set(fromUserId),
//               if (adId != null) ...AppNavigationParams.adId.set(adId),
//             };

//             if (adId == null && fromUserId != null) {
//               // router.goNamed(
//               //   MainAreaNavigationZone.userChat.name,
//               //   pathParameters: params,
//               // );
//             }

//             // toUserId == null && fromUserId == null
//             //     ? router.goNamed(MainAreaNavigationZone.homePage.name)
//             //     : router.goNamed(
//             //         AdNavigationZone.chat.name,
//             //         pathParameters: params,
//             //       );
//             break;
//           case NotificationType.levelAvailable:
//             // router.goNamed(MainAreaNavigationZone.profile.name);
//             router.goNamed(MainAreaNavigationZone.settings.name);
//           default:
//             router.goNamed(MainAreaNavigationZone.homePage.name);
//             break;
//         }
//       });
//     });
//   }
// }
