part of '../ui_kit.dart';

class NotificationPopUp {
  static Future<dynamic> popup(
    context,
    notificationText,
  ) =>
      showModalBottomSheet(
        barrierColor: Colors.transparent,
        backgroundColor: Colors.transparent,
        useRootNavigator: true,
        constraints: BoxConstraints.loose(
          Size(
            MediaQuery.sizeOf(context).width,
            200,
          ),
        ),
        context: context,
        builder: (BuildContext context) {
          return Align(
            alignment: Alignment.bottomLeft,
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 16, bottom: 16),
                  child: DecoratedBox(
                    decoration: const BoxDecoration(color: Colors.greenAccent),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      mainAxisSize: MainAxisSize.min,
                      children: <Widget>[
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text(notificationText),
                        ),
                        ElevatedButton(
                          child: const Text('Закрыть'),
                          onPressed: () => Navigator.pop(context),
                        ),
                      ],
                    ),
                  ),
                ),
                const Spacer(),
              ],
            ),
          );
        },
      );
  static OverlayEntry? overlayEntry;

  static void showOverlay(
    BuildContext context,
    ThemeData theme,
    String notificationText,
    String title,
  ) {
    if (overlayEntry != null && overlayEntry?.mounted == true) {
      overlayEntry?.remove();
      overlayEntry?.dispose();
    }
    overlayEntry = OverlayEntry(
      builder: (context) => Positioned(
        top: 0,
        left: 0,
        child: Material(
          color: Colors.black.withOpacity(0.6),
          borderRadius: BorderRadius.circular(10),
          child: SizedBox(
            width: 200,
            child: Padding(
              padding: const EdgeInsets.all(12.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        notificationText,
                        style: theme.textTheme.bodySmall
                            ?.copyWith(color: Colors.white),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () => {
                          overlayEntry?.remove(),
                          overlayEntry = null,
                        },
                        icon: const Icon(
                          Icons.close,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 16),
                    child: Text(
                      'Новое сообщение test',
                      style: Theme.of(context)
                          .textTheme
                          .bodyMedium
                          ?.copyWith(color: Colors.white),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );

    Overlay.of(context).insert(overlayEntry!);
  }
}
