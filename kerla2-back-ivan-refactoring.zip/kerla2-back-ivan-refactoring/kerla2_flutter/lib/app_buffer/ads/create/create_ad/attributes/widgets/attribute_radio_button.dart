import 'package:flutter/material.dart';
import 'package:nit_app/nit_app.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class RadioButton extends StatelessWidget {
  const RadioButton({
    super.key,
    required this.text,
    required this.isSelected,
    required this.onTap,
  });

  final String text;
  final bool isSelected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 30,
        padding: const EdgeInsets.symmetric(horizontal: 10),
        decoration: BoxDecoration(
          color: isSelected
              ? ThemePrimaryColors.primary
              : context.theme.canvasColor,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Align(
          child: Text(
            text,
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: isSelected ? Colors.white : context.theme.iconTheme.color,
            ),
          ),
        ),
      ),
    );
  }
}
