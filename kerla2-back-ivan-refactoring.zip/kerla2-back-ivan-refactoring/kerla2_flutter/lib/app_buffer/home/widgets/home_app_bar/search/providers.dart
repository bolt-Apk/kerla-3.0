import 'package:hooks_riverpod/hooks_riverpod.dart';

final isSearchFieldVisible = StateProvider.autoDispose<bool>((_) => false);

final searchTabState =
    StateProvider.autoDispose<SearchState>((_) => SearchState.ads);

final isSubscribedAds = StateProvider.autoDispose<bool>((_) => false);

final searchString = StateProvider.autoDispose<String>((_) => '');

// final users = StateProvider<List<UserInfoPublic>>((_) => []);
enum SearchState { account, ads }
