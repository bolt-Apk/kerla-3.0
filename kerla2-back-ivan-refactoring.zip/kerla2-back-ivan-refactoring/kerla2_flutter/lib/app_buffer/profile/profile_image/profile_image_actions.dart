import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_svg/svg.dart';
import 'package:go_router/go_router.dart';
import 'package:kerla2_flutter/common/user_profile_ref_extensions.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_app/nit_app.dart';
import 'package:nit_riverpod_notifications/nit_riverpod_notifications.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class ProfileImageActions extends ConsumerWidget {
  const ProfileImageActions({
    super.key,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final user = ref.currentUserProfile;

    return Material(
      color: theme.scaffoldBackgroundColor,
      child: ListView(
        physics: const NeverScrollableScrollPhysics(),
        padding: const EdgeInsets.all(4),
        children: [
          InkWell(
            onTap: () async {
              try {
                final image = await ref.pickAndUploadImage();
                await ref.saveModel(
                  user!.copyWith(
                    imageUrl: image!.publicUrl,
                  ),
                );
                context.pop();
              } catch (e) {
                ref.notifyUser(NitNotification.error('Ошибка загрузки фото'));
              }
            },
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    user?.imageUrl != null ? 'Изменить фото' : 'Добавить фото',
                    style: Theme.of(context).textTheme.displayLarge,
                  ),
                  const Gap(8),
                  SvgPicture.asset(
                    AppIconsSvg.edit,
                    height: 12,
                    width: 12,
                    colorFilter: ColorFilter.mode(
                      theme.iconTheme.color ?? Colors.black,
                      BlendMode.srcIn,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const Divider(),
          // if (user?.imageUrl != null)
          Builder(
            builder: (context) {
              final bool isDisabled = user?.imageUrl == null;
              return InkWell(
                onTap: isDisabled
                    ? null
                    : () async {
                        await ref.saveModel(
                          user!.copyWith(
                            imageUrl: null,
                          ),
                        );
                        context.pop();
                      },
                child: Opacity(
                  opacity: isDisabled ? 0.5 : 1.0,
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Удалить фото',
                          style: Theme.of(context)
                              .textTheme
                              .displayLarge
                              ?.copyWith(
                                color: isDisabled
                                    ? Colors.red.shade300
                                    : Colors.red,
                              ),
                        ),
                        SvgPicture.asset(
                          AppIconsSvg.delete,
                          height: 12,
                          width: 12,
                          colorFilter: ColorFilter.mode(
                            isDisabled ? Colors.red.shade300 : Colors.red,
                            BlendMode.srcIn,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}
