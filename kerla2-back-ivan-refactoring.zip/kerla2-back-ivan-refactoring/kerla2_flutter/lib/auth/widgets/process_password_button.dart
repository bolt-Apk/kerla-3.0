import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:kerla2_flutter/auth/widgets/auth_bottom_sheet.dart';
import 'package:kerla2_flutter/router/router.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_riverpod_notifications/nit_riverpod_notifications.dart';

import '../../router/navigation_zones/auth_navigation_zone.dart';
import '../state/auth_mode_enum.dart';
import '../state/auth_page_state.dart';

class ProcessPasswordButton extends ConsumerWidget {
  const ProcessPasswordButton({
    super.key,
    required this.mode,
  });

  final AuthModeEnum mode;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return ConstrainedBox(
      constraints: const BoxConstraints(minWidth: 320),
      child: Button(
        title: switch (mode) {
          AuthModeEnum.registration => 'Зарегистрироваться',
          // AuthModeEnum.change => 'Изменить пароль',
          AuthModeEnum.signIn => 'Войти',
          _ => 'Продолжить',
        },
        onPressed: () async {
          if (Form.of(context).validate()) {
            if (await ref
                .read(authPageStateProvider.notifier)
                .processPassword(mode)) {
              if (context.mounted) {
                switch (mode) {
                  case AuthModeEnum.recover:
                    {
                      ref.notifyUser(NitNotification.success('Пароль изменен'));
                      context.hideAuthModalBottomSheet();
                      context.goNamed(MainAreaNavigationZone.profile.name);
                    }
                  case AuthModeEnum.signIn:
                    {
                      context.hideAuthModalBottomSheet();
                      context.goNamed(MainAreaNavigationZone.profile.name);
                    }
                  case AuthModeEnum.registration:
                    ref
                        .read(authPageStateProvider.notifier)
                        .setPage(AuthAreaNavigationZone.registrationCode);
                  default:
                    UnimplementedError();
                }
              }
            } else {
              switch (mode) {
                case AuthModeEnum.signIn:
                  ref.notifyUser(
                    NitNotification.error('Неверный пароль, повторите попытку'),
                  );
                default:
                  ref.notifyUser(
                    NitNotification.error('Произошла ошибка, попробуйте позже'),
                  );
              }
            }
          }
        },
      ),
    );
  }
}
