import 'package:kerla2_client/kerla2_client.dart';
import 'package:nit_app/nit_app.dart';

enum AppBackendFilter<T> with BackendFilterMethodsMixin<T> {
  userId<int>(),
  id<int>(),
  channel<String>(),
  chatChannelId<int>(),
  userName<String>(),
  profileDescription<String>(),
  subscriberId<int>(),
  type<KerlaServiceType>(),
  toUserId<int>(),
  lastMessage<String>(),
  lastMessageId<int>(),
  isRead<bool>(),
  isDeleted<bool>(),
  endsAt<DateTime>(),
  isApproved<bool>(),
}
