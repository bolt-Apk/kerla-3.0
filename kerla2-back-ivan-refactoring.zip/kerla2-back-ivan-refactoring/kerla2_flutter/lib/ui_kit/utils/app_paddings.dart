part of '../ui_kit.dart';

class AppPaddings {
  AppPaddings._();

  static const double _sp4 = 4;
  static const double _sp6 = 6;
  static const double _sp8 = 8;
  static const double _sp12 = 12;
  static const double _sp16 = 16;

  /// Only Bottom
  static const b4 = EdgeInsets.only(bottom: _sp4);
  static const b6 = EdgeInsets.only(bottom: _sp6);
  static const b8 = EdgeInsets.only(bottom: _sp8);

  /// Only Top
  static const t4 = EdgeInsets.only(top: _sp4);
  static const t6 = EdgeInsets.only(top: _sp6);
  static const t8 = EdgeInsets.only(top: _sp8);

  /// Only Left
  static const l4 = EdgeInsets.only(left: _sp4);
  static const l6 = EdgeInsets.only(left: _sp6);
  static const l8 = EdgeInsets.only(left: _sp8);

  /// Only Right
  static const r4 = EdgeInsets.only(right: _sp4);
  static const r6 = EdgeInsets.only(right: _sp6);
  static const r8 = EdgeInsets.only(right: _sp8);

  /// Symmetric horizontal
  static const hor8 = EdgeInsets.symmetric(horizontal: _sp8);
  static const hor12 = EdgeInsets.symmetric(horizontal: _sp12);
  static const hor16 = EdgeInsets.symmetric(horizontal: _sp16);

  /// _Symmetric vertical
  static const ver8 = EdgeInsets.symmetric(vertical: _sp8);
  static const ver12 = EdgeInsets.symmetric(vertical: _sp12);
  static const ver16 = EdgeInsets.symmetric(vertical: _sp16);

  /// Symmetric all
  static const all4 = EdgeInsets.all(_sp4);
  static const all8 = EdgeInsets.all(_sp8);
  static const all12 = EdgeInsets.all(_sp12);
  static const all16 = EdgeInsets.all(_sp16);
}
