// import 'package:collection/collection.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_riverpod/flutter_riverpod.dart';
// import 'package:kerla2_client/kerla2_client.dart';

// import '/state/ad_create_page/ad_create_state.dart';
// import '/state/ad_edit_page/ad_edit_state.dart';
// import '/state/home_filters/home_filters_state.dart';

// class AttributeChooseColor extends ConsumerWidget {
//   const AttributeChooseColor({
//     super.key,
//     this.title,
//     this.attribute,
//     this.adId,
//     this.isFilter = false,
//     this.userId,
//   });

//   final String? title;
//   final Attribute? attribute;
//   final int? adId;
//   final bool? isFilter;
//   final int? userId;

//   @override
//   Widget build(BuildContext context, WidgetRef ref) {
//     // final stateCreate = ref.watch(adCreateStateProvider(isStory: false));
//     // final state = ref.watch(adCreateStateProvider(isStory: false));
//     final editState = ref.watch(adEditStateProvider(adId: adId));

//     final AdAttributeValue? attributeValue =
//         editState.value?.ad?.attributeValues?.firstWhereOrNull(
//       (element) => element.attribute?.id == attribute?.id,
//     );

//     final bool attributeValueExist =
//         (attributeValue?.value != null && attributeValue!.value.isNotEmpty);

//     void onTap(index) {
//       if (adId != null) {
//         // ref.read(adEditStateProvider(adId: adId).notifier).updateAttributeValue(
//         //       attributeValue!.attribute!.id!,
//         //       attributeValue.attribute?.subAttributeId != null,
//         //       KerlaColors.values[index].index.toString(),
//         //     );
//       } else {
//         !isFilter!
//             ? ref
//                 .read(
//                   adCreateStateProvider(isStory: false).notifier,
//                 )
//                 .setAttribute<KerlaColors>(
//                   attribute!,
//                   KerlaColors.values[index],
//                 )
//             : ref
//                 .read(
//                   homeFiltersStateProvider(isProfile: userId != null).notifier,
//                 )
//                 .setAttribute(
//                   AdAttributeValue(
//                     attributeId: attribute!.id!,
//                     value: KerlaColors.values[index].toString(),
//                   ),
//                 );
//       }
//     }

//     double circleSize(int index) {
//       double size = 12;
//       if (adId != null) {
//         attributeValueExist
//             ? (KerlaColors.fromJson(int.parse(attributeValue.value))
//                             as KerlaColors)
//                         .title ==
//                     KerlaColors.values[index].title
//                 ? size = 16
//                 : size = 12
//             : size = 12;
//       } else {
//         state.attribute[attribute] != null
//             ? (state.attribute[attribute] as KerlaColors).title ==
//                     KerlaColors.values[index].title
//                 ? size = 16
//                 : size = 12
//             : size = 12;
//       }
//       return size;
//     }

//     return Column(
//       children: [
//         Row(
//           mainAxisAlignment: MainAxisAlignment.spaceBetween,
//           children: [
//             const Padding(
//               padding: EdgeInsets.symmetric(vertical: 8),
//               child: Align(
//                 alignment: Alignment.centerLeft,
//                 child: Text(
//                   "Цвет",
//                   style: TextStyle(fontSize: 16, color: Colors.black),
//                 ),
//               ),
//             ),
//             Container(
//               padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
//               decoration: BoxDecoration(
//                 borderRadius: BorderRadius.circular(5),
//                 color: Colors.white,
//               ),
//               child: Consumer(
//                 builder: (context, ref, child) {
//                   final stateFilter = ref.watch(
//                     homeFiltersStateProvider(isProfile: userId != null),
//                   );

//                   String title;
//                   if (adId != null) {
//                     attributeValueExist
//                         ? title = (KerlaColors.fromJson(
//                             int.parse(attributeValue.value),
//                           ) as KerlaColors)
//                             .title
//                         : title = 'Выберите цвет';
//                   } else {
//                     !isFilter!
//                         ? stateCreate.attribute[attribute] != null
//                             ? title = (stateCreate.attribute[attribute]
//                                     as KerlaColors)
//                                 .title
//                             : title = 'Выберите цвет'
//                         : stateFilter.attribute.firstWhereOrNull(
//                                   (element) =>
//                                       element.attributeId == attribute!.id!,
//                                 ) !=
//                                 null
//                             ? title = KerlaColors
//                                 .values[int.parse(
//                                 stateFilter.attribute
//                                     .firstWhere(
//                                       (element) =>
//                                           element.attributeId == attribute!.id!,
//                                     )
//                                     .value,
//                               )]
//                                 .title
//                             : title = 'Выберите цвет';
//                   }
//                   return Text(
//                     title,
//                     style: const TextStyle(
//                       fontSize: 12,
//                       fontWeight: FontWeight.w400,
//                       color: Colors.black,
//                     ),
//                   );
//                 },
//               ),
//             ),
//           ],
//         ),
//         SingleChildScrollView(
//           scrollDirection: Axis.horizontal,
//           child: SizedBox(
//             height: 60,
//             child: Row(
//               children: List.generate(
//                 KerlaColors.values.length,
//                 (index) => Padding(
//                   padding: const EdgeInsets.all(8.0),
//                   child: Container(
//                     decoration: BoxDecoration(
//                       color: Colors.white,
//                       shape: BoxShape.circle,
//                       boxShadow: [
//                         BoxShadow(
//                           color: Colors.grey.withOpacity(0.5),
//                           spreadRadius: 1,
//                           blurRadius: 5,
//                         ),
//                       ],
//                     ),
//                     child: GestureDetector(
//                       onTap: () => onTap(index),
//                       child: CircleAvatar(
//                         backgroundColor:
//                             Color(KerlaColors.values[index].colorHex),
//                         radius: circleSize(index),
//                       ),
//                     ),
//                   ),
//                 ),
//               ),
//             ),
//           ),
//         ),
//         const SizedBox(height: 10),
//       ],
//     );
//   }
// }
