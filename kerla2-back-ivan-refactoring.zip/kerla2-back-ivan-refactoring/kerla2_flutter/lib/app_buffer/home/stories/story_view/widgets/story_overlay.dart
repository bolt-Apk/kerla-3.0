import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/app_buffer/profile/profile_image/profile_image.dart';
import 'package:kerla2_flutter/app_buffer/profile/subscribers/widgets/subscribe_button.dart';
import 'package:kerla2_flutter/router/router.dart';
import 'package:nit_app/nit_app.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';
import 'package:story_view/controller/story_controller.dart';

class StoryOverlay extends ConsumerWidget {
  const StoryOverlay({
    super.key,
    required this.user,
    required this.story,
    required this.onClose,
    required this.storyController,
  });

  final UserProfile user;
  final Ad story;
  final VoidCallback onClose;
  final StoryController storyController;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isMyProfile = user.userId == ref.signedInUserId;
    return SafeArea(
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 18),
            child: Row(
              children: [
                // User avatar
                Flexible(
                  child: GestureDetector(
                    onTap: () async {
                      storyController.pause();
                      await context.pushNamed(
                        MainAreaNavigationZone.user.name,
                        pathParameters:
                            AppNavigationParams.userId.set(user.userId),
                      );
                      storyController.play();
                    },
                    child: Row(
                      children: [
                        ProfileImage.mini(userId: user.userId),
                        const Gap(12),
                        // Username
                        Expanded(
                          child: Text(
                            user.userName ?? '',
                            style: context.theme.textTheme.bodyMedium?.copyWith(
                              color: Colors.white,
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const Gap(32),
                if (ref.signedIn && !isMyProfile)
                  SubscribeButton(userId: user.userId),
                const Gap(8),
                Row(
                  children: [
                    Text(
                      story.visitCount.toString(),
                      style: context.theme.textTheme.bodyMedium?.copyWith(
                        color: Colors.white,
                      ),
                    ),
                    const Gap(4),
                    const Icon(
                      Icons.remove_red_eye,
                      color: Colors.white,
                      size: 20,
                    ),
                  ],
                ),

                // Close button
                IconButton(
                  icon: const Icon(Icons.close, color: Colors.white),
                  onPressed: onClose,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
