import 'package:kerla2_flutter/core/core.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:kerla2_client/kerla2_client.dart';

part 'story_list_state.g.dart';

@Riverpod(keepAlive: true)
class StoryListState extends _$StoryListState {
  @override
  Future<List<UserProfile>> build() async {
    return await client.ad.getUsersWithStories();
  }
}
