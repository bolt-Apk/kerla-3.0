import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerla2_flutter/common/user_profile_ref_extensions.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_app/nit_app.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class EditLinkWidget extends ConsumerWidget {
  const EditLinkWidget({
    super.key,
    required this.userId,
  });

  final int userId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return ref.watchUserProfile(userId).nitWhen(
          childBuilder: (userProfile) => TextSettingsRow(
            title: 'Ссылка',
            subtitle: userProfile.link ?? '',
            // TODO: использовать цвет из темы
            subtitleColor: const Color(0xFF0B45DB),
            editingBottomSheet: TextEditingBottomSheet(
              initialValue: userProfile.link ?? '',
              title: 'Ссылка',
              keyboardType: TextInputType.url,
              maxLength: 120,
              acceptAction: (String newValue) async =>
                  null !=
                  await ref.saveModel(
                    userProfile.copyWith(link: newValue),
                  ),
            ),
          ),
        );
  }
}
