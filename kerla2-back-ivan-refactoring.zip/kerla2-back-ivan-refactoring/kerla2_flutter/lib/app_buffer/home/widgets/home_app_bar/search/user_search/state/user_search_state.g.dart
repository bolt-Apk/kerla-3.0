// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'user_search_state.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$userSearchStateHash() => r'6490e59d376d001dfc734c3ef3d85447324fe7a4';

/// See also [userSearchState].
@ProviderFor(userSearchState)
final userSearchStateProvider =
    AutoDisposeFutureProvider<List<UserProfile>>.internal(
  userSearchState,
  name: r'userSearchStateProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$userSearchStateHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef UserSearchStateRef = AutoDisposeFutureProviderRef<List<UserProfile>>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
