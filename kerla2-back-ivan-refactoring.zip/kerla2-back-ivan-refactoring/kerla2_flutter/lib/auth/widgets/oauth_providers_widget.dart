import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/app/profile/settings/widgets/edit_phone_widget.dart';
import 'package:kerla2_flutter/auth/enter_user_profile_page.dart';
import 'package:kerla2_flutter/auth/state/auth_mode_enum.dart';
import 'package:kerla2_flutter/auth/widgets/auth_bottom_sheet.dart';
import 'package:kerla2_flutter/core/app_repository.dart';
import 'package:kerla2_flutter/router/router.dart';
import 'package:nit_app/nit_app.dart';
import 'package:nit_riverpod_notifications/nit_riverpod_notifications.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';
import 'package:serverpod_auth_apple_flutter/serverpod_auth_apple_flutter.dart';

import '../../core/core.dart';

class OauthProvidersWidget extends ConsumerWidget {
  const OauthProvidersWidget({super.key});

  _redirect(BuildContext context, WidgetRef ref) async {
    await Future.delayed(const Duration(milliseconds: 500)); //TODO: handle this
    final userId = ref
        .read(nitSessionStateProvider)
        .serverpodSessionManager
        ?.signedInUser
        ?.id;

    if (userId == null) return;
    final profile = await ref.readOrFetchModel(
        userId, AppRepository.userProfileByUserId.descriptor);
    // UserProfile? profile;

    if (profile.gender == null) {
      final registrationResult = await showModalBottomSheet<bool>(
          context: context,
          useRootNavigator: true,
          isDismissible: false,
          enableDrag: false,
          builder: (context) {
            return const Padding(
              padding: EdgeInsets.all(8.0),
              child: EnterUserProfilePage(mode: AuthModeEnum.oauth),
            );
          });

      if (registrationResult == true) {
        await showModalBottomSheet(
          useRootNavigator: true,
          context: context,
          builder: (context) {
            return const PhoneEditBottomSheet();
          },
        );
        context.goNamed(MainAreaNavigationZone.profile.name);
      } else {
        await ref.read(nitSessionStateProvider.notifier).signOut();
      }
    } else {
      context.goNamed(MainAreaNavigationZone.profile.name);
    }
    context.hideAuthModalBottomSheet();
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Platform.isIOS // TODO: do another check
        ? Column(
            children: [
              const Divider(
                thickness: 1,
              ),
              // Padding(
              //   padding: const EdgeInsets.only(left: 19, bottom: 20),
              //   child: Row(
              //     crossAxisAlignment: CrossAxisAlignment.start,
              //     children: [
              //       Text(
              //         'Или продолжите через',
              //         style: context.textTheme.titleSmall,
              //       ),
              //     ],
              //   ),
              // ),

              SizedBox(
                height: 40,
                child: SignInWithAppleButton(
                  caller: client.modules.auth,
                  onSignedIn: () => {
                    _redirect(context, ref),
                  },
                  label: 'Продолжить с Apple',
                  style: ElevatedButton.styleFrom(
                    backgroundColor: context.theme.iconTheme.color,
                    foregroundColor: context.theme.dialogBackgroundColor,
                    alignment: Alignment.center,
                    textStyle: context.textTheme.labelLarge,
                    padding: EdgeInsets.zero,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(100),
                    ),
                  ),
                ),
              ),
              // const Gap(8),
              // CustomGoogleAuthButton(
              //   caller: client.modules.auth,
              //   serverClientId:
              //       '792502470558-vj4kujd77g1cjj5mffpce6ousr8err9p.apps.googleusercontent.com', // needs to be supplied for the web integration
              //   redirectUri: Uri.parse(
              //       '${kDebugMode ? 'http://localhost' : 'http://82.97.253.234'}:8082/googlesignin'),
              //   label: 'Продолжить с Google',
              //   onSignedIn: () => _redirect(context, ref),
              // ),

              // SignInWithGoogleButton(
              //   caller: client.modules.auth,
              //   serverClientId:
              //       '792502470558-vj4kujd77g1cjj5mffpce6ousr8err9p.apps.googleusercontent.com', // needs to be supplied for the web integration
              //   redirectUri: Uri.parse('http://localhost:8082/googlesignin'),
              //   label: 'Продолжить с Google',
              //   onSignedIn: () => _redirect(context, ref),
              // ),
              // const SizedBox(
              //   width: 10,
              // ),
              // const Text('Продолжить с Google')
              // ],
              // ),
            ],
          )
        : const SizedBox();
  }
}
