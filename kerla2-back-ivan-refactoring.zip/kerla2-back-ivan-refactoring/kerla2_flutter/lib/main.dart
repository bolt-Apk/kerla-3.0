import 'dart:math';

import 'package:appmetrica_plugin/appmetrica_plugin.dart';
import 'package:firebase_core/firebase_core.dart';
// import 'package:firebase_crashlytics/firebase_crashlytics.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/app/profile/settings/widgets/edit_phone_widget.dart';
import 'package:kerla2_flutter/common/user_profile_ref_extensions.dart';
import 'package:kerla2_flutter/core/app_repository.dart';
import 'package:kerla2_flutter/core/core.dart';
import 'package:kerla2_flutter/core/default_models.dart';
import 'package:kerla2_flutter/core/view_session_id.dart';
import 'package:kerla2_flutter/one_signal_wrapper.dart';
import 'package:kerla2_flutter/router/router.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
// import 'package:mytracker_sdk/mytracker_sdk.dart';
import 'package:nit_app/nit_app.dart';
// import 'package:onesignal_flutter/onesignal_flutter.dart';
import 'package:serverpod_auth_shared_flutter/serverpod_auth_shared_flutter.dart';
import 'package:serverpod_flutter/serverpod_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'core/app_sources.dart';
import 'firebase_options.dart';

// void main() async {
//   client = Client(
//     'http://91.142.73.206:8080/', //stage server
//     authenticationKeyManager: FlutterAuthenticationKeyManager(),
//   )..connectivityMonitor = FlutterConnectivityMonitor();

//   WidgetsFlutterBinding.ensureInitialized();
//   if (!kIsWeb) {
//     await Firebase.initializeApp(
//         options: DefaultFirebaseOptions.currentPlatform);

//     // Pass all uncaught "fatal" errors from the framework to Crashlytics
//     // FlutterError.onError = FirebaseCrashlytics.instance.recordFlutterFatalError;

//     // PlatformDispatcher.instance.onError = (error, stack) {
//     //   // FirebaseCrashlytics.instance.recordError(error, stack, fatal: true);
//     //   return true;
//     // };

//     AppMetrica.activate(
//         const AppMetricaConfig("6dae8a73-409c-45a5-928e-72c7fe9fe91b"));

//     OneSignal.Debug.setLogLevel(OSLogLevel.verbose);

//     oneSignalAppId = '93fcf33c-caf9-4c86-93dc-a2267f51ed04'; //prod

//     // ПОМЕНЯТЬ OneSignalId НА БЭКЕ
//     OneSignal.initialize(oneSignalAppId);

//     // OneSignal.Notifications.requestPermission(true);
//   }

//   runApp(
//     const ProviderScope(child: InitMessages()),
//   );
// }

// final isTestServer = StateProvider<bool>((ref) {
//   return false;
// });

final themeNotifierProvider = ChangeNotifierProvider<ThemeProvider>((ref) {
  return ThemeProvider();
});

class InitMessages extends ConsumerStatefulWidget {
  const InitMessages({super.key});

  @override
  ConsumerState<ConsumerStatefulWidget> createState() => _InitMessagesState();
}

class _InitMessagesState extends ConsumerState<InitMessages> {
  @override
  Widget build(BuildContext context) {
    final themeProvider = ref.watch(themeNotifierProvider);

    return NitApp(
      locale: 'ru',
      title: 'Керла',
      routerProvider: routerProvider,
      // deeplinkHandler: deeplinksHandler,
      initializers: [
        () async {
          prefs = await SharedPreferences.getInstance();
          return true;
        },
        () async => await ref.initNitServerpodApp(
              client: client,
              initRepositoryFunction: DefaultModels.initRepository,
              customRepositoryDescriptors:
                  AppRepository.values.map((repo) => repo.descriptor).toList(),
            ),
        () async => AppSources.instance.init(ref),
        () async {
          if (ref.read(viewSessionIdProvider) ==
              const UuidValue.fromNamespace(Namespace.nil)) {
            // Генерируем новый UUID с помощью пакета uuid
            final newUuid = const Uuid().v4();
            await ref.watch(viewSessionIdProvider.notifier).update(
                  UuidValue.fromString(newUuid),
                );
          }
          return true;
        },
      ],
      themeData: themeProvider.themeData,
      loadingScreen: ColoredBox(
        color: Theme.of(context).canvasColor,
        child: const Center(
          child: CircularProgressIndicator(
            color: ThemePrimaryColors.primary,
          ),
        ),
      ),
      loadingFailedScreen: const ColoredBox(
        color: ThemePrimaryColors.primary,
        child: Center(
          child: Directionality(
            textDirection: TextDirection.ltr,
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Center(
                    child: Text(
                      'Не удалось подключиться к серверу',
                      style: TextStyle(color: Colors.black),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  // TextButton(
                  //   onPressed: () {
                  //     initializers().forEach(
                  //       (element) async {
                  //         await element();
                  //       },
                  //     );
                  //     setState(() {});
                  //   },
                  //   child: const Text('Обновить'),
                  // ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
