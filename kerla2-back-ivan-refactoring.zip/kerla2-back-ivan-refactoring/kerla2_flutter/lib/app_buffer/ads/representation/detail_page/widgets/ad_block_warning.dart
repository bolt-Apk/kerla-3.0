import 'package:flutter/material.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class AdBlockWarning extends StatelessWidget {
  const AdBlockWarning({super.key});

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        color: context.theme.canvasColor,
      ),
      child: const Padding(
        padding: EdgeInsets.all(8.0),
        child: Text(
          'Объявление заблокировано',
          style: TextStyle(color: Colors.red),
        ),
      ),
    );
  }
}
