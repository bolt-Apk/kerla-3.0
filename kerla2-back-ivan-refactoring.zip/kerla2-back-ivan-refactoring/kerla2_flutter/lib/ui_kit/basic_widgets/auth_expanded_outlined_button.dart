part of '../ui_kit.dart';

class AuthExpandedOutlinedButton extends StatelessWidget {
  final Widget child;
  final double height;
  final Function()? onPressed;
  final Guard? guard;
  final double borderRadius;
  final double borderWidth;

  const AuthExpandedOutlinedButton({
    required this.child,
    required this.onPressed,
    this.guard,
    this.height = 40,
    this.borderRadius = 4,
    this.borderWidth = 1,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    final ButtonStyle style = OutlinedButton.styleFrom(
      side: BorderSide(
        color: ThemePrimaryColors.primary,
        width: borderWidth,
      ),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(borderRadius),
      ),
      foregroundColor: ThemePrimaryColors.primary,
    );

    return SizedBox(
      height: height,
      width: double.infinity,
      child: guard != null
          ? GuardedOutlinedButton(
              guard: guard,
              onPressed: onPressed,
              style: style,
              child: child,
            )
          : OutlinedButton(
              onPressed: onPressed,
              style: style,
              child: child,
            ),
    );
  }
}
