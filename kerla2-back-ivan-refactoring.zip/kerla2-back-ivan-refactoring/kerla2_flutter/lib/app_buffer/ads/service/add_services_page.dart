import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerla2_flutter/app_buffer/ads/service/state/service_state.dart';
import 'package:kerla2_flutter/app_buffer/ads/service/widget/connect_services.dart';
import 'package:kerla2_flutter/app_buffer/ads/service/widget/service_list_widget.dart';
import 'package:kerla2_flutter/core/app_scaffold.dart';
import 'package:kerla2_flutter/router/router.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_router/nit_router.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class AddServicesPage extends ConsumerWidget {
  final bool isUpdateService;
  const AddServicesPage({
    super.key,
    this.isUpdateService = false,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final int? adId = ref.watchNavigationParam(AppNavigationParams.adId);

    if (adId == null) {
      return Scaffold(
        appBar: AppBar(),
        body: const Text('Возникла ошибка. Объявление не найдено'),
      );
    }

    return PopScope(
      canPop: false,
      child: AppScaffold(
        showBottomNavBar: false,
        backgroundColor: context.theme.scaffoldBackgroundColor,
        appBar: AppBar(
          automaticallyImplyLeading: false,
          elevation: 0,
          backgroundColor: context.theme.appBarTheme.backgroundColor,
          foregroundColor: context.theme.textTheme.titleLarge?.color,
          centerTitle: true,
          title: Text(
            "Хотите продавать быстрее?",
            style: TextStyle(
                color: context.theme.textTheme.titleLarge?.color, fontSize: 17),
          ),
        ),
        body: ref.watch(serviceListStateProvider(adId)).nitWhen(
          childBuilder: (data) {
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    const RecommendMessage(
                      boldText: "Рекомендуем",
                      text:
                          "подключить дополнительную услугу для своего объявления,"
                          " для того, чтобы его увидели как можно больше людей.",
                      containerColor: Color(0xffB8EAE2),
                    ),
                    ServiceListWidget.free(adId: adId, state: data),
                    ServiceListWidget.payable(adId: adId, state: data),
                    if (data.selectedServices.isNotEmpty)
                      ConnectService(
                        adId: adId,
                      ),
                    const SizedBox(height: 32),
                    GestureDetector(
                      onTap: () {
                        if (isUpdateService) {
                          context.pop();
                          return;
                        }
                        context.goNamed(MainAreaNavigationZone.profile.name);
                      },
                      child: Text(
                        "Продолжить без изменений",
                        style: TextStyle(
                          color: context.theme.textTheme.titleLarge?.color,
                          fontSize: 18,
                        ),
                      ),
                    ),
                    const SizedBox(height: 52),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
