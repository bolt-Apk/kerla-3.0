import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:kerla2_flutter/auth/state/auth_page_state.dart';
import 'package:kerla2_flutter/auth/widgets/auth_header_widget.dart';
import 'package:kerla2_flutter/auth/widgets/email_input_widget.dart';
import 'package:kerla2_flutter/auth/widgets/process_password_button.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

import '../router/navigation_zones/auth_navigation_zone.dart';
import '../ui_kit/ui_kit.dart';
import 'state/auth_mode_enum.dart';

class EnterAuthPasswordPage extends ConsumerWidget {
  const EnterAuthPasswordPage({
    super.key,
    required this.mode,
  });

  final AuthModeEnum mode;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(authPageStateProvider);

    // if (state.emailController.text.isEmpty) {
    //   return RedirectWidget(
    //     fallbackRoute: AuthAreaNavigationZone.registration,
    //     notification: NitNotification.warning(
    //       'Ошибка регистрации, попробуйте начать сначала',
    //     ),
    //   );
    // }

    return Form(
      // key: formKey,
      child: Column(
        children: [
          AuthHeaderWidget(
            mode: mode,
          ),
          if (mode == AuthModeEnum.registration) const EmailInputWidget(),
          // Padding(
          //   padding: const EdgeInsets.only(top: 8, bottom: 5),
          //   child: Text(
          //     "Введите пароль",
          //     style: context.textTheme.titleLarge,
          //   ),
          // ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: TextEntryField.password(
                controller: state.passwordController,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Поле не может быть пустым';
                  }
                  return null;
                },
                label: 'Пароль'),
          ),
          if (mode == AuthModeEnum.registration)
            TextEntryField.password(
                controller: state.confirmPasswordController,
                validator: (value) {
                  if (value != state.passwordController.text) {
                    //state.password.text
                    return 'Пароли не совпадают';
                  }
                  return null;
                },
                label: 'Eщё раз'),
          if (mode == AuthModeEnum.signIn)
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Button.text(
                  title: 'Забыли пароль?',
                  onPressed: () {
                    context.pushNamed(
                      AuthAreaNavigationZone.recover.name,
                    );
                  },
                ),
              ],
            ),
          const Gap(16),
          ProcessPasswordButton(mode: mode),
        ],
      ),
    );
  }
}
