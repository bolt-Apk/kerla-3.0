/* AUTOMATICALLY GENERATED CODE DO NOT MODIFY */
/*   To generate run: "serverpod generate"    */

// ignore_for_file: implementation_imports
// ignore_for_file: library_private_types_in_public_api
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: public_member_api_docs
// ignore_for_file: type_literal_in_constant_pattern
// ignore_for_file: use_super_parameters

// ignore_for_file: no_leading_underscores_for_library_prefixes
import 'package:serverpod_client/serverpod_client.dart' as _i1;
import 'dart:async' as _i2;
import 'package:nit_tools_client/src/extra_classes/api_response.dart' as _i3;
import 'package:kerla2_client/src/protocol/kerla_services/kerla_service.dart'
    as _i4;
import 'package:kerla2_client/src/protocol/ads/ad.dart' as _i5;
import 'package:kerla2_client/src/protocol/ads/ad_list_type.dart' as _i6;
import 'package:kerla2_client/src/protocol/ads/ad_type.dart' as _i7;
import 'package:kerla2_client/src/protocol/ads/ad_sort_by_values.dart' as _i8;
import 'package:kerla2_client/src/protocol/user_profile/user_gender.dart'
    as _i9;
import 'package:kerla2_client/src/protocol/user_profile/user_profile.dart'
    as _i10;
import 'package:kerla2_client/src/protocol/kerla_services/kerla_service_info.dart'
    as _i11;
import 'package:serverpod_auth_client/serverpod_auth_client.dart' as _i12;
import 'package:kerla2_client/src/protocol/ads/ad_category.dart' as _i13;
import 'package:kerla2_client/src/protocol/attributes/attribute.dart' as _i14;
import 'package:kerla2_client/src/protocol/attributes/sub_attribute.dart'
    as _i15;
import 'package:kerla2_client/src/protocol/notifications/app_notification.dart'
    as _i16;
import 'package:kerla2_client/src/protocol/promos/promo_level.dart' as _i17;
import 'package:dartway_tinkoff_serverpod_client/dartway_tinkoff_serverpod_client.dart'
    as _i18;
import 'package:nit_tools_client/nit_tools_client.dart' as _i19;
import 'protocol.dart' as _i20;

/// {@category Endpoint}
class EndpointAcquiring extends _i1.EndpointRef {
  EndpointAcquiring(_i1.EndpointCaller caller) : super(caller);

  @override
  String get name => 'acquiring';

  _i2.Future<_i3.ApiResponse<String>> initPayment(
          {required List<_i4.KerlaService> services}) =>
      caller.callServerEndpoint<_i3.ApiResponse<String>>(
        'acquiring',
        'initPayment',
        {'services': services},
      );
}

/// {@category Endpoint}
class EndpointAd extends _i1.EndpointRef {
  EndpointAd(_i1.EndpointCaller caller) : super(caller);

  @override
  String get name => 'ad';

  _i2.Future<List<_i5.Ad>> getAds({
    required _i6.AdListType adListType,
    required List<int> excludeAdIds,
    required _i7.AdType adType,
    int? userId,
    int? page,
    int? limit,
    List<int>? categoryIds,
    List<Map<int, String>>? attributes,
    String? searchQuery,
    _i8.AdOrderBy? adOrderBy,
    bool? isPromotedAds,
    required bool getSubscribedAds,
    _i9.UserGender? gender,
  }) =>
      caller.callServerEndpoint<List<_i5.Ad>>(
        'ad',
        'getAds',
        {
          'adListType': adListType,
          'excludeAdIds': excludeAdIds,
          'adType': adType,
          'userId': userId,
          'page': page,
          'limit': limit,
          'categoryIds': categoryIds,
          'attributes': attributes,
          'searchQuery': searchQuery,
          'adOrderBy': adOrderBy,
          'isPromotedAds': isPromotedAds,
          'getSubscribedAds': getSubscribedAds,
          'gender': gender,
        },
      );

  /// Update ad visit counts field
  _i2.Future<void> updateAdCounts(
    bool isStory,
    int adId,
    String userSessionId,
  ) =>
      caller.callServerEndpoint<void>(
        'ad',
        'updateAdCounts',
        {
          'isStory': isStory,
          'adId': adId,
          'userSessionId': userSessionId,
        },
      );

  /// Gets a list of users who have stories
  _i2.Future<List<_i10.UserProfile>> getUsersWithStories() =>
      caller.callServerEndpoint<List<_i10.UserProfile>>(
        'ad',
        'getUsersWithStories',
        {},
      );

  /// Gets a list of story ads for a specific user
  _i2.Future<List<int>> getStoriesByUser(int userId) =>
      caller.callServerEndpoint<List<int>>(
        'ad',
        'getStoriesByUser',
        {'userId': userId},
      );
}

/// {@category Endpoint}
class EndpointAdManagement extends _i1.EndpointRef {
  EndpointAdManagement(_i1.EndpointCaller caller) : super(caller);

  @override
  String get name => 'adManagement';

  _i2.Future<List<_i11.KerlaServiceInfo>> getFreeConnectableServices(
          {required int adId}) =>
      caller.callServerEndpoint<List<_i11.KerlaServiceInfo>>(
        'adManagement',
        'getFreeConnectableServices',
        {'adId': adId},
      );

  _i2.Future<List<_i11.KerlaServiceInfo>> getPayableServices(
          {required int adId}) =>
      caller.callServerEndpoint<List<_i11.KerlaServiceInfo>>(
        'adManagement',
        'getPayableServices',
        {'adId': adId},
      );
}

/// Endpoint for handling admin functions.
/// {@category Endpoint}
class EndpointAdmin extends _i1.EndpointRef {
  EndpointAdmin(_i1.EndpointCaller caller) : super(caller);

  @override
  String get name => 'admin';

  /// Finds a user by its id.
  _i2.Future<_i12.UserInfo?> getUserInfo(int userId) =>
      caller.callServerEndpoint<_i12.UserInfo?>(
        'admin',
        'getUserInfo',
        {'userId': userId},
      );

  /// Changes the block status of a user.
  _i2.Future<bool> changeUserBlockStatus(int userId) =>
      caller.callServerEndpoint<bool>(
        'admin',
        'changeUserBlockStatus',
        {'userId': userId},
      );

  /// Changes the block status of an ad.
  _i2.Future<bool> changeAdBlockStatus(int adId) =>
      caller.callServerEndpoint<bool>(
        'admin',
        'changeAdBlockStatus',
        {'adId': adId},
      );
}

/// {@category Endpoint}
class EndpointAdCategory extends _i1.EndpointRef {
  EndpointAdCategory(_i1.EndpointCaller caller) : super(caller);

  @override
  String get name => 'adCategory';

  _i2.Future<List<_i13.AdCategory>> getAdCategoryList() =>
      caller.callServerEndpoint<List<_i13.AdCategory>>(
        'adCategory',
        'getAdCategoryList',
        {},
      );

  _i2.Future<List<_i13.AdCategory>> getAdCategoriesForProfile(int userId) =>
      caller.callServerEndpoint<List<_i13.AdCategory>>(
        'adCategory',
        'getAdCategoriesForProfile',
        {'userId': userId},
      );

  /// Gets all attributes for a category.
  /// Pass the subcategory to get all attributes for that category.
  _i2.Future<List<_i14.Attribute>> getAttributesByCategory(
          _i13.AdCategory category) =>
      caller.callServerEndpoint<List<_i14.Attribute>>(
        'adCategory',
        'getAttributesByCategory',
        {'category': category},
      );

  _i2.Future<List<_i15.SubAttribute>> getSubAttributeByAttribute(
    _i14.Attribute attribute,
    String value,
  ) =>
      caller.callServerEndpoint<List<_i15.SubAttribute>>(
        'adCategory',
        'getSubAttributeByAttribute',
        {
          'attribute': attribute,
          'value': value,
        },
      );
}

/// {@category Endpoint}
class EndpointNotification extends _i1.EndpointRef {
  EndpointNotification(_i1.EndpointCaller caller) : super(caller);

  @override
  String get name => 'notification';

  _i2.Future<List<_i16.AppNotification>> getUserNotifications() =>
      caller.callServerEndpoint<List<_i16.AppNotification>>(
        'notification',
        'getUserNotifications',
        {},
      );

  _i2.Future<void> setAllNotificationIsRead() =>
      caller.callServerEndpoint<void>(
        'notification',
        'setAllNotificationIsRead',
        {},
      );

  _i2.Future<bool> hasNewNotification() => caller.callServerEndpoint<bool>(
        'notification',
        'hasNewNotification',
        {},
      );
}

/// {@category Endpoint}
class EndpointOnlineStatus extends _i1.EndpointRef {
  EndpointOnlineStatus(_i1.EndpointCaller caller) : super(caller);

  @override
  String get name => 'onlineStatus';
}

/// {@category Endpoint}
class EndpointPromocode extends _i1.EndpointRef {
  EndpointPromocode(_i1.EndpointCaller caller) : super(caller);

  @override
  String get name => 'promocode';

  ///Returns null if promocode is valid. Returns error message if promocode is invalid
  _i2.Future<String?> acceptPromocode(String promocode) =>
      caller.callServerEndpoint<String?>(
        'promocode',
        'acceptPromocode',
        {'promocode': promocode},
      );

  /// Returns error message if level activation is failed. Returns null if level activation is successful
  /// if userId not passed accepts for current user
  _i2.Future<String?> acceptNewLevelBonus([int? userId]) =>
      caller.callServerEndpoint<String?>(
        'promocode',
        'acceptNewLevelBonus',
        {'userId': userId},
      );

  _i2.Future<_i17.PromoLevel?> getNextPromocodeLevel() =>
      caller.callServerEndpoint<_i17.PromoLevel?>(
        'promocode',
        'getNextPromocodeLevel',
        {},
      );

  _i2.Future<_i17.PromoLevel?> getCurrentPromocodeLevel() =>
      caller.callServerEndpoint<_i17.PromoLevel?>(
        'promocode',
        'getCurrentPromocodeLevel',
        {},
      );

  _i2.Future<int> getInvitesCount() => caller.callServerEndpoint<int>(
        'promocode',
        'getInvitesCount',
        {},
      );

  _i2.Future<void> testImitateInvite() => caller.callServerEndpoint<void>(
        'promocode',
        'testImitateInvite',
        {},
      );
}

/// {@category Endpoint}
class EndpointUserAuth extends _i1.EndpointRef {
  EndpointUserAuth(_i1.EndpointCaller caller) : super(caller);

  @override
  String get name => 'userAuth';

  _i2.Future<bool> verifyResetCode(
    String email,
    String code,
  ) =>
      caller.callServerEndpoint<bool>(
        'userAuth',
        'verifyResetCode',
        {
          'email': email,
          'code': code,
        },
      );

  _i2.Future<bool> verifyEmail(String email) => caller.callServerEndpoint<bool>(
        'userAuth',
        'verifyEmail',
        {'email': email},
      );

  _i2.Future<bool> verifyRegisterCode(
    String email,
    String code,
  ) =>
      caller.callServerEndpoint<bool>(
        'userAuth',
        'verifyRegisterCode',
        {
          'email': email,
          'code': code,
        },
      );

  _i2.Future<String?> validateUsername(String username) =>
      caller.callServerEndpoint<String?>(
        'userAuth',
        'validateUsername',
        {'username': username},
      );
}

/// {@category Endpoint}
class EndpointUsers extends _i1.EndpointRef {
  EndpointUsers(_i1.EndpointCaller caller) : super(caller);

  @override
  String get name => 'users';

  /// Retrieves a list of user profiles matching the given nickname prefix.
  ///
  /// The search is case-insensitive and only returns non-blocked users for non-admin users.
  /// For authenticated users, it also indicates if they are subscribed to each user.
  _i2.Future<List<_i10.UserProfile>> getUserListByNick(String userName) =>
      caller.callServerEndpoint<List<_i10.UserProfile>>(
        'users',
        'getUserListByNick',
        {'userName': userName},
      );
}

class _Modules {
  _Modules(Client client) {
    dartway_tinkoff_serverpod = _i18.Caller(client);
    auth = _i12.Caller(client);
    nitTools = _i19.Caller(client);
  }

  late final _i18.Caller dartway_tinkoff_serverpod;

  late final _i12.Caller auth;

  late final _i19.Caller nitTools;
}

class Client extends _i1.ServerpodClientShared {
  Client(
    String host, {
    dynamic securityContext,
    _i1.AuthenticationKeyManager? authenticationKeyManager,
    Duration? streamingConnectionTimeout,
    Duration? connectionTimeout,
    Function(
      _i1.MethodCallContext,
      Object,
      StackTrace,
    )? onFailedCall,
    Function(_i1.MethodCallContext)? onSucceededCall,
    bool? disconnectStreamsOnLostInternetConnection,
  }) : super(
          host,
          _i20.Protocol(),
          securityContext: securityContext,
          authenticationKeyManager: authenticationKeyManager,
          streamingConnectionTimeout: streamingConnectionTimeout,
          connectionTimeout: connectionTimeout,
          onFailedCall: onFailedCall,
          onSucceededCall: onSucceededCall,
          disconnectStreamsOnLostInternetConnection:
              disconnectStreamsOnLostInternetConnection,
        ) {
    acquiring = EndpointAcquiring(this);
    ad = EndpointAd(this);
    adManagement = EndpointAdManagement(this);
    admin = EndpointAdmin(this);
    adCategory = EndpointAdCategory(this);
    notification = EndpointNotification(this);
    onlineStatus = EndpointOnlineStatus(this);
    promocode = EndpointPromocode(this);
    userAuth = EndpointUserAuth(this);
    users = EndpointUsers(this);
    modules = _Modules(this);
  }

  late final EndpointAcquiring acquiring;

  late final EndpointAd ad;

  late final EndpointAdManagement adManagement;

  late final EndpointAdmin admin;

  late final EndpointAdCategory adCategory;

  late final EndpointNotification notification;

  late final EndpointOnlineStatus onlineStatus;

  late final EndpointPromocode promocode;

  late final EndpointUserAuth userAuth;

  late final EndpointUsers users;

  late final _Modules modules;

  @override
  Map<String, _i1.EndpointRef> get endpointRefLookup => {
        'acquiring': acquiring,
        'ad': ad,
        'adManagement': adManagement,
        'admin': admin,
        'adCategory': adCategory,
        'notification': notification,
        'onlineStatus': onlineStatus,
        'promocode': promocode,
        'userAuth': userAuth,
        'users': users,
      };

  @override
  Map<String, _i1.ModuleEndpointCaller> get moduleLookup => {
        'dartway_tinkoff_serverpod': modules.dartway_tinkoff_serverpod,
        'auth': modules.auth,
        'nitTools': modules.nitTools,
      };
}
