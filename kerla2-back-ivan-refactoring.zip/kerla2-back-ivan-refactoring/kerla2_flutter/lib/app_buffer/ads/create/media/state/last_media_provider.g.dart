// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'last_media_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$lastMediaHash() => r'fb4919717db4092cb4a889117f8bc6f33b86922e';

/// Copied from Dart SDK
class _SystemHash {
  _SystemHash._();

  static int combine(int hash, int value) {
    // ignore: parameter_assignments
    hash = 0x1fffffff & (hash + value);
    // ignore: parameter_assignments
    hash = 0x1fffffff & (hash + ((0x0007ffff & hash) << 10));
    return hash ^ (hash >> 6);
  }

  static int finish(int hash) {
    // ignore: parameter_assignments
    hash = 0x1fffffff & (hash + ((0x03ffffff & hash) << 3));
    // ignore: parameter_assignments
    hash = hash ^ (hash >> 11);
    return 0x1fffffff & (hash + ((0x00003fff & hash) << 15));
  }
}

/// See also [lastMedia].
@ProviderFor(lastMedia)
const lastMediaProvider = LastMediaFamily();

/// See also [lastMedia].
class LastMediaFamily extends Family<AsyncValue<List<AssetEntity>>> {
  /// See also [lastMedia].
  const LastMediaFamily();

  /// See also [lastMedia].
  LastMediaProvider call({
    required BuildContext context,
    int count = 20,
  }) {
    return LastMediaProvider(
      context: context,
      count: count,
    );
  }

  @override
  LastMediaProvider getProviderOverride(
    covariant LastMediaProvider provider,
  ) {
    return call(
      context: provider.context,
      count: provider.count,
    );
  }

  static const Iterable<ProviderOrFamily>? _dependencies = null;

  @override
  Iterable<ProviderOrFamily>? get dependencies => _dependencies;

  static const Iterable<ProviderOrFamily>? _allTransitiveDependencies = null;

  @override
  Iterable<ProviderOrFamily>? get allTransitiveDependencies =>
      _allTransitiveDependencies;

  @override
  String? get name => r'lastMediaProvider';
}

/// See also [lastMedia].
class LastMediaProvider extends FutureProvider<List<AssetEntity>> {
  /// See also [lastMedia].
  LastMediaProvider({
    required BuildContext context,
    int count = 20,
  }) : this._internal(
          (ref) => lastMedia(
            ref as LastMediaRef,
            context: context,
            count: count,
          ),
          from: lastMediaProvider,
          name: r'lastMediaProvider',
          debugGetCreateSourceHash:
              const bool.fromEnvironment('dart.vm.product')
                  ? null
                  : _$lastMediaHash,
          dependencies: LastMediaFamily._dependencies,
          allTransitiveDependencies: LastMediaFamily._allTransitiveDependencies,
          context: context,
          count: count,
        );

  LastMediaProvider._internal(
    super._createNotifier, {
    required super.name,
    required super.dependencies,
    required super.allTransitiveDependencies,
    required super.debugGetCreateSourceHash,
    required super.from,
    required this.context,
    required this.count,
  }) : super.internal();

  final BuildContext context;
  final int count;

  @override
  Override overrideWith(
    FutureOr<List<AssetEntity>> Function(LastMediaRef provider) create,
  ) {
    return ProviderOverride(
      origin: this,
      override: LastMediaProvider._internal(
        (ref) => create(ref as LastMediaRef),
        from: from,
        name: null,
        dependencies: null,
        allTransitiveDependencies: null,
        debugGetCreateSourceHash: null,
        context: context,
        count: count,
      ),
    );
  }

  @override
  FutureProviderElement<List<AssetEntity>> createElement() {
    return _LastMediaProviderElement(this);
  }

  @override
  bool operator ==(Object other) {
    return other is LastMediaProvider &&
        other.context == context &&
        other.count == count;
  }

  @override
  int get hashCode {
    var hash = _SystemHash.combine(0, runtimeType.hashCode);
    hash = _SystemHash.combine(hash, context.hashCode);
    hash = _SystemHash.combine(hash, count.hashCode);

    return _SystemHash.finish(hash);
  }
}

mixin LastMediaRef on FutureProviderRef<List<AssetEntity>> {
  /// The parameter `context` of this provider.
  BuildContext get context;

  /// The parameter `count` of this provider.
  int get count;
}

class _LastMediaProviderElement extends FutureProviderElement<List<AssetEntity>>
    with LastMediaRef {
  _LastMediaProviderElement(super.provider);

  @override
  BuildContext get context => (origin as LastMediaProvider).context;
  @override
  int get count => (origin as LastMediaProvider).count;
}
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
