part of '../ui_kit.dart';

class LinkTextSpan extends TextSpan {
  LinkTextSpan({
    required Uri url,
    required String super.text,
    super.style,
  }) : super(
          recognizer: TapGestureRecognizer()
            ..onTap = () {
              launchUrl(
                url,
                mode: LaunchMode.inAppWebView,
              );
            },
        );
}
