import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerla2_flutter/app_buffer/profile/user_online/last_time_online_info.dart';
import 'package:kerla2_flutter/common/is_my_profile.dart';
import 'package:kerla2_flutter/common/user_profile_ref_extensions.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

import '../../profile_image/profile_image.dart';

class ProfileAppBarTitle extends ConsumerWidget {
  final int userId;

  const ProfileAppBarTitle({
    super.key,
    required this.userId,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return ref.watchUserProfileCustom(userId).nitWhen(
      childBuilder: (userProfile) {
        return Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            ProfileImage(
              userId: userId,
              size: 40,
            ),
            const Gap(8),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  '@${userProfile.userName}',
                  style: context.textTheme.titleMedium,
                ),
                const Gap(5),
                if (!ref.isMyProfile(userId))
                  LastTimeOnlineInfo(
                    userId: userId,
                    style: context.textTheme.displayMedium?.copyWith(
                      color: context.theme.primaryColorDark,
                    ),
                  )
              ],
            ),
          ],
        );
      },
    );
  }
}
