import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/app/favorites/utils/widget_ref_extension.dart';
import 'package:kerla2_flutter/app_buffer/ads/representation/ad_card/ad.dart';
import 'package:kerla2_flutter/app_buffer/ads/representation/ad_card/ad_story.dart';
import 'package:nit_app/nit_app.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class FavoritesListView extends HookConsumerWidget {
  const FavoritesListView({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final selectedFilter = useState<AdType>(AdType.ad);

    return ref.watchFavorites.nitWhen(
      errorWidget: const Center(child: Text('Возникла какая-то ошибка')),
      childBuilder: (favourites) {
        if (favourites.isEmpty) {
          return Padding(
            padding: const EdgeInsets.symmetric(vertical: 170),
            child: Center(
              child: Text(
                'Нет избранных',
                style: context.textTheme.headlineMedium,
              ),
            ),
          );
        }

        final adAsyncValues = favourites
            .map((fav) => ref.watchOrFetchModelAsync<Ad>(fav.adId))
            .toList();

        if (adAsyncValues.any((asyncAd) => asyncAd.isLoading)) {
          return const Center(child: CircularProgressIndicator());
        }

        final allAds = adAsyncValues
            .map((asyncAd) => asyncAd.asData?.value)
            .whereType<Ad>()
            .toList();

        final filteredAds =
            allAds.where((ad) => ad.adType == selectedFilter.value).toList();

        return Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(8),
              child: SizedBox(
                width: double.infinity,
                child: SegmentedButton<AdType>(
                  segments: const <ButtonSegment<AdType>>[
                    ButtonSegment<AdType>(
                      value: AdType.ad,
                      label: Text('Объявления'),
                      icon: Icon(Icons.article_outlined),
                    ),
                    ButtonSegment<AdType>(
                      value: AdType.story,
                      label: Text('Истории'),
                      icon: Icon(Icons.photo_rounded),
                    ),
                  ],
                  selected: {selectedFilter.value},
                  onSelectionChanged: (Set<AdType> newSelection) {
                    selectedFilter.value = newSelection.first;
                  },
                ),
              ),
            ),
            if (filteredAds.isEmpty)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 120),
                child: Center(
                  child: Text(
                    selectedFilter.value == AdType.story
                        ? 'Нет избранных историй'
                        : 'Нет избранных объявлений',
                    style: context.textTheme.headlineMedium,
                  ),
                ),
              )
            else
              GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                padding: const EdgeInsets.all(8),
                itemCount: filteredAds.length,
                itemBuilder: (BuildContext context, int index) {
                  if (AdType.story == selectedFilter.value) {
                    return StoryWidget(
                      ad: filteredAds[index],
                    );
                  }
                  return AdWidget(
                    ad: filteredAds[index],
                  );
                },
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 8,
                  mainAxisSpacing: 8,
                  mainAxisExtent: 322,
                ),
              ),
          ],
        );
      },
    );
  }
}
