part of '../ui_kit.dart';

class TextEntryField extends StatefulWidget {
  const TextEntryField({
    required this.controller,
    required this.label,
    this.onChanged,
    this.onEditingComplete,
    this.enabled = true,
    this.sufixIcon,
    this.validator,
    this.autovalidate = false,
    this.onSaved,
    this.autofillHints,
    this.inputFormatters = const [],
    this.readOnly = false,
    super.key,
  })  : digitsOnly = false,
        autocorrect = true,
        isPassword = false,
        labelAsHint = false,
        keyboardType = TextInputType.text;

  TextEntryField.password({
    super.key,
    required this.label,
    required this.controller,
    this.onChanged,
    this.onEditingComplete,
    this.enabled = true,
    this.validator,
    this.autovalidate = false,
    this.onSaved,
    this.autofillHints,
    this.readOnly = false,
  })  : digitsOnly = false,
        autocorrect = false,
        isPassword = true,
        sufixIcon = null,
        labelAsHint = false,
        keyboardType = TextInputType.visiblePassword,
        inputFormatters = [];

  TextEntryField.email({
    super.key,
    required this.label,
    required this.controller,
    this.onChanged,
    this.onEditingComplete,
    this.enabled = true,
    this.sufixIcon,
    this.validator,
    this.autofillHints,
    this.autovalidate = false,
    this.onSaved,
    this.readOnly = false,
  })  : digitsOnly = false,
        autocorrect = false,
        isPassword = false,
        labelAsHint = false,
        keyboardType = TextInputType.emailAddress,
        inputFormatters = [];

  TextEntryField.digits({
    super.key,
    required this.label,
    required this.controller,
    this.onChanged,
    this.onEditingComplete,
    this.enabled = true,
    this.sufixIcon,
    this.validator,
    this.autofillHints,
    this.autovalidate = false,
    this.onSaved,
    this.readOnly = false,
  })  : digitsOnly = true,
        autocorrect = false,
        isPassword = false,
        keyboardType = TextInputType.number,
        labelAsHint = false,
        inputFormatters = [FilteringTextInputFormatter.digitsOnly];

  TextEntryField.expanded({
    super.key,
    required this.label,
    required this.controller,
    this.onChanged,
    this.onEditingComplete,
    this.enabled = true,
    this.validator,
    this.sufixIcon,
    this.onSaved,
    this.autofillHints,
    this.labelAsHint = false,
    this.autovalidate = false,
    this.readOnly = false,
  })  : digitsOnly = false,
        autocorrect = true,
        isPassword = false,
        keyboardType = TextInputType.multiline,
        inputFormatters = [];

  TextEntryField.phone({
    super.key,
    required this.label,
    required this.controller,
    this.onChanged,
    this.onEditingComplete,
    this.enabled = true,
    this.validator,
    this.sufixIcon,
    this.onSaved,
    this.autofillHints,
    this.autovalidate = false,
    this.readOnly = false,
  })  : digitsOnly = true,
        autocorrect = false,
        isPassword = false,
        keyboardType = TextInputType.phone,
        labelAsHint = false,
        inputFormatters = [
          FilteringTextInputFormatter.digitsOnly,
          PhoneInputFormatter(),
        ];

  final TextEditingController controller;
  final void Function(String?)? onChanged;
  final String label;
  final bool digitsOnly;
  final bool enabled;
  final bool autocorrect;
  final String? Function(String?)? validator;
  final void Function(String?)? onSaved;
  final void Function(String)? onEditingComplete;
  final TextInputType? keyboardType;
  final List<TextInputFormatter> inputFormatters;
  final bool labelAsHint;
  final Widget? sufixIcon;
  final bool autovalidate;
  final bool isPassword;
  final List<String>? autofillHints;
  final bool readOnly;

  @override
  State<TextEntryField> createState() => _TextEntryFieldState();
}

class _TextEntryFieldState extends State<TextEntryField> {
  late bool obscureText = widget.isPassword;
  @override
  Widget build(BuildContext context) {
    final focusNode = FocusNode();
    focusNode.addListener(() {
      if (!focusNode.hasFocus) {
        if (widget.onEditingComplete != null) {
          widget.onEditingComplete!(widget.controller.text);
        }
      }
    });
    return TextFormField(
      autofillHints: widget.autofillHints,
      focusNode: focusNode,
      onTapOutside: (event) {
        focusNode.unfocus();
      },
      enabled: widget.enabled,
      readOnly: widget.readOnly,
      autovalidateMode:
          widget.autovalidate ? AutovalidateMode.onUserInteraction : null,
      validator: widget.validator,
      onSaved: widget.onSaved,
      controller: widget.controller,
      onChanged: widget.onChanged,
      autocorrect: widget.autocorrect,
      obscureText: widget.isPassword ? obscureText : false,
      style: context.textTheme.titleMedium,
      keyboardType: widget.keyboardType,
      maxLength: widget.keyboardType == TextInputType.multiline ? 500 : null,
      maxLines: widget.keyboardType == TextInputType.multiline ? null : 1,
      minLines: widget.keyboardType == TextInputType.multiline ? 2 : 1,
      inputFormatters: widget.inputFormatters,
      decoration: InputDecoration(
        errorMaxLines: 1,
        suffixIcon: widget.isPassword
            ? InkWell(
                onTap: () => setState(() {
                      obscureText = !obscureText;
                    }),
                child: Icon(obscureText
                    ? Icons.remove_red_eye
                    : Icons.remove_red_eye_outlined))
            : widget.sufixIcon,
        label: Text(
          widget.label,
          style: context.textTheme.titleSmall,
          maxLines: widget.keyboardType == TextInputType.multiline ? 2 : 1,
        ),
        floatingLabelBehavior: widget.labelAsHint
            ? FloatingLabelBehavior.never
            : FloatingLabelBehavior.auto,
        // labelText: label,
        // labelStyle: context.textTheme.bodyLarge,
        helperText: widget.keyboardType == TextInputType.multiline
            ? 'Не более 500 символов'
            : null,
        alignLabelWithHint: true,
        counterText:
            (widget.keyboardType == TextInputType.multiline) ? '' : null,
        enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(4),
            borderSide: BorderSide(
                color: context.colorScheme.outlineVariant, width: 1.0)),
        contentPadding: EdgeInsets.fromLTRB(
          16,
          15,
          16,
          widget.keyboardType == TextInputType.multiline ? 21 : 15,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(4),
          borderSide: BorderSide(
            width: 1.0,
            color: context.colorScheme.outlineVariant,
          ),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(4),
          borderSide: BorderSide(
            color: context.colorScheme.outlineVariant,
            width: 1.0,
          ),
        ),
      ),
    );
  }
}
