import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_svg/svg.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/app/favorites/utils/widget_ref_extension.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_app/nit_app.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class FavoriteButton extends ConsumerWidget {
  const FavoriteButton.basic({
    super.key,
    required this.adId,
  })  : wrapInCommonButton = false,
        wrapInFloatingActionButton = false,
        size = 25,
        secondChildColor = null,
        shape = null,
        backgroundColor = null;

  const FavoriteButton.wrappedInCommonButton({
    super.key,
    required this.adId,
  })  : wrapInCommonButton = true,
        wrapInFloatingActionButton = false,
        size = 20,
        secondChildColor = null,
        shape = null,
        backgroundColor = null;

  const FavoriteButton.wrappedInFloatingActionButton({
    super.key,
    required this.adId,
  })  : wrapInCommonButton = false,
        wrapInFloatingActionButton = true,
        size = 25,
        secondChildColor = null,
        shape = null,
        backgroundColor = null;

  FavoriteButton.stories({
    super.key,
    required this.adId,
  })  : secondChildColor = ThemePrimaryColors.white,
        size = 25,
        shape = RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
        wrapInFloatingActionButton = true,
        wrapInCommonButton = false,
        backgroundColor = ThemePrimaryColors.floatingActionButtonColor;

  final int adId;

  final double? size;
  final bool wrapInCommonButton;
  final bool wrapInFloatingActionButton;

  final Color? secondChildColor;
  final ShapeBorder? shape;
  final Color? backgroundColor;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final iconHeight = size ?? 24;
    return ref.watchFavorites.nitWhen(
      childBuilder: (favorites) {
        final isFavorite = favorites.any((e) => e.adId == adId);

        final child = IconButton(
          alignment: Alignment.center,
          padding: null, // withPadding ? null : EdgeInsets.zero,
          onPressed: ref.nitUiCallback(
            () => isFavorite
                ? ref.deleteModel(favorites.firstWhere((e) => e.adId == adId))
                : ref.saveModel(
                    FavouriteAd(
                      userId: ref.signedInUserId!,
                      adId: adId,
                    ),
                  ),
            onValueSuccessNotification: isFavorite ? 'Удалено' : 'Добавлено',
            onErrorNotification: isFavorite
                ? 'Ошибка при удалении из избранного'
                : 'Ошибка при добавлении в избранное',
          ),
          icon: AnimatedCrossFade(
            firstChild: SvgPicture.asset(
              AppIconsSvg.activeFavorite,
              height: iconHeight,
              width: iconHeight,
            ),
            secondChild: SvgPicture.asset(
              AppIconsSvg.favorite,
              height: iconHeight,
              width: iconHeight,
              colorFilter: ColorFilter.mode(
                secondChildColor ??
                    context.theme.iconTheme.color ??
                    Colors.black,
                BlendMode.srcIn,
              ),
            ),
            crossFadeState: isFavorite
                ? CrossFadeState.showFirst
                : CrossFadeState.showSecond,
            duration: const Duration(milliseconds: 100),
          ),
        );

        return ConditionalParentWidget(
          condition: wrapInCommonButton,
          parentBuilder: (_) => child,
          child: ConditionalParentWidget(
            condition: wrapInFloatingActionButton,
            parentBuilder: (_) => FloatingActionButton(
              heroTag: '3',
              backgroundColor:
                  backgroundColor ?? Theme.of(context).scaffoldBackgroundColor,
              mini: true,
              shape: shape,
              onPressed: () {},
              child: child,
            ),
            child: child,
          ),
        );
      },
    );
  }
}
