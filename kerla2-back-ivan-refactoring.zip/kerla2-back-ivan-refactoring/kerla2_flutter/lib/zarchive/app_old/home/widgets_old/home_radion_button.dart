// import 'package:flutter/material.dart';
// import 'package:flutter_svg/svg.dart';
// import 'package:kerla2_flutter/ui_kit/ui_kit.dart';

// class RadioButton extends StatelessWidget {
//   const RadioButton({
//     super.key,
//     required this.text,
//     required this.isSelected,
//     required this.onTap,
//   });

//   final String text;
//   final bool isSelected;
//   final VoidCallback onTap;

//   @override
//   Widget build(BuildContext context) {
//     return GestureDetector(
//       onTap: onTap,
//       child: AnimatedContainer(
//         duration: const Duration(milliseconds: 200),
//         decoration: BoxDecoration(
//           color: isSelected ? ThemePrimaryColors.primary : Colors.white,
//           borderRadius: BorderRadius.circular(8),
//         ),
//         padding: const EdgeInsets.symmetric(horizontal: 10),
//         child: Row(
//           mainAxisSize: MainAxisSize.min,
//           children: [
//             AnimatedCrossFade(
//               duration: const Duration(milliseconds: 100),
//               firstCurve: Curves.linearToEaseOut,
//               firstChild: Padding(
//                 padding: const EdgeInsets.only(right: 8),
//                 child: SvgPicture.asset(
//                   AppIconsSvg.closeRadioButton,
//                   height: 20,
//                   width: 20,
//                 ),
//               ),
//               secondChild: const SizedBox.shrink(),
//               crossFadeState: isSelected
//                   ? CrossFadeState.showFirst
//                   : CrossFadeState.showSecond,
//             ),
//             Text(
//               text,
//               style: TextStyle(
//                 fontSize: 16,
//                 fontWeight: FontWeight.bold,
//                 color: isSelected ? Colors.white : Colors.black,
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }
