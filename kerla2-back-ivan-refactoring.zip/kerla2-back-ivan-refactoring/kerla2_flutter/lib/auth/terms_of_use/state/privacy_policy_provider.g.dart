// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'privacy_policy_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$privacyPolicyHash() => r'e0a4280b4e84286c5bf0f59d68d4ab8430232c90';

/// See also [privacyPolicy].
@ProviderFor(privacyPolicy)
final privacyPolicyProvider = AutoDisposeFutureProvider<String>.internal(
  privacyPolicy,
  name: r'privacyPolicyProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$privacyPolicyHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef PrivacyPolicyRef = AutoDisposeFutureProviderRef<String>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
