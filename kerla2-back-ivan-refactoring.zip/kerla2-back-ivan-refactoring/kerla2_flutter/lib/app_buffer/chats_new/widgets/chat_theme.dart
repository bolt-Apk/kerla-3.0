import 'package:flutter/material.dart';
import 'package:nit_app/nit_app.dart';

ChatThemeData whatsAppChatTheme(BuildContext context) {
  final theme = Theme.of(context);
  final isDark = theme.brightness == Brightness.dark;

  // Цвета, приближённые к WhatsApp
  final Color outgoingBubbleColor = isDark
      ? const Color(0xFF056162) // WhatsApp dark outgoing
      : const Color(0xFFDCF8C6); // WhatsApp light outgoing

  final Color incomingBubbleColor = isDark
      ? const Color(0xFF262D31) // WhatsApp dark incoming
      : Colors.white; // WhatsApp light incoming

  final Color outgoingTextColor = isDark ? Colors.white : Colors.black87;
  final Color incomingTextColor = isDark ? Colors.white : Colors.black87;

  return ChatThemeData(
    settings:
        const Settings(enableMessageOverlay: true, enableVoiceMessages: true),
    mainTheme: MainTheme(
      backgroundColor: theme.scaffoldBackgroundColor,
      primaryColor: theme.colorScheme.primary,
      secondaryColor: theme.colorScheme.secondary,
      errorColor: theme.colorScheme.error,
      dividerColor: theme.dividerColor,
      timeTextStyle: TextStyle(
        color: isDark ? Colors.white60 : Colors.grey,
        fontSize: 11,
      ),
      timeTextColor: isDark ? Colors.white60 : Colors.grey,

      sentStatusColor: isDark ? Colors.white54 : Colors.grey,
      deliveredStatusColor: isDark ? Colors.white70 : Colors.grey,
      readStatusColor: const Color(0xFF34B7F1), // WhatsApp blue

      typingIndicatorColor: isDark ? Colors.white70 : Colors.grey,
      typingIndicatorSize: 12.0,
    ),
    incomingBubble: ChatBubbleThemeData(
      backgroundColor: incomingBubbleColor,
      textColor: incomingTextColor,
      borderRadius: 16,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      margin: const EdgeInsets.symmetric(vertical: 2, horizontal: 8),
      boxShadow: [
        BoxShadow(
          color: isDark ? Colors.black54 : Colors.black12,
          blurRadius: 2,
          offset: const Offset(0, 1),
        ),
      ],
      textStyle: TextStyle(
        color: incomingTextColor,
        fontSize: 16,
        height: 1.3,
      ),
    ),
    outgoingBubble: ChatBubbleThemeData(
      backgroundColor: outgoingBubbleColor,
      textColor: outgoingTextColor,
      borderRadius: 16,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      margin: const EdgeInsets.symmetric(vertical: 2, horizontal: 8),
      boxShadow: [
        BoxShadow(
          color: isDark ? Colors.black54 : Colors.black12,
          blurRadius: 2,
          offset: const Offset(0, 1),
        ),
      ],
      textStyle: TextStyle(
        color: outgoingTextColor,
        fontSize: 16,
        height: 1.3,
      ),
    ),
    inputTheme: ChatInputThemeData(
      backgroundColor: isDark ? const Color(0xFF1F2C34) : Colors.white,
      textColor: isDark ? Colors.white : Colors.black87,
      hintColor: isDark ? Colors.white70 : Colors.grey,
      cursorColor: theme.colorScheme.primary,
      borderRadius: 24.0,
      border: InputBorder.none,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      textStyle: TextStyle(
        color: isDark ? Colors.white : Colors.black87,
        fontSize: 16,
      ),
      hintStyle: TextStyle(
        color: isDark ? Colors.white54 : Colors.grey,
        fontSize: 16,
      ),
    ),
  );
}
