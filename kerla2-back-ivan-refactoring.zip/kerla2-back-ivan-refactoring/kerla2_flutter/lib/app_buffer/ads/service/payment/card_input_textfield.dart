// import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
// import 'package:flutter_riverpod/flutter_riverpod.dart';
// import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
// import 'package:nit_ui_kit/nit_ui_kit.dart';

// import 'payment/payment_state.dart';

// class CardInputTextField extends ConsumerWidget {
//   const CardInputTextField({
//     super.key,
//     required this.controller,
//     required this.hint,
//     this.additionalFormatters,
//     this.obscureText = false,
//   });

//   final TextEditingController controller;
//   final String hint;
//   final bool obscureText;
//   final List<TextInputFormatter>? additionalFormatters;

//   @override
//   Widget build(BuildContext context, WidgetRef ref) {
//     return Padding(
//       padding: const EdgeInsets.only(left: 16, right: 16, bottom: 16),
//       child: TextField(
//         style: context.textTheme.titleMedium,
//         controller: controller,
//         keyboardType: TextInputType.number,
//         textInputAction: TextInputAction.next,
//         cursorColor: ThemePrimaryColors.primary,
//         inputFormatters: [
//           FilteringTextInputFormatter.digitsOnly,
//           ...?additionalFormatters,
//         ],
//         obscureText: obscureText ? true : false,
//         // onChanged: (_) =>
//         //     ref.read(paymentStateProvider.notifier).canContinueNotifier(),
//         decoration: InputDecoration(
//           filled: true,
//           fillColor: context.theme.scaffoldBackgroundColor,
//           enabledBorder: OutlineInputBorder(
//             borderRadius: BorderRadius.circular(16),
//             borderSide: const BorderSide(color: Colors.transparent),
//           ),
//           focusedBorder: OutlineInputBorder(
//             borderRadius: BorderRadius.circular(16),
//             borderSide: const BorderSide(color: ThemePrimaryColors.primary),
//           ),
//           hintText: hint,
//           hintStyle: TextStyle(
//             color: context.theme.primaryColorDark,
//             fontSize: 16,
//           ),
//         ),
//       ),
//     );
//   }
// }
