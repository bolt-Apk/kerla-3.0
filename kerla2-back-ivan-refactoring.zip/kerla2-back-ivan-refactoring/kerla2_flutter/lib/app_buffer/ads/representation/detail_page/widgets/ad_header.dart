import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_svg/svg.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/app/favorites/favorite_button.dart';
import 'package:kerla2_flutter/app_buffer/ads/utils/ad_price_extencion.dart';
import 'package:kerla2_flutter/app_buffer/ads/utils/ad_share.dart';
import 'package:kerla2_flutter/app_buffer/chats_new/widgets/chat_button.dart';
import 'package:kerla2_flutter/common/user_profile_ref_extensions.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:kerla2_shared/kerla2_shared.dart';
import 'package:nit_app/nit_app.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class AdHeader extends ConsumerWidget {
  const AdHeader({
    super.key,
    required this.ad,
  });

  final Ad ad;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isMyAd = ref.currentUserProfile?.id == ad.userId;
    return DecoratedBox(
      decoration: BoxDecoration(
        color: context.theme.canvasColor,
      ),
      child: Padding(
        padding: const EdgeInsets.only(left: 10, right: 10, top: 10),
        child: Column(
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Text(
                    ad.title.trim().replaceAll('\n', ''),
                    style: context.textTheme.headlineMedium,
                  ),
                ),
                if (ref.signedIn)
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      if (!isMyAd)
                        ChatButton(
                          chatChannelType: ChatChannelType.ad,
                          userId: ad.userId!,
                          adId: ad.id,
                        )
                      else
                        IconButton(
                          icon: GestureDetector(
                            child: SvgPicture.asset(
                              AppIconsSvg.share,
                              colorFilter: ColorFilter.mode(
                                Theme.of(context).iconTheme.color!,
                                BlendMode.srcIn,
                              ),
                              height: 24,
                              width: 24,
                            ),
                          ),
                          onPressed: () {
                            AdShareState(context, ad.id!)
                                .showGeneralShareBottomSheet();
                          },
                        ),
                      if (!isMyAd)
                        FavoriteButton.basic(
                          adId: ad.id!,
                        ),
                    ],
                  ),
              ],
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: Text(
                    ad.region?.title ?? '',
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w300,
                    ),
                    softWrap: false,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    ad.formattedPrice,
                    textAlign: TextAlign.end,
                    style: context.textTheme.titleLarge?.copyWith(
                      fontSize: 20,
                    ),
                    maxLines: 1,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
          ],
        ),
      ),
    );
  }
}
