import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/common/ad_utils.dart';
import 'package:kerla2_flutter/router/router.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';

import 'ad_details.dart';

class AdWidget extends ConsumerWidget {
  const AdWidget({
    super.key,
    required this.ad,
  });

  final Ad ad;
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final bool allowedAd = ref.isAdAllowed(ad);

    return CommonButton(
      backgroundColor: Colors.white,
      borderRadius: BorderRadius.circular(6),
      action: () {
        if (allowedAd) {
          context.pushNamed(
            AdNavigationZone.adPage.name,
            pathParameters: AppNavigationParams.adId.set(ad.id!),
          );
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              showCloseIcon: true,
              content: Text(
                "Зарегестрируйтесь или войдите в аккаунт, чтобы просматривать объявления",
              ),
            ),
          );
        }
      },
      child: DecoratedBox(
        decoration: BoxDecoration(
          color: Theme.of(context).canvasColor,
          borderRadius: const BorderRadius.all(Radius.circular(6)),
        ),
        child: Column(
          children: [
            AdImageCarousel(
              needBlur: !allowedAd,
              borderRadius: const BorderRadiusDirectional.only(
                topStart: Radius.circular(6),
                topEnd: Radius.circular(6),
              ),
              imageHeight: 197,
              isLimitDots: true,
              urls: ad.media!,
            ),
            Flexible(
              child: AdDetails(
                ad: ad,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
