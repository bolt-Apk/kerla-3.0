import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/app_buffer/ads/create/create_story/image_editor_localization.dart';
import 'package:kerla2_flutter/common/user_profile_ref_extensions.dart';
import 'package:kerla2_flutter/core/app_scaffold.dart';
import 'package:kerla2_flutter/router/router.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_riverpod_notifications/nit_riverpod_notifications.dart';
import 'package:nit_router/nit_router.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';
import 'package:pro_image_editor/models/editor_callbacks/pro_image_editor_callbacks.dart';
import 'package:pro_image_editor/models/editor_configs/pro_image_editor_configs.dart';
import 'package:pro_image_editor/modules/main_editor/main_editor.dart';
import 'package:wechat_assets_picker/wechat_assets_picker.dart';

import '../create_ad/attributes/widgets/story_price_input.dart';
import '../state/ad_create_state.dart';
import '../media/state/selected_media_state.dart';

class CreateStoryPage extends HookConsumerWidget {
  const CreateStoryPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final selectedAsset = ref.watch(adMediaStateProvider()).items.firstOrNull;
    final adState = ref.watch(createAdStateProvider(AdType.story));

    final priceController = useTextEditingController();
    final descriptionController =
        useTextEditingController(text: adState.description);
    final isDescriptionEmpty = useState(adState.description.isEmpty);
    final isLoading = useState(false);

    useEffect(() {
      if (selectedAsset == null) {
        ref
            .read(adMediaStateProvider().notifier)
            .openMediaPicker(context, AdType.story)
            .then((success) {
          if (!success) {
            context.pop();
          }
        });
      }
      return null;
    }, [selectedAsset]);

    void onEditPhoto() async {
      isLoading.value = true;
      final callbacks = ProImageEditorCallbacks(
        onImageEditingComplete: (Uint8List bytes) async {
          ref.watch(adMediaStateProvider().notifier).setBytes(bytes);
          context.pop();
        },
      );

      final file = await selectedAsset?.asAsset().originFile;
      if (file == null) {
        isLoading.value = false;
        return;
      }

      if (!context.mounted) {
        isLoading.value = false;
        return;
      }

      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => selectedAsset?.asBytes() != null
              ? ProImageEditor.memory(
                  selectedAsset!.asBytes()!,
                  callbacks: callbacks,
                  configs:
                      ProImageEditorConfigs(i18n: ImageEditorLocalization.i18n),
                )
              : ProImageEditor.file(
                  file,
                  callbacks: callbacks,
                  configs:
                      ProImageEditorConfigs(i18n: ImageEditorLocalization.i18n),
                ),
        ),
      );
      isLoading.value = false;
    }

    Future<void> onNext() async {
      if (isDescriptionEmpty.value ||
          adState.category == null ||
          priceController.text.isEmpty) {
        ref.notifyUser('Необходимо заполнить все поля');
        return;
      }

      ref
          .read(createAdStateProvider(AdType.story).notifier)
          .setDescription(descriptionController.text);
      isLoading.value = true;

      await ref.read(adMediaStateProvider().notifier).startUploadMedia();

      final adId = await ref
          .read(createAdStateProvider(AdType.story).notifier)
          .publishAd();
      isLoading.value = false;

      if (adId != null) {
        context.goNamed(
          AdNavigationZone.confirmStory.name,
          pathParameters: AppNavigationParams.adId.set(adId),
        );
      } else {
        ref.notifyUser('Ошибка загрузки медиа');
      }
    }

    return AppScaffold(
      backgroundColor: Colors.black,
      showBottomNavBar: false,
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text(
          'Создание истории',
          style: context.textTheme.headlineLarge!.copyWith(color: Colors.white),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => context.pop(),
        ),
      ),
      body: selectedAsset == null
          ? const SizedBox()
          : Stack(
              children: [
                Positioned.fill(
                  child: selectedAsset.isBytes
                      ? Image.memory(
                          selectedAsset.asBytes()!,
                          fit: BoxFit.fitWidth,
                        )
                      : selectedAsset.isAsset
                          ? Image(
                              image: AssetEntityImageProvider(
                                  selectedAsset.asAsset()),
                              fit: BoxFit.fitWidth)
                          : CachedNetworkImage(
                              imageUrl: selectedAsset.asMedia().publicUrl),
                ),
                Positioned.fill(
                  child: Container(
                    alignment: Alignment.center,
                    color: Colors.black45,
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        if (!(ref.currentUserProfile?.isAdmin ?? false))
                          StoryPriceInput(priceController: priceController),
                        const Gap(16),
                        TextField(
                          textCapitalization: TextCapitalization.sentences,
                          controller: descriptionController,
                          style: context.textTheme.bodyLarge
                              ?.copyWith(color: context.theme.iconTheme.color),
                          onChanged: (value) =>
                              isDescriptionEmpty.value = value.isEmpty,
                          decoration: InputDecoration(
                            filled: true,
                            fillColor: context.theme.cardColor,
                            hintText: 'Описание',
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(16),
                              borderSide: BorderSide.none,
                            ),
                          ),
                        ),
                        const Gap(16),
                        InkWell(
                          onTap: () => context.pushNamed(
                              AdNavigationZone.chooseCategoryCreateStory.name),
                          child: Container(
                            height: 60,
                            padding: const EdgeInsets.all(12),
                            alignment: Alignment.centerLeft,
                            width: double.infinity,
                            decoration: BoxDecoration(
                              color: context.theme.cardColor,
                              borderRadius: BorderRadius.circular(16),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(adState.category?.title ?? 'Тематика',
                                    style:
                                        Theme.of(context).textTheme.bodyMedium),
                                const RotatedBox(
                                  quarterTurns: 2,
                                  child:
                                      Icon(Icons.arrow_back_ios_new, size: 20),
                                ),
                              ],
                            ),
                          ),
                        ),
                        const Gap(16),
                        if (selectedAsset.isAsset &&
                            selectedAsset.asAsset().type == AssetType.image)
                          TextButton(
                            onPressed: isLoading.value ? null : onEditPhoto,
                            child: const Text('Изменить фото',
                                style: TextStyle(color: Colors.white)),
                          ),
                        const Gap(16),
                        GestureDetector(
                          onTap: isLoading.value ? null : onNext,
                          child: Container(
                            height: 60,
                            padding: const EdgeInsets.all(12),
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                              color: ThemePrimaryColors.primary,
                              borderRadius: BorderRadius.circular(16),
                            ),
                            child: isLoading.value
                                ? const CircularProgressIndicator.adaptive()
                                : Text(
                                    'Далее',
                                    style: Theme.of(context)
                                        .textTheme
                                        .headlineLarge
                                        ?.copyWith(color: Colors.white),
                                  ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
    );
  }
}
