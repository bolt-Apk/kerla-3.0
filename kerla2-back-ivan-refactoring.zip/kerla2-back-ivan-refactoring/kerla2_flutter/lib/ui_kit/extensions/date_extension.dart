part of '../ui_kit.dart';

extension DateExtension on DateTime {
  String get formatDate {
    final currentDate = DateTime.now();
    final localDateTime = toLocal(); // Конвертируем в локальное время

    final yesterday = currentDate.subtract(const Duration(days: 1));

    if (localDateTime.year == currentDate.year &&
        localDateTime.month == currentDate.month &&
        localDateTime.day == currentDate.day) {
      return 'сегодня, ${intl.DateFormat.Hm('ru').format(localDateTime)}';
    } else if (localDateTime.year == yesterday.year &&
        localDateTime.month == yesterday.month &&
        localDateTime.day == yesterday.day) {
      return 'вчера, ${intl.DateFormat.Hm('ru').format(localDateTime)}';
    } else {
      return intl.DateFormat('d MMMM, H:mm', 'ru').format(localDateTime);
    }
  }

  String get formatLastTimeOnlineDate {
    final currentDate = DateTime.now();
    final localDateTime = toLocal(); // Конвертируем в локальное время

    final yesterday = currentDate.subtract(const Duration(days: 1));

    if (localDateTime.year == currentDate.year &&
        localDateTime.month == currentDate.month &&
        localDateTime.day == currentDate.day) {
      return 'сегодня в ${intl.DateFormat.Hm('ru').format(localDateTime)}';
    } else if (localDateTime.year == yesterday.year &&
        localDateTime.month == yesterday.month &&
        localDateTime.day == yesterday.day) {
      return 'вчера в ${intl.DateFormat.Hm('ru').format(localDateTime)}';
    } else {
      return intl.DateFormat('d MMMM, H:mm', 'ru').format(localDateTime);
    }
  }

  String? getRemainingTimeDescription({String title = 'Осталось: '}) {
    final DateTime now = DateTime.now().toLocal();
    final Duration difference = this.difference(now);

    if (difference.isNegative) {
      return null;
    }

    final int days = difference.inDays;
    final int hours = difference.inHours % 24;
    final int minutes = difference.inMinutes % 60;

    if (days > 0) {
      return '$title$days ${_pluralize(days, 'день', 'дня', 'дней')} $hours ${_pluralize(hours, 'час', 'часа', 'часов')}';
    } else if (hours > 0) {
      return '$title$hours ${_pluralize(hours, 'час', 'часа', 'часов')} и $minutes ${_pluralize(minutes, 'минута', 'минуты', 'минут')}';
    } else {
      return '$title$minutes ${_pluralize(minutes, 'минута', 'минуты', 'минут')}';
    }
  }

  String _pluralize(int count, String one, String two, String many) {
    if (count % 100 >= 11 && count % 100 <= 19) {
      return many;
    } else {
      switch (count % 10) {
        case 1:
          return one;
        case 2:
        case 3:
        case 4:
          return two;
        default:
          return many;
      }
    }
  }
}
