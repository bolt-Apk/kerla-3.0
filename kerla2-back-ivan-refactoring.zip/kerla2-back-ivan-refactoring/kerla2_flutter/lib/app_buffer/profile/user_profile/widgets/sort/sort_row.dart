import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/app_buffer/profile/user_profile/widgets/sort/state/ad_sort_state.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class SortRow extends ConsumerWidget {
  final AdOrderBy type;
  final ValueNotifier<AdOrderBy> checkedValue;

  const SortRow({
    super.key,
    required this.type,
    required this.checkedValue,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final checked = checkedValue.value;

    return CommonButton(
      action: () => checkedValue.value = type,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 18),
        child: Row(
          children: [
            CustomCheckBox(value: checked == type),
            const SizedBox(width: 7),
            Text(
              type.localizedName,
              style: context.textTheme.titleMedium,
            ),
          ],
        ),
      ),
    );
  }
}
