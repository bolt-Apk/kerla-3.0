import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class CreateAdTextField extends HookConsumerWidget {
  const CreateAdTextField({
    super.key,
    required this.symbolCount,
    required this.hintText,
    required this.title,
    required this.controller,
    required this.minLines,
    required this.maxLines,
  });

  final int symbolCount;
  final String hintText;
  final String title;
  final TextEditingController controller;
  final int minLines;
  final int maxLines;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    useListenable(controller);
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 16),
          child: Align(
            alignment: Alignment.topLeft,
            child: RichText(
              text: TextSpan(
                children: <TextSpan>[
                  TextSpan(
                      text: title,
                      style: Theme.of(context).textTheme.headlineMedium),
                  const TextSpan(
                    text: " *",
                    style: TextStyle(color: Colors.red),
                  ),
                ],
              ),
            ),
          ),
        ),
        TextField(
          textCapitalization: TextCapitalization.sentences,
          controller: controller,
          style: context.textTheme.titleMedium,
          decoration: InputDecoration(
            filled: true,
            fillColor: context.theme.canvasColor,
            hintText: hintText,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: BorderSide.none,
            ),
          ),
          minLines: minLines,
          maxLines: maxLines,
          inputFormatters: [
            LengthLimitingTextInputFormatter(symbolCount),
            NoEmojiFormatter(),
          ],
          // onChanged: (value) {
          //   controller.text = value.trim(); // don't allow to use space bars at all
          // },
        ),
        Padding(
          padding: const EdgeInsets.all(10),
          child: Align(
            alignment: Alignment.topLeft,
            child: Text(
              'Символов ${controller.text.length} из $symbolCount',
              style: Theme.of(context).textTheme.labelMedium,
            ),
          ),
        ),
      ],
    );
  }
}
