import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kerla2_flutter/app/profile/settings/widgets/edit_phone_widget.dart';
import 'package:kerla2_flutter/auth/state/auth_page_state.dart';
import 'package:kerla2_flutter/router/navigation_zones/auth_navigation_zone.dart';

class AuthBottomSheet extends HookConsumerWidget {
  const AuthBottomSheet({
    super.key,
    this.initPart,
  });
  final AuthAreaNavigationZone? initPart;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // sets init part to state
    useEffect(() {
      if (initPart != null) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          ref.read(authPageStateProvider.notifier).setPage(initPart!);
        });
      }
      return null;
    }, const []);

    final viewInsets = MediaQuery.of(context).viewInsets;
    final padding = EdgeInsets.only(
      bottom: viewInsets.bottom + 16,
      left: 16,
      right: 16,
    );

    final currentPart =
        ref.watch(authPageStateProvider.select((model) => model.currentPart));

    return SingleChildScrollView(
      child: AnimatedSwitcher(
        duration: const Duration(milliseconds: 400), // Увеличили для плавности
        switchInCurve: Curves.easeInOut, // Более мягкая кривая
        switchOutCurve: Curves.easeOut,
        transitionBuilder: (child, animation) {
          return FadeTransition(
            opacity: animation,
            child: SizeTransition(
              sizeFactor: animation,
              child: child,
            ),
          );
        },
        child: Padding(
          padding: padding,
          key: ValueKey<AuthAreaNavigationZone>(
              currentPart), // Уникальный ключ для плавного переключения
          child: currentPart.descriptor.page,
        ),
      ),
    );
  }
}

extension AuthBottomSheetExtension on BuildContext {
  Future<void> showAuthBottomSheet({AuthAreaNavigationZone? initPart}) async {
    final showPhoneEditBottomSheet = await showModalBottomSheet(
      context: this,
      isScrollControlled: true,
      useSafeArea: true,
      sheetAnimationStyle: AnimationStyle(
          curve: Curves.easeInOut, duration: const Duration(milliseconds: 300)),
      builder: (context) {
        return AuthBottomSheet(
          initPart: initPart,
        );
      },
    );
    if (showPhoneEditBottomSheet == true) {
      await showModalBottomSheet(
        context: this,
        isScrollControlled: true,
        useSafeArea: true,
        sheetAnimationStyle: AnimationStyle(
            curve: Curves.easeInOut,
            duration: const Duration(milliseconds: 300)),
        builder: (context) {
          return const PhoneEditBottomSheet();
        },
      );
    }
  }

  void hideAuthModalBottomSheet() {
    if (Navigator.of(this).canPop()) {
      Navigator.of(this, rootNavigator: true).pop();
    }
  }
}
