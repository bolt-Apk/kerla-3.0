import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

class PayDialog extends StatelessWidget {
  final String paymentUrl;

  const PayDialog({required this.paymentUrl, super.key});

  @override
  Widget build(BuildContext context) {
    return WebViewWidget(
      controller: WebViewController()
        ..setJavaScriptMode(JavaScriptMode.unrestricted)
        // ..setNavigationDelegate(
        //   NavigationDelegate(
        //     onProgress: (int progress) {
        //       // Update loading bar.
        //     },
        //     onPageStarted: (String url) {},
        //     onPageFinished: (String url) {},
        //     onHttpError: (HttpResponseError error) {},
        //     onWebResourceError: (WebResourceError error) {},
        //     onNavigationRequest: (NavigationRequest request) {
        //       if (request.url.startsWith('https://www.youtube.com/')) {
        //         return NavigationDecision.prevent;
        //       }
        //       return NavigationDecision.navigate;
        //     },
        //   ),
        // )
        ..loadRequest(Uri.parse(paymentUrl)),
    );
  }
}

// import 'dart:html';
// import 'dart:ui' as ui;

// import 'package:flutter/material.dart';

// class PayDialog extends StatefulWidget {
//   const PayDialog({
//     super.key,
//     required this.paymentUrl,
//   });

//   final String paymentUrl;

//   @override
//   State<PayDialog> createState() => _PayDialogState();
// }

// class _PayDialogState extends State<PayDialog> {
//   final IFrameElement _iFrameElement = IFrameElement();

//   @override
//   void initState() {
//     _iFrameElement.style.height = '100%';
//     _iFrameElement.style.width = '100%';
//     _iFrameElement.src = widget.paymentUrl;
//     _iFrameElement.style.border = 'none';
//     _iFrameElement.style.scrollBehavior = 'auto';

// // ignore: undefined_prefixed_name
//     ui.platformViewRegistry.registerViewFactory(
//       'iframeElement',
//       (int viewId) => _iFrameElement,
//     );

//     super.initState();
//   }

//   final Widget _iframeWidget = HtmlElementView(
//     viewType: 'iframeElement',
//     key: UniqueKey(),
//   );

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Column(
//         children: [
//           SizedBox(
//             height: MediaQuery.of(context).size.height,
//             width: MediaQuery.of(context).size.width,
//             child: _iframeWidget,
//           )
//         ],
//       ),
//     );
//   }
// }
