// import 'package:cached_network_image/cached_network_image.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_riverpod/flutter_riverpod.dart';
// import 'package:intl/intl.dart';
// import 'package:kerla2_client/kerla2_client.dart';
// import 'package:kerla2_flutter/app_old/chats/state/chat_list_state.dart';
// import 'package:kerla2_flutter/core/core.dart';
// import 'package:kerla2_flutter/router/router.dart';
// import 'package:kerla2_flutter/ui/widgets/ad/ad_price.dart';
// import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
// import 'package:nit_app/nit_app.dart';
// import 'package:nit_router/nit_router.dart';
// import 'package:nit_ui_kit/nit_ui_kit.dart';
// import 'package:serverpod_chat_client/module.dart';

// import '../state/selected_chat_provider.dart';

// class ChatCard extends ConsumerWidget {
//   final int index;
//   final ChannelInfo channel;

//   const ChatCard({required this.index, required this.channel, super.key});

//   String getLastMessageTitlePreview(ChatMessage? message) {
//     if (message?.attachments?.firstOrNull?.contentType == 'image') {
//       return 'Фотография';
//     } else if (message?.attachments?.firstOrNull?.contentType == 'audio') {
//       return 'Голосовое сообщение';
//     } else {
//       return message?.message ?? 'Пока нет сообщений';
//     }
//   }

//   @override
//   Widget build(BuildContext context, WidgetRef ref) {
//     return SizedBox(
//       height: 90,
//       child: Card(
//         margin: EdgeInsets.zero,
//         elevation: 0,
//         borderOnForeground: false,
//         child: InkWell(
//           onTap: () {
//             ref.read(selectedChatIdProvider.notifier).state = channel.id;
//             if (channel.adId != null) {
//               context.pushNamed(
//                 AdNavigationZone.chat.name,
//                 pathParameters: {
//                   ...AppNavigationParams.adId.set(channel.ad!.id!),
//                   ...AppNavigationParams.userId.set(channel.chatWith!.id!),
//                 },
//               );
//             } else {
//               context.pushNamed(
//                 MainAreaNavigationZone.userChat.name,
//                 pathParameters:
//                     AppNavigationParams.userId.set(channel.chatWith!.id!),
//               );
//             }
//           },
//           onLongPress: () {
//             showModalBottomSheet<void>(
//               context: context,
//               builder: (BuildContext context) {
//                 return MainBottomSheet(
//                   child: Column(
//                     mainAxisAlignment: MainAxisAlignment.center,
//                     mainAxisSize: MainAxisSize.min,
//                     children: [
//                       Padding(
//                         padding: const EdgeInsets.all(8.0),
//                         child: Container(
//                           height: 2,
//                           width: MediaQuery.sizeOf(context).width * 0.1,
//                           color: Colors.black.withOpacity(0.5),
//                         ),
//                       ),
//                       NavigationButton(
//                         buttonText: "Удалить",
//                         imageAsset: AppIconsSvg.delete,
//                         onTap: () {
//                           showDialog(
//                             context: context,
//                             builder: (_) {
//                               return AlertDialog(
//                                 backgroundColor:
//                                     context.theme.canvasColor, //TODO: set theme
//                                 content: const Text(
//                                     'Вы действительно хотите удалить этот чат?'),
//                                 actions: <Widget>[
//                                   TextButton(
//                                     child: const Text('Отмена'),
//                                     onPressed: () {
//                                       Navigator.of(context).pop();
//                                       Navigator.of(context).pop();
//                                     },
//                                   ),
//                                   TextButton(
//                                     child: const Text('Удалить',
//                                         style: TextStyle(color: Colors.red)),
//                                     onPressed: () async {
//                                       await client.channels
//                                           .deleteChannel(channel.id!);

//                                       ref
//                                           .read(chatListStateProvider.notifier)
//                                           .removeChannel(channel);
//                                       Navigator.of(context).pop();
//                                       Navigator.of(context).pop();
//                                     },
//                                   ),
//                                 ],
//                               );
//                             },
//                           );
//                         },
//                         alignment: Alignment.center,
//                         imageSize: 20,
//                         fontSize: 16,
//                         fontColor: Colors.red,
//                       ),
//                       const SizedBox(height: 20),
//                     ],
//                   ),
//                 );
//               },
//             );
//           },
//           child: Padding(
//             padding: const EdgeInsets.all(8.0),
//             child: Row(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 if (channel.ad?.media?.first.publicUrl != null &&
//                     channel.ad?.media?.first.type == MediaType.image)
//                   Padding(
//                     padding: const EdgeInsets.only(left: 8),
//                     child: ClipRRect(
//                       borderRadius: BorderRadius.circular(8.0),
//                       child: Image.network(
//                         channel.ad!.media!.first.publicUrl,
//                         fit: BoxFit.fitWidth,
//                         width: 100,
//                       ),
//                     ),
//                   ),
//                 Expanded(
//                   child: Padding(
//                     padding: const EdgeInsets.only(left: 12),
//                     child: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         FittedBox(
//                           fit: BoxFit.fitWidth,
//                           child: Row(
//                             mainAxisSize: MainAxisSize.min,
//                             children: [
//                               Padding(
//                                 padding: const EdgeInsets.only(
//                                   right: 8,
//                                 ),
//                                 child: CircleAvatar(
//                                   radius: 12,
//                                   backgroundColor: const Color(0xFF104930),
//                                   backgroundImage:
//                                       channel.chatWith?.imageUrl != null
//                                           ? CachedNetworkImageProvider(
//                                               channel.chatWith?.imageUrl ?? '',
//                                             )
//                                           : null,
//                                 ),
//                               ),
//                               FittedBox(
//                                 fit: BoxFit.fitWidth,
//                                 child: Text(
//                                   '${channel.chatWith?.userName}',
//                                   style: context.textTheme.titleMedium,
//                                 ),
//                               ),
//                               if (channel.hasUnreadMessages)
//                                 Padding(
//                                   padding: const EdgeInsets.only(left: 4),
//                                   child: CircleAvatar(
//                                     radius: 6,
//                                     backgroundColor:
//                                         Theme.of(context).colorScheme.error,
//                                   ),
//                                 ),
//                             ],
//                           ),
//                         ),
//                         if (channel.ad?.title != null)
//                           Text(
//                             '${channel.ad?.title}',
//                             style: Theme.of(context).textTheme.bodySmall,
//                             maxLines: 1,
//                             overflow: TextOverflow.ellipsis,
//                           ),
//                         Text(
//                           getLastMessageTitlePreview(channel.lastMessage),
//                           style: context.textTheme.displayLarge
//                               ?.copyWith(fontSize: 15),
//                           overflow: TextOverflow.ellipsis,
//                           maxLines: 1,
//                         ),
//                       ],
//                     ),
//                   ),
//                 ),
//                 Padding(
//                   padding: const EdgeInsets.symmetric(vertical: 4),
//                   child: Column(
//                     crossAxisAlignment: CrossAxisAlignment.end,
//                     mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                     children: [
//                       Row(
//                         children: [
//                           Text(
//                             DateFormat('HH:mm').format(
//                               channel.lastMessage?.time.toLocal() ??
//                                   DateTime.now(),
//                             ),
//                             style: Theme.of(context).textTheme.bodySmall,
//                           ),
//                           // IconButton(
//                           //   iconSize: 15,
//                           //   icon: const Icon(Icons.more_vert),
//                           //   onPressed: () {
//                           //     showDialog(
//                           //       context: context,
//                           //       builder: (_) {
//                           //         return AlertDialog(
//                           //           backgroundColor: Colors.white,
//                           //           content: const Text(
//                           //               'Вы действительно хотите удалить этот чат?'),
//                           //           actions: <Widget>[
//                           //             TextButton(
//                           //               child: const Text('Отмена'),
//                           //               onPressed: () {
//                           //                 Navigator.of(context).pop();
//                           //               },
//                           //             ),
//                           //             TextButton(
//                           //               child: const Text('Удалить',
//                           //                   style:
//                           //                       TextStyle(color: Colors.red)),
//                           //               onPressed: () {
//                           //                 Navigator.of(context).pop();
//                           //               },
//                           //             ),
//                           //           ],
//                           //         );
//                           //       },
//                           //     );
//                           //   },
//                           // ),
//                         ],
//                       ),
//                       if (channel.ad?.price != null)
//                         Text(
//                           (channel.ad?.price ?? 0).priceFormat(),
//                           style:
//                               Theme.of(context).textTheme.bodyMedium?.copyWith(
//                                         //TODO could be potential issuer
//                                         fontWeight: FontWeight.bold,
//                                       ) ??
//                                   const TextStyle(fontWeight: FontWeight.bold),
//                         ),
//                     ],
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }
