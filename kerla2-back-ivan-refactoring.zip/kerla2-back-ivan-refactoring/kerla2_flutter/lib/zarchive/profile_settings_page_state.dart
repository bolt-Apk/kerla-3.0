// import 'package:flutter/material.dart';
// import 'package:freezed_annotation/freezed_annotation.dart';
// import 'package:kerla2_client/kerla2_client.dart';
// import 'package:kerla2_flutter/common/default_models.dart';
// import 'package:riverpod_annotation/riverpod_annotation.dart';
// import 'package:serverpod_auth_client/module.dart';

// import '../../user_profile/state/signed_in_user_profile_state.dart';

// part 'profile_settings_page_state.freezed.dart';
// part 'profile_settings_page_state.g.dart';

// @freezed
// class ProfileSettings with _$ProfileSettings {
//   const factory ProfileSettings({
//     required TextEditingController descriptionController,
//     required TextEditingController linkController,
//     required TextEditingController usernameController,
//     required TextEditingController cityController,
//     required TextEditingController phoneNumberController,
//     required ValueNotifier<String?> avatarNotifier,
//     required ValueNotifier<String?> backgroundNotifier,
//     required UserInfo userInfo,
//     required UserProfile userProfile,
//   }) = _ProfileSettings;

//   static ProfileSettings defaultModel = ProfileSettings(
//     descriptionController: TextEditingController(),
//     linkController: TextEditingController(),
//     usernameController: TextEditingController(),
//     cityController: TextEditingController(),
//     phoneNumberController: TextEditingController(),
//     avatarNotifier: ValueNotifier<String?>(null),
//     backgroundNotifier: ValueNotifier<String?>(null),
//     userInfo: DefaultModels.userInfo,
//     userProfile: DefaultModels.userProfile,
//   );
// }

// @riverpod
// class ProfileSettingsState extends _$ProfileSettingsState {
//   @override
//   Future<ProfileSettings> build() async {
//     // ref.onDispose(() {
//     // state.usernameController.dispose();
//     // state.linkController.dispose();
//     // state.descriptionController.dispose();
//     // });

//     final state = (await ref.watch(signedInUserProfileStateProvider.future))!;

//     return ProfileSettings(
//       descriptionController: TextEditingController(
//         text: state.userProfile.profileDescription ?? '',
//       ),
//       linkController: TextEditingController(
//         text: state.userProfile.link ?? '',
//       ),
//       usernameController: TextEditingController(
//         text: state.userInfo.userName ?? '',
//       ),
//       cityController: TextEditingController(
//         text: state.userProfile.city ?? '',
//       ),
//       phoneNumberController: TextEditingController(
//         text: state.userProfile.phoneNumber,
//       ),
//       avatarNotifier: ValueNotifier(state.userInfo.imageUrl),
//       // user: ref.signedInUser,
//       backgroundNotifier: ValueNotifier(state.userProfile.backgroundImageUrl),
//       userInfo: state.userInfo,
//       userProfile: state.userProfile,
//     );
//   }

//   // Future<void> updateProfileDescription() async {
//   //   await client.modules.auth.user
//   //       .changeProfileDescription(state.descriptionController.text);
//   //   updateUser();
//   // }

//   // Future<void> updateProfileLink() async {
//   //   await client.modules.auth.user.changeProfileLink(state.linkController.text);
//   //   updateUser();
//   // }

//   // Future<void> updateProfileCity() async {
//   //   await client.modules.auth.user.changeProfileCity(state.cityController.text);
//   //   updateUser();
//   // }

//   // Future<void> updatePhoneNumber(String phoneNumber) async {
//   //   final unMaskedPhoneNumber = phoneNumber.unmaskPhone;
//   //   if (unMaskedPhoneNumber == null) return;
//   //   await client.modules.auth.user.changePhoneNumber(
//   //     unMaskedPhoneNumber,
//   //   );
//   //   updateUser();
//   // }

//   // Future<String?> acceptPromocode(String promocode) async {
//   //   final result = await client.promocode.acceptPromocode(promocode);
//   //   if (result != null) {
//   //     return result;
//   //   }

//   //   updateUser();
//   //   return null;
//   // }

//   // Future<bool> updateProfileUsername({String? username}) async {
//   //   final res = await client.modules.auth.user
//   //       .changeUserName(username ?? state.usernameController.text);
//   //   if (res) {
//   //     await updateUser();
//   //     return true;
//   //   }
//   //   return false;
//   // }

//   // Future<String?> setProfileAvatar(ByteData image) async {
//   //   await client.modules.auth.user.setUserImage(image);
//   //   updateUser();
//   //   return state.user?.imageUrl;
//   // }

//   // Future<void> deleteProfileAvatar() async {
//   //   await client.modules.auth.user.removeUserImage();
//   //   updateUser();
//   // }

//   // Future<void> updateUser() async {
//   //   // TODO: Provide errors to UI
//   //   await sessionManager.refreshSession();
//   //   final user = sessionManager.signedInUser;
//   //   state = state.copyWith(user: user);
//   //   ref.invalidate(userProvider(id: state.user!.id!));
//   //   ref.read(appSessionStateProvider.notifier).setUser(user);
//   // }

//   // Future<void> loadCover() async {
//   //   final file = await ImagePicker().pickImage(
//   //       source: ImageSource.gallery,
//   //       requestFullMetadata: false,
//   //       imageQuality: 100);

//   //   if (file == null) {
//   //     return;
//   //   }

//   //   final bytes = await file.readAsBytes();

//   //   final newImageUrl = await client.modules.auth.user
//   //       .setUserBackgroundImage(ByteData.view(bytes.buffer));

//   //   await updateUser();
//   //   state = state.copyWith(background: newImageUrl);

//   //   debugPrint('Success: $newImageUrl');
//   // }

//   // Future<void> uploadAvatar(
//   //   BuildContext context,
//   // ) async {
//   //   final XFile? file = await ImagePicker().pickImage(
//   //     source: ImageSource.gallery,
//   //     requestFullMetadata: false,
//   //     imageQuality: 20,
//   //   );

//   //   if (file != null) {
//   //     final CroppedFile? croppedFile = await ImageCropper().cropImage(
//   //       sourcePath: file.path,
//   //       aspectRatio: const CropAspectRatio(ratioX: 1, ratioY: 1),
//   //       compressQuality: 50,
//   //       maxWidth: 800,
//   //       maxHeight: 800,
//   //     );

//   //     if (croppedFile != null) {
//   //       final Uint8List bytes = await croppedFile.readAsBytes();
//   //       await setProfileAvatar(ByteData.view(bytes.buffer)).then(
//   //         (value) => context.pop(),
//   //       );
//   //     }
//   //   }
//   // }

//   // Future<void> editAvatar(BuildContext context) async {
//   //   final fileUrl = state.avatar;

//   //   if (fileUrl != null) {
//   //     final File imageFile = await DefaultCacheManager().getSingleFile(fileUrl);
//   //     final CroppedFile? croppedFile = await ImageCropper().cropImage(
//   //       sourcePath: imageFile.path,
//   //       aspectRatio: const CropAspectRatio(ratioX: 1, ratioY: 1),
//   //       compressQuality: 50,
//   //       maxWidth: 800,
//   //       maxHeight: 800,
//   //     );

//   //     if (croppedFile != null) {
//   //       final Uint8List bytes = await croppedFile.readAsBytes();
//   //       await setProfileAvatar(ByteData.view(bytes.buffer));
//   //     }
//   //   }
//   // }
// }
