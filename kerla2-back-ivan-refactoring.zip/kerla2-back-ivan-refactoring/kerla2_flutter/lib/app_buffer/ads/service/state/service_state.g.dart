// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'service_state.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$serviceListStateHash() => r'189ed855d7e5d2fbb6b58c09927dff9bc42ccc45';

/// Copied from Dart SDK
class _SystemHash {
  _SystemHash._();

  static int combine(int hash, int value) {
    // ignore: parameter_assignments
    hash = 0x1fffffff & (hash + value);
    // ignore: parameter_assignments
    hash = 0x1fffffff & (hash + ((0x0007ffff & hash) << 10));
    return hash ^ (hash >> 6);
  }

  static int finish(int hash) {
    // ignore: parameter_assignments
    hash = 0x1fffffff & (hash + ((0x03ffffff & hash) << 3));
    // ignore: parameter_assignments
    hash = hash ^ (hash >> 11);
    return 0x1fffffff & (hash + ((0x00003fff & hash) << 15));
  }
}

abstract class _$ServiceListState
    extends BuildlessAutoDisposeAsyncNotifier<ServiceStateModel> {
  late final int? adId;

  FutureOr<ServiceStateModel> build(
    int? adId,
  );
}

/// See also [ServiceListState].
@ProviderFor(ServiceListState)
const serviceListStateProvider = ServiceListStateFamily();

/// See also [ServiceListState].
class ServiceListStateFamily extends Family<AsyncValue<ServiceStateModel>> {
  /// See also [ServiceListState].
  const ServiceListStateFamily();

  /// See also [ServiceListState].
  ServiceListStateProvider call(
    int? adId,
  ) {
    return ServiceListStateProvider(
      adId,
    );
  }

  @override
  ServiceListStateProvider getProviderOverride(
    covariant ServiceListStateProvider provider,
  ) {
    return call(
      provider.adId,
    );
  }

  static const Iterable<ProviderOrFamily>? _dependencies = null;

  @override
  Iterable<ProviderOrFamily>? get dependencies => _dependencies;

  static const Iterable<ProviderOrFamily>? _allTransitiveDependencies = null;

  @override
  Iterable<ProviderOrFamily>? get allTransitiveDependencies =>
      _allTransitiveDependencies;

  @override
  String? get name => r'serviceListStateProvider';
}

/// See also [ServiceListState].
class ServiceListStateProvider extends AutoDisposeAsyncNotifierProviderImpl<
    ServiceListState, ServiceStateModel> {
  /// See also [ServiceListState].
  ServiceListStateProvider(
    int? adId,
  ) : this._internal(
          () => ServiceListState()..adId = adId,
          from: serviceListStateProvider,
          name: r'serviceListStateProvider',
          debugGetCreateSourceHash:
              const bool.fromEnvironment('dart.vm.product')
                  ? null
                  : _$serviceListStateHash,
          dependencies: ServiceListStateFamily._dependencies,
          allTransitiveDependencies:
              ServiceListStateFamily._allTransitiveDependencies,
          adId: adId,
        );

  ServiceListStateProvider._internal(
    super._createNotifier, {
    required super.name,
    required super.dependencies,
    required super.allTransitiveDependencies,
    required super.debugGetCreateSourceHash,
    required super.from,
    required this.adId,
  }) : super.internal();

  final int? adId;

  @override
  FutureOr<ServiceStateModel> runNotifierBuild(
    covariant ServiceListState notifier,
  ) {
    return notifier.build(
      adId,
    );
  }

  @override
  Override overrideWith(ServiceListState Function() create) {
    return ProviderOverride(
      origin: this,
      override: ServiceListStateProvider._internal(
        () => create()..adId = adId,
        from: from,
        name: null,
        dependencies: null,
        allTransitiveDependencies: null,
        debugGetCreateSourceHash: null,
        adId: adId,
      ),
    );
  }

  @override
  AutoDisposeAsyncNotifierProviderElement<ServiceListState, ServiceStateModel>
      createElement() {
    return _ServiceListStateProviderElement(this);
  }

  @override
  bool operator ==(Object other) {
    return other is ServiceListStateProvider && other.adId == adId;
  }

  @override
  int get hashCode {
    var hash = _SystemHash.combine(0, runtimeType.hashCode);
    hash = _SystemHash.combine(hash, adId.hashCode);

    return _SystemHash.finish(hash);
  }
}

mixin ServiceListStateRef
    on AutoDisposeAsyncNotifierProviderRef<ServiceStateModel> {
  /// The parameter `adId` of this provider.
  int? get adId;
}

class _ServiceListStateProviderElement
    extends AutoDisposeAsyncNotifierProviderElement<ServiceListState,
        ServiceStateModel> with ServiceListStateRef {
  _ServiceListStateProviderElement(super.provider);

  @override
  int? get adId => (origin as ServiceListStateProvider).adId;
}
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
