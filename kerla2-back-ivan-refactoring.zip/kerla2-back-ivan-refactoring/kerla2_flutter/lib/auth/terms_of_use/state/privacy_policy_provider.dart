import 'package:flutter/services.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';

part 'privacy_policy_provider.g.dart';

@riverpod
Future<String> privacyPolicy(PrivacyPolicyRef ref) async {
  return await rootBundle.loadString('assets/privacy_policy_ru.txt');
}
