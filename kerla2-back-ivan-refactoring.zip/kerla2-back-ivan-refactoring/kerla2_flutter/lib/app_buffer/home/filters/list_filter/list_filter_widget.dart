import 'package:flutter/widgets.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/app_buffer/home/filters/list_filter/attribute_filter/filter_attribute_widget.dart';
import 'package:kerla2_flutter/app_buffer/home/filters/list_filter/attribute_filter/state/filter_attribute_state.dart';
import 'package:kerla2_flutter/app_buffer/home/filters/list_filter/filter_category_widget.dart';
import 'package:kerla2_flutter/app_buffer/home/filters/list_filter/widgets/remove_filter_widget.dart';
import 'package:kerla2_flutter/core/app_sources.dart';

class ListFilterWidget extends HookConsumerWidget {
  const ListFilterWidget({
    super.key,
    required this.adListType,
    this.categories,
  });

  final AdListType adListType;
  final List<AdCategory>? categories;
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final selectedItem = useState<AdCategory?>(null);
    final initCategories = categories ?? AppSources.instance.categories;
    return SizedBox(
      height: 40,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (selectedItem.value != null)
              Padding(
                padding: const EdgeInsets.only(right: 8),
                child: RemoveFilterWidget(
                  onTap: () {
                    selectedItem.value = selectedItem.value?.parent;
                    ref
                        .read(filterStateProvider(adListType).notifier)
                        .updateCategory(selectedItem.value);
                  },
                ),
              ),
            if (selectedItem.value == null ||
                (selectedItem.value!.children != null &&
                    selectedItem.value!.children!.isNotEmpty))
              Flexible(
                child: FilterCategoryWidget(
                  items: selectedItem.value == null
                      ? initCategories
                      : selectedItem.value!.children!,
                  onTap: (category) {
                    category.parent = selectedItem.value;
                    ref
                        .read(filterStateProvider(adListType).notifier)
                        .updateCategory(category);
                    selectedItem.value = category;
                  },
                ),
              )
            else
              Flexible(
                child: FilterAttributeWidget(
                  category: selectedItem.value!.copyWith(parent: null),
                  adListType: adListType,
                ),
              ),
          ],
        ),
      ),
    );
  }
}
