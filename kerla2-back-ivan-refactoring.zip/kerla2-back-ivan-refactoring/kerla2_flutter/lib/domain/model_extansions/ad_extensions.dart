import 'package:kerla2_client/kerla2_client.dart';
import '../../../../../ui_kit/ui_kit.dart';

typedef AdCharacteristic = ({String title, String value});

extension AdCharacteristicsExtension on Ad {
  List<AdCharacteristic> get adCharacteristicList {
    final List<AdCharacteristic> characteristics = [];

    if (category?.title != null) {
      characteristics.add((title: 'Категория', value: category!.title));
    }

    final filteredAttributes = attributeValues?.where((item) =>
            item.attribute?.title != null &&
            item.attribute!.title!.isNotEmpty &&
            item.attribute!.title! != "Цена" &&
            item.attribute!.title! != "Где искать?") ??
        [];

    for (final item in filteredAttributes) {
      final title = item.attribute!.title!;
      final value = item.value;

      final formattedValue = (title == 'Год' || title == 'Модель')
          ? value
          : (value as String?).formatNumber();

      characteristics.add((title: title, value: formattedValue));
    }

    return characteristics;
  }
}
