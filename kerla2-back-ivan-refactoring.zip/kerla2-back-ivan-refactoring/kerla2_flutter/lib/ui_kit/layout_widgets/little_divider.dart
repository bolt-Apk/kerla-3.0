part of '../ui_kit.dart';

class LittleDivider extends StatelessWidget {
  const LittleDivider({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 8, bottom: 16),
      child: Container(
        height: 2,
        width: 32,
        decoration: BoxDecoration(
          color: Colors.grey,
          borderRadius: BorderRadius.circular(30),
        ),
      ),
    );
  }
}
