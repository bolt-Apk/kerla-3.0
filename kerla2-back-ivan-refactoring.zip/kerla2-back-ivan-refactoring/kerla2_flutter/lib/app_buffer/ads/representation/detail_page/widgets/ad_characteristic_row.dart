import 'package:flutter/material.dart';
import 'package:kerla2_flutter/domain/model_extansions/ad_extensions.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class AdCharacteristicRow extends StatelessWidget {
  const AdCharacteristicRow({super.key, required this.characteristics});

  final List<AdCharacteristic> characteristics;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: characteristics.map((item) {
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
          child: Row(
            children: [
              Text(
                item.title,
                style: context.textTheme.bodyMedium?.copyWith(
                  fontSize: 16,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(width: 8),
              Flexible(
                child: Text(
                  item.value,
                  maxLines: 3,
                  overflow: TextOverflow.ellipsis,
                  style: context.textTheme.bodyMedium?.copyWith(
                    fontSize: 14,
                  ),
                ),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }
}
