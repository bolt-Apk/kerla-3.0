import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/core/core.dart';
import 'package:kerla2_flutter/firebase_options.dart';
import 'package:kerla2_flutter/main.dart';
import 'package:nit_app/nit_app.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';
import 'package:serverpod_auth_shared_flutter/serverpod_auth_shared_flutter.dart';
import 'package:serverpod_flutter/serverpod_flutter.dart';

void main() async {
  client = Client(
    'http://89.169.1.221:8080/', //dev server
    // 'http://91.142.73.206:8080/', //stage server
    // 'http://10.0.2.2:8080/',
    // kIsWeb || Platform.isIOS
    //     ? 'http://localhost:8080/'
    //     : 'http://10.0.2.2:8080/',
    authenticationKeyManager: FlutterAuthenticationKeyManager(),
  )..connectivityMonitor = FlutterConnectivityMonitor();

  WidgetsFlutterBinding.ensureInitialized();

  await NitApp.preInitialization(
    goRouterOptionURLReflectsImperativeAPIs: true,
    firebaseOptions: kIsWeb ? null : DefaultFirebaseOptions.currentPlatform,
  );

  NitUiKitConfig.initStaticConfig(
    defaultLoadingValueGetter: NitDefaultModelsRepository.get,
    errorHandler: (error, stackTrace) => debugPrint(
      '$error\n$stackTrace',
    ),
  );

  runApp(
    const ProviderScope(child: InitMessages()),
  );
}
