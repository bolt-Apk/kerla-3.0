part of '../ui_kit.dart';

class MainInfoWidget extends StatelessWidget {
  final Widget imageWidget;
  final Widget infoWidget;

  const MainInfoWidget({
    required this.imageWidget,
    required this.infoWidget,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        const Gap(16),
        Stack(
          alignment: Alignment.bottomRight,
          children: [
            Container(
              color: Theme.of(context).canvasColor,
              width: 50,
              height: MediaQuery.sizeOf(context).height * 0.07,
            ),
            imageWidget,
          ],
        ),
        Expanded(
          child: Container(
            decoration: BoxDecoration(
              color: Theme.of(context).canvasColor,
              borderRadius: const BorderRadius.only(
                topRight: Radius.circular(20),
              ),
            ),
            child: infoWidget,
          ),
        ),
      ],
    );
  }
}
