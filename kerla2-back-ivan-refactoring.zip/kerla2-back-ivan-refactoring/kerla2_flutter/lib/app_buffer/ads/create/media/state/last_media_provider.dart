import 'package:flutter/material.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:wechat_assets_picker/wechat_assets_picker.dart';

part 'last_media_provider.g.dart';

@Riverpod(keepAlive: true)
FutureOr<List<AssetEntity>> lastMedia(
  LastMediaRef ref, {
  required BuildContext context,
  int count = 20,
}) async {
  final permission = await PhotoManager.requestPermissionExtend();
  late final List<AssetPathEntity> albumList;
  List<AssetEntity> lastMediaAssets = [];

  if (permission.isAuth == true) {
    albumList = await PhotoManager.getAssetPathList(type: RequestType.image);
  } else {
    if (context.mounted) {
      Navigator.pop(context);
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text(
            'Требуется доступ к библиотеке фотографий',
            // textAlign: TextAlign.center,
          ),
          content: const Text(
              'Пожалуйста, предоставьте доступ к библиотеке фотографий в настройках вашего устройства.'),
          actionsAlignment: MainAxisAlignment.start,
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('Закрыть'),
            ),
          ],
        ),
      );
    }
  }

  if (albumList.isNotEmpty) {
    lastMediaAssets = await albumList.first.getAssetListRange(
      start: 0,
      end: count,
    );
  }

  return lastMediaAssets;
}
