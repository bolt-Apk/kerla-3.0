import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerla2_flutter/app_buffer/ads/service/state/service_state.dart';
import 'package:kerla2_flutter/app_buffer/ads/service/widget/service_row.dart';

class ServiceListWidget extends ConsumerWidget {
  const ServiceListWidget.free({
    super.key,
    required this.adId,
    required this.state,
  }) : isFree = true;

  const ServiceListWidget.payable({
    super.key,
    required this.adId,
    required this.state,
  }) : isFree = false;

  final int adId;
  final ServiceStateModel state;
  final bool isFree;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final notifier = ref.watch(serviceListStateProvider(adId).notifier);
    final serviceList = isFree ? state.freeServices : state.payableServices;

    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 100),
      transitionBuilder: (Widget child, Animation<double> animation) {
        return FadeTransition(opacity: animation, child: child);
      },
      child: (serviceList.isNotEmpty &&
              (isFree
                  ? notifier.allowFreeServices
                  : notifier.allowPayableServices))
          ? Padding(
              key: UniqueKey(),
              padding: const EdgeInsets.symmetric(vertical: 8.0),
              child: Column(
                children: [
                  if (isFree) const Text("Подключите бесплатно"),
                  ListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: serviceList.length,
                    itemBuilder: (context, index) {
                      return ServiceRow.toggleable(
                        serviceInfo: serviceList[index],
                        adId: adId,
                      );
                    },
                  ),
                ],
              ),
            )
          : const SizedBox.shrink(),
    );
  }
}
