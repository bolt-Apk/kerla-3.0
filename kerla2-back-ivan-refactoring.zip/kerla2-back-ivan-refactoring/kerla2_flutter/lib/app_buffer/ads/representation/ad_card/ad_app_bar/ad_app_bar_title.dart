import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/common/user_profile_ref_extensions.dart';
import 'package:kerla2_flutter/router/router.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_router/nit_router.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

import '/app_buffer/profile/profile_image/profile_image.dart';

class AdAppBarTitle extends ConsumerWidget {
  final Ad ad;

  const AdAppBarTitle({
    super.key,
    required this.ad,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return InkWell(
      onTap: () => context.pushNamed(
        MainAreaNavigationZone.user.name,
        pathParameters: AppNavigationParams.userId.set(ad.userId!),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          ProfileImage(
            userId: ad.userId!,
            size: 40,
            // TODO: косметика
            // isShrinkImage: true,
          ),
          Flexible(
            child: Padding(
              padding: const EdgeInsets.only(left: 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '@${ref.watchUserProfile(ad.userId!).whenData(
                          (user) => user.userName ?? '',
                        ).value ?? ''}',
                    style: context.textTheme.titleMedium,
                    overflow: TextOverflow.ellipsis,
                  ),
                  Row(
                    children: [
                      Text(
                        '''Размещено ${ad.createdAt.toLocal().formatDate}''',
                        style: context.textTheme.labelSmall?.copyWith(
                          fontSize: 10,
                          letterSpacing: 0.1,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 7),
                        child: Icon(
                          Icons.remove_red_eye_outlined,
                          size: 15,
                          color: context.theme.iconTheme.color,
                        ),
                      ),
                      Text(
                        '${ad.visitCount}',
                        style: context.textTheme.labelSmall?.copyWith(
                          fontSize: 10,
                          letterSpacing: 0.1,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
