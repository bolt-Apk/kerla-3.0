#import "PMImport.h"

@interface PhotoManagerPlugin : NSObject <FlutterPlugin>
@property(nonatomic, strong) NSObject <FlutterPluginRegistrar> *registrar;
@end
