import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/core/app_repository.dart';
import 'package:nit_app/nit_app.dart';

class DeleteAccountButton extends ConsumerWidget {
  const DeleteAccountButton({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return TextButton(
      onPressed: () async {
        showDialog<String>(
          context: context,
          builder: (BuildContext context) => AlertDialog(
            title: const Text(
              'Вы уверены, что хотите удалить аккаунт?',
              textAlign: TextAlign.center,
            ),
            actions: <Widget>[
              TextButton(
                onPressed: () => Navigator.pop(context, 'Cancel'),
                child: const Text('Отмена'),
              ),
              TextButton(
                onPressed: () async {
                  await ref.deleteModel<UserProfile>(ref.readModel(
                    ref.read(nitSessionStateProvider).signedInUserId!,
                    AppRepository.userProfileByUserId.descriptor,
                  ));
                  await ref.read(nitSessionStateProvider.notifier).signOut();

                  // if (context.mounted) {
                  //   context.goNamed(
                  //     MainAreaNavigationZone.homePage.name,
                  //   );
                  // }
                },
                child: Text(
                  'Удалить',
                  style: Theme.of(context).textTheme.displayLarge?.copyWith(
                        color: Colors.red,
                        fontWeight: FontWeight.bold,
                      ),
                ),
              ),
            ],
          ),
        );
      },
      child: Text(
        'Удалить аккаунт',
        style: Theme.of(context).textTheme.displayLarge?.copyWith(
              color: Colors.red,
              fontWeight: FontWeight.bold,
            ),
      ),
    );
  }
}
