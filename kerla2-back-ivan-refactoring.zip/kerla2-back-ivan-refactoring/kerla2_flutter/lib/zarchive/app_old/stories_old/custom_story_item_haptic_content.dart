// import 'dart:ui';

// import 'package:cached_network_image/cached_network_image.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_hooks/flutter_hooks.dart';
// import 'package:flutter_svg/svg.dart';

// import 'package:guarded_button/guarded_button.dart';
// import 'package:hooks_riverpod/hooks_riverpod.dart';
// import 'package:intl/intl.dart';
// import 'package:kerla2_client/kerla2_client.dart';
// import 'package:kerla2_flutter/core/core.dart';
// import 'package:kerla2_flutter/router/router.dart';
// import 'package:kerla2_flutter/zarchive/session/app_session_state_extension.dart';
// import 'package:nit_app/nit_app.dart';
// import 'package:kerla2_flutter/ui_kit/ui_kit.dart';

// import 'package:serverpod_auth_client/module.dart';
// import 'package:share_plus/share_plus.dart';

// import 'package:story_view/controller/story_controller.dart';

// import '../../../app_buffer/stories/state/stories_providers.dart';
// import '../../../common/share.dart';
// import '../../../app_buffer/favorites/state/ad_favorites_state.dart';
// import '../../../scaffold/widget/main_bottom_sheet.dart';
// import '../../widgets/ad/report_ad.dart';
// import '../../widgets/navigation_button.dart';

// class CustomStoryItemHapticContent extends HookConsumerWidget {
//   const CustomStoryItemHapticContent({
//     super.key,
//     required this.story,
//     required this.user,
//     required this.storyController,
//   });

//   final Ad story;
//   final UserInfoPublic user;
//   final StoryController storyController;

//   @override
//   Widget build(BuildContext context, WidgetRef ref) {
//     void storyDeleteDialog() => showDialog(
//           context: context,
//           builder: (context) => Dialog(
//             child: Padding(
//               padding: const EdgeInsets.all(16.0),
//               child: Column(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 mainAxisSize: MainAxisSize.min,
//                 children: [
//                   const Text(
//                     'Вы уверены, что хотите удалить сторис?',
//                     textAlign: TextAlign.center,
//                   ),
//                   const SizedBox(height: 10),
//                   Row(
//                     mainAxisAlignment: MainAxisAlignment.spaceAround,
//                     children: [
//                       TextButton(
//                         child: const Text('Отмена'),
//                         onPressed: () => context.pop(),
//                       ),
//                       TextButton(
//                         child: const Text('Удалить'),
//                         onPressed: () async {
//                           await client.adManagement.deleteAd(story.id!);

//                           if (context.mounted && context.canPop()) {
//                             context.pop();
//                             context.pop();
//                           }
//                         },
//                       ),
//                     ],
//                   ),
//                 ],
//               ),
//             ),
//           ),
//         );
//     // final currentUser = ref.signedInUser;
//     // final bool allowedAd = story.onlyForGender == ref.signedInUser?.gender ||
//     //     story.onlyForGender == null;
//     final isSubscriptionOpened = useState(false);
//     final numberFormatter = NumberFormat('#,###', 'ru_RU');
//     return Stack(
//       alignment: Alignment.bottomRight,
//       children: [
//         Padding(
//           padding: const EdgeInsets.only(
//             // left: 12,
//             // right: 12,
//             top: 16,
//             bottom: 16,
//           ),
//           child: DefaultTextStyle(
//             style: Theme.of(context)
//                 .textTheme
//                 .bodySmall!
//                 .copyWith(color: Colors.white),
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 Padding(
//                   padding: const EdgeInsets.symmetric(horizontal: 12),
//                   child: Row(
//                     children: [
//                       InkWell(
//                         onTap: () {
//                           context.pushNamed(
//                             MainAreaNavigationZone.user.name,
//                             pathParameters:
//                                 AppNavigationParams.userId.set(user.id!),
//                           );
//                         },
//                         onLongPress: () {
//                           showDialog(
//                               context: context,
//                               builder: (context) {
//                                 return Dialog(
//                                     backgroundColor: Colors.transparent,
//                                     child: Container(
//                                       decoration: BoxDecoration(
//                                         shape: BoxShape.circle,
//                                         image: DecorationImage(
//                                           image: CachedNetworkImageProvider(
//                                               user.imageUrl!),
//                                           fit: BoxFit.cover,
//                                         ),
//                                       ),
//                                       height: 200,
//                                       width: 200,
//                                     ));
//                               });
//                         },
//                         child: Container(
//                           decoration: BoxDecoration(
//                             border: Border.all(
//                               color: Colors.white,
//                             ),
//                             shape: BoxShape.circle,
//                             image: DecorationImage(
//                               image: CachedNetworkImageProvider(
//                                 user.imageUrl ?? '',
//                               ),
//                               fit: BoxFit.cover,
//                             ),
//                           ),
//                           height: 30,
//                           width: 30,
//                         ),
//                       ),
//                       const SizedBox(width: 8),
//                       Expanded(
//                         child: Text(
//                           user.userName,
//                           style: TextStyle(shadows: [
//                             Shadow(
//                               color: Colors.black.withOpacity(0.6),
//                               offset: const Offset(0, 1),
//                               blurRadius: 4,
//                             )
//                           ]),
//                         ),
//                       ),
//                       Text(
//                         story.storiesViewsCount.toString(),
//                         style: TextStyle(shadows: [
//                           Shadow(
//                             color: Colors.black.withOpacity(0.8),
//                             offset: const Offset(0, 1),
//                             blurRadius: 4,
//                           )
//                         ]),
//                       ),
//                       Padding(
//                         padding: const EdgeInsets.symmetric(horizontal: 10),
//                         child: Icon(
//                           Icons.remove_red_eye,
//                           color: Colors.white,
//                           shadows: [
//                             Shadow(
//                               color: Colors.black.withOpacity(0.8),
//                               offset: const Offset(0, 1),
//                               blurRadius: 4,
//                             )
//                           ],
//                         ),
//                       ),
//                       if (currentUser?.id != null && currentUser?.id != user.id)
//                         _StorySubscribeBtn(user),
//                       const SizedBox(width: 5),
//                       FloatingActionButton(
//                         elevation: 0,
//                         backgroundColor: Colors.transparent,
//                         mini: true,
//                         onPressed: () => debugPrint('icon 1 pressed'),
//                         child: Stack(children: [
//                           Positioned(
//                             top: 1,
//                             left: 2,
//                             child: SvgPicture.asset(
//                               AppIconsSvg.search,
//                               height: 20,
//                               width: 20,
//                               colorFilter: ColorFilter.mode(
//                                 Colors.black.withOpacity(0.3),
//                                 BlendMode.srcIn,
//                               ),
//                             ),
//                           ),
//                           SvgPicture.asset(
//                             AppIconsSvg.search,
//                             height: 20,
//                             width: 20,
//                             colorFilter: const ColorFilter.mode(
//                               Colors.white,
//                               BlendMode.srcIn,
//                             ),
//                           ),
//                         ]),
//                       ),
//                     ],
//                   ),
//                 ),
//                 const Spacer(),
//                 GestureDetector(
//                   onTap: () {
//                     isSubscriptionOpened.value = !isSubscriptionOpened.value;
//                     isSubscriptionOpened.value
//                         ? storyController.pause()
//                         : storyController.play();
//                   },
//                   child: Container(
//                     width: double.infinity,
//                     decoration: BoxDecoration(
//                       color: isSubscriptionOpened.value
//                           ? Colors.black.withOpacity(0.3)
//                           : Colors.transparent,
//                     ),
//                     child: Padding(
//                       padding: const EdgeInsets.symmetric(horizontal: 8),
//                       child: Column(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         children: [
//                           Text(
//                             (user.userName == 'kerla') //TODO: convert it
//                                 ? ''
//                                 : '${story.price >= 1000 ? numberFormatter.format(story.price) : story.price} ₽',
//                             style: context.textTheme.headlineLarge?.copyWith(
//                                 color: Colors.white,
//                                 fontWeight: FontWeight.bold,
//                                 shadows: [
//                                   Shadow(
//                                     color: Colors.black.withOpacity(1),
//                                     offset: const Offset(1, 1),
//                                     blurRadius: 4,
//                                   )
//                                 ]),
//                           ),
//                           const SizedBox(height: 8),
//                           AnimatedContainer(
//                             duration: const Duration(milliseconds: 200),
//                             height: isSubscriptionOpened.value
//                                 ? story.title.length > 80
//                                     ? 250
//                                     : 100
//                                 : 50,
//                             // width: MediaQuery.sizeOf(context).width * 0.7,
//                             child: SingleChildScrollView(
//                               child: Text(
//                                 story.title,
//                                 style: Theme.of(context)
//                                     .textTheme
//                                     .headlineMedium
//                                     ?.copyWith(color: Colors.white, shadows: [
//                                   Shadow(
//                                     color: Colors.black.withOpacity(1),
//                                     offset: const Offset(1, 1),
//                                     blurRadius: 4,
//                                   )
//                                 ]),
//                                 overflow: TextOverflow.ellipsis,
//                                 maxLines: isSubscriptionOpened.value ? 99 : 2,
//                               ),
//                             ),
//                           ),
//                         ],
//                       ),
//                     ),
//                   ),
//                 ),
//                 if (story.isAd && allowedAd)
//                   ElevatedButton(
//                     style: OutlinedButton.styleFrom(
//                       padding: const EdgeInsets.all(5),
//                       backgroundColor:
//                           ThemePrimaryColors.primary.withOpacity(0.25),
//                     ),
//                     onPressed: () {
//                       storyController.pause();
//                       context.pushNamed(
//                         AdNavigationZone.adPage.name,
//                         pathParameters: AppNavigationParams.adId.set(story.id!),
//                         extra: story,
//                       );
//                     },
//                     child: Text(
//                       'Показать объявление',
//                       style: Theme.of(context)
//                           .textTheme
//                           .titleMedium
//                           ?.copyWith(color: Colors.white),
//                     ),
//                   ),
//               ],
//             ),
//           ),
//         ),
//         // Positioned(
//         //   bottom: story.isAd && allowedAd ? 70 : 16,
//         //   right: isSubscriptionOpened.value ? 8 : 80,
//         //   left: 8,
//         //   child: Container(
//         //     color: Colors.transparent,
//         //     height: isSubscriptionOpened.value ? 140 : 70,
//         //   ),
//         // ),
//         if (allowedAd && !isSubscriptionOpened.value)
//           Padding(
//             padding: const EdgeInsets.only(bottom: 70, right: 8),
//             child: Column(
//               children: [
//                 const Spacer(),
//                 if (ref.signedInUserId != user.id)
//                   Consumer(
//                     builder: (_, ref, __) {
//                       final isFavorite =
//                           ref.watch(isAdFavoriteProvider(story.id!));
//                       return isFavorite.when(
//                         loading: () => const CircularProgressIndicator(),
//                         error: ((error, stackTrace) => const SizedBox.shrink()),
//                         data: (data) {
//                           return FloatingActionButton(
//                             heroTag: '1',
//                             backgroundColor: Colors.grey.withOpacity(0.5),
//                             mini: true,
//                             onPressed: () {},
//                             child: FavoriteView(
//                               isFavorite: data,
//                               secondChildColor: ThemePrimaryColors.white,
//                               ad: story,
//                               isStory: true,
//                             ),
//                           );
//                         },
//                       );
//                     },
//                   ),
//                 if (currentUser?.id != user.id)
//                   FloatingActionButton(
//                     heroTag: '2',
//                     backgroundColor: Colors.grey.withOpacity(0.5),
//                     mini: true,
//                     onPressed: () {
//                       context.pushNamed(
//                         MainAreaNavigationZone.chatAd.name,
//                         pathParameters: {
//                           ChatNavigationParameters.adId.name:
//                               story.id.toString(),
//                           ChatNavigationParameters.userId.name:
//                               story.user!.id.toString(),
//                         },
//                       );
//                     },
//                     child: SvgPicture.asset(
//                       AppNavigationIconsSvg.chats,
//                       height: 20,
//                       width: 20,
//                       colorFilter: const ColorFilter.mode(
//                         Colors.white,
//                         BlendMode.srcIn,
//                       ),
//                     ),
//                   ),
//                 // FloatingActionButton(
//                 //   heroTag: '3',
//                 //   backgroundColor: Colors.grey.withOpacity(0.5),
//                 //   mini: true,
//                 //   onPressed: () {},
//                 //   child: SvgPicture.asset(
//                 //     AppIconsSvg.comment,
//                 //     height: 20,
//                 //     width: 20,
//                 //     colorFilter: const ColorFilter.mode(
//                 //       Colors.white,
//                 //       BlendMode.srcIn,
//                 //     ),
//                 //   ),
//                 // ),
//                 FloatingActionButton(
//                   heroTag: '4',
//                   backgroundColor: Colors.grey.withOpacity(0.5),
//                   mini: true,
//                   onPressed: story.id == null
//                       ? () {}
//                       : () {
//                           Share.share(
//                             ShareType.story.getShareLink(story.id!),
//                           );
//                         },
//                   child: SvgPicture.asset(
//                     AppIconsSvg.upload,
//                     height: 20,
//                     width: 20,
//                     colorFilter: const ColorFilter.mode(
//                       Colors.white,
//                       BlendMode.srcIn,
//                     ),
//                   ),
//                 ),
//                 FloatingActionButton(
//                   heroTag: '5',
//                   backgroundColor: Colors.grey.withOpacity(0.5),
//                   mini: true,
//                   onPressed: () async {
//                     storyController.pause();
//                     await showModalBottomSheet<void>(
//                       context: context,
//                       builder: (BuildContext context) {
//                         final userId = ref.signedInUser?.id;
//                         final isOwner = story.user?.id == userId;
//                         return MainBottomSheet(
//                           child: Column(
//                             mainAxisAlignment: MainAxisAlignment.center,
//                             mainAxisSize: MainAxisSize.min,
//                             children: [
//                               Padding(
//                                 padding: const EdgeInsets.all(8.0),
//                                 child: Container(
//                                   height: 2,
//                                   width: MediaQuery.sizeOf(context).width * 0.1,
//                                   color: Colors.black.withOpacity(0.5),
//                                 ),
//                               ),
//                               // const Divider(
//                               //   height: 1,
//                               // ),
//                               // NavigationButton(
//                               //   buttonText: "Поделиться",
//                               //   imageAsset: AppIconsSvg.upload,
//                               //   onTap: story.id == null
//                               //       ? () {}
//                               //       : () {
//                               //           Share.shareUri(
//                               //             Uri.parse(
//                               //               ShareType.story
//                               //                   .getShareLink(story.id!),
//                               //             ),
//                               //           );
//                               //         },
//                               //   alignment: Alignment.center,
//                               //   imageSize: 20,
//                               //   fontSize: 16,
//                               // ),
//                               if (ref.signedInUser?.isAdminGetter == true)
//                                 NavigationButton(
//                                   buttonText: story.status == AdStatus.active
//                                       ? "Заблокировать"
//                                       : "Разблокировать",
//                                   imageAsset: AppIconsSvg.warning,
//                                   onTap: () async {
//                                     await client.admin
//                                         .changeAdBlockStatus(story.id!);
//                                     ref.invalidate(userStoriesProvider);
//                                   },
//                                   alignment: Alignment.center,
//                                   imageSize: 20,
//                                   fontSize: 16,
//                                   fontColor: Colors.red,
//                                 ),
//                               const Divider(
//                                 height: 1,
//                               ),
//                               NavigationButton(
//                                 buttonText: "Пожаловаться",
//                                 imageAsset: AppIconsSvg.warning,
//                                 onTap: () {
//                                   showModalBottomSheet(
//                                     context: context,
//                                     isScrollControlled: true,
//                                     builder: (BuildContext context) {
//                                       return ReportAdWidget(adId: story.id!);
//                                     },
//                                   );
//                                 },
//                                 alignment: Alignment.center,
//                                 imageSize: 20,
//                                 fontSize: 16,
//                                 fontColor: Colors.red,
//                               ),
//                               if (isOwner) const Divider(height: 1),
//                               if (isOwner)
//                                 NavigationButton(
//                                   buttonText: "Удалить",
//                                   imageAsset: AppIconsSvg.delete,
//                                   onTap: () async {
//                                     storyDeleteDialog();
//                                   },
//                                   alignment: Alignment.center,
//                                   imageSize: 20,
//                                   fontSize: 16,
//                                   fontColor: Colors.red,
//                                 ),
//                               const SizedBox(height: 20),
//                             ],
//                           ),
//                         );
//                       },
//                     );
//                     storyController.play();
//                   },
//                   child: Text(
//                     '...',
//                     style: Theme.of(context)
//                         .textTheme
//                         .headlineLarge
//                         ?.copyWith(color: Colors.white),
//                   ),
//                 ),
//               ],
//             ),
//           ),
//       ],
//     );
//   }
// }

// class _StorySubscribeBtn extends ConsumerStatefulWidget {
//   const _StorySubscribeBtn(this.user);

//   final UserInfoPublic user;

//   @override
//   ConsumerState<ConsumerStatefulWidget> createState() =>
//       __StorySubscribeBtnState();
// }

// class __StorySubscribeBtnState extends ConsumerState<_StorySubscribeBtn> {
//   bool? isSubscribed;

//   @override
//   void initState() {
//     super.initState();
//     isSubscribed = widget.user.isSubscribed;
//   }

//   @override
//   Widget build(BuildContext context) {
//     return SizedBox(
//       height: 30,
//       width: 110,
//       child: GuardedElevatedButton(
//         style: OutlinedButton.styleFrom(
//           backgroundColor: Colors.white.withOpacity(0.15),
//           padding: const EdgeInsets.all(8),
//         ),
//         onPressed: () async {
//           if (isSubscribed == false) {
//             final s =
//                 await client.subscription.subscribe(userId: widget.user.id!);
//             if (s) isSubscribed = true;
//             setState(() {});
//           } else if (isSubscribed == true) {
//             final s =
//                 await client.subscription.unsubscribe(userId: widget.user.id!);
//             if (s) isSubscribed = false;
//             setState(() {});
//           }
//         },
//         child: Text(
//           isSubscribed == true ? 'Отписаться' : 'Подписаться',
//           style: Theme.of(context)
//               .textTheme
//               .titleSmall
//               ?.copyWith(color: Colors.white),
//         ),
//       ),
//     );
//   }
// }
