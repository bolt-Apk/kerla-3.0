import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/core/app_sources.dart';

import '../../../../../ads/create/create_ad/attributes/widgets/attribute_range_input.dart';
import '../../widgets/home_attribute_dialog.dart';
import '../../widgets/home_attribute_radio_button_list.dart';
import '../../widgets/home_filter_bottom_sheet.dart';
import '../../widgets/home_filter_drop_down_row_widget.dart';
import '../../widgets/home_radio_button.dart';

class FiltersInlineRender extends HookConsumerWidget {
  const FiltersInlineRender({
    super.key,
    required this.attributeValue,
    required this.onSave,
    this.userId,
  });

  final AdAttributeValue attributeValue;
  final int? userId;
  final void Function(AdAttributeValue) onSave;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // final bool isSubAttribute =
    //     attributeValue.attribute?.subAttributeId != null;

    if (attributeValue.attribute == null) return const SizedBox.shrink();

    final filterValueNotifier = useState('');
    return switch (attributeValue.attribute?.type) {
      AttributeType.category => HomeRadioButton(
          text: attributeValue.attribute!.title,
          isSelected: false,
          onTap: () => showModalBottomSheet(
            context: context,
            builder: (BuildContext context) {
              return HomeAttributeDialog(
                onPressed: () {
                  context.pop();
                },
                child: Container(
                  height: 100,
                  width: 100,
                  color: Colors.blue,
                ),
              );
            },
          ),
        ),
      AttributeType.radioButton => HomeRadioButton(
          text: attributeValue.attribute!.title,
          isSelected: false,
          onTap: () => showModalBottomSheet(
            context: context,
            builder: (BuildContext context) {
              return HookBuilder(builder: (context) {
                final filterValue = useState<String>(attributeValue.value);

                return HomeAttributeDialog(
                  onPressed: () {
                    onSave(
                      attributeValue.copyWith(value: filterValue.value),
                    );
                    context.pop();
                  },
                  child: SizedBox(
                    height: 300,
                    child: HomeAttributeRadioButtonList(
                      attribute: attributeValue.attribute!,
                      onReset: () {
                        onSave(
                          attributeValue.copyWith(value: ''),
                        );
                        context.pop();
                      },
                      onRadioButtonTap: (value) {
                        filterValue.value = value;
                      },
                      valueNotifier: filterValue,
                    ),
                  ),
                );
              });
            },
          ),
        ),
      // AttributeType.regionsDropdown => HomeRadioButton(
      //     text: attributeValue.attribute!.title,
      //     isSelected: false,
      //     onTap: () => showModalBottomSheet(
      //       context: context,
      //       builder: (BuildContext context) {
      //         return const Text("TEST");
      //       },
      //     ),
      //   ),
      AttributeType.valuesDropdown ||
      AttributeType.regionsDropdown =>
        HomeRadioButton(
          text: attributeValue.attribute!.title,
          isSelected: false,
          onTap: () => showModalBottomSheet(
            context: context,
            isScrollControlled: true,
            builder: (BuildContext context) {
              final regions = AppSources.instance.regions;
              final values = attributeValue.attribute?.type ==
                      AttributeType.regionsDropdown
                  ? regions.map((e) => e.title).toList()
                  : attributeValue.attribute!.values;
              return HookBuilder(
                builder: (context) {
                  final searchString = useState('');

                  final List<String> filtredList = values!
                      .where(
                        (element) => element
                            .toLowerCase()
                            .contains(searchString.value.toLowerCase().trim()),
                      )
                      .toList();

                  final filterValue = useState(attributeValue.value);

                  return SizedBox(
                    height: MediaQuery.sizeOf(context).height - kToolbarHeight,
                    child: HomeAttributeDialog(
                      onPressed: () {
                        onSave(
                          attributeValue.copyWith(value: filterValue.value),
                        );
                        context.pop();
                      },
                      child: FilterBottomSheet(
                        attribute: attributeValue.attribute!,
                        body: SizedBox(
                          height: MediaQuery.sizeOf(context).height -
                              kToolbarHeight -
                              200,
                          child: ListView.builder(
                            itemCount: filtredList.length,
                            shrinkWrap: true,
                            itemBuilder: (context, index) {
                              return HomeFilterDropDownRow(
                                attribute: attributeValue.attribute!,
                                value: filtredList[index],
                                values: filtredList,
                                valueNotifier: filterValue,
                              );
                            },
                          ),
                        ),
                        filterValueNotifier: searchString,
                        onReset: () {
                          onSave(attributeValue.copyWith(value: ''));
                        },
                      ),
                    ),
                  );
                },
              );
            },
          ),
        ),
      AttributeType.number || AttributeType.decimal => HomeRadioButton(
          text: attributeValue.attribute!.title,
          isSelected: false,
          onTap: () => showModalBottomSheet(
            isScrollControlled: true,
            context: context,
            builder: (BuildContext context) {
              return Padding(
                padding: MediaQuery.of(context).viewInsets,
                child: HookConsumer(
                  builder: (context, ref, child) {
                    final leftController = useTextEditingController(
                        text: attributeValue.value.split(':').length > 1
                            ? attributeValue.value.split(':')[0]
                            : '');
                    final rightController = useTextEditingController(
                        text: attributeValue.value.split(':').length > 1
                            ? attributeValue.value.split(':')[1]
                            : '');

                    return HomeAttributeDialog(
                      onPressed: () {
                        onSave(attributeValue.copyWith(
                          value:
                              "${leftController.text.isEmpty ? '-1' : leftController.text}:${rightController.text.isEmpty ? '-1' : rightController.text}",
                        ));

                        context.pop();
                      },
                      child: FilterBottomSheet(
                        attribute: attributeValue.attribute!,
                        body: AttributeRangeInput(
                          leftController: leftController,
                          rightController: rightController,
                          keyboardType: TextInputType.number,
                          onSave: (value) {},
                        ),
                        filterValueNotifier: filterValueNotifier,
                        onReset: () {
                          onSave(
                            attributeValue.copyWith(value: ''),
                          );
                        },
                      ),
                    );
                  },
                ),
              );
            },
          ),
        ),
      AttributeType.string => HomeRadioButton(
          text: attributeValue.attribute!.title,
          isSelected: false,
          onTap: () => showModalBottomSheet(
            context: context,
            builder: (BuildContext context) {
              return HomeAttributeDialog(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: Container(
                  height: 100,
                  width: 100,
                  color: Colors.cyan,
                ),
              );
            },
          ),
        ),
      AttributeType.color => Container(),
      // TODO: Handle this case.
      null => throw UnimplementedError(),
    };
  }
}
