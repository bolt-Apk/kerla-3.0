import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/app_buffer/ads/create/state/ad_create_state.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class StoryPriceInput extends ConsumerStatefulWidget {
  final TextEditingController priceController;
  const StoryPriceInput({
    super.key,
    required this.priceController,
  });

  @override
  ConsumerState<ConsumerStatefulWidget> createState() =>
      _StoryPriceInputState();
}

class _StoryPriceInputState extends ConsumerState<StoryPriceInput> {
  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: widget.priceController,
      onChanged: (value) {
        final Attribute storyPrice = Attribute(
          id: 1,
          type: AttributeType.number,
          title: 'Цена',
        );

        ref.read(createAdStateProvider(AdType.story).notifier).setAttribute(
              AdAttributeValue(
                attributeId: 1,
                value: value,
                attribute: storyPrice,
              ),
            );
      },
      keyboardType: TextInputType.number,
      style: context.textTheme.bodyLarge
          ?.copyWith(color: context.theme.iconTheme.color),
      decoration: InputDecoration(
        filled: true,
        fillColor: context.theme.cardColor,
        hintText: 'Цена',
        suffixText: '₽',
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide.none,
        ),
      ),
      inputFormatters: [
        FilteringTextInputFormatter.digitsOnly,
        LengthLimitingTextInputFormatter(15),
      ],
    );
  }
}
