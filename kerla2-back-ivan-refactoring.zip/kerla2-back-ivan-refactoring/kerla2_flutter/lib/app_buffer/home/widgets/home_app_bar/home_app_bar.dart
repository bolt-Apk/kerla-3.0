import 'package:animated_size_and_fade/animated_size_and_fade.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kerla2_flutter/app_buffer/home/widgets/home_app_bar/search/providers.dart';
import 'package:kerla2_flutter/app_buffer/home/widgets/home_app_bar/search/widgets/search_bar.dart';
import 'package:kerla2_flutter/app_buffer/home/widgets/home_app_bar/search/widgets/search_mode_button.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

import 'widgets/notification_button.dart';

import 'search/widgets/search_toggle_button.dart';
import 'widgets/tab_selector.dart';

class HomeAppBar extends HookConsumerWidget implements PreferredSizeWidget {
  const HomeAppBar({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isSearchFieldVisibleValue = ref.watch(isSearchFieldVisible);

    // final controller = useTextEditingController();

    return AppBar(
      title: AnimatedSizeAndFade(
        sizeDuration: const Duration(milliseconds: 100),
        fadeDuration: const Duration(milliseconds: 100),
        fadeInCurve: Curves.linear,
        child: isSearchFieldVisibleValue
            ? const SearchBarWidget()
            : const TabSelector(),
      ),
      elevation: 1,
      actions: [
        if (isSearchFieldVisibleValue) const SearchIconMode(),
        const SearchToggleButton(),
        if (!isSearchFieldVisibleValue) ...[
          const Gap(8),
          const NotificationButton(),
        ],
      ],
      backgroundColor: context.theme.canvasColor,
    );
  }

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);
}
