import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerla2_flutter/app/profile/settings/widgets/edit_notification_persmissions_widget.dart';
import 'package:kerla2_flutter/app/profile/settings/widgets/edit_phone_widget.dart';
import 'package:kerla2_flutter/app/profile/settings/widgets/sign_out_button.dart';
import 'package:kerla2_flutter/app/profile/settings/widgets/version_info.dart';
import 'package:kerla2_flutter/app_buffer/profile/background_image_widget.dart';
import 'package:kerla2_flutter/app_buffer/profile/profile_settings/promo_level/bonus_bottom_sheet.dart';
import 'package:kerla2_flutter/app_buffer/profile/profile_settings/widgets/business_info_widget.dart';
import 'package:kerla2_flutter/app_buffer/profile/profile_settings/widgets/edit_avatar_widget.dart';
import 'package:kerla2_flutter/app_buffer/profile/profile_settings/widgets/promocode_activation_widget.dart';
import 'package:kerla2_flutter/app_buffer/profile/profile_settings/widgets/edit_city_widget.dart';
import 'package:kerla2_flutter/auth/widgets/auth_bottom_sheet.dart';
import 'package:kerla2_flutter/common/user_profile_extension.dart';
import 'package:kerla2_flutter/common/user_profile_ref_extensions.dart';
import 'package:kerla2_flutter/core/core.dart';

import 'package:kerla2_flutter/router/navigation_zones/auth_navigation_zone.dart';
import 'package:kerla2_flutter/router/router.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_app/nit_app.dart';
import 'package:nit_router/nit_router.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';
import 'package:share_plus/share_plus.dart';

import '../../../app/profile/settings/widgets/edit_profile_description_widget.dart';
import 'widgets/delete_account_button.dart';
import 'widgets/load_cover_widget.dart';

class ProfileSettingsPage extends ConsumerWidget {
  const ProfileSettingsPage({
    super.key,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    //TODO: fix this

    // final promoExpiredDate =
    //     ref.read(userProvider(id: state.user!.id!)).maybeWhen(
    //           data: (user) => user?.promoEndsAt != null
    //               ? DateFormat('dd.MM.yyyy HH:mm').format(user!.promoEndsAt!)
    //               : null,
    //           orElse: () => null,
    //         );

    // final userId = ref.signedInUserId!;

    return Scaffold(
      backgroundColor: context.theme.canvasColor,
      extendBodyBehindAppBar: true,
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        leading: IconButton.filledTonal(
          onPressed: () => context.pop(),
          style: IconButton.styleFrom(
            backgroundColor: Colors.black.withOpacity(0.4),
          ),
          color: Colors.white,
          icon: const Icon(Icons.arrow_back_ios_new),
        ),
      ),
      body: SafeArea(
        top: false,
        child: ref.watchUserProfileCustom(ref.signedInUserId!).nitWhen(
          childBuilder: (userProfile) {
            return Column(
              children: [
                Stack(
                  alignment: Alignment.bottomCenter,
                  children: [
                    Container(
                      color: Colors.black.withOpacity(0.2),
                      height: MediaQuery.sizeOf(context).height * 0.35,
                      width: double.infinity,
                      child: BackgroundImageWidget(
                        userId: userProfile.userId,
                      ),
                    ),
                    Column(
                      children: [
                        EditAvatarWidget(
                          userId: userProfile.userId,
                        ),
                        if (userProfile.isBusiness(ref))
                          const BusinessInfoWidget(),
                      ],
                    ),
                    if (userProfile.isBusiness(ref))
                      const Positioned(
                        top: 100,
                        child: LoadCoverWidget(),
                      ),
                  ],
                ),
                Expanded(
                  child: Material(
                    color: Theme.of(context).canvasColor,
                    child: ListView(
                      shrinkWrap: true,
                      padding: EdgeInsets.zero,
                      children: [
                        const EditNotificationPermissionsWidget(),
                        const EditProfileDescriptionWidget(),
                        TextSettingsRow(
                          title: 'E-mail:',
                          subtitle: userProfile.email ?? 'почта не указана',
                          // editingBottomSheet: TextEditingBottomSheet(
                          //   title: 'E-mail:',
                          //   keyboardType: TextInputType.emailAddress,
                          //   maxLength: 120,
                          // ),
                        ),
                        TextSettingsRow(
                          title: 'Пароль:',
                          subtitle: '*********',
                          onTap: (c) async {
                            await c.showAuthBottomSheet(
                              initPart: AuthAreaNavigationZone.recover,
                            );
                          },
                        ),
                        const EditPhoneWidget(),
                        const EditCityWidget(),
                        const PromocodeActivationWidget(),

                        const TextSettingsRow(
                          title: 'Награды',
                          subtitle: '',
                          editingBottomSheet: BonusBottomSheet(),
                        ),
                        if (userProfile.phoneNumber != null)
                          TextSettingsRow(
                            title: 'Показывать мой телефон в объявлении',
                            subtitle: '',
                            endWidget: SwitchWidget(
                              isActive: userProfile.showPhone,
                              onTap: () {
                                final newShowPhone =
                                    !userProfile.showPhone; // Toggle the value
                                ref.saveModel(userProfile.copyWith(
                                    showPhone: newShowPhone));
                                return newShowPhone;
                              },
                            ),
                          ),

                        TextButton(
                          onPressed: () => SharePlus.instance.share(
                            ShareParams(
                              text:
                                  'Регистрируйся в приложении КЕРЛА по промокоду ${userProfile.userName} и получай бонусы для продвижения своих объявлений! Присоединяйтесь по ссылке: https://onelink.to/75qux8',
                            ),
                          ),
                          child: const Text(
                            'Пригласить пользователей',
                          ),
                        ),

                        TextButton(
                          onPressed: () => client.promocode.testImitateInvite(),
                          child: const Text(
                            'Имитация того что по вашему промокоду зарегестрировались',
                            textAlign: TextAlign.center,
                          ),
                        ),

                        // const SwitchSettingsRow(
                        //   title: 'Показывать мой телефон в объявлен...',
                        //   isActive: false,
                        // ),
                        // const SwitchSettingsRow(
                        //   title: 'Комментарии в объявлениях',
                        //   isActive: true,
                        // ),
                        if (!userProfile.isBusiness(ref))
                          Center(
                            child: TextButton(
                              onPressed: () async {
                                if (context.mounted) {
                                  context.pushNamed(
                                    MainAreaNavigationZone.businessProfile.name,
                                  );
                                }
                              },
                              child: Text('Оформить бизнес профиль',
                                  style:
                                      Theme.of(context).textTheme.displayLarge),
                            ),
                          ),
                        const Center(
                          child: SignOutButton(),
                        ),
                        const Center(
                          child: DeleteAccountButton(),
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        const VersionInfo(),
                        const SizedBox(
                          height: 10,
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
      // ),
    );
  }
}
