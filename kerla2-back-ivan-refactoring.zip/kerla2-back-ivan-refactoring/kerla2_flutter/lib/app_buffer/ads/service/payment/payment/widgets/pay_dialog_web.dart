// ignore: avoid_web_libraries_in_flutter
import 'dart:html';
import 'dart:ui_web';

import 'package:flutter/material.dart';

class PayDialog extends StatefulWidget {
  final String paymentUrl;

  const PayDialog({required this.paymentUrl, super.key});

  @override
  State<PayDialog> createState() => _PayDialogState();
}

class _PayDialogState extends State<PayDialog> {
  late IFrameElement _iFrameElement;
  late String iframeKey;

  @override
  void initState() {
    super.initState();
    iframeKey = 'iframe${widget.paymentUrl.split('/').last}';
    _iFrameElement = IFrameElement()
      ..src = widget.paymentUrl
      ..style.height = '100%'
      ..style.width = '100%'
      ..style.border = 'none'
      ..style.scrollBehavior = 'auto';

    platformViewRegistry.registerViewFactory(
      iframeKey,
      (int viewId) => _iFrameElement,
    );
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: MediaQuery.of(context).size.height,
      width: MediaQuery.of(context).size.width,
      child: HtmlElementView(
        viewType: iframeKey,
      ),
    );
  }
}
