import 'package:intl/intl.dart';
import 'package:kerla2_client/kerla2_client.dart';

extension AdPriceExtencion on Ad {
  String get formattedPrice {
    final formatter = NumberFormat('#,###');
    return '${formatter.format(price).replaceAll(',', ' ')} ₽';
  }
}
