// import 'package:flutter/material.dart';
// import 'package:flutter_riverpod/flutter_riverpod.dart';
// import 'package:intl/intl.dart';
// import 'package:kerla2_flutter/core/core.dart';
// import 'package:nit_router/nit_router.dart';

// import '../../../../core/app_scaffold.dart';

// class PaymentsStausPage extends ConsumerWidget {
//   const PaymentsStausPage({super.key});

//   @override
//   Widget build(BuildContext context, WidgetRef ref) {
//     return AppScaffold(
//       appBar: AppBar(),
//       body: FutureBuilder(
//         future: client.payment.getPayments(),
//         builder: (context, snapshot) {
//           if (snapshot.connectionState != ConnectionState.done) {
//             return const Center(
//               child: CircularProgressIndicator(),
//             );
//           }

//           if (snapshot.data == null || snapshot.data!.isEmpty) {
//             return const Center(
//               child: Text('Данные о покупках не найдены'),
//             );
//           }

//           return ListView.builder(
//             itemCount: snapshot.data!.length,
//             itemBuilder: (context, index) {
//               final amount = snapshot.data![index].amount ~/ 100;
//               final date = snapshot.data![index].createdAt;
//               final status = snapshot.data![index].status;
//               return ListTile(
//                 title: Row(
//                   children: [
//                     Column(
//                       children: [
//                         Text('Сумма: $amount₽'),
//                         Text(
//                           DateFormat('yyyy-MM-dd – kk:mm')
//                               .format(date.toLocal()),
//                         ),
//                         Text(status.toString()),
//                       ],
//                     ),
//                     if (status == 'Status.authorized' ||
//                         status == 'Status.confirmed')
//                       ElevatedButton(
//                         onPressed: () {
//                           client.payment
//                               .cancelPayment(snapshot.data![index].id!);
//                           context.pop();
//                         },
//                         child: const Text('Отменить'),
//                       ),
//                   ],
//                 ),
//               );
//             },
//           );
//         },
//       ),
//     );
//   }
// }

// class CapchaDialog {
//   static Future<bool?> showCapchaDialog(BuildContext context) async {
//     final passController = TextEditingController();
//     return showDialog<bool>(
//       context: context,
//       builder: (BuildContext context) {
//         return AlertDialog(
//           title: const Text('Подтверждение'),
//           content: TextField(controller: passController),
//           actions: <Widget>[
//             ElevatedButton(
//               child: const Text(
//                 'Продолжить',
//               ),
//               onPressed: () {
//                 if (passController.text == '141592') {
//                   Navigator.pop(context, true);
//                 }
//               },
//             )
//           ],
//         );
//       },
//     );
//   }
// }
