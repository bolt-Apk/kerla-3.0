part of '../ui_kit.dart';

extension DefaultFlashContextExtension on BuildContext {
  Future showDefaultErrorFlash(String error) async {
    return this.showFlash<bool>(
      duration: const Duration(seconds: 3),
      builder: (context, controller) {
        // TODO: ХЗ зачем тут был консьюмер, вероятно, он не нужен. В любом случае, лучше все это выпилить и использовать nit_riverpod_notifications
        // return Consumer(
        //   builder: (context, ref, _) {
        return DefaultErrorFlash(
          error: error,
          controller: controller,
          //   );
          // },
        );
      },
    );
  }
}

class DefaultErrorFlash extends StatelessWidget {
  final String error;
  final FlashController controller;
  final double? maxWidth;

  const DefaultErrorFlash({
    required this.error,
    required this.controller,
    this.maxWidth,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Theme(
      data: Theme.of(context).copyWith(
        extensions: const [FlashBarTheme()],
      ),
      child: FlashBar(
        margin: maxWidth != null && MediaQuery.sizeOf(context).width > maxWidth!
            ? EdgeInsets.symmetric(
                horizontal:
                    (MediaQuery.sizeOf(context).width - maxWidth!) / 2 + 32,
                vertical: 16,
              )
            : const EdgeInsets.symmetric(
                vertical: 16,
                horizontal: 32,
              ),
        controller: controller,
        behavior: FlashBehavior.floating,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(8)),
        ),
        clipBehavior: Clip.antiAlias,
        icon: const Icon(
          Icons.error_outline,
          color: Colors.red,
        ),
        contentTextStyle:
            Theme.of(context).textTheme.bodyMedium?.copyWith(height: 1),
        content: Text(
          error,
        ),
      ),
    );
  }
}
