// import 'package:kerla2_flutter/core/core.dart';
// import 'package:riverpod_annotation/riverpod_annotation.dart';
// import 'package:serverpod_auth_client/module.dart';

// part 'subscribers_state.g.dart';

// @riverpod
// Future<List<UserInfoPublic>> getSubs(
//     GetSubsRef ref, int userId, bool isSubscribers) {
//   return isSubscribers
//       ? client.subscription.getSubscribers(userId: userId)
//       : client.subscription.getSubscriptions(userId: userId);
// }
