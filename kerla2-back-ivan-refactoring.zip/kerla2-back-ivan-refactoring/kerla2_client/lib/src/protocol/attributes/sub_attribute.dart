/* AUTOMATICALLY GENERATED CODE DO NOT MODIFY */
/*   To generate run: "serverpod generate"    */

// ignore_for_file: implementation_imports
// ignore_for_file: library_private_types_in_public_api
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: public_member_api_docs
// ignore_for_file: type_literal_in_constant_pattern
// ignore_for_file: use_super_parameters

// ignore_for_file: no_leading_underscores_for_library_prefixes
import 'package:serverpod_client/serverpod_client.dart' as _i1;
import '../protocol.dart' as _i2;

abstract class SubAttribute implements _i1.SerializableModel {
  SubAttribute._({
    this.id,
    required this.parentAttributeId,
    required this.type,
    this.parentAttributeName,
    this.values,
    this.title,
  });

  factory SubAttribute({
    int? id,
    required int parentAttributeId,
    required _i2.AttributeType type,
    String? parentAttributeName,
    List<String>? values,
    String? title,
  }) = _SubAttributeImpl;

  factory SubAttribute.fromJson(Map<String, dynamic> jsonSerialization) {
    return SubAttribute(
      id: jsonSerialization['id'] as int?,
      parentAttributeId: jsonSerialization['parentAttributeId'] as int,
      type: _i2.AttributeType.fromJson((jsonSerialization['type'] as int)),
      parentAttributeName: jsonSerialization['parentAttributeName'] as String?,
      values: (jsonSerialization['values'] as List?)
          ?.map((e) => e as String)
          .toList(),
      title: jsonSerialization['title'] as String?,
    );
  }

  /// The database id, set if the object has been inserted into the
  /// database or if it has been fetched from the database. Otherwise,
  /// the id will be null.
  int? id;

  int parentAttributeId;

  _i2.AttributeType type;

  String? parentAttributeName;

  List<String>? values;

  String? title;

  SubAttribute copyWith({
    int? id,
    int? parentAttributeId,
    _i2.AttributeType? type,
    String? parentAttributeName,
    List<String>? values,
    String? title,
  });
  @override
  Map<String, dynamic> toJson() {
    return {
      if (id != null) 'id': id,
      'parentAttributeId': parentAttributeId,
      'type': type.toJson(),
      if (parentAttributeName != null)
        'parentAttributeName': parentAttributeName,
      if (values != null) 'values': values?.toJson(),
      if (title != null) 'title': title,
    };
  }

  @override
  String toString() {
    return _i1.SerializationManager.encode(this);
  }
}

class _Undefined {}

class _SubAttributeImpl extends SubAttribute {
  _SubAttributeImpl({
    int? id,
    required int parentAttributeId,
    required _i2.AttributeType type,
    String? parentAttributeName,
    List<String>? values,
    String? title,
  }) : super._(
          id: id,
          parentAttributeId: parentAttributeId,
          type: type,
          parentAttributeName: parentAttributeName,
          values: values,
          title: title,
        );

  @override
  SubAttribute copyWith({
    Object? id = _Undefined,
    int? parentAttributeId,
    _i2.AttributeType? type,
    Object? parentAttributeName = _Undefined,
    Object? values = _Undefined,
    Object? title = _Undefined,
  }) {
    return SubAttribute(
      id: id is int? ? id : this.id,
      parentAttributeId: parentAttributeId ?? this.parentAttributeId,
      type: type ?? this.type,
      parentAttributeName: parentAttributeName is String?
          ? parentAttributeName
          : this.parentAttributeName,
      values: values is List<String>?
          ? values
          : this.values?.map((e0) => e0).toList(),
      title: title is String? ? title : this.title,
    );
  }
}
