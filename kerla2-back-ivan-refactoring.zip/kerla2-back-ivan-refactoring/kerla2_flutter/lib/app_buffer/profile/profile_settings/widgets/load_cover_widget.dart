import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_svg/svg.dart';
import 'package:kerla2_flutter/common/user_profile_ref_extensions.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_app/nit_app.dart';
import 'package:nit_riverpod_notifications/nit_riverpod_notifications.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class LoadCoverWidget extends ConsumerWidget {
  const LoadCoverWidget({
    super.key,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final userProfile = ref.currentUserProfile!;
    return SizedBox(
      width: 160,
      child: Column(
        children: [
          Material(
            color: context.theme.canvasColor,
            borderRadius: BorderRadius.circular(4),
            child: InkWell(
              onTap: () async {
                final image = await ref.pickAndUploadImage();
                if (image == null) {
                  ref.notifyUser('Ошибка загрузки');
                  return;
                }
                ref.saveModel(
                    userProfile.copyWith(backgroundImageUrl: image.publicUrl));
              },
              child: Padding(
                padding: const EdgeInsets.all(8),
                child: Row(
                  children: [
                    SvgPicture.asset(
                      AppIconsSvg.picture,
                      height: 12,
                      width: 12,
                      colorFilter: ColorFilter.mode(
                          context.theme.iconTheme.color!, BlendMode.srcIn),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      userProfile.backgroundImageUrl != null
                          ? 'Изменить обложку'
                          : 'Загрузить обложку',
                      style: Theme.of(context).textTheme.displayLarge,
                    ),
                  ],
                ),
              ),
            ),
          ),
          if (userProfile.backgroundImageUrl != null)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Material(
                borderRadius: BorderRadius.circular(4),
                child: InkWell(
                  onTap: () async {
                    await ref.saveModel(
                      userProfile.copyWith(backgroundImageUrl: null),
                    );
                    ref.notifyUser('Обложка удалена');
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(8),
                    child: Row(
                      children: [
                        SvgPicture.asset(
                          AppIconsSvg.delete,
                          height: 12,
                          width: 12,
                          colorFilter: ColorFilter.mode(
                            Colors.red,
                            BlendMode.srcIn,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          'Удалить обложку',
                          style: Theme.of(context)
                              .textTheme
                              .displayLarge
                              ?.copyWith(
                                color: Colors.red,
                              ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            )
        ],
      ),
    );
  }
}
