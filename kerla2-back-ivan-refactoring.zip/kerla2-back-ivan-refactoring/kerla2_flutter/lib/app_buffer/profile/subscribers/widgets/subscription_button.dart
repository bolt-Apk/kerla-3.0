import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:guarded_button/guarded_button.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class SubscriptionButton extends ConsumerWidget {
  final bool isSubscribed;
  final VoidCallback? onPressed;
  final void Function(BuildContext)? onSubscriptionTap;

  const SubscriptionButton({
    super.key,
    this.isSubscribed = false,
    this.onPressed,
    this.onSubscriptionTap,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // TODO: Replace with actual auth check
    // if (!ref.signedIn) {
    //   return _SignInButton(onPressed: onPressed);
    // }

    return isSubscribed
        ? _SubscribedButton(onTap: onSubscriptionTap)
        : _SubscribeButton(onPressed: onPressed);
  }
}

class _SubscribeButton extends StatelessWidget {
  final VoidCallback? onPressed;

  const _SubscribeButton({this.onPressed});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 120,
      height: 38,
      child: GuardedElevatedButton(
        guard: Guard(),
        style: ElevatedButton.styleFrom(
          backgroundColor: ThemePrimaryColors.primary,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(5),
          ),
          padding: const EdgeInsets.symmetric(vertical: 10),
        ),
        onPressed: onPressed,
        child: Text(
          'Подписаться',
          style: context.textTheme.displayLarge?.copyWith(
            color: ThemePrimaryColors.white,
          ),
        ),
      ),
    );
  }
}

class _SubscribedButton extends StatelessWidget {
  final void Function(BuildContext)? onTap;

  const _SubscribedButton({this.onTap});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return TextSettingsRow(
      boxColor: theme.secondaryHeaderColor,
      title: '           ',
      borderRadius: BorderRadius.circular(5),
      titelFontSize: 9,
      iconSize: 13,
      subtitleFontSize: 15,
      spaceBetweenObjects: 0,
      endSizedBoxWidth: 5,
      columnPadding: const EdgeInsets.symmetric(horizontal: 0, vertical: 10),
      iconEnd: Icons.arrow_drop_down,
      subtitle: 'Подписан',
      useDivider: false,
      onTap: onTap != null ? (context) => onTap!(context) : null,
    );
  }
}
