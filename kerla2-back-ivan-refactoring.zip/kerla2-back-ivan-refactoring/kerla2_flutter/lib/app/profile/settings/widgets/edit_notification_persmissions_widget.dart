import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/core/app_repository.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_app/nit_app.dart';
import 'package:nit_router/nit_router.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class EditNotificationPermissionsWidget extends HookConsumerWidget {
  const EditNotificationPermissionsWidget({
    super.key,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return const TextSettingsRow(
      title: 'Уведомления',
      subtitle: '',
      editingBottomSheet: _NotificationPermissionsBottomSheet(),
    );
  }
}

class _NotificationPermissionsBottomSheet extends HookConsumerWidget {
  const _NotificationPermissionsBottomSheet();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return ref
        .watchOrFetchModelAsync(ref.signedInUserId!,
            AppRepository.notificationPermissionByUserId.descriptor)
        .nitWhen(
      childBuilder: (notificationPermission) {
        final permissionList = useState(notificationPermission.permissionList);
        return DecoratedBox(
          decoration: BoxDecoration(color: context.theme.canvasColor),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const LittleDivider(),
              Text(
                'Уведомления',
                style: context.textTheme.headlineMedium?.copyWith(
                  fontWeight: FontWeight.w500,
                ),
              ),
              ...[
                (
                  NotificationPermissionType.newMessage,
                  'Сообщения',
                  'Уведомлять меня о получении новых сообщений',
                  AppIconsSvg.chats,
                ),
                (
                  NotificationPermissionType.newSubsribedAd,
                  'Новые публикации объявлений',
                  'Уведомлять меня о публикациях объявлений пользователей на которых я подписан',
                  AppIconsSvg.comment
                ),
                (
                  NotificationPermissionType.newSubscribedStory,
                  'Новые публикации сторисов',
                  'Уведомлять меня о публикациях сторисов пользователей на которых я подписан',
                  AppNavigationIconsSvg.stories
                ),
                (
                  NotificationPermissionType.newSubscriber,
                  'Новые подписчики',
                  'Уведомлять меня о новых подписчиках',
                  AppIconsSvg.man,
                ),
              ].map(
                (e) => Padding(
                  padding: const EdgeInsets.symmetric(vertical: 11),
                  child:
                      //  ValueListenableBuilder(
                      //   valueListenable: permissionList,
                      //   builder: (context, value, child) =>
                      AppointmentRow(
                    title: e.$2,
                    subtitle: e.$3,
                    iconName: e.$4,
                    isActive: permissionList.value.contains(e.$1),
                    onTap: () {
                      if (permissionList.value.contains(e.$1)) {
                        permissionList.value = permissionList.value
                            .where((element) => element != e.$1)
                            .toList();
                        return false;
                      } else {
                        permissionList.value = [e.$1, ...permissionList.value];
                        return true;
                      }
                    },
                  ),
                  // ),
                ),
              ),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 20),
                child: Text(
                  'Керла оставляет за собой право отправлять пользователям информационные сообщения',
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(bottom: 17),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    TextButton(
                      onPressed: context.pop,
                      child: Text(
                        'Отмена',
                        style:
                            Theme.of(context).textTheme.titleMedium?.copyWith(
                                  color: Colors.grey,
                                ),
                      ),
                    ),
                    TextButton(
                      onPressed: ref.nitUiCallback(
                          () => ref.saveModel(
                                notificationPermission.copyWith(
                                  permissionList: permissionList.value,
                                ),
                              ),
                          followUpIfMountedAction: context.pop),
                      child: Text(
                        'Готово',
                        style:
                            Theme.of(context).textTheme.titleMedium?.copyWith(
                                  color: ThemePrimaryColors.primary,
                                ),
                      ),
                      // () => ref
                      //     .read(notificationPermissonStateProvider.notifier)
                      //     .saveList()
                      //     .then(
                      //       (value) => context.pop(),
                      //     ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
