import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/core/app_scaffold.dart';
import 'package:kerla2_flutter/router/router.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_router/nit_router.dart';

import '../state/ad_create_state.dart';
import '../media/state/selected_media_state.dart';
import 'widget/create_ad_text_field.dart';
import 'widget/selected_media_widget.dart';

class CreateAdPage extends HookConsumerWidget {
  const CreateAdPage({
    super.key,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final int? adId = ref.watchNavigationParam(AppNavigationParams.adId);
    ref.watch(createAdStateProvider(AdType.ad));
    final theme = Theme.of(context);
    final titleController = useTextEditingController();
    final descriptionController = useTextEditingController();

    return GestureDetector(
      onTap: () => FocusManager.instance.primaryFocus?.unfocus(),
      child: AppScaffold(
        backgroundColor: theme.scaffoldBackgroundColor,
        appBar: AppBar(
          leading: IconButton(
            color: theme.iconTheme.color,
            icon: const Icon(Icons.arrow_back),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          title: Text(
            "Новое объявление",
            style: theme.textTheme.headlineMedium,
          ),
          backgroundColor: theme.canvasColor,
          iconTheme: const IconThemeData(color: Colors.black),
          elevation: 1,
        ),
        body: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: SingleChildScrollView(
            child: Column(
              children: [
                CreateAdTextField(
                  symbolCount: 70,
                  hintText: "Пожалуйста, укажите заголовок",
                  title: "Заголовок",
                  controller: titleController,
                  minLines: 1,
                  maxLines: 3,
                ),
                CreateAdTextField(
                  symbolCount: 3000,
                  hintText: "Пожалуйста, укажите описание",
                  title: "Описание",
                  controller: descriptionController,
                  minLines: 2,
                  maxLines: 5,
                ),
                DecoratedBox(
                  decoration: BoxDecoration(
                    color: theme.canvasColor,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Padding(
                    padding: EdgeInsets.all(10.0),
                    child: AdSelectedMediaWidget(),
                  ),
                ),
              ],
            ),
          ),
        ),
        floatingActionButton: Consumer(
          builder: (context, ref, child) {
            final selectedAssets =
                ref.watch(adMediaStateProvider(adId: adId)).items;
            return selectedAssets.isEmpty
                ? const SizedBox()
                : Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: MainButton(
                      buttonText: 'Далее',
                      onTap: () {
                        FocusScope.of(context).unfocus();

                        final error = ref
                            .read(createAdStateProvider(AdType.ad).notifier)
                            .saveTitleDescription(
                              title: titleController.text,
                              description: descriptionController.text,
                            );

                        if (error != null) {
                          // ref.notifyUser(error); //TODO: сделать через ref.notifyUser
                          context.showDefaultErrorFlash(
                            error,
                          );
                          return;
                        }
                        ref
                            .read(adMediaStateProvider(adId: adId).notifier)
                            .startUploadMedia();

                        context.pushNamed(
                          AdNavigationZone.chooseCategoryCreateAd.name,
                        );
                      },
                    ),
                  );
          },
        ),
        floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
        floatingActionButtonAnimator: FloatingActionButtonAnimator.scaling,
        resizeToAvoidBottomInset: false,
      ),
    );
  }
}
