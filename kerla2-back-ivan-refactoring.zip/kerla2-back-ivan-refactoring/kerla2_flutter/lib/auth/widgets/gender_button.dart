import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_svg/svg.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class GenderButton extends ConsumerWidget {
  const GenderButton({
    super.key,
    required this.typeButton,
    required this.userGenderNotifier,
  });

  final UserGender typeButton;
  final ValueNotifier<UserGender?> userGenderNotifier;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final activeColor = context.colorScheme.primary;
    final disableColor = context.theme.cardColor;
    final bool choosenButton = (typeButton == UserGender.male &&
            userGenderNotifier.value == UserGender.male) ||
        (typeButton == UserGender.female &&
            userGenderNotifier.value == UserGender.female);

    return OutlinedButton(
      style: ElevatedButton.styleFrom(
        side: BorderSide(color: activeColor),
        foregroundColor: disableColor,
        backgroundColor: choosenButton ? activeColor : disableColor,
        padding: const EdgeInsets.all(8),
      ),
      onPressed: () {
        userGenderNotifier.value = typeButton;
      },
      child: Column(
        children: [
          SvgPicture.asset(
            typeButton == UserGender.male ? AppIconsSvg.man : AppIconsSvg.woman,
            height: 25,
            width: 25,
            colorFilter: ColorFilter.mode(
              choosenButton ? disableColor : context.theme.iconTheme.color!,
              BlendMode.srcIn,
            ),
          ),
          Text(
            typeButton == UserGender.male ? 'Мужчина' : 'Женщина',
            style: Theme.of(context).textTheme.displayLarge?.copyWith(
                  color: choosenButton ? disableColor : activeColor,
                ),
          ),
        ],
      ),
    );
  }
}
