part of '../ui_kit.dart';

class NavigationButton extends StatelessWidget {
  const NavigationButton({
    super.key,
    required this.imageAsset,
    required this.buttonText,
    required this.onTap,
    this.color = Colors.white,
    this.alignment = Alignment.centerLeft,
    this.imageSize = 25,
    this.fontSize = 20,
    this.fontColor = Colors.black,
    this.imageColor,
  });

  final String imageAsset;
  final String buttonText;
  final Color color;
  final VoidCallback onTap;
  final Alignment alignment;
  final double imageSize;
  final double fontSize;
  final Color fontColor;
  final Color? imageColor;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      child: Align(
        alignment: alignment,
        child: TextButton.icon(
          onPressed: onTap,
          icon: SvgPicture.asset(
            imageAsset,
            height: imageSize,
            width: imageSize,
            color: imageColor,
          ),
          label: Text(
            buttonText,
            style: TextStyle(
              fontSize: fontSize,
              color: fontColor,
            ),
          ),
        ),
      ),
    );
  }
}
