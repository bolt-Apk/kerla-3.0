import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class AddServiceCheckbox extends ConsumerWidget {
  const AddServiceCheckbox({
    super.key,
    required this.state,
    required this.onTap,
  });

  final bool state;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        alignment: Alignment.centerRight,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeInOutCubic,
          alignment: state ? Alignment.centerRight : Alignment.centerLeft,
          height: 20,
          width: 48,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(7),
            color: Colors.blue.withOpacity(0.1),
          ),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            curve: Curves.easeInOutCubic,
            height: 20,
            width: 20,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(7),
              color: state ? Colors.blue : Colors.blue.withOpacity(0.2),
            ),
          ),
        ),
      ),
    );
  }
}
