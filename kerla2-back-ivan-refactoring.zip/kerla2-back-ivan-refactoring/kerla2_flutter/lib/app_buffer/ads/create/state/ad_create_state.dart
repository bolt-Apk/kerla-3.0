import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/app_buffer/ads/representation/ad_list/state/ad_list_state.dart';
import 'package:kerla2_flutter/core/core.dart';
import 'package:nit_app/nit_app.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';

import '../media/state/selected_media_state.dart';

// part 'ad_create_state.freezed.dart';
part 'ad_create_state.g.dart';

// @riverpod
// class AdCreateState extends _$AdCreateState {
//   late int mediaLimit;

//   @override
//   AdCreateData build({required bool isStory}) {
//     ref.watch(promotionPricesProvider);

//     mediaLimit = isStory ? 1 : 20;

//     return AdCreateData.empty();
//   }

//   int get oneDayPrice {
//     if (state.promotions == null || state.promotions!.isEmpty) return -1;

//     return state.promotions!.fold(
//       0,
//       (sum, prom) =>
//           sum +
//           ref
//               .read(promotionPricesProvider.notifier)
//               .getPromotionPrice(prom.type),
//     );
//   }

//   bool isPromotionSelected(KerlaServiceType type) {
//     if (state.promotions == null || state.promotions!.isEmpty) return false;
//     return state.promotions!.firstWhereOrNull((p) => p.type == type) != null;
//   }

//   bool isPromotionContainsFree() {
//     if (state.promotions == null || state.promotions!.isEmpty) return false;
//     return state.promotions!.firstWhereOrNull((p) => p.isFree == true) != null;
//   }

//   void setCategoryAndSubcategory(AdCategory category, AdCategory subcategory) {
//     state = state.copyWith(
//       attribute: {},
//       category: category,
//       subcategory: subcategory,
//     );
//   }

//   // Future<List<Attribute>> getAttributes(WidgetRef ref) async {
//   //   if (state.subcategory == null) {
//   //     throw ArgumentError("subcategory == null");
//   //   }
//   //   final attributes = await ref.readSession.client.adCategory
//   //       .getAttributesByCategory(state.subcategory!);

//   //   return attributes;
//   // }

//   void removeCategory() {
//     state =
//         state.copyWith(category: null, subcategory: null, attribute: {}); //Тут
//   }

//   void removeSubcategory() {
//     state = state.copyWith(subcategory: null, attribute: {}); //Тут
//   }

//   Future<int?> createAd(BuildContext context) async {
//     if (state.isLoading) {
//       debugPrint("пока что нельзя отправите еще раз, отправка уже идет");
//       return null;
//     }

//     state = state.copyWith(isLoading: true);

//     final user = await ref.watch(signedInUserProfileStateProvider.future);

//     final Ad ad = Ad(
//       title: isStory ? state.description.text : state.title.text,
//       // isAd: !isStory,
//       // isStories: isPromotionSelected(KerlaServiceType.stories) || isStory,
//       price: user?.userProfile.isAdmin == true && isStory
//           ? 0
//           : int.parse(
//               state.attribute.entries
//                   .firstWhere(
//                     (entry) => entry.key.id == 1,
//                   )
//                   .value,
//             ),
//       description: state.description.text,
//       visitCount: 0,
//       // storiesViewsCount: 0,
//       status: AdStatus.active,
//       category: user?.userProfile.isAdmin == true && isStory
//           ? AdCategory(title: '', id: 5)
//           : state.subcategory,
//       onlyForGender: state.subcategory?.genderFilter == true ||
//               state.category?.genderFilter == true
//           ? user?.userProfile.gender
//           : null,
//       region: state.attribute.entries
//               .firstWhereOrNull(
//                 (entry) => entry.key.type == AttributeType.regionsDropdown,
//               )
//               ?.value ??
//           Region(
//             id: 2,
//             title: 'Москва',
//             latitude: 50,
//             longitude: 50,
//             radius: 50,
//           ),
//       media: [],
//       attributeValues: _convert(),
//       promotions: state.promotions,
//     );

//     final assetList = ref.read(selectedMediaStateProvider(limit: mediaLimit));

//     final editedImage = ref.read(editedFileFromAssetProvider);
//     if (editedImage != null) {
//       await _uploadMedia(ad, editedImage, MediaType.image, mime: 'jpg');
//     } else {
//       for (final asset in assetList) {
//         await _uploadAsset(ad, asset);
//       }
//     }

//     if (ad.media?.isEmpty == true) {
//       state = state.copyWith(isLoading: false);
//       if (context.mounted) {
//         context.showDefaultErrorFlash(
//           'Не удалось создать объявление',
//         );
//       }

//       return null;
//     }

//     final int? isAdCreated = await client.adManagement.createAd(ad);

//     debugPrint('Ad creation success: $isAdCreated');

//     state = AdCreateData.empty();
//     state = state.copyWith(isLoading: false);

//     if (isAdCreated != null) {
//       invalidateStates();
//     }

//     return isAdCreated;
//   }

//   void invalidateStates() {
//     ref.invalidate(selectedMediaStateProvider());
//     ref.invalidate(editedFileFromAssetProvider);
//     ref.invalidate(adListStateProvider);
//     ref.invalidateSelf();
//   }

//   Future<void> _uploadAsset(Ad ad, AssetEntity asset) async {
//     File? file = await asset.file;

//     if (file != null) {
//       final mediaType = switch (asset.type) {
//         AssetType.video => MediaType.video,
//         _ => MediaType.image,
//       };

//       if (mediaType == MediaType.video) {
//         MediaInfo? compressFile = await VideoCompress.compressVideo(
//           file.path,
//           quality: VideoQuality.DefaultQuality,
//           deleteOrigin: false, // It's false by default
//         );

//         if (compressFile?.file != null) {
//           file = compressFile!.file;
//         }
//         print('new file size ${compressFile?.filesize}');
//       }

//       final mime = asset.mimeType ?? file!.path.split('.').last;
//       final bytes = await file!.readAsBytes();
//       await _uploadMedia(ad, bytes, mediaType,
//           mime: mime, duration: asset.duration);
//     }
//   }

//   Future<void> _uploadMedia(
//     Ad ad,
//     Uint8List bytes,
//     MediaType mediaType, {
//     String? mime,
//     int? duration,
//   }) async {
//     final info = await client.adManagement.getFileUploadInfo(
//       mediaType: mediaType,
//       mimeType: mime,
//     );

//     if (info != null) {
//       final uploader = CustomFileUploader(info.uploadDescription, mediaType);

//       final success = await uploader.uploadByteData(
//         ByteData.view(bytes.buffer),
//       );

//       if (!success) {
//         debugPrint('File upload failed');

//         return;
//       }

//       final media =
//           await client.adManagement.createMedia(info, mediaType, duration ?? 0);

//       if (media == null) {
//         debugPrint('Media creation failed');

//         return;
//       }

//       ad.media ??= [];
//       // ad.media!.add(media);
//     }
//   }

//   bool isPriceEmpty() {
//     return state.attribute.entries
//             .firstWhereOrNull(
//               (entry) => entry.key.id == 1,
//             )
//             ?.value
//             .toString()
//             .isEmpty ??
//         true;
//   }

//   void setAttribute<T>(Attribute attribute, T value) async {
//     // final Map<Attribute, dynamic> newMap = {};
//     // newMap.addAll(state.attribute);
//     // newMap[attribute] = value;
//     // state = state.copyWith(
//     //   attribute: newMap,
//     // );
//     removeAttribute(attribute);
//     if (attribute.hasSubAttribute == true) {
//       ref
//           .read(attributeStateProvider(state.subcategory).notifier)
//           .addSubAttributeToState(attribute, value as String);

//       //TODO: pass here correct value
//     }

//     if (attribute.type == AttributeType.regionsDropdown) {
//       final region = ref
//           .read(regionsProvider)
//           .firstWhere((element) => element.title == value); // Region
//       state = state.copyWith(
//         attribute: {
//           ...state.attribute,
//           attribute: region,
//         },
//       );
//       return;
//     }

//     state = state.copyWith(
//       attribute: {
//         ...state.attribute,
//         attribute: value,
//       },
//     );
//   }

//   void removeAttribute(Attribute attribute) {
//     final newMap = Map.of(state.attribute);

//     if (attribute.hasSubAttribute == true) {
//       newMap.removeWhere(
//         (key, value) => key.id == attribute.id && key.hasSubAttribute != true,
//       );
//     }

//     newMap.removeWhere(
//       (key, value) =>
//           key.isEqual(attribute) &&
//           key.subAttributeId == attribute.subAttributeId,
//     );

//     state = state.copyWith(attribute: newMap);

//     //TODO: look for this maybe isEqual wont work. try compare by title

//     debugPrint('Attribute removed: $attribute');
//   }

//   void removeSubAttribute(Attribute subAttribute) {
//     final newMap = Map.of(state.attribute);

//     newMap.removeWhere(
//       (key, value) => key.subAttributeId == subAttribute.subAttributeId,
//     );
//     state = state.copyWith(attribute: newMap);

//     //TODO: look for this maybe isEqual wont work. try compare by title

//     debugPrint('SubAttribute removed: $subAttribute');
//   }

//   String getValueByAttribute(Attribute attr) {
//     if (state.attribute[attr] is Region) {
//       return state.attribute[attr].title;
//     }
//     return state.attribute[attr] ?? '';
//   }

//   void switchPromotionState(KerlaServiceType type, int? adId) async {
//     final List<KerlaService> proms = [...state.promotions ?? []];

//     final endsFreePromotion = ref
//         .read(promotionPricesProvider.notifier)
//         .getEndsAtForFreePromotion(type);

//     final isFreePromotion = endsFreePromotion != null;

//     final endsAt = endsFreePromotion ??
//         DateTime.now().add(Duration(days: state.daysBySlider));

//     final promotionPrice =
//         ref.read(promotionPricesProvider.notifier).getPromotionPrice(type);

//     final user = await ref
//         .watch(signedInUserProfileStateProvider.future); // ref.signedInUser;
//     final isBuisnessService =
//         (user?.userProfile.isBusiness == true) && promotionPrice == 0;

//     if (proms.firstWhereOrNull((element) => element.type == type) != null) {
//       proms.removeWhere((element) => element.type == type);
//     } else {
//       switch (type) {
//         case KerlaServiceType.turbo:
//           if (isPromotionSelected(KerlaServiceType.boost)) {
//             proms.removeWhere(
//               (element) => element.type == KerlaServiceType.boost,
//             );
//           }
//           proms.add(
//             KerlaService(
//               type: type,
//               endsAt: endsAt,
//               adId: adId,
//               isFree: isFreePromotion,
//             ),
//           );
//         case KerlaServiceType.boost:
//           if (isPromotionSelected(KerlaServiceType.turbo)) {
//             proms.removeWhere(
//               (element) => element.type == KerlaServiceType.turbo,
//             );
//           }
//           proms.add(
//             KerlaService(
//               type: type,
//               endsAt: endsAt,
//               adId: adId,
//               isFree: isFreePromotion,
//             ),
//           );
//         case KerlaServiceType.stories:
//           proms.add(
//             KerlaService(
//               type: type,
//               endsAt: isBuisnessService
//                   ? user!.userProfile.businessEndsAt!
//                   : endsAt,
//               adId: adId,
//               isFree: isFreePromotion || isBuisnessService ? true : null,
//             ),
//           );
//         default:
//       }
//     }

//     state = state.copyWith(promotions: proms);
//   }

//   Future<bool> updatePromotions(int? adId) async {
//     if (adId == null) {
//       debugPrint('ad id is null');
//       return false;
//     }

//     if (state.isLoading) {
//       debugPrint("пока что нельзя отправите еще раз, отправка уже идет");
//       return false;
//     }

//     state = state.copyWith(isLoading: true);

//     if (state.promotions != null && state.promotions!.isNotEmpty) {
//       final promotions = state.promotions!.map((e) {
//         e.adId = adId;
//         return e;
//       }).toList();
//       final result = await client.adManagement
//           .updateServiceTime(promotions, adId, ref.signedInUserId!);
//       //updates ads
//       ref.invalidate(adListStateProvider);
//       ref.invalidate(usersWithStoriesProvider);
//       state = state.copyWith(isLoading: false);
//       return result;
//     } else {
//       debugPrint('services not found');
//       state = state.copyWith(isLoading: false);
//       return false;
//     }
//   }

//   void setCountOfDays(int days) {
//     for (KerlaService p in state.promotions ?? []) {
//       p.endsAt = DateTime.now().add(Duration(days: days));
//     }
//     state = state.copyWith(daysBySlider: days);
//   }

//   List<AdAttributeValue> _convert() {
//     final List<AdAttributeValue> adAttributeValues =
//         state.attribute.entries.map((entry) {
//       dynamic value;
//       if (entry.value is Region) {
//         value = entry.value.title;
//       } else if (entry.value is KerlaColors) {
//         final color = entry.value;

//         value = KerlaColors.values[color.index].toString();
//       } else {
//         value = entry.value;
//       }

//       return AdAttributeValue(
//         attributeId: entry.key.id!,
//         value: value,
//         subAttributeId: entry.key.subAttributeId,
//       );
//     }).toList();

//     return adAttributeValues;
//   }
// }

// @freezed
// class AdCreateData with _$AdCreateData {
//   const factory AdCreateData({
//     required TextEditingController description,
//     required TextEditingController title,
//     List<KerlaService>? promotions,
//     AdCategory? category,
//     AdCategory? subcategory,
//     @Default(1) int daysBySlider,
//     @Default(70) int titleSymbolCount,
//     @Default(3000) int descriptionSymbolCount,
//     @Default({}) Map<Attribute, dynamic> attribute,
//     @Default(false) bool isLoading,
//   }) = _AdCreateData;

//   factory AdCreateData.empty() => _AdCreateData(
//         description: TextEditingController(),
//         title: TextEditingController(),
//       );
// }

// @riverpod
// class PromotionPrices extends _$PromotionPrices {
//   @override
//   List<KerlaServicePrice> build() {
//     state = List.empty();
//     _init();
//     return state;
//   }

//   void _init() async {
//     state = await client.adManagement.getAdPromotionPrices();
//   }

//   int getPromotionPrice(KerlaServiceType type) {
//     return state.firstWhereOrNull((e) => e.type == type)?.cost ?? -1;
//   }

//   DateTime? getEndsAtForFreePromotion(KerlaServiceType type) {
//     return state.firstWhereOrNull((e) => e.type == type)?.endsAt;
//   }
// }

@riverpod
class AttributeState extends _$AttributeState {
  @override
  FutureOr<List<Attribute>> build(AdCategory? subcategory) async {
    if (subcategory == null) {
      return [];
    }
    final attributes =
        await client.adCategory.getAttributesByCategory(subcategory);

    // ref.invalidate(attributeDropDownValueProvider);
    // ref.invalidate(attributeRangeProvider); //TODO: remove

    return attributes;
  }

  Future<List<Attribute>> addSubAttributeToState(
      Attribute attribute, String value) async {
    final subAttribute =
        await client.adCategory.getSubAttributeByAttribute(attribute, value);

    final List<Attribute> newState = [];

    for (var element in subAttribute) {
      newState.add(
        Attribute(
          id: element
              .parentAttributeId, //TODO: check for this. Maybe make AttrtributeValue is nullable
          type: element.type,
          title: element.title,
          values: element.values,
          subAttributeId: element.id,
          order: attribute.order,
        ),
      );
    }

    return newState;
  }
}

enum PublicationStep {
  titleDescrtiptionPhoto,
  category,
  attributes,
}

@riverpod
class CreateAdState extends _$CreateAdState {
  @override
  Ad build(AdType adType, {int? adId}) {
    ref.onDispose(() {
      // ref.invalidate(getAdByIdProvider(adId));
      ref.invalidate(adMediaStateProvider(adId: adId));
      ref.invalidate(adListStateProvider);
    });
    if (adId != null) {
      final ad = ref.readModel<Ad>(adId);
      return ad.copyWith();
    }
    return Ad(
      title: '',
      price: 0,
      description: '',
      visitCount: 0,
      status: AdStatus.active,
      adType: adType,
    );
  }

  // void setPrice(int price) {
  //   state = state.copyWith(price: price);
  // }

  void setCategory(AdCategory? category) async {
    final attributeState =
        await ref.watch(attributeStateProvider(category).future);

    state = state.copyWith(
      category: category,
      attributeValues: (state.attributeValues?.isNotEmpty ?? false)
          ? state.attributeValues
          : attributeState
              .map(
                (e) => AdAttributeValue(
                  attribute: e,
                  attributeId: e.id!,
                  value: '',
                  subAttributeId: e.subAttributeId,
                ),
              )
              .toList(),
    );
  }

  /// Sets an attribute value for an ad.
  ///
  /// If the attribute has subattributes, adds them to the attribute list and
  /// inserts them after the current attribute.
  ///
  /// If the attribute value is not in the list of attribute values, adds it.
  ///
  /// Otherwise, updates the attribute value in the list of attribute values.
  void setAttribute(AdAttributeValue attribute) async {
    final currentAttributes = state.attributeValues ?? [];
    final index = currentAttributes.indexWhere(
      (element) =>
          element.attributeId == attribute.attributeId &&
          element.subAttributeId == attribute.subAttributeId,
    );
    if (index != -1) {
      currentAttributes[index] = attribute;

      if (attribute.attribute?.hasSubAttribute == true) {
        final newSubAttributes = await ref
            .read(attributeStateProvider(state.category).notifier)
            .addSubAttributeToState(attribute.attribute!, attribute.value);

        for (var element in newSubAttributes) {
          if (currentAttributes.indexWhere(
                  (e) => e.subAttributeId == element.subAttributeId) ==
              -1) {
            for (int i = 0; i < newSubAttributes.length; i++) {
              currentAttributes.insert(
                  index + 1 + i,
                  AdAttributeValue(
                    attribute: element,
                    attributeId: element.id!,
                    value: '',
                    subAttributeId: element.subAttributeId,
                  ));
            }
          }
        }
      }
    } else {
      currentAttributes.add(attribute);
    }
    state = state.copyWith(attributeValues: currentAttributes);
  }

  /// Publishes an ad and saves it to the server.
  ///
  /// Returns the id of the created ad if the ad was successfully created.
  /// Otherwise, returns null.
  ///
  /// The ad is created with the current state of attributes and media.
  /// The ad is not created if media is still uploading.
  Future<int?> publishAd() async {
    final mediaState = ref.read(adMediaStateProvider(adId: adId));
    if (mediaState.isUploading || mediaState.items.isEmpty) {
      return null;
    }

    final createdAdId = await ref.saveModel<Ad>(
      state.copyWith(
        media: ref
            .read(adMediaStateProvider(adId: adId).notifier)
            .getNitMediaList(),
      ),
    );

    if (createdAdId == null) {
      return null;
    }
    return createdAdId;
  }

  String? saveTitleDescription({
    String? title,
    String? description,
  }) {
    final trimmedTitle = title?.trim();
    final trimmedDescription = description?.trim();
    if (trimmedTitle != null && trimmedTitle.length <= 7) {
      return 'Заголовок слишком короткий';
    }
    if (trimmedDescription?.isEmpty == true) {
      return 'Необходимо заполнить описание';
    }
    state = state.copyWith(
      title: trimmedTitle ?? state.title,
      description: trimmedDescription ?? state.description,
    );
    return null;
  }

  void setDescription(String description) {
    state = state.copyWith(description: description);
  }
}
