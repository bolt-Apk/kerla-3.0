import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/app_buffer/ads/representation/detail_page/widgets/ad_block_warning.dart';
import 'package:kerla2_flutter/app_buffer/ads/representation/detail_page/widgets/ad_characteristics.dart';
import 'package:kerla2_flutter/app_buffer/ads/representation/detail_page/widgets/ad_description.dart';
import 'package:kerla2_flutter/app_buffer/ads/representation/detail_page/widgets/ad_header.dart';
import 'package:kerla2_flutter/common/is_my_profile.dart';
import 'package:kerla2_flutter/common/user_profile_ref_extensions.dart';
import 'package:kerla2_flutter/router/router.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_router/nit_router.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

import '../../../../core/app_scaffold.dart';
import '../ad_card/ad_app_bar/ad_app_bar.dart';
import '../ad_list/ads_grid.dart';
import 'ad_promotions_list.dart';
import '../ad_list/state/ad_list_state.dart';

class AdDetailPage extends ConsumerWidget {
  const AdDetailPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final adId = ref.watchNavigationParam(AppNavigationParams.adId);

    return ref.watch(getAdByIdProvider(adId)).nitWhen(
      childBuilder: (ad) {
        if (ad == null) {
          return Scaffold(
            appBar: AppBar(
              backgroundColor: context.theme.canvasColor,
            ),
            body: Center(
              child: Text(
                'Объявление не найдено',
                style: context.textTheme.headlineMedium,
              ),
            ),
          );
        }

        final isMyAd = ref.isMyProfile(ad.userId);
        final isBlocked = ref.currentUserProfile?.isAdmin != true &&
            ad.status == AdStatus.blocked;

        return AppScaffold(
          backgroundColor: context.theme.scaffoldBackgroundColor,
          extendBodyBehindAppBar: true,
          appBar: AdAppbar(
            ad: ad,
          ),
          body: ListView(
            controller: ScrollController(initialScrollOffset: 15),
            children: [
              AdImageCarousel(
                borderRadius: const BorderRadiusDirectional.only(
                  topStart: Radius.circular(6),
                  topEnd: Radius.circular(6),
                ),
                imageHeight: 300,
                urls: ad.media!,
                zoomable: true,
              ),
              AdHeader(ad: ad),
              const SizedBox(height: 8),
              if (isMyAd)
                AdPromotionList(
                  promotionList: ad.promotions,
                  adId: ad.id!,
                ),
              if (isBlocked) const AdBlockWarning(),
              AdDescription(ad: ad),
              Divider(
                color: context.theme.primaryColorDark.withOpacity(0.5),
                height: 1,
              ),
              AdCharacteristics(ad: ad),
              AdsGrid(
                physics: const NeverScrollableScrollPhysics(),
                params: GetAdParam(
                  adListType: AdListType.similarAd,
                  id: ad.category?.id,
                  currentAdId: ad.id,
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
