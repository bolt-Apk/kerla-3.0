import 'package:kerla2_client/kerla2_client.dart';

extension KerlaColorsExtension on KerlaColors {
  int get colorHex {
    switch (this) {
      case KerlaColors.red:
        return 0xFFFF0000;
      case KerlaColors.green:
        return 0xFF00FF00;
      case KerlaColors.blue:
        return 0xFF0000FF;
      case KerlaColors.yellow:
        return 0xFFFFFF00;
      case KerlaColors.purple:
        return 0xFFFF00FF;
      case KerlaColors.cyan:
        return 0xFF00FFFF;
      case KerlaColors.white:
        return 0xFFFFFFFF;
      case KerlaColors.black:
        return 0xFF000000;
      case KerlaColors.grey:
        return 0xFF808080;
      case KerlaColors.orange:
        return 0xFFFFA500;
      case KerlaColors.brown:
        return 0xFFA52A2A;
      case KerlaColors.indigo:
        return 0xFF4B0082;
      case KerlaColors.teal:
        return 0xFF008080;
      case KerlaColors.lime:
        return 0xFFC0FF00;
      case KerlaColors.pink:
        return 0xFFFFC0CB;
    }
  }

  String get title {
    switch (this) {
      case KerlaColors.red:
        return 'Красный';
      case KerlaColors.green:
        return 'Зеленый';
      case KerlaColors.blue:
        return 'Синий';
      case KerlaColors.yellow:
        return 'Желтый';
      case KerlaColors.purple:
        return 'Фиолетовый';
      case KerlaColors.cyan:
        return 'Голубой';
      case KerlaColors.white:
        return 'Белый';
      case KerlaColors.black:
        return 'Черный';
      case KerlaColors.grey:
        return 'Серый';
      case KerlaColors.orange:
        return 'Оранжевый';
      case KerlaColors.brown:
        return 'Коричневый';
      case KerlaColors.indigo:
        return 'Индиго';
      case KerlaColors.teal:
        return 'Бирюзовый';
      case KerlaColors.lime:
        return 'Лайм';
      case KerlaColors.pink:
        return 'Розовый';
    }
  }
}
