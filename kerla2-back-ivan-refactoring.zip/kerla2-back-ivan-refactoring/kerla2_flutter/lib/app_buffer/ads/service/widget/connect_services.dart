import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/app_buffer/ads/service/payment/payment_button.dart';
import 'package:kerla2_flutter/app_buffer/ads/service/state/service_state.dart';
import 'package:nit_app/nit_app.dart';
import 'package:nit_riverpod_notifications/nit_riverpod_notifications.dart';
import 'package:nit_router/nit_router.dart';
// import 'package:kerla2_flutter/state/ad/ad_state.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

import '../../../../router/router.dart';

// import '/state/ad_create_page/ad_create_state.dart';

enum ConnectServiceType {
  createAd,
  updateService,
  createStory,
}

class ConnectService extends ConsumerWidget {
  const ConnectService({
    super.key,
    this.connectServiceType = ConnectServiceType.createAd,
    required this.adId,
  });

  final int adId;

  final ConnectServiceType? connectServiceType;

  int? calculateTotalCost(Map<KerlaServiceInfo, int> selectedServices) {
    int totalCost = 0;
    if (selectedServices.entries.isEmpty) {
      return null;
    }
    for (final entry in selectedServices.entries) {
      final service = entry.key;
      final days = entry.value;
      totalCost += service.cost * days;
    }

    return (totalCost / 100).round();
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final provider = serviceListStateProvider(adId);
    final state = ref.watch(provider);

    return state.nitWhen(childBuilder: (state) {
      final totalPrice = calculateTotalCost(state.selectedServices);
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 10),
        child: Container(
          width: double.infinity,
          decoration: BoxDecoration(
            color: context.theme.canvasColor,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Column(
            children: [
              if (totalPrice != null && totalPrice != 0)
                Column(
                  children: [
                    const SizedBox(height: 20),
                    Text(
                      connectServiceType == ConnectServiceType.updateService
                          ? "Продление услуг"
                          : "Создание услуги",
                      style: TextStyle(
                        fontSize: 20,
                        color: context.theme.iconTheme.color,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      "Выберите срок оплаты",
                      style: TextStyle(
                        color: context.theme.primaryColorDark,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(12.0),
                      child: Container(
                        padding: const EdgeInsets.all(10),
                        width: double.infinity,
                        decoration: BoxDecoration(
                          color: Colors.transparent,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                            color:
                                context.theme.primaryColorDark.withOpacity(0.3),
                          ),
                        ),
                        child: Align(
                          child: RichText(
                            text: TextSpan(
                              children: [
                                TextSpan(
                                  text: "Стоимость    ",
                                  style: TextStyle(
                                    color: context.theme.primaryColorDark,
                                  ),
                                ),
                                TextSpan(
                                  text: "${150 + totalPrice} ",
                                  style: const TextStyle(
                                    color: Colors.red,
                                    decoration: TextDecoration.lineThrough,
                                  ),
                                ),
                                TextSpan(
                                  text: " $totalPrice",
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: context.theme.primaryColorDark,
                                  ),
                                ),
                                // TextSpan(
                                //   text: "    за $days ${day(days)}",
                                //   style: TextStyle(
                                //     color: context.theme.primaryColorDark,
                                //   ),
                                // ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              if (connectServiceType == ConnectServiceType.createStory &&
                  totalPrice == 0)
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Padding(
                      padding: EdgeInsets.all(8.0),
                      child: Text(
                        'Публикация stream stories будет бесплатной!',
                        textAlign: TextAlign.center,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text(
                        'Stream stories будет активна до:\n ${DateFormat('dd.MM.yyyy HH:mm').format(
                          state.selectedServices.entries.firstOrNull?.key
                                  .freeEndsAt ??
                              DateTime.now(),
                        )}',
                        textAlign: TextAlign.center,
                      ),
                    )
                  ],
                ),
              if (totalPrice != null ||
                  (connectServiceType == ConnectServiceType.createStory &&
                      totalPrice == 0))
                DecoratedBox(
                  decoration: BoxDecoration(
                    color: context.theme.cardColor,
                  ),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 60, vertical: 20),
                    child: PaymentButton(
                      isLoading: false,
                      buttonText: "Подключить",
                      amount: totalPrice ?? 0,
                      promotions:
                          ref.read(provider.notifier).getKerlaServices(),
                      onSuccess: () async {
                        ref.read(globalRefreshTriggerProvider.notifier).state =
                            DateTime.now();
                        if (context.mounted) {
                          context.goNamed(MainAreaNavigationZone.homePage.name);
                        } else {
                          ref.notifyUser(NitNotification.error(
                              'Не удалось подключить услуги'));
                        }
                      },
                    ),
                  ),
                ),
            ],
          ),
        ),
      );
    });
  }
}
