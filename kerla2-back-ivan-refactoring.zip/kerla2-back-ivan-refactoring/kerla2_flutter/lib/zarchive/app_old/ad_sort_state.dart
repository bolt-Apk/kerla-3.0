// import 'package:flutter_riverpod/flutter_riverpod.dart';
// import 'package:kerla2_client/kerla2_client.dart';
// import 'package:riverpod_annotation/riverpod_annotation.dart';

// part 'ad_sort_state.g.dart';



// @Riverpod(keepAlive: true)
// class AdSort extends _$AdSort {
//   @override
//   AdOrderBy build() {
//     return AdOrderBy.dateDes;
//   }

//   void setSortParam(AdOrderBy param) {
//     state = param;
//   }

//   AdOrderBy get() => state;
// }
