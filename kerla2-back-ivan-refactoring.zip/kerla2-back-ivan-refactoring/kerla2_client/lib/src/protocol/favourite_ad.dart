/* AUTOMATICALLY GENERATED CODE DO NOT MODIFY */
/*   To generate run: "serverpod generate"    */

// ignore_for_file: implementation_imports
// ignore_for_file: library_private_types_in_public_api
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: public_member_api_docs
// ignore_for_file: type_literal_in_constant_pattern
// ignore_for_file: use_super_parameters

// ignore_for_file: no_leading_underscores_for_library_prefixes
import 'package:serverpod_client/serverpod_client.dart' as _i1;

abstract class FavouriteAd implements _i1.SerializableModel {
  FavouriteAd._({
    this.id,
    required this.userId,
    required this.adId,
  });

  factory FavouriteAd({
    int? id,
    required int userId,
    required int adId,
  }) = _FavouriteAdImpl;

  factory FavouriteAd.fromJson(Map<String, dynamic> jsonSerialization) {
    return FavouriteAd(
      id: jsonSerialization['id'] as int?,
      userId: jsonSerialization['userId'] as int,
      adId: jsonSerialization['adId'] as int,
    );
  }

  /// The database id, set if the object has been inserted into the
  /// database or if it has been fetched from the database. Otherwise,
  /// the id will be null.
  int? id;

  int userId;

  int adId;

  FavouriteAd copyWith({
    int? id,
    int? userId,
    int? adId,
  });
  @override
  Map<String, dynamic> toJson() {
    return {
      if (id != null) 'id': id,
      'userId': userId,
      'adId': adId,
    };
  }

  @override
  String toString() {
    return _i1.SerializationManager.encode(this);
  }
}

class _Undefined {}

class _FavouriteAdImpl extends FavouriteAd {
  _FavouriteAdImpl({
    int? id,
    required int userId,
    required int adId,
  }) : super._(
          id: id,
          userId: userId,
          adId: adId,
        );

  @override
  FavouriteAd copyWith({
    Object? id = _Undefined,
    int? userId,
    int? adId,
  }) {
    return FavouriteAd(
      id: id is int? ? id : this.id,
      userId: userId ?? this.userId,
      adId: adId ?? this.adId,
    );
  }
}
