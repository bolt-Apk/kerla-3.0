/* AUTOMATICALLY GENERATED CODE DO NOT MODIFY */
/*   To generate run: "serverpod generate"    */

// ignore_for_file: implementation_imports
// ignore_for_file: library_private_types_in_public_api
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: public_member_api_docs
// ignore_for_file: type_literal_in_constant_pattern
// ignore_for_file: use_super_parameters

// ignore_for_file: no_leading_underscores_for_library_prefixes
import 'package:serverpod_client/serverpod_client.dart' as _i1;

abstract class AdViewCount implements _i1.SerializableModel {
  AdViewCount._({
    this.id,
    required this.userSessionId,
    required this.adId,
    required this.isStory,
  });

  factory AdViewCount({
    int? id,
    required String userSessionId,
    required int adId,
    required bool isStory,
  }) = _AdViewCountImpl;

  factory AdViewCount.fromJson(Map<String, dynamic> jsonSerialization) {
    return AdViewCount(
      id: jsonSerialization['id'] as int?,
      userSessionId: jsonSerialization['userSessionId'] as String,
      adId: jsonSerialization['adId'] as int,
      isStory: jsonSerialization['isStory'] as bool,
    );
  }

  /// The database id, set if the object has been inserted into the
  /// database or if it has been fetched from the database. Otherwise,
  /// the id will be null.
  int? id;

  String userSessionId;

  int adId;

  bool isStory;

  AdViewCount copyWith({
    int? id,
    String? userSessionId,
    int? adId,
    bool? isStory,
  });
  @override
  Map<String, dynamic> toJson() {
    return {
      if (id != null) 'id': id,
      'userSessionId': userSessionId,
      'adId': adId,
      'isStory': isStory,
    };
  }

  @override
  String toString() {
    return _i1.SerializationManager.encode(this);
  }
}

class _Undefined {}

class _AdViewCountImpl extends AdViewCount {
  _AdViewCountImpl({
    int? id,
    required String userSessionId,
    required int adId,
    required bool isStory,
  }) : super._(
          id: id,
          userSessionId: userSessionId,
          adId: adId,
          isStory: isStory,
        );

  @override
  AdViewCount copyWith({
    Object? id = _Undefined,
    String? userSessionId,
    int? adId,
    bool? isStory,
  }) {
    return AdViewCount(
      id: id is int? ? id : this.id,
      userSessionId: userSessionId ?? this.userSessionId,
      adId: adId ?? this.adId,
      isStory: isStory ?? this.isStory,
    );
  }
}
