import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/common/is_my_profile.dart';
import 'package:kerla2_flutter/core/app_backend_filters.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_app/nit_app.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class SubscribeButton extends HookConsumerWidget {
  const SubscribeButton({
    super.key,
    required this.userId,
  });

  final int userId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isLoading = useState(false);
    if (ref.isMyProfile(userId)) return const SizedBox.shrink();
    return ref
        .watchEntityListAsync<UserSubscription>(
          backendFilter: NitBackendFilter.and(
            [
              AppBackendFilter.userId.equals(userId),
              AppBackendFilter.subscriberId.equals(ref.signedInUserId!),
            ],
          ),
          // frontendFilter: (e) =>
          //     e.userId == userId && e.subscriberId == ref.signedInUserId,
        )
        .whenData((s) => s.firstOrNull)
        .nitWhen(
      childBuilder: (subs) {
        if (subs != null) {
          return Button.secondary(
            onPressed: isLoading.value
                ? null
                : () async {
                    isLoading.value = true;
                    try {
                      await ref.deleteModel<UserSubscription>(subs);
                    } finally {
                      isLoading.value = false;
                    }
                  },
            child: const Text('Отписаться'),
          );
        }
        return Button.secondary(
          onPressed: isLoading.value
              ? null
              : () async {
                  isLoading.value = true;
                  try {
                    await ref.saveModel<UserSubscription>(
                      UserSubscription(
                        userId: userId,
                        subscriberId: ref.signedInUserId!,
                        created: DateTime.now(),
                      ),
                    );
                  } finally {
                    isLoading.value = false;
                  }
                },
          child: const Text('Подписаться'),
        );
      },
    );
  }
}
