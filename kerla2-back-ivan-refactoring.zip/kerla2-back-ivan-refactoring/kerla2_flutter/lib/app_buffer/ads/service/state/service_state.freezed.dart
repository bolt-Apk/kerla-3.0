// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'service_state.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$ServiceStateModel {
  List<KerlaServiceInfo> get payableServices =>
      throw _privateConstructorUsedError;
  List<KerlaServiceInfo> get freeServices => throw _privateConstructorUsedError;
  Map<KerlaServiceInfo, int> get selectedServices =>
      throw _privateConstructorUsedError;

  /// Create a copy of ServiceStateModel
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $ServiceStateModelCopyWith<ServiceStateModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ServiceStateModelCopyWith<$Res> {
  factory $ServiceStateModelCopyWith(
          ServiceStateModel value, $Res Function(ServiceStateModel) then) =
      _$ServiceStateModelCopyWithImpl<$Res, ServiceStateModel>;
  @useResult
  $Res call(
      {List<KerlaServiceInfo> payableServices,
      List<KerlaServiceInfo> freeServices,
      Map<KerlaServiceInfo, int> selectedServices});
}

/// @nodoc
class _$ServiceStateModelCopyWithImpl<$Res, $Val extends ServiceStateModel>
    implements $ServiceStateModelCopyWith<$Res> {
  _$ServiceStateModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of ServiceStateModel
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? payableServices = null,
    Object? freeServices = null,
    Object? selectedServices = null,
  }) {
    return _then(_value.copyWith(
      payableServices: null == payableServices
          ? _value.payableServices
          : payableServices // ignore: cast_nullable_to_non_nullable
              as List<KerlaServiceInfo>,
      freeServices: null == freeServices
          ? _value.freeServices
          : freeServices // ignore: cast_nullable_to_non_nullable
              as List<KerlaServiceInfo>,
      selectedServices: null == selectedServices
          ? _value.selectedServices
          : selectedServices // ignore: cast_nullable_to_non_nullable
              as Map<KerlaServiceInfo, int>,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ServiceStateModelImplCopyWith<$Res>
    implements $ServiceStateModelCopyWith<$Res> {
  factory _$$ServiceStateModelImplCopyWith(_$ServiceStateModelImpl value,
          $Res Function(_$ServiceStateModelImpl) then) =
      __$$ServiceStateModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {List<KerlaServiceInfo> payableServices,
      List<KerlaServiceInfo> freeServices,
      Map<KerlaServiceInfo, int> selectedServices});
}

/// @nodoc
class __$$ServiceStateModelImplCopyWithImpl<$Res>
    extends _$ServiceStateModelCopyWithImpl<$Res, _$ServiceStateModelImpl>
    implements _$$ServiceStateModelImplCopyWith<$Res> {
  __$$ServiceStateModelImplCopyWithImpl(_$ServiceStateModelImpl _value,
      $Res Function(_$ServiceStateModelImpl) _then)
      : super(_value, _then);

  /// Create a copy of ServiceStateModel
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? payableServices = null,
    Object? freeServices = null,
    Object? selectedServices = null,
  }) {
    return _then(_$ServiceStateModelImpl(
      payableServices: null == payableServices
          ? _value._payableServices
          : payableServices // ignore: cast_nullable_to_non_nullable
              as List<KerlaServiceInfo>,
      freeServices: null == freeServices
          ? _value._freeServices
          : freeServices // ignore: cast_nullable_to_non_nullable
              as List<KerlaServiceInfo>,
      selectedServices: null == selectedServices
          ? _value._selectedServices
          : selectedServices // ignore: cast_nullable_to_non_nullable
              as Map<KerlaServiceInfo, int>,
    ));
  }
}

/// @nodoc

class _$ServiceStateModelImpl implements _ServiceStateModel {
  const _$ServiceStateModelImpl(
      {required final List<KerlaServiceInfo> payableServices,
      required final List<KerlaServiceInfo> freeServices,
      final Map<KerlaServiceInfo, int> selectedServices = const {}})
      : _payableServices = payableServices,
        _freeServices = freeServices,
        _selectedServices = selectedServices;

  final List<KerlaServiceInfo> _payableServices;
  @override
  List<KerlaServiceInfo> get payableServices {
    if (_payableServices is EqualUnmodifiableListView) return _payableServices;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_payableServices);
  }

  final List<KerlaServiceInfo> _freeServices;
  @override
  List<KerlaServiceInfo> get freeServices {
    if (_freeServices is EqualUnmodifiableListView) return _freeServices;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_freeServices);
  }

  final Map<KerlaServiceInfo, int> _selectedServices;
  @override
  @JsonKey()
  Map<KerlaServiceInfo, int> get selectedServices {
    if (_selectedServices is EqualUnmodifiableMapView) return _selectedServices;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableMapView(_selectedServices);
  }

  @override
  String toString() {
    return 'ServiceStateModel(payableServices: $payableServices, freeServices: $freeServices, selectedServices: $selectedServices)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ServiceStateModelImpl &&
            const DeepCollectionEquality()
                .equals(other._payableServices, _payableServices) &&
            const DeepCollectionEquality()
                .equals(other._freeServices, _freeServices) &&
            const DeepCollectionEquality()
                .equals(other._selectedServices, _selectedServices));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(_payableServices),
      const DeepCollectionEquality().hash(_freeServices),
      const DeepCollectionEquality().hash(_selectedServices));

  /// Create a copy of ServiceStateModel
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$ServiceStateModelImplCopyWith<_$ServiceStateModelImpl> get copyWith =>
      __$$ServiceStateModelImplCopyWithImpl<_$ServiceStateModelImpl>(
          this, _$identity);
}

abstract class _ServiceStateModel implements ServiceStateModel {
  const factory _ServiceStateModel(
          {required final List<KerlaServiceInfo> payableServices,
          required final List<KerlaServiceInfo> freeServices,
          final Map<KerlaServiceInfo, int> selectedServices}) =
      _$ServiceStateModelImpl;

  @override
  List<KerlaServiceInfo> get payableServices;
  @override
  List<KerlaServiceInfo> get freeServices;
  @override
  Map<KerlaServiceInfo, int> get selectedServices;

  /// Create a copy of ServiceStateModel
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$ServiceStateModelImplCopyWith<_$ServiceStateModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
