// part of '../../ui_kit.dart';

// class ShimmerListTile extends StatelessWidget {
//   const ShimmerListTile({
//     super.key,
//     this.height = 150,
//     this.width,
//   });

//   final double height;
//   final double? width;

//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       margin: const EdgeInsets.symmetric(horizontal: 5, vertical: 5),
//       height: height,
//       width: width,
//       decoration: BoxDecoration(
//         color: context.theme.canvasColor,
//         borderRadius: BorderRadius.circular(8),
//       ),
//     );
//   }
// }
