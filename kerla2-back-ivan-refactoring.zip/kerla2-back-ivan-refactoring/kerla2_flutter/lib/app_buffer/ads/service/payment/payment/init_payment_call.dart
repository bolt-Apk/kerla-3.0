import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/app_buffer/ads/service/payment/payment/widgets/pay_dialog_mobile.dart';
import 'package:kerla2_flutter/core/core.dart';
import 'package:nit_app/nit_app.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

extension InitPaymentCallExtension on WidgetRef {
  // initPaymentWithRegisteredCard({
  //   required DwTinkoffRegisteredCard selectedCard,
  // }) =>
  //     nitUiCallback<String?>(
  //       () async {
  //         return processApiResponse(
  //           await client.payments.initPayment(
  //             subscriptionOption: SubscriptionOption.manualPayment,
  //             selectedCardRebillId: selectedCard.rebillId!,
  //           ),
  //           updateListeners: true,
  //         );
  //       },
  //       followUpIfMountedAction: (_) => context.pop(),
  //     );

  Future<void> initPayment({
    required List<KerlaService> services,
    ValueNotifier? paymentInProgressNotifier,
  }) =>
      nitUiCallback<String?>(
        () async {
          return processApiResponse(
              await client.acquiring.initPayment(
                services: services,
              ),
              updateListeners: true);
        },
        followUpIfMountedAction: (paymentUrl) async {
          if (paymentUrl != null) {
            paymentInProgressNotifier?.value = true;
            await context.showForceBottomSheetDialog(
              PayDialog(
                paymentUrl: paymentUrl,
              ),
              maxHeightPercentage: 0.9,
            );
          }
        },
      )();
}
