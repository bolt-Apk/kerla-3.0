import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/app_buffer/ads/service/state/service_state.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class AddServiceSlider extends HookConsumerWidget {
  const AddServiceSlider({
    super.key,
    required this.width,
    required this.serviceInfo,
    this.adId,
  });

  final double width;
  final KerlaServiceInfo serviceInfo;
  final int? adId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final days = useState(1);
    const sliderHeight = 15.0;

    void handleDrag(DragUpdateDetails details) {
      final percentage = (details.localPosition.dx / width).clamp(0.0, 1.0);
      final newDays = ((percentage * 29).round() + 1).clamp(1, 30);

      days.value = newDays;

      ref
          .read(serviceListStateProvider(adId!).notifier)
          .updateDays(serviceInfo, newDays);
    }

    return GestureDetector(
      onHorizontalDragUpdate: handleDrag,
      onHorizontalDragStart: (details) => handleDrag(DragUpdateDetails(
          globalPosition: details.globalPosition,
          localPosition: details.localPosition)),
      child: Container(
        height: 4 * sliderHeight,
        width: width,
        alignment: Alignment.center,
        color: context.theme.canvasColor,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Stack(
              alignment: Alignment.center,
              children: [
                SizedBox(
                  width: width,
                  height: 25,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      _buildDayLabel(context, '1 день'),
                      _buildDayLabel(context, '30 дней'),
                    ],
                  ),
                ),
                AnimatedContainer(
                  duration: const Duration(milliseconds: 50),
                  curve: Curves.easeInOut,
                  width: width,
                  height: 25,
                  alignment: FractionalOffset(
                    (days.value - 1) / 29,
                    0.5,
                  ),
                  child: _buildSelectedDayLabel(days.value),
                ),
              ],
            ),
            const SizedBox(height: 8),
            _buildSlider(context, days.value, width, sliderHeight),
          ],
        ),
      ),
    );
  }

  Widget _buildDayLabel(BuildContext context, String text) {
    return Container(
      height: 20,
      width: 60,
      decoration: BoxDecoration(
        color: context.theme.canvasColor.withOpacity(0.05),
        borderRadius: BorderRadius.circular(3),
      ),
      alignment: Alignment.center,
      child: Text(
        text,
        style: TextStyle(
          fontSize: 12,
          color: context.theme.primaryColorDark,
          fontWeight: FontWeight.w400,
        ),
      ),
    );
  }

  Widget _buildSelectedDayLabel(int daysValue) {
    return Container(
      height: 20,
      width: 60,
      decoration: BoxDecoration(
        color: Colors.blue,
        borderRadius: BorderRadius.circular(3),
      ),
      alignment: Alignment.center,
      child: Text(
        '$daysValue ${_getDayLabel(daysValue)}',
        style: const TextStyle(
          fontSize: 12,
          color: Colors.white,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }

  Widget _buildSlider(
      BuildContext context, int daysValue, double width, double height) {
    final barWidth = (daysValue - 1) / 29 * width;

    return Container(
      width: width,
      height: height,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(width / 2),
        color: context.theme.primaryColorDark.withOpacity(0.1),
      ),
      alignment: Alignment.centerLeft,
      child: Stack(
        alignment: Alignment.center,
        children: [
          AnimatedContainer(
            duration: const Duration(milliseconds: 50),
            curve: Curves.easeInOut,
            width: barWidth + height,
            height: height,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(width / 2),
              color: Colors.blue,
            ),
            alignment: Alignment.centerRight,
            child: Container(
              height: height,
              width: height,
              decoration: BoxDecoration(
                color: Colors.white,
                shape: BoxShape.circle,
                border: Border.all(
                  color: Colors.blue,
                  width: 3,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  String _getDayLabel(int num) {
    if (num % 100 ~/ 10 == 1) {
      return 'дней';
    } else if (num % 10 == 1) {
      return 'день';
    } else if (num % 10 >= 2 && num % 10 <= 4) {
      return 'дня';
    } else {
      return 'дней';
    }
  }
}
