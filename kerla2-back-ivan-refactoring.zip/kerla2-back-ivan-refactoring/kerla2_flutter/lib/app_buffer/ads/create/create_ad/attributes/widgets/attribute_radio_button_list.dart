import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:kerla2_client/kerla2_client.dart';

import 'attribute_radio_button.dart';

class AttributeRadioButtonList extends ConsumerWidget {
  const AttributeRadioButtonList({
    super.key,
    required this.attributeValue,
    required this.onAcceptTap,
  });

  final AdAttributeValue attributeValue;
  final Function(AdAttributeValue) onAcceptTap;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (attributeValue.attribute!.title != null)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Text(
                attributeValue.attribute!.title!,
                style: Theme.of(context).textTheme.titleLarge,
              ),
            ),
          ),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: attributeValue.attribute!.values!.map(
              (text) {
                return Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: RadioButton(
                    text: text,
                    isSelected: text == attributeValue.value,
                    onTap: () {
                      onAcceptTap(
                        attributeValue.copyWith(value: text),
                      );
                    },
                  ),
                );
              },
            ).toList(),
          ),
        ),
        const SizedBox(height: 10),
      ],
    );
  }
}
