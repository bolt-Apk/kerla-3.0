// import 'dart:async';

// import 'package:flutter_riverpod/flutter_riverpod.dart';
// import 'package:kerla2_client/kerla2_client.dart';
// import 'package:kerla2_flutter/core/core.dart';
// import 'package:riverpod_annotation/riverpod_annotation.dart';
// import 'package:serverpod_auth_client/module.dart';

// import '../../../ui/pages/home/home_page.dart';

// part 'stories_providers.g.dart';

// @riverpod
// Future<List<UserInfoPublic>> usersWithStories(Ref ref) async {
//   final link = ref.keepAlive();
//   final timer = Timer(const Duration(seconds: 30), () {
//     link.close();
//   });
//   ref.onDispose(() => timer.cancel());

//   // final list = await client.ad.getUsersWithStories(await ref.sessionGender);

//   final uniqueUserIds = list.map((userInfo) => userInfo.id).toSet();

//   final List<UserInfoPublic> uniqueList = List.empty(growable: true);
//   for (var uniqueId in uniqueUserIds) {
//     uniqueList.add(list.firstWhere((userInfo) => userInfo.id == uniqueId));
//   }
//   return uniqueList;
// }

// @riverpod
// Future<List<Ad>> userStories(
//   Ref ref, {
//   required int id,
// }) async {
//   final link = ref.keepAlive();
//   final timer = Timer(const Duration(seconds: 30), () {
//     link.close();
//   });
//   ref.onDispose(() => timer.cancel());

//   final ads = await client.ad.getAds(
//     userId: id,
//     limit: 100,
//     page: 1,
//     adType: AdType.story,
//     adOrderBy: AdOrderBy.dateDes,
//     getSubscribedAds: ref.read(isSubscribedAds),
//     gender: await ref.sessionGender,
//   );
//   final res = ads
//       .where((element) => element.media != null && element.media!.isNotEmpty)
//       .toList();
//   return res;
// }
