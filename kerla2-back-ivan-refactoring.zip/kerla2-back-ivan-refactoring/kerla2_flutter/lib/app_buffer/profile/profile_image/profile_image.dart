import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_svg/svg.dart';
import 'package:kerla2_flutter/app_buffer/profile/user_online/user_online_status_dot.dart';
import 'package:kerla2_flutter/common/is_my_profile.dart';
import 'package:kerla2_flutter/common/user_profile_ref_extensions.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';
import 'package:popover/popover.dart';

import 'profile_image_actions.dart';

class ProfileImage extends ConsumerWidget {
  const ProfileImage({
    super.key,
    required this.userId,
    this.size = 100,
    this.withOnlineDot = true,
  }) : allowEditing = false;

  const ProfileImage.editable({
    super.key,
    required this.userId,
    this.size = 100,
    this.withOnlineDot = true,
  }) : allowEditing = true;

  const ProfileImage.mini({
    super.key,
    required this.userId,
    this.size = 40,
  })  : allowEditing = false,
        withOnlineDot = false;

  final int userId;
  final double size;
  final bool allowEditing;
  final bool withOnlineDot;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return ref.watchUserProfile(userId).nitWhen(
          childBuilder: (userProfile) => Stack(
            alignment: AlignmentDirectional.center,
            children: [
              AnimatedContainer(
                width: size * 1.1,
                height: size * 1.1,
                duration: const Duration(milliseconds: 300),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: ref.isMyProfile(userId)
                        ? [context.theme.canvasColor, context.theme.canvasColor]
                        : [
                            context.theme.canvasColor,
                            context.theme.canvasColor
                          ],
                  ),
                ),
              ),
              Container(
                width: size,
                height: size,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: Theme.of(context).colorScheme.primary,
                    width: 2.5,
                  ),
                ),
                child: ClipOval(
                  child: userProfile.imageUrl != null
                      ? CachedNetworkImage(
                          imageUrl: userProfile.imageUrl ?? '',
                          width: size,
                          height: size,
                          fit: BoxFit.cover,
                        )
                      : Padding(
                          padding: EdgeInsets.all(size / 4),
                          child: SvgPicture.asset(
                            AppIconsSvg.account,
                            colorFilter: ColorFilter.mode(
                              context.theme.iconTheme.color ?? Colors.black,
                              BlendMode.srcIn,
                            ),
                            width: size,
                            height: size,
                            fit: BoxFit.contain,
                          ),
                        ),
                ),
              ),
              if (!ref.isMyProfile(userId) && withOnlineDot)
                Positioned(
                  right: 0,
                  bottom: size * 0.1,
                  child: UserOnlineStatusDot(
                    size: size * 0.23,
                    borderThickness: size * 0.05,
                    userId: userId,
                  ),
                ),
              if (allowEditing)
                Positioned(
                  right: 0,
                  bottom: 10,
                  child: GestureDetector(
                    onTap: () {
                      showPopover(
                        context: context,
                        bodyBuilder: (context) => const ProfileImageActions(),
                        direction: PopoverDirection.right,
                        backgroundColor:
                            Theme.of(context).scaffoldBackgroundColor,
                        width: 130,
                        height: 75,
                        arrowHeight: 15,
                        arrowWidth: 30,
                      );
                    },
                    child: CircleAvatar(
                      backgroundColor: context.theme.canvasColor,
                      radius: 17,
                      child: Icon(
                        Icons.add_circle_outline,
                        color: context.theme.iconTheme.color,
                      ),
                    ),
                  ),
                ),
            ],
          ),
        );
  }
}
