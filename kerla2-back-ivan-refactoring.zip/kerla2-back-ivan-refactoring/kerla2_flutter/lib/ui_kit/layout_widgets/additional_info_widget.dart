part of '../ui_kit.dart';

class AdditionalInfoWidget extends StatelessWidget {
  final Widget infoWidget;

  const AdditionalInfoWidget({
    required this.infoWidget,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        color: context.theme.canvasColor,
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(30),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 1.0,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: infoWidget,
    );
  }
}
