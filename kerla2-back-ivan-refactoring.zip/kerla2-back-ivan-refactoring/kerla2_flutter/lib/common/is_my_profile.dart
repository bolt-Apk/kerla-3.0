import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:nit_app/nit_app.dart';

extension IsMyProfileExtension on WidgetRef {
  bool isMyProfile(int? userId) =>
      signedInUserId != null && signedInUserId == userId;
}
