part of '../ui_kit.dart';

class AboutProfileDialog extends StatelessWidget {
  const AboutProfileDialog({
    super.key,
    required this.text,
  });
  final String text;
  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      content: SingleChildScrollView(
        child: Text(
          text,
          style: context.textTheme.displayLarge?.copyWith(height: 1.2),
        ),
      ),
      actions: <Widget>[
        TextButton(
          child: Text('Закрыть',
              style: GoogleFonts.roboto(
                color: const Color.fromRGBO(1, 150, 162, 1),
              )),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ],
    );
  }
}
