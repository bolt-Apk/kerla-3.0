/* AUTOMATICALLY GENERATED CODE DO NOT MODIFY */
/*   To generate run: "serverpod generate"    */

// ignore_for_file: implementation_imports
// ignore_for_file: library_private_types_in_public_api
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: public_member_api_docs
// ignore_for_file: type_literal_in_constant_pattern
// ignore_for_file: use_super_parameters

// ignore_for_file: no_leading_underscores_for_library_prefixes
import 'package:serverpod_client/serverpod_client.dart' as _i1;
import '../protocol.dart' as _i2;

abstract class AdCategory implements _i1.SerializableModel {
  AdCategory._({
    this.id,
    this.parentId,
    this.parent,
    this.children,
    required this.title,
    this.genderFilter,
  });

  factory AdCategory({
    int? id,
    int? parentId,
    _i2.AdCategory? parent,
    List<_i2.AdCategory>? children,
    required String title,
    bool? genderFilter,
  }) = _AdCategoryImpl;

  factory AdCategory.fromJson(Map<String, dynamic> jsonSerialization) {
    return AdCategory(
      id: jsonSerialization['id'] as int?,
      parentId: jsonSerialization['parentId'] as int?,
      parent: jsonSerialization['parent'] == null
          ? null
          : _i2.AdCategory.fromJson(
              (jsonSerialization['parent'] as Map<String, dynamic>)),
      children: (jsonSerialization['children'] as List?)
          ?.map((e) => _i2.AdCategory.fromJson((e as Map<String, dynamic>)))
          .toList(),
      title: jsonSerialization['title'] as String,
      genderFilter: jsonSerialization['genderFilter'] as bool?,
    );
  }

  /// The database id, set if the object has been inserted into the
  /// database or if it has been fetched from the database. Otherwise,
  /// the id will be null.
  int? id;

  int? parentId;

  _i2.AdCategory? parent;

  List<_i2.AdCategory>? children;

  String title;

  bool? genderFilter;

  AdCategory copyWith({
    int? id,
    int? parentId,
    _i2.AdCategory? parent,
    List<_i2.AdCategory>? children,
    String? title,
    bool? genderFilter,
  });
  @override
  Map<String, dynamic> toJson() {
    return {
      if (id != null) 'id': id,
      if (parentId != null) 'parentId': parentId,
      if (parent != null) 'parent': parent?.toJson(),
      if (children != null)
        'children': children?.toJson(valueToJson: (v) => v.toJson()),
      'title': title,
      if (genderFilter != null) 'genderFilter': genderFilter,
    };
  }

  @override
  String toString() {
    return _i1.SerializationManager.encode(this);
  }
}

class _Undefined {}

class _AdCategoryImpl extends AdCategory {
  _AdCategoryImpl({
    int? id,
    int? parentId,
    _i2.AdCategory? parent,
    List<_i2.AdCategory>? children,
    required String title,
    bool? genderFilter,
  }) : super._(
          id: id,
          parentId: parentId,
          parent: parent,
          children: children,
          title: title,
          genderFilter: genderFilter,
        );

  @override
  AdCategory copyWith({
    Object? id = _Undefined,
    Object? parentId = _Undefined,
    Object? parent = _Undefined,
    Object? children = _Undefined,
    String? title,
    Object? genderFilter = _Undefined,
  }) {
    return AdCategory(
      id: id is int? ? id : this.id,
      parentId: parentId is int? ? parentId : this.parentId,
      parent: parent is _i2.AdCategory? ? parent : this.parent?.copyWith(),
      children: children is List<_i2.AdCategory>?
          ? children
          : this.children?.map((e0) => e0.copyWith()).toList(),
      title: title ?? this.title,
      genderFilter: genderFilter is bool? ? genderFilter : this.genderFilter,
    );
  }
}
