part of '../ui_kit.dart';

// TODO: переписать на обычный форм стейт
class TextEditingBottomSheet extends HookWidget {
  // final TextEditingController controller;
  final String initialValue;
  final String title;
  final TextInputType? keyboardType;
  final TextStyle? titleTextStyle;
  final TextInputFormatter? inputFormatter;
  final int maxLength;
  final int maxLines;
  final Future<bool> Function(String) acceptAction;
  final bool showCounter;
  final bool withDivider;
  final TextCapitalization textCapitalization;
  // final VoidCallback? onCanceled;
  final String? onCancelButtonText;

  const TextEditingBottomSheet({
    super.key,
    // required this.controller,
    required this.title,
    required this.initialValue,
    required this.acceptAction,
    required this.maxLength,
    this.showCounter = true,
    this.withDivider = true,
    this.textCapitalization = TextCapitalization.none,
    this.keyboardType,
    this.inputFormatter,
    this.titleTextStyle,
    // this.onCanceled,
    this.maxLines = 1,
    this.onCancelButtonText,
  });

  @override
  Widget build(BuildContext context) {
    final localController = TextEditingController(text: initialValue);
    final errorValue = useState<String?>(null);
    return DecoratedBox(
      decoration: BoxDecoration(color: context.theme.canvasColor),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (withDivider) const LittleDivider(),
            Align(
              alignment: Alignment.centerLeft,
              child: Text(title, style: context.textTheme.headlineMedium),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 12),
              child: TextField(
                textCapitalization: textCapitalization,
                controller: localController,
                style: titleTextStyle ??
                    context.textTheme.displayLarge?.copyWith(fontSize: 16),
                keyboardType: keyboardType,
                maxLines: maxLines,
                cursorColor: ThemePrimaryColors.primary,
                decoration: InputDecoration(
                  fillColor: context.theme.cardColor,
                  enabledBorder: const OutlineInputBorder(
                    borderSide: BorderSide(
                      color: Colors.grey,
                    ),
                  ),
                  hintStyle: context.textTheme.bodyMedium,
                  focusedBorder: const OutlineInputBorder(
                    borderSide: BorderSide(
                      color: ThemePrimaryColors.primary,
                    ),
                  ),
                ),
                inputFormatters:
                    inputFormatter != null ? [inputFormatter!] : null,
                maxLength: maxLength,
                buildCounter: (
                  context, {
                  required currentLength,
                  required isFocused,
                  maxLength,
                }) {
                  return showCounter
                      ? Align(
                          alignment: Alignment.centerLeft,
                          child: Text('Символов $currentLength из $maxLength'),
                        )
                      : null;
                },
              ),
            ),
            Text(
              errorValue.value ?? '',
              style: const TextStyle(color: Colors.red),
            ),
            Padding(
              padding: const EdgeInsets.only(bottom: 16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  TextButton(
                    child: Text(
                      onCancelButtonText ?? 'Отмена',
                      style: context.textTheme.titleMedium?.copyWith(
                        color: Colors.grey,
                      ),
                    ),
                    onPressed: () {
                      context.pop();
                    },
                  ),
                  TextButton(
                    child: Text(
                      'Готово',
                      style: context.textTheme.titleMedium?.copyWith(
                        color: ThemePrimaryColors.primary,
                      ),
                    ),
                    onPressed: () async {
                      // if (acceptAction != null) {
                      await acceptAction(localController.text).then(
                        (res) => res && context.mounted
                            ? context.pop()
                            : {},
                      );
                      // errorValue.value = res;
                      // }
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
