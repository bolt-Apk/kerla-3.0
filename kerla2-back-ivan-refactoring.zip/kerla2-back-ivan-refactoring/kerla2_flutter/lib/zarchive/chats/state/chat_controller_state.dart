// import 'package:flutter/material.dart';
// import 'package:freezed_annotation/freezed_annotation.dart';
// import 'package:kerla2_flutter/core/core.dart';
// import 'package:nit_app/nit_app.dart';
// import 'package:riverpod_annotation/riverpod_annotation.dart';
// import 'package:serverpod_chat_client/module.dart' as chat_client;
// import 'package:serverpod_chat_flutter/serverpod_chat_flutter.dart';

// import 'chat_list_state.dart';

// part 'chat_controller_state.freezed.dart';
// part 'chat_controller_state.g.dart';

// @Riverpod(keepAlive: false)
// class ChatControllerState extends _$ChatControllerState {
//   ChatController? _controller;

//   @override
//   AsyncValue<ChatControllerData> build(String channel) {
//     ref.onDispose(() {
//       print('Disposing controller for ${_controller?.channel}');
//       // ref.refresh(chatListStateProvider);
//       final changedList = ref.read(chatListStateProvider).value?.map(
//         (element) {
//           if (element.channel == channel) {
//             return element.copyWith(
//               hasUnreadMessages: false,
//               lastMessage: _controller?.messages.lastOrNull,
//             );

//             // ChannelInfo(
//             //   id: element.id,
//             //   channel: channel,
//             //   isPrivate: element.isPrivate,
//             //   chatWith: element.chatWith,
//             //   hasUnreadMessages: false,
//             // lastMessage: _controller.messages.lastOrNull,
//             //   adId: element.adId,
//             //   ad: element.ad,
//             // );
//           }
//           return element;
//         },
//       ).toList();

//       ref.read(chatListStateProvider.notifier).updateState(changedList ?? []);
//       _controller?.dispose();
//       ref.read(chatListStateProvider.notifier).newChannelListener();
//     });

//     // ref.listen(
//     //     nitSessionStateProvider.select(
//     //       (s) => s.websocketStatus == StreamingConnectionStatus.connected,
//     //     ), (previous, next) {
//     //   if (previous == false && next) {
//     //     // ref.invalidateSelf();
//     //     _controller?.dispose();
//     //     _controller = ChatController(
//     //       channel: channel,
//     //       module: client.modules.chat,
//     //       sessionManager:
//     //           ref.read(nitSessionStateProvider).serverpodSessionManager!,
//     //     );

//     //     _controller?.addConnectionStatusListener(_listener);
//     //     state = AsyncData(
//     //       ChatControllerData(
//     //         controller: _controller!,
//     //         hasUnreadMessages: _controller!.hasUnreadMessages,
//     //         lastMessage: _controller!.messages.lastOrNull,
//     //       ),
//     //     );
//     //   }
//     // });

//     _controller = ChatController(
//       channel: channel,
//       module: client.modules.chat,
//       sessionManager:
//           ref.read(nitSessionStateProvider).serverpodSessionManager!,
//     );

//     _controller?.addConnectionStatusListener(_listener);

//     // _controller.addUnreadMessagesListener(() {
//     //   _listener;
//     //   // ref.invalidate(hasNewMessagesProvider);
//     // });

//     // _controller.addMessageReceivedListener(
//     //   (message, addedByUser) {
//     //     return _listener();
//     //   },
//     // );

//     return const AsyncLoading();
//   }

//   void _listener() {
//     // TODO: обработать прочие важные ситуации
//     if (_controller!.joinedChannel) {
//       debugPrint('joined ${_controller!.channel}');
//       state = AsyncData(
//         ChatControllerData(
//           controller: _controller!,
//           hasUnreadMessages: _controller!.hasUnreadMessages,
//           lastMessage: _controller!.messages.lastOrNull,
//         ),
//       );
//     }
//   }

//   Future<void> shareAd(int adId) async {
//     await _controller?.shareAd(adId);
//   }
// }

// @freezed
// class ChatControllerData with _$ChatControllerData {
//   // bool get isSignedIn => signedInUser != null;
//   // @override
//   // TelemedRole? get role => signedInUser?.currentRole;

//   const factory ChatControllerData({
//     required ChatController controller,
//     required bool hasUnreadMessages,
//     required chat_client.ChatMessage? lastMessage,
//   }) = _ChatControllerData;
// }
