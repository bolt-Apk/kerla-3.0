package com.fluttercandies.photo_manager.constant

enum class AssetType { Image, Video, Audio }
