import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/app_buffer/home/widgets/home_app_bar/search/providers.dart';
import 'package:kerla2_flutter/app_buffer/home/widgets/home_app_bar/search/user_search/user_search_item.dart';
import 'package:kerla2_flutter/core/app_backend_filters.dart';
import 'package:nit_app/nit_app.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class SearchQueryUsers extends ConsumerWidget {
  const SearchQueryUsers({
    super.key,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final searchStringVal = ref.watch(searchString);
    if (searchStringVal.isEmpty) return const SizedBox();
    return DecoratedBox(
      decoration: BoxDecoration(
        color: context.colorScheme.surface,
      ),
      child: ref
          .watchEntityListCustomizedAsync<UserProfile>(
            entityListConfig: EntityListConfig(
              backendFilter: NitBackendFilter.and([
                NitBackendFilter.or(
                  [
                    AppBackendFilter.userName.ilike(
                      '%$searchStringVal%',
                    ),
                    AppBackendFilter.profileDescription.ilike(
                      '%$searchStringVal%',
                    ),
                  ],
                ),
                AppBackendFilter.userId
                    .equals(ref.signedInUserId, negate: true),
              ]),
              pageSize: 20,
            ),
          )
          .nitWhenList(
            loadingItemsCount: 0,
            childBuilder: (users) {
              return ListView.builder(
                itemCount: users.length,
                itemBuilder: (context, index) {
                  final user = users[index];
                  return UserSearchItem(
                    key: ValueKey(user.userId),
                    userId: user.userId,
                  );
                },
              );
            },
          ),
    );
  }
}
