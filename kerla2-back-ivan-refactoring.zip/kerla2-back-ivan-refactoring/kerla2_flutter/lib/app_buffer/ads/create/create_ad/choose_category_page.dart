import 'package:expandable/expandable.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/app_buffer/ads/create/state/ad_create_state.dart';
import 'package:kerla2_flutter/core/app_sources.dart';
import 'package:kerla2_flutter/router/router.dart';
import 'package:nit_router/nit_router.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class ChooseCategoryPage extends ConsumerWidget {
  const ChooseCategoryPage({
    super.key,
    required this.adType,
  });
  final AdType adType;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final categories = AppSources.instance.categories;

    // final Map<String, String>? params =
    //     ref.watch(navigationPathParametersProvider);
    // int? adId;
    // if (params != null) {
    //   adId = ChatNavigationParameters.adId.get(params);
    // }

    void onTap(AdCategory category, AdCategory subcategory) {
      // TODO: вернуть и переделать
      // if (adId != null) {
      //lines for editing categories

      // ref
      //     .read(adEditStateProvider(adId: adId).notifier)
      //     .setsubcategory(subcategory);
      // ref.read(adEditStateProvider(adId: adId).notifier).getAttributes();
      // context.pop();
      // } else {

      // final isStoryCreation = false;
      // ref.watch(navigationExtraParameterProvider) as bool?;
      //   ref
      //       .read(
      //         adCreateStateProvider(
      //           isStory: isStoryCreation ?? false,
      //         ).notifier,
      //       )
      //       .setCategoryAndSubcategory(
      //         category,
      //         subcategory,
      //       );

      //   if (isStoryCreation == true) {
      //     context.pop();
      //   } else {
      //     context.pushNamed(
      //       MainAreaNavigationZone.chooseAttribute.name,
      //     );
      //   }
      // }
      ref.read(createAdStateProvider(adType).notifier).setCategory(subcategory);
      if (adType == AdType.story) {
        context.pop();
      } else {
        context.pushNamed(
          AdNavigationZone.chooseAttribute.name,
        );
      }
    }

    return Scaffold(
      appBar: AppBar(
        foregroundColor: context.theme.iconTheme.color,
        backgroundColor: context.theme.canvasColor,
        automaticallyImplyLeading: false,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back,
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: Text(
          "Выберите категорию",
          style: context.theme.textTheme.headlineMedium,
        ),
      ),
      body: ListView.builder(
        itemCount: categories.length,
        itemBuilder: (context, index) {
          final category = categories[index];
          return ExpandableNotifier(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: ExpandablePanel(
                header: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(
                    category.title,
                    style: const TextStyle(
                      fontSize: 18.0,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
                collapsed: Container(),
                // TODO: Проверять наличие подкатегории
                expanded: category.children == null
                    ? const SizedBox()
                    : ListView.builder(
                        shrinkWrap: true,
                        physics: const ClampingScrollPhysics(),
                        itemCount: category.children!.length,
                        itemBuilder: (context, subIndex) {
                          final subcategory = category.children![subIndex];
                          if (subcategory.children == null ||
                              subcategory.children!.isEmpty) {
                            return Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 8),
                              child: ListTile(
                                title: Text(
                                  subcategory.title,
                                ),
                                onTap: () {
                                  onTap(category, subcategory);
                                },
                              ),
                            );
                          } else {
                            return Padding(
                              padding: const EdgeInsets.only(left: 16),
                              child: ExpandableNotifier(
                                child: Padding(
                                  padding: const EdgeInsets.only(
                                    left: 8,
                                    top: 8,
                                    bottom: 8,
                                  ),
                                  child: ExpandablePanel(
                                    header: Text(
                                      subcategory.title,
                                      style: const TextStyle(
                                        fontSize: 18.0,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                    collapsed: const SizedBox.shrink(),
                                    expanded: ListView.builder(
                                      shrinkWrap: true,
                                      physics: const ClampingScrollPhysics(),
                                      itemCount: subcategory.children!.length,
                                      itemBuilder: (context, subIndex2) {
                                        final subcategory2 =
                                            subcategory.children![subIndex2];

                                        return ListTile(
                                          title: Text(
                                            subcategory2.title,
                                          ),
                                          onTap: () {
                                            onTap(category, subcategory2);
                                          },
                                        );
                                      },
                                    ),
                                  ),
                                ),
                              ),
                            );
                          }
                        },
                      ),
              ),
            ),
          );
        },
      ),
    );
  }
}
