import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';
import 'package:package_info_plus/package_info_plus.dart';

class VersionInfo extends ConsumerWidget {
  const VersionInfo({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return FutureBuilder<PackageInfo>(
      future: PackageInfo.fromPlatform(),
      builder: (context, snapshot) {
        switch (snapshot.connectionState) {
          case ConnectionState.done:
            if (snapshot.hasData && snapshot.data != null) {
              return Align(
                alignment: Alignment.bottomCenter,
                child: Text(
                  snapshot.data!.version,
                  style: context.textTheme.displayLarge,
                ),
              );
            } else {
              return Align(
                alignment: Alignment.bottomCenter,
                child: Text(
                  'unknown version',
                  style: context.textTheme.displayLarge,
                ),
              );
            }
          default:
            return const SizedBox();
        }
      },
    );
  }
}
