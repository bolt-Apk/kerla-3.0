import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';

part 'card_data_storage.g.dart';

part 'card_data_storage.freezed.dart';

class CreditCardStorage {
  final FlutterSecureStorage _secureStorage = const FlutterSecureStorage();
  static const String _cardNumberKey = 'cardNumber';
  static const String _creationDateKey = 'creationDate';
  static const String _cardSavedKey = 'cardSaved';

  Future<void> saveCreditCard(
      String cardNumber, String creationDate, bool isCardSaved) async {
    await _secureStorage.write(key: _cardNumberKey, value: cardNumber);
    await _secureStorage.write(key: _creationDateKey, value: creationDate);
    await _secureStorage.write(
      key: _cardSavedKey,
      value: isCardSaved.toString(),
    );
  }

  Future<Map<String, dynamic>> getCreditCard() async {
    final String? cardNumber = await _secureStorage.read(key: _cardNumberKey);
    final String? creationDate =
        await _secureStorage.read(key: _creationDateKey);
    final String? isCardSaved = await _secureStorage.read(key: _cardSavedKey);

    return {
      'cardNumber': cardNumber ?? '',
      'creationDate': creationDate ?? '',
      'cardSaved': isCardSaved == 'true' ? true : false,
    };
  }

  Future<void> deleteCreditCard() async {
    await _secureStorage.delete(key: _cardNumberKey);
    await _secureStorage.delete(key: _creationDateKey);
    await _secureStorage.delete(key: _cardSavedKey);
  }
}

@riverpod
class CreditCardData extends _$CreditCardData {
  @override
  Future<CreditCard> build() async {
    final card = await CreditCardStorage().getCreditCard();
    return CreditCard(
      cardNumber: card[CreditCardStorage._cardNumberKey] ?? '',
      creationDate: card[CreditCardStorage._creationDateKey] ?? '',
      isCardSaved: card[CreditCardStorage._cardSavedKey] ?? false,
    );
  }

  Future<void> saveCreditCard(
    String cardNumber,
    String creationDate,
  ) async {
    if (!state.value!.isCardSaved) {
      deleteCreditCard();
      return;
    }
    await CreditCardStorage().saveCreditCard(
      cardNumber,
      creationDate,
      state.value!.isCardSaved,
    );
  }

  Future<void> deleteCreditCard() async {
    await CreditCardStorage().deleteCreditCard();
  }

  set isCardSaved(bool isCardSaved) {
    state = AsyncData(state.value!.copyWith(isCardSaved: isCardSaved));
  }
}

@freezed
class CreditCard with _$CreditCard {
  const factory CreditCard({
    required String cardNumber,
    required String creationDate,
    required bool isCardSaved,
  }) = _CreditCard;
}
