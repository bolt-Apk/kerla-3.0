// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'promo_level_state.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$PromoLevelModel {
  PromoLevel? get currentPromoLevel => throw _privateConstructorUsedError;
  PromoLevel? get nextPromoLevel => throw _privateConstructorUsedError;
  int get countInvites => throw _privateConstructorUsedError;
  int get countToNewLevel => throw _privateConstructorUsedError;
  bool get isAvailableNewLevel => throw _privateConstructorUsedError;
  bool get isLastLevel => throw _privateConstructorUsedError;

  /// Create a copy of PromoLevelModel
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $PromoLevelModelCopyWith<PromoLevelModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $PromoLevelModelCopyWith<$Res> {
  factory $PromoLevelModelCopyWith(
          PromoLevelModel value, $Res Function(PromoLevelModel) then) =
      _$PromoLevelModelCopyWithImpl<$Res, PromoLevelModel>;
  @useResult
  $Res call(
      {PromoLevel? currentPromoLevel,
      PromoLevel? nextPromoLevel,
      int countInvites,
      int countToNewLevel,
      bool isAvailableNewLevel,
      bool isLastLevel});
}

/// @nodoc
class _$PromoLevelModelCopyWithImpl<$Res, $Val extends PromoLevelModel>
    implements $PromoLevelModelCopyWith<$Res> {
  _$PromoLevelModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of PromoLevelModel
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? currentPromoLevel = freezed,
    Object? nextPromoLevel = freezed,
    Object? countInvites = null,
    Object? countToNewLevel = null,
    Object? isAvailableNewLevel = null,
    Object? isLastLevel = null,
  }) {
    return _then(_value.copyWith(
      currentPromoLevel: freezed == currentPromoLevel
          ? _value.currentPromoLevel
          : currentPromoLevel // ignore: cast_nullable_to_non_nullable
              as PromoLevel?,
      nextPromoLevel: freezed == nextPromoLevel
          ? _value.nextPromoLevel
          : nextPromoLevel // ignore: cast_nullable_to_non_nullable
              as PromoLevel?,
      countInvites: null == countInvites
          ? _value.countInvites
          : countInvites // ignore: cast_nullable_to_non_nullable
              as int,
      countToNewLevel: null == countToNewLevel
          ? _value.countToNewLevel
          : countToNewLevel // ignore: cast_nullable_to_non_nullable
              as int,
      isAvailableNewLevel: null == isAvailableNewLevel
          ? _value.isAvailableNewLevel
          : isAvailableNewLevel // ignore: cast_nullable_to_non_nullable
              as bool,
      isLastLevel: null == isLastLevel
          ? _value.isLastLevel
          : isLastLevel // ignore: cast_nullable_to_non_nullable
              as bool,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$PromoLevelModelImplCopyWith<$Res>
    implements $PromoLevelModelCopyWith<$Res> {
  factory _$$PromoLevelModelImplCopyWith(_$PromoLevelModelImpl value,
          $Res Function(_$PromoLevelModelImpl) then) =
      __$$PromoLevelModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {PromoLevel? currentPromoLevel,
      PromoLevel? nextPromoLevel,
      int countInvites,
      int countToNewLevel,
      bool isAvailableNewLevel,
      bool isLastLevel});
}

/// @nodoc
class __$$PromoLevelModelImplCopyWithImpl<$Res>
    extends _$PromoLevelModelCopyWithImpl<$Res, _$PromoLevelModelImpl>
    implements _$$PromoLevelModelImplCopyWith<$Res> {
  __$$PromoLevelModelImplCopyWithImpl(
      _$PromoLevelModelImpl _value, $Res Function(_$PromoLevelModelImpl) _then)
      : super(_value, _then);

  /// Create a copy of PromoLevelModel
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? currentPromoLevel = freezed,
    Object? nextPromoLevel = freezed,
    Object? countInvites = null,
    Object? countToNewLevel = null,
    Object? isAvailableNewLevel = null,
    Object? isLastLevel = null,
  }) {
    return _then(_$PromoLevelModelImpl(
      currentPromoLevel: freezed == currentPromoLevel
          ? _value.currentPromoLevel
          : currentPromoLevel // ignore: cast_nullable_to_non_nullable
              as PromoLevel?,
      nextPromoLevel: freezed == nextPromoLevel
          ? _value.nextPromoLevel
          : nextPromoLevel // ignore: cast_nullable_to_non_nullable
              as PromoLevel?,
      countInvites: null == countInvites
          ? _value.countInvites
          : countInvites // ignore: cast_nullable_to_non_nullable
              as int,
      countToNewLevel: null == countToNewLevel
          ? _value.countToNewLevel
          : countToNewLevel // ignore: cast_nullable_to_non_nullable
              as int,
      isAvailableNewLevel: null == isAvailableNewLevel
          ? _value.isAvailableNewLevel
          : isAvailableNewLevel // ignore: cast_nullable_to_non_nullable
              as bool,
      isLastLevel: null == isLastLevel
          ? _value.isLastLevel
          : isLastLevel // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$PromoLevelModelImpl implements _PromoLevelModel {
  const _$PromoLevelModelImpl(
      {required this.currentPromoLevel,
      required this.nextPromoLevel,
      required this.countInvites,
      required this.countToNewLevel,
      this.isAvailableNewLevel = false,
      this.isLastLevel = false});

  @override
  final PromoLevel? currentPromoLevel;
  @override
  final PromoLevel? nextPromoLevel;
  @override
  final int countInvites;
  @override
  final int countToNewLevel;
  @override
  @JsonKey()
  final bool isAvailableNewLevel;
  @override
  @JsonKey()
  final bool isLastLevel;

  @override
  String toString() {
    return 'PromoLevelModel(currentPromoLevel: $currentPromoLevel, nextPromoLevel: $nextPromoLevel, countInvites: $countInvites, countToNewLevel: $countToNewLevel, isAvailableNewLevel: $isAvailableNewLevel, isLastLevel: $isLastLevel)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$PromoLevelModelImpl &&
            (identical(other.currentPromoLevel, currentPromoLevel) ||
                other.currentPromoLevel == currentPromoLevel) &&
            (identical(other.nextPromoLevel, nextPromoLevel) ||
                other.nextPromoLevel == nextPromoLevel) &&
            (identical(other.countInvites, countInvites) ||
                other.countInvites == countInvites) &&
            (identical(other.countToNewLevel, countToNewLevel) ||
                other.countToNewLevel == countToNewLevel) &&
            (identical(other.isAvailableNewLevel, isAvailableNewLevel) ||
                other.isAvailableNewLevel == isAvailableNewLevel) &&
            (identical(other.isLastLevel, isLastLevel) ||
                other.isLastLevel == isLastLevel));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      currentPromoLevel,
      nextPromoLevel,
      countInvites,
      countToNewLevel,
      isAvailableNewLevel,
      isLastLevel);

  /// Create a copy of PromoLevelModel
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$PromoLevelModelImplCopyWith<_$PromoLevelModelImpl> get copyWith =>
      __$$PromoLevelModelImplCopyWithImpl<_$PromoLevelModelImpl>(
          this, _$identity);
}

abstract class _PromoLevelModel implements PromoLevelModel {
  const factory _PromoLevelModel(
      {required final PromoLevel? currentPromoLevel,
      required final PromoLevel? nextPromoLevel,
      required final int countInvites,
      required final int countToNewLevel,
      final bool isAvailableNewLevel,
      final bool isLastLevel}) = _$PromoLevelModelImpl;

  @override
  PromoLevel? get currentPromoLevel;
  @override
  PromoLevel? get nextPromoLevel;
  @override
  int get countInvites;
  @override
  int get countToNewLevel;
  @override
  bool get isAvailableNewLevel;
  @override
  bool get isLastLevel;

  /// Create a copy of PromoLevelModel
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$PromoLevelModelImplCopyWith<_$PromoLevelModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
