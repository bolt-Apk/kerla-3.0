import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/app_buffer/ads/representation/ad_card/ad_price.dart';
import 'package:kerla2_flutter/router/router.dart';
import 'package:kerla2_flutter/ui_kit/basic_widgets/image_or_video_thumbnail_widget.dart';
import 'package:nit_app/nit_app.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class AdPreviewWidget extends ConsumerWidget {
  const AdPreviewWidget({super.key, required this.adId});

  final int adId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return ref.watchOrFetchMaybeModelAsync<Ad>(adId).nitWhen(
        childBuilder: (ad) {
      if (ad == null) {
        return const SizedBox.shrink();
      }
      return SizedBox(
        height: 60,
        child: InkWell(
          onTap: () {
            if (ad.adType == AdType.story) {
              context.pushNamed(
                MainAreaNavigationZone.userStoriesByStoryId.name,
                pathParameters: AppNavigationParams.storyId.set(ad.id!),
              );
            } else {
              context.pushNamed(
                AdNavigationZone.adPage.name,
                pathParameters: AppNavigationParams.adId.set(ad.id!),
              );
            }
          },
          child: Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(6),
                child: SizedBox(
                  height: 60,
                  width: 60,
                  child: ImageOrVideoThumbnailWidget(
                    url: ad.media?.firstOrNull?.publicUrl ?? '',
                    type: ad.media?.firstOrNull?.type ?? MediaType.image,
                  ),
                ),
              ),
              const Gap(8),
              Flexible(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      ad.adType == AdType.story ? ad.description : ad.title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: context.textTheme.bodyMedium,
                    ),
                    if (ad.price != 0) AdPrice(price: ad.price),
                  ],
                ),
              ),
            ],
          ),
        ),
      );
    });
  }
}
