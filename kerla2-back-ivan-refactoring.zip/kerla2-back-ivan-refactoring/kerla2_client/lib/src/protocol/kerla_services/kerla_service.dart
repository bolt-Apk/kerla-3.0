/* AUTOMATICALLY GENERATED CODE DO NOT MODIFY */
/*   To generate run: "serverpod generate"    */

// ignore_for_file: implementation_imports
// ignore_for_file: library_private_types_in_public_api
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: public_member_api_docs
// ignore_for_file: type_literal_in_constant_pattern
// ignore_for_file: use_super_parameters

// ignore_for_file: no_leading_underscores_for_library_prefixes
import 'package:serverpod_client/serverpod_client.dart' as _i1;
import '../protocol.dart' as _i2;
import 'package:dartway_tinkoff_serverpod_client/dartway_tinkoff_serverpod_client.dart'
    as _i3;

abstract class KerlaService implements _i1.SerializableModel {
  KerlaService._({
    this.id,
    required this.type,
    required this.endsAt,
    this.dwPaymentId,
    this.dwPayment,
    this.adId,
    this.isFree,
    this.price,
    this.daysCount,
  });

  factory KerlaService({
    int? id,
    required _i2.KerlaServiceType type,
    required DateTime endsAt,
    int? dwPaymentId,
    _i3.DwTinkoffPayment? dwPayment,
    int? adId,
    bool? isFree,
    int? price,
    int? daysCount,
  }) = _KerlaServiceImpl;

  factory KerlaService.fromJson(Map<String, dynamic> jsonSerialization) {
    return KerlaService(
      id: jsonSerialization['id'] as int?,
      type:
          _i2.KerlaServiceType.fromJson((jsonSerialization['type'] as String)),
      endsAt: _i1.DateTimeJsonExtension.fromJson(jsonSerialization['endsAt']),
      dwPaymentId: jsonSerialization['dwPaymentId'] as int?,
      dwPayment: jsonSerialization['dwPayment'] == null
          ? null
          : _i3.DwTinkoffPayment.fromJson(
              (jsonSerialization['dwPayment'] as Map<String, dynamic>)),
      adId: jsonSerialization['adId'] as int?,
      isFree: jsonSerialization['isFree'] as bool?,
      price: jsonSerialization['price'] as int?,
      daysCount: jsonSerialization['daysCount'] as int?,
    );
  }

  /// The database id, set if the object has been inserted into the
  /// database or if it has been fetched from the database. Otherwise,
  /// the id will be null.
  int? id;

  _i2.KerlaServiceType type;

  DateTime endsAt;

  int? dwPaymentId;

  _i3.DwTinkoffPayment? dwPayment;

  int? adId;

  bool? isFree;

  int? price;

  int? daysCount;

  KerlaService copyWith({
    int? id,
    _i2.KerlaServiceType? type,
    DateTime? endsAt,
    int? dwPaymentId,
    _i3.DwTinkoffPayment? dwPayment,
    int? adId,
    bool? isFree,
    int? price,
    int? daysCount,
  });
  @override
  Map<String, dynamic> toJson() {
    return {
      if (id != null) 'id': id,
      'type': type.toJson(),
      'endsAt': endsAt.toJson(),
      if (dwPaymentId != null) 'dwPaymentId': dwPaymentId,
      if (dwPayment != null) 'dwPayment': dwPayment?.toJson(),
      if (adId != null) 'adId': adId,
      if (isFree != null) 'isFree': isFree,
      if (price != null) 'price': price,
      if (daysCount != null) 'daysCount': daysCount,
    };
  }

  @override
  String toString() {
    return _i1.SerializationManager.encode(this);
  }
}

class _Undefined {}

class _KerlaServiceImpl extends KerlaService {
  _KerlaServiceImpl({
    int? id,
    required _i2.KerlaServiceType type,
    required DateTime endsAt,
    int? dwPaymentId,
    _i3.DwTinkoffPayment? dwPayment,
    int? adId,
    bool? isFree,
    int? price,
    int? daysCount,
  }) : super._(
          id: id,
          type: type,
          endsAt: endsAt,
          dwPaymentId: dwPaymentId,
          dwPayment: dwPayment,
          adId: adId,
          isFree: isFree,
          price: price,
          daysCount: daysCount,
        );

  @override
  KerlaService copyWith({
    Object? id = _Undefined,
    _i2.KerlaServiceType? type,
    DateTime? endsAt,
    Object? dwPaymentId = _Undefined,
    Object? dwPayment = _Undefined,
    Object? adId = _Undefined,
    Object? isFree = _Undefined,
    Object? price = _Undefined,
    Object? daysCount = _Undefined,
  }) {
    return KerlaService(
      id: id is int? ? id : this.id,
      type: type ?? this.type,
      endsAt: endsAt ?? this.endsAt,
      dwPaymentId: dwPaymentId is int? ? dwPaymentId : this.dwPaymentId,
      dwPayment: dwPayment is _i3.DwTinkoffPayment?
          ? dwPayment
          : this.dwPayment?.copyWith(),
      adId: adId is int? ? adId : this.adId,
      isFree: isFree is bool? ? isFree : this.isFree,
      price: price is int? ? price : this.price,
      daysCount: daysCount is int? ? daysCount : this.daysCount,
    );
  }
}
