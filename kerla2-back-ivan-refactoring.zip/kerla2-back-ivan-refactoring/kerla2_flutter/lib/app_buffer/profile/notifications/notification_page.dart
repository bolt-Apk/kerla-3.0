import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kerla2_flutter/app_buffer/profile/profile_image/profile_image.dart';
import 'package:kerla2_flutter/common/infinite_list_view/infinite_list_view.dart';
import 'package:kerla2_flutter/core/app_backend_filters.dart';
import 'package:kerla2_flutter/core/app_scaffold.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_app/nit_app.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';
import 'package:visibility_detector/visibility_detector.dart';

class NotificationPage extends HookConsumerWidget {
  const NotificationPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final signedUserId = ref.signedInUserId;
    if (signedUserId == null) return const SizedBox.shrink();
    return AppScaffold(
      appBar: AppBar(
        title: const Text(
          'Уведомления',
        ),
      ),
      body: InfiniteListView<NitAppNotification>(
        listViewConfig: EntityListConfig(
          backendFilter: AppBackendFilter.toUserId.equals(signedUserId),
          pageSize: 20,
        ),
        emptyListPlaceHolder: const Center(
          child: Text(
            'Нет уведомлений',
          ),
        ),
        separatorBuilder: (BuildContext context, int index) {
          return const Divider();
        },
        listTileBuilder: (context, notification) {
          return VisibilityDetector(
            key: ValueKey(notification.id),
            onVisibilityChanged: (info) {
              if (info.visibleFraction > 0.5) {
                if (!notification.isRead) {
                  ref.saveModel(notification.copyWith(isRead: true));
                }
              }
            },
            child: InkWell(
              onTap: () {
                if (notification.goToPath != null) {
                  context.pushNamed(
                    notification.goToPath!,
                    pathParameters:
                        notification.pathQueryParams!.parsePushPathParameters,
                  );
                }
              },
              child: Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 8,
                  vertical: 8,
                ),
                child: Row(
                  children: [
                    if (notification.fromUserId != null)
                      ProfileImage(
                        userId: notification.fromUserId!,
                      ),
                    if (!notification.isRead)
                      const CircleAvatar(
                        radius: 3,
                        backgroundColor: Colors.red,
                      ),
                    const SizedBox(width: 8),
                    Flexible(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            notification.title,
                            style: context.theme.textTheme.titleMedium,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Flexible(
                                flex: 3,
                                child: Text(
                                  notification.body ?? '',
                                  style: context.theme.textTheme.bodySmall,
                                  overflow: TextOverflow.ellipsis,
                                  maxLines: 2,
                                ),
                              ),
                              Flexible(
                                flex: 2,
                                child: Text(
                                  notification.timestamp.formatDate,
                                  overflow: TextOverflow.ellipsis,
                                  style: context.theme.textTheme.bodySmall,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );

    //    ref
    //       .watchEntityListAsync<NitAppNotification>(
    //         backendFilter: AppBackendFilter.toUserId.equals(ref.signedInUserId),
    //       )
    //       .nitWhenList(
    //         loadingItemsCount: 1,
    //         loadingItem: NitDefaultModelsRepository.get<NitAppNotification>(),
    //         childBuilder: (notifications) {
    //           if (notifications.isEmpty) {
    //             return const Center(
    //               child: Text(
    //                 'Нет уведомлений',
    //               ),
    //             );
    //           }
    //           return ListView.separated(
    //             itemCount: notifications.length,
    //             shrinkWrap: true,
    //             itemBuilder: (context, index) {
    //               final notification = notifications[index];
    //               return InkWell(
    //                 onTap: () {
    //                   if (notification.goToPath != null) {
    //                     context.pushNamed(
    //                       notification.goToPath!,
    //                       pathParameters: notification
    //                           .pathQueryParams!.parsePushPathParameters,
    //                     );
    //                   }
    //                 },
    //                 child: Padding(
    //                   padding: const EdgeInsets.symmetric(
    //                     horizontal: 8,
    //                     vertical: 8,
    //                   ),
    //                   child: Row(
    //                     children: [
    //                       if (notification.fromUserId != null)
    //                         ProfileImage(
    //                           userId: notification.fromUserId!,
    //                         ),
    //                       const SizedBox(width: 8),
    //                       Flexible(
    //                         child: Column(
    //                           mainAxisSize: MainAxisSize.min,
    //                           crossAxisAlignment: CrossAxisAlignment.start,
    //                           children: [
    //                             Text(
    //                               notification.title,
    //                               style: context.theme.textTheme.titleMedium,
    //                             ),
    //                             Row(
    //                               mainAxisAlignment:
    //                                   MainAxisAlignment.spaceBetween,
    //                               children: [
    //                                 Flexible(
    //                                   flex: 3,
    //                                   child: Text(
    //                                     notification.body ?? '',
    //                                     style:
    //                                         context.theme.textTheme.bodySmall,
    //                                     overflow: TextOverflow.ellipsis,
    //                                     maxLines: 2,
    //                                   ),
    //                                 ),
    //                                 Flexible(
    //                                   flex: 2,
    //                                   child: Text(
    //                                     notification.timestamp.formatDate,
    //                                     overflow: TextOverflow.ellipsis,
    //                                     style:
    //                                         context.theme.textTheme.bodySmall,
    //                                   ),
    //                                 ),
    //                               ],
    //                             ),
    //                           ],
    //                         ),
    //                       ),
    //                     ],
    //                   ),
    //                 ),
    //               );
    //             },
    //             separatorBuilder: (BuildContext context, int index) {
    //               return const Divider();
    //             },
    //           );
    //         },
    //       ),
    // );
  }
}
