import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class AttributeInput extends HookConsumerWidget {
  const AttributeInput({
    super.key,
    required this.attributeValue,
    required this.onAccept,
    this.keyboardType,
    this.textAlign,
  });

  final AdAttributeValue attributeValue;
  final TextInputType? keyboardType;
  final TextAlign? textAlign;
  final Function(AdAttributeValue) onAccept;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final controller = useTextEditingController(text: attributeValue.value);
    return Column(
      children: [
        attributeValue.attribute?.title != null
            ? Padding(
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    attributeValue.attribute!.title!,
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                ),
              )
            : const SizedBox(),
        Container(
          height: 40,
          decoration: BoxDecoration(
            color: Theme.of(context).canvasColor,
            borderRadius: BorderRadius.circular(10),
          ),
          child: TextFormField(
            inputFormatters: [
              if (attributeValue.attribute?.type == AttributeType.number)
                FilteringTextInputFormatter.digitsOnly,
              if (attributeValue.attribute?.type == AttributeType.decimal)
                FilteringTextInputFormatter.allow(RegExp(r'^\d+\.?\d*')),
            ],
            style: context.textTheme.titleMedium,
            controller: controller,
            onChanged: (text) => onAccept(attributeValue.copyWith(value: text)),
            onEditingComplete: () => debugPrint('123123'),
            textAlign: textAlign ?? TextAlign.start,
            keyboardType: keyboardType,
            decoration: InputDecoration(
              suffixText: attributeValue.attribute?.suffixText,
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: const BorderSide(color: Colors.transparent),
              ),
              focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide(
                      color:
                          Theme.of(context).iconTheme.color ?? Colors.black)),
              contentPadding: const EdgeInsets.symmetric(horizontal: 8),
            ),
          ),
        ),
      ],
    );
  }
}

// class AttributeInput extends ConsumerStatefulWidget {
//   const AttributeInput({
//     super.key,
//     required this.attributeValue,
//     required this.onAccept,
//     this.keyboardType,
//     this.textAlign,
//     // this.title,
//     // this.suffixText,
//     // this.max,
//     // this.min,
//   });

//   final AdAttributeValue attributeValue;

//   // final String? title;
//   // final String? suffixText;
//   final TextInputType? keyboardType;
//   // final int? max;
//   // final int? min;
//   final TextAlign? textAlign;
//   final Function(AdAttributeValue) onAccept;

//   @override
//   ConsumerState<ConsumerStatefulWidget> createState() => _AttributeInputState();
// }

// class _AttributeInputState extends ConsumerState<AttributeInput> {
//   final TextEditingController controller = TextEditingController();
//   @override
//   void initState() {
//     super.initState();
//     controller.text = widget.attributeValue.value;
//   }

//   @override
//   Widget build(BuildContext context) {
//     // void onChanged(String text) {
//     //   if (widget.adId == null) {
//     //     ref.read(adCreateStateProvider(isStory: false).notifier).setAttribute(
//     //           widget.attributeValue.attribute!,
//     //           text,
//     //         );
//     //   } else {
//     //     ref
//     //         .read(adEditStateProvider(adId: widget.adId).notifier)
//     //         .updateAttributeValue(
//     //           widget.attributeValue.attributeId,
//     //           widget.attributeValue.attribute?.subAttributeId != null,
//     //           text,
//     //         );
//     //   }
//     // }

//     return Column(
//       children: [
//         widget.title != null
//             ? Padding(
//                 padding: const EdgeInsets.symmetric(vertical: 8),
//                 child: Align(
//                   alignment: Alignment.centerLeft,
//                   child: Text(
//                     widget.title!,
//                     style: Theme.of(context).textTheme.titleLarge,
//                   ),
//                 ),
//               )
//             : const SizedBox(),
//         Container(
//           height: 40,
//           decoration: BoxDecoration(
//             color: Theme.of(context).canvasColor,
//             borderRadius: BorderRadius.circular(10),
//           ),
//           child: TextFormField(
//             style: context.textTheme.titleMedium,
//             controller: controller,
//             onChanged: (text) => widget.onAccept(text),
//             onEditingComplete: () => debugPrint('123123'),
//             textAlign: widget.textAlign ?? TextAlign.start,
//             keyboardType: widget.keyboardType,
//             decoration: InputDecoration(
//               suffixText: widget.suffixText,
//               enabledBorder: OutlineInputBorder(
//                 borderRadius: BorderRadius.circular(10),
//                 borderSide: const BorderSide(color: Colors.transparent),
//               ),
//               focusedBorder: OutlineInputBorder(
//                   borderRadius: BorderRadius.circular(10),
//                   borderSide: BorderSide(
//                       color:
//                           Theme.of(context).iconTheme.color ?? Colors.black)),
//               contentPadding: const EdgeInsets.symmetric(horizontal: 8),
//             ),
//           ),
//         ),
//       ],
//     );
//   }
// }
