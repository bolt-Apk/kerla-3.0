import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:kerla2_flutter/app_buffer/profile/subscribers/widgets/subscribe_button.dart';
import 'package:kerla2_flutter/common/user_profile_ref_extensions.dart';

import 'package:kerla2_flutter/router/router.dart';
import 'package:nit_app/nit_app.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class UserSearchItem extends ConsumerWidget {
  const UserSearchItem({
    super.key,
    required this.userId,
  });

  final int userId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final colorScheme = context.theme.colorScheme;

    return ref.watchUserProfile(userId).nitWhen(
          childBuilder: (user) => Material(
            color: colorScheme.surface,
            child: InkWell(
              onTap: () => context.pushNamed(
                MainAreaNavigationZone.user.name,
                pathParameters: AppNavigationParams.userId.set(user.userId),
              ),
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(
                  children: [
                    // Avatar
                    // should be UserProfile
                    Container(
                      width: 45,
                      height: 45,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: colorScheme.outlineVariant,
                          width: 0.5,
                        ),
                      ),
                      child: ClipOval(
                        child: user.imageUrl?.isNotEmpty == true
                            ? CachedNetworkImage(
                                imageUrl: user.imageUrl!,
                                fit: BoxFit.cover,
                                errorWidget: (context, url, error) =>
                                    const Icon(Icons.person, size: 40),
                              )
                            : const Icon(Icons.person, size: 40),
                      ),
                    ),
                    const Gap(16),
                    // User info
                    Expanded(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            user.userName ?? 'Пользователь',
                            style: context.textTheme.titleMedium?.copyWith(
                              fontWeight: FontWeight.w600,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          if (user.profileDescription?.isNotEmpty == true) ...{
                            const Gap(4),
                            Text(
                              user.profileDescription!,
                              style: context.textTheme.bodyMedium?.copyWith(
                                color: colorScheme.onSurfaceVariant,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          },
                        ],
                      ),
                    ),
                    // const Spacer(),
                    if (ref.signedIn)
                      SubscribeButton(
                        key: ValueKey(user.userId),
                        userId: user.userId,
                      )
                  ],
                ),
              ),
            ),
          ),
        );
  }
}
