import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:kerla2_flutter/common/user_profile_extension.dart';
import 'package:kerla2_flutter/common/user_profile_ref_extensions.dart';
import 'package:kerla2_flutter/router/router.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class BusinessInfoWidget extends ConsumerWidget {
  const BusinessInfoWidget({
    super.key,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final userProfile = ref.currentUserProfile!;
    return AdditionalInfoWidget(
      infoWidget: Column(
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 100),
            child: Container(
              color: Colors.grey.withOpacity(0.15),
              height: 1,
              width: MediaQuery.sizeOf(context).width * 0.6,
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(
              left: 16,
              top: 12,
              bottom: 12,
            ),
            child: InkWell(
              onTap: () => context
                  .pushNamed(MainAreaNavigationZone.businessProfile.name),
              child: Row(
                children: [
                  Text(
                    'БП активен до: ',
                    style: Theme.of(context)
                        .textTheme
                        .titleMedium
                        ?.copyWith(color: ThemePrimaryColors.primary),
                  ),
                  const SizedBox(
                    width: 8,
                  ),
                  Text(
                    userProfile.businessEndsAtString(ref),
                    style: Theme.of(context).textTheme.labelMedium?.copyWith(
                          fontSize: 15,
                        ),
                  ),
                  const Spacer(),
                  Icon(
                    Icons.chevron_right,
                    color: Theme.of(context).iconTheme.color,
                  ),
                  const Gap(12),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
