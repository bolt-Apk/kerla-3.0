import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class AttributeRangeInput extends HookConsumerWidget {
  const AttributeRangeInput({
    super.key,
    required this.onSave,
    required this.leftController,
    required this.rightController,
    this.title,
    this.suffixText,
    this.keyboardType,
    this.maxCount,
  });

  final Function(String) onSave;
  final TextEditingController leftController;
  final TextEditingController rightController;
  final String? title;
  final String? suffixText;
  final TextInputType? keyboardType;
  final int? maxCount;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    void handleRangeChange() {
      final leftValue = leftController.text;
      final rightValue = rightController.text;
      final rangeValue =
          "${leftValue.isEmpty ? '-1' : leftValue}:${rightValue.isEmpty ? '-1' : rightValue}";
      onSave(rangeValue);
    }

    return Column(
      children: [
        if (title != null && title!.isNotEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Text(
                title!,
                style: context.textTheme.titleLarge,
              ),
            ),
          ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Expanded(
              child: Container(
                height: 40,
                decoration: BoxDecoration(
                  color: context.theme.canvasColor,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: TextFormField(
                  style: context.textTheme.displaySmall,
                  keyboardType: keyboardType,
                  controller: leftController,
                  onChanged: (_) => handleRangeChange(),
                  decoration: InputDecoration(
                    hintText: "От  ",
                    suffixText: suffixText,
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: context.theme.canvasColor),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: context.theme.canvasColor),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    fillColor: context.theme.canvasColor,
                    contentPadding: const EdgeInsets.symmetric(horizontal: 8),
                  ),
                  inputFormatters: [
                    LengthLimitingTextInputFormatter(maxCount),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Container(
                height: 40,
                decoration: BoxDecoration(
                  color: context.theme.canvasColor,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: TextFormField(
                  style: context.textTheme.displaySmall,
                  keyboardType: keyboardType,
                  controller: rightController,
                  onChanged: (_) => handleRangeChange(),
                  decoration: InputDecoration(
                    hintText: "До  ",
                    suffixText: suffixText,
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: context.theme.canvasColor),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: context.theme.canvasColor),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 8),
                  ),
                  inputFormatters: [
                    LengthLimitingTextInputFormatter(maxCount),
                  ],
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
      ],
    );
  }
}
