// import 'package:collection/collection.dart';
// import 'package:flutter/foundation.dart';
// import 'package:kerla2_client/kerla2_client.dart';
// import 'package:kerla2_flutter/app_old/chats/state/chat_controller_state.dart'
//     as chat_controller_state;
// import 'package:kerla2_flutter/core/core.dart';
// import 'package:nit_app/nit_app.dart';
// import 'package:riverpod_annotation/riverpod_annotation.dart';

// part 'chat_list_state.g.dart';

// @Riverpod(keepAlive: true)
// class ChatListState extends _$ChatListState {
//   @override
//   Future<List<ChannelInfo>> build() async {
//     // ref.onDispose(() {
//     //   ChatDispatch.getInstance(client.modules.chat)
//     //       .removeListener('user$userId');
//     // });

//     final userId = ref.signedInUserId;
//     print('building chat list for $userId');

//     // final chats = <ChatManager>[];
//     if (!ref.signedIn) return [];

//     final channels = await client.channels.getPrivateChannels();

//     // ChatDispatch.getInstance(client.user.caller as Caller)
//     // .addListener('user$userId', _newChannelListener);

//     newChannelListener();

//     // await client.openStreamingConnection();

//     // for (var channel in channels) {
//     //   chats.add(
//     //     ChatManager(channel: channel),
//     //   );
//     // }

//     return channels;
//   }

//   void newChannelListener() async {
//     client.channels.resetStream();

//     await for (var update in client.channels.stream) {
//       if (update is ChannelInfo) {
//         final isInChatNow = ref.exists(
//             chat_controller_state.chatControllerStateProvider(update.channel));

//         final old = state.value?.indexWhere((e) => e.channel == update.channel);

//         if (old != null && old != -1) {
//           if (isInChatNow) return;
//           final newList = state.value!;
//           newList[old] = newList[old].copyWith(
//             hasUnreadMessages: update.hasUnreadMessages,
//             lastMessage: update.lastMessage,
//           );

//           state = AsyncValue.data(_sortList(newList));
//         } else {
//           state = AsyncValue.data(_sortList([update, ...state.value!]));
//         }
//       }
//     }
//   }

//   List<ChannelInfo> _sortList(List<ChannelInfo> list) {
//     try {
//       list.sort((a, b) => b.lastMessage!.time.compareTo(a.lastMessage!.time));
//     } catch (e) {
//       debugPrint(e.toString());
//     }
//     return list;
//   }

//   void updateState(List<ChannelInfo> newList) {
//     state = AsyncValue.data(_sortList(newList));
//   }

//   void removeChannel(ChannelInfo channel) {
//     final res = AsyncValue.data(_sortList(state.value!
//         .where((element) => element.channel != channel.channel)
//         .toList()));
//     state = res;
//   }
// }

// @riverpod
// Future<ChannelInfo?> startChat(
//   StartChatRef ref,
//   int? chatWithId,
//   int? adId,
//   int? channelInfoId,
// ) async {
//   try {
//     final future = ref.watch(chatListStateProvider);
//     final value =
//         future.maybeWhen(data: (data) => data, orElse: List<ChannelInfo>.empty);

//     ChannelInfo? channel = value.firstWhereOrNull(
//       (e) =>
//           (e.chatWith?.id == chatWithId && e.adId == adId) ||
//           e.id == channelInfoId,
//     );

//     if (channel == null) {
//       channel = await client.channels.getPrivateChatChannel(chatWithId, adId);

//       ref
//           .watch(chatListStateProvider.notifier)
//           .updateState([channel, ...value]);
//     }

//     return channel;
//   } catch (e) {
//     debugPrint(e.toString());
//     return null;
//   }
// }
