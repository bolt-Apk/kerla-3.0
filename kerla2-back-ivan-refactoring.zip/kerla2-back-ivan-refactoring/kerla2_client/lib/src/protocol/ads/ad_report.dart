/* AUTOMATICALLY GENERATED CODE DO NOT MODIFY */
/*   To generate run: "serverpod generate"    */

// ignore_for_file: implementation_imports
// ignore_for_file: library_private_types_in_public_api
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: public_member_api_docs
// ignore_for_file: type_literal_in_constant_pattern
// ignore_for_file: use_super_parameters

// ignore_for_file: no_leading_underscores_for_library_prefixes
import 'package:serverpod_client/serverpod_client.dart' as _i1;
import '../protocol.dart' as _i2;

abstract class AdReport implements _i1.SerializableModel {
  AdReport._({
    this.id,
    required this.complaint,
    required this.accusedId,
    required this.adId,
  });

  factory AdReport({
    int? id,
    required _i2.AdReportReason complaint,
    required int accusedId,
    required int adId,
  }) = _AdReportImpl;

  factory AdReport.fromJson(Map<String, dynamic> jsonSerialization) {
    return AdReport(
      id: jsonSerialization['id'] as int?,
      complaint:
          _i2.AdReportReason.fromJson((jsonSerialization['complaint'] as int)),
      accusedId: jsonSerialization['accusedId'] as int,
      adId: jsonSerialization['adId'] as int,
    );
  }

  /// The database id, set if the object has been inserted into the
  /// database or if it has been fetched from the database. Otherwise,
  /// the id will be null.
  int? id;

  _i2.AdReportReason complaint;

  int accusedId;

  int adId;

  AdReport copyWith({
    int? id,
    _i2.AdReportReason? complaint,
    int? accusedId,
    int? adId,
  });
  @override
  Map<String, dynamic> toJson() {
    return {
      if (id != null) 'id': id,
      'complaint': complaint.toJson(),
      'accusedId': accusedId,
      'adId': adId,
    };
  }

  @override
  String toString() {
    return _i1.SerializationManager.encode(this);
  }
}

class _Undefined {}

class _AdReportImpl extends AdReport {
  _AdReportImpl({
    int? id,
    required _i2.AdReportReason complaint,
    required int accusedId,
    required int adId,
  }) : super._(
          id: id,
          complaint: complaint,
          accusedId: accusedId,
          adId: adId,
        );

  @override
  AdReport copyWith({
    Object? id = _Undefined,
    _i2.AdReportReason? complaint,
    int? accusedId,
    int? adId,
  }) {
    return AdReport(
      id: id is int? ? id : this.id,
      complaint: complaint ?? this.complaint,
      accusedId: accusedId ?? this.accusedId,
      adId: adId ?? this.adId,
    );
  }
}
