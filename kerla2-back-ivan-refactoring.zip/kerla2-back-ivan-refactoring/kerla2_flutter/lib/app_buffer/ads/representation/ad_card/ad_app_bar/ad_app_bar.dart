import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_svg/svg.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/app_buffer/ads/representation/ad_card/ad_app_bar/widgets/show_phone_icon.dart';
import 'package:kerla2_flutter/app_buffer/ads/representation/ad_card/ad_more_info_button.dart';
import 'package:kerla2_flutter/app_buffer/ads/utils/ad_share.dart';
import 'package:kerla2_flutter/app_buffer/profile/categories/state/categories_provider.dart';
import 'package:kerla2_flutter/router/router.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_app/nit_app.dart';
import 'package:nit_router/nit_router.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

import '../../ad_list/state/ad_list_state.dart';
import 'ad_app_bar_title.dart';

class AdAppbar extends ConsumerWidget implements PreferredSizeWidget {
  const AdAppbar({
    super.key,
    required this.ad,
  });

  final Ad ad;

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final isMyAd = ref.signedInUserId == ad.userId;

    void deleteDialog() => showDialog(
          context: context,
          builder: (context) => Dialog(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text(
                    'Вы уверены, что хотите удалить объявление?',
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 10),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      TextButton(
                        child: const Text('Отмена'),
                        onPressed: () => context.pop(),
                      ),
                      TextButton(
                        child: const Text('Удалить'),
                        onPressed: () async {
                          await ref.deleteModel<Ad>(ad);
                          if (context.mounted && context.canPop()) {
                            ref
                                .read(
                                  adListStateProvider(GetAdParam(
                                    adListType: AdListType.profile,
                                    id: ref.signedInUserId,
                                  )),
                                )
                                .controller
                                .refresh();
                            ref.invalidate(profileAdCategoriesProvider);
                            context.pop();
                            if (context.mounted) {
                              context.pop();
                            }
                          }
                        },
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        );

    return AppBar(
      leading: BackButton(
        onPressed: () {
          if (context.canPop()) {
            context.pop();
          } else {
            context.goNamed(MainAreaNavigationZone.homePage.name);
          }
        },
        color: theme.iconTheme.color,
      ),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          bottom: Radius.circular(16),
        ),
      ),
      titleSpacing: 0,
      title: AdAppBarTitle(ad: ad),
      elevation: 1,
      iconTheme: const IconThemeData(color: Colors.black),
      actions: [
        isMyAd
            ? Row(
                children: [
                  IconButton(
                    icon: SvgPicture.asset(
                      AppIconsSvg.edit,
                      height: 20,
                      width: 20,
                      colorFilter: ColorFilter.mode(
                        theme.iconTheme.color ?? Colors.black,
                        BlendMode.srcIn,
                      ),
                    ),
                    onPressed: () => context.pushNamed(
                      AdNavigationZone.edit.name,
                      pathParameters: AppNavigationParams.adId.set(ad.id!),
                    ),
                  ),
                  IconButton(
                    icon: SvgPicture.asset(
                      AppIconsSvg.delete,
                      colorFilter: ColorFilter.mode(
                        theme.iconTheme.color ?? Colors.black,
                        BlendMode.srcIn,
                      ),
                      height: 20,
                      width: 20,
                    ),
                    onPressed: deleteDialog,
                  ),
                ],
              )
            : Row(
                children: [
                  ShowPhoneIcon(
                    userId: ad.userId!,
                  ),
                  IconButton(
                    visualDensity: VisualDensity.compact,
                    icon: const Icon(Icons.share),
                    onPressed: () => AdShareState(context, ad.id!)
                        .showChatShareBottomSheet(),
                  ),
                  const Gap(10),
                  AdMoreInfoButton(
                    ad: ad,
                    icon: Icons.more_vert,
                    size: 25,
                  ),
                  const Gap(10)
                ],
              ),
      ],
      backgroundColor: context.colorScheme.surface,
    );
  }
}
