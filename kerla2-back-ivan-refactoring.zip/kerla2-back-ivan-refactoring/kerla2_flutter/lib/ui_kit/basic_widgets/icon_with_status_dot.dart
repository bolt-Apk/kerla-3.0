part of '../ui_kit.dart';

class IconWithStatusDot extends StatelessWidget {
  const IconWithStatusDot({
    super.key,
    required this.svgIcon,
    this.iconColor = Colors.black,
    this.withStatusDot = false,
  });
  final String svgIcon;
  final Color iconColor;
  final bool withStatusDot;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 20,
      width: 20,
      child: Stack(
        children: [
          SvgPicture.asset(
            svgIcon,
            height: 18,
            width: 18,
            colorFilter: ColorFilter.mode(iconColor, BlendMode.srcIn),
          ),
          // TODO: вернуть
          // if (withStatusDot)
          //   const Positioned(
          //     top: 0,
          //     right: 5,
          //     child: StatusDot(
          //       isIconStatusDot: true,
          //     ),
          //   ),
        ],
      ),
    );
  }
}
