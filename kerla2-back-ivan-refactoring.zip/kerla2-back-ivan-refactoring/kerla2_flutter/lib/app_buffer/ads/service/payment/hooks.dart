// import 'package:flutter/material.dart';
// import 'package:flutter_hooks/flutter_hooks.dart';
// import 'package:flutter_riverpod/flutter_riverpod.dart';
// import 'package:kerla2_flutter/ui_kit/ui_kit.dart';

// import 'payment/payment_state.dart';

// void useFlashErrorNotifier(WidgetRef ref) {
//   final state = ref.watch(paymentStateProvider);
//   final isMounted = useIsMounted();
//   final context = useContext();

//   if (state.error != null && state.error!.isNotEmpty) {
//     WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
//       if (isMounted()) {
//         context.showDefaultErrorFlash(
//           state.error ?? 'Что-то пошло не так',
//         );

//         ref.read(paymentStateProvider.notifier).resetError();
//       }
//     });
//   }
// }
