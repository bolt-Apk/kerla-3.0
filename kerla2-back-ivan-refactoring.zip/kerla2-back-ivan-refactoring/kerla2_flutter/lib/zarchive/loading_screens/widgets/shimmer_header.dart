// part of '../../ui_kit.dart';

// class ShimmerHeader extends StatelessWidget {
//   const ShimmerHeader({
//     super.key,
//     this.height = 60,
//     this.width,
//   });

//   final double height;
//   final double? width;

//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       margin: const EdgeInsets.symmetric(horizontal: 2),
//       height: height,
//       width: width,
//       decoration: BoxDecoration(
//         color: context.theme.canvasColor,
//         borderRadius: BorderRadius.circular(12),
//       ),
//     );
//   }
// }
