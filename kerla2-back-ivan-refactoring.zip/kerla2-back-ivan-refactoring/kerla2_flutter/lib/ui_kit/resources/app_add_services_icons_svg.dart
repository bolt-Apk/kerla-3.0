part of '../ui_kit.dart';

class AppAddServicesIconsSvg {
  AppAddServicesIconsSvg._();

  static const String arrow = 'assets/icons/add_services/arrow.svg';
  static const String rocket = 'assets/icons/add_services/rocket.svg';
  static const String stories = 'assets/icons/add_services/stories.svg';
  static const String businessCase =
      'assets/icons/add_services/business_case.svg';
}
