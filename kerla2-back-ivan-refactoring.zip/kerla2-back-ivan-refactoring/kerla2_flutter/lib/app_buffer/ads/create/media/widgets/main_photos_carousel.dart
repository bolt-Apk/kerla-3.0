import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:wechat_assets_picker/wechat_assets_picker.dart';

import '../state/last_media_provider.dart';
import 'asset.dart';

class MainPhotosCarousel extends ConsumerWidget {
  const MainPhotosCarousel({
    super.key,
    required this.imageSize,
  });

  final double imageSize;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final lastMedia = ref.watch(lastMediaProvider(context: context));

    return Container(
      padding: const EdgeInsets.only(left: 5),
      height: imageSize,
      width: double.infinity,
      child: lastMedia.maybeWhen(
        data: (data) {
          return ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: data.length,
            itemBuilder: (context, index) {
              final AssetEntity assetEntity = data[index];
              return SizedBox(
                width: imageSize + 8,
                height: imageSize + 8,
                child: Padding(
                  padding: const EdgeInsets.all(4),
                  child: Asset(assetEntity: assetEntity),
                ),
              );
            },
          );
        },
        orElse: () => const SizedBox.shrink(),
      ),
    );
  }
}
