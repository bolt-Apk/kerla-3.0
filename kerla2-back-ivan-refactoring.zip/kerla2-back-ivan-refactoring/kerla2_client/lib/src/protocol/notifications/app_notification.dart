/* AUTOMATICALLY GENERATED CODE DO NOT MODIFY */
/*   To generate run: "serverpod generate"    */

// ignore_for_file: implementation_imports
// ignore_for_file: library_private_types_in_public_api
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: public_member_api_docs
// ignore_for_file: type_literal_in_constant_pattern
// ignore_for_file: use_super_parameters

// ignore_for_file: no_leading_underscores_for_library_prefixes
import 'package:serverpod_client/serverpod_client.dart' as _i1;
import '../protocol.dart' as _i2;

/// Users notification
abstract class AppNotification implements _i1.SerializableModel {
  AppNotification._({
    this.id,
    this.toUserId,
    this.fromUserId,
    this.fromUserImage,
    this.fromUserName,
    this.channelId,
    this.adId,
    required this.timestamp,
    this.title,
    required this.text,
    this.link,
    required this.type,
    required this.isRead,
  });

  factory AppNotification({
    int? id,
    int? toUserId,
    int? fromUserId,
    String? fromUserImage,
    String? fromUserName,
    int? channelId,
    int? adId,
    required DateTime timestamp,
    String? title,
    required String text,
    String? link,
    required _i2.NotificationType type,
    required bool isRead,
  }) = _AppNotificationImpl;

  factory AppNotification.fromJson(Map<String, dynamic> jsonSerialization) {
    return AppNotification(
      id: jsonSerialization['id'] as int?,
      toUserId: jsonSerialization['toUserId'] as int?,
      fromUserId: jsonSerialization['fromUserId'] as int?,
      fromUserImage: jsonSerialization['fromUserImage'] as String?,
      fromUserName: jsonSerialization['fromUserName'] as String?,
      channelId: jsonSerialization['channelId'] as int?,
      adId: jsonSerialization['adId'] as int?,
      timestamp:
          _i1.DateTimeJsonExtension.fromJson(jsonSerialization['timestamp']),
      title: jsonSerialization['title'] as String?,
      text: jsonSerialization['text'] as String,
      link: jsonSerialization['link'] as String?,
      type: _i2.NotificationType.fromJson((jsonSerialization['type'] as int)),
      isRead: jsonSerialization['isRead'] as bool,
    );
  }

  /// The database id, set if the object has been inserted into the
  /// database or if it has been fetched from the database. Otherwise,
  /// the id will be null.
  int? id;

  int? toUserId;

  int? fromUserId;

  String? fromUserImage;

  String? fromUserName;

  int? channelId;

  int? adId;

  DateTime timestamp;

  String? title;

  String text;

  String? link;

  _i2.NotificationType type;

  bool isRead;

  AppNotification copyWith({
    int? id,
    int? toUserId,
    int? fromUserId,
    String? fromUserImage,
    String? fromUserName,
    int? channelId,
    int? adId,
    DateTime? timestamp,
    String? title,
    String? text,
    String? link,
    _i2.NotificationType? type,
    bool? isRead,
  });
  @override
  Map<String, dynamic> toJson() {
    return {
      if (id != null) 'id': id,
      if (toUserId != null) 'toUserId': toUserId,
      if (fromUserId != null) 'fromUserId': fromUserId,
      if (fromUserImage != null) 'fromUserImage': fromUserImage,
      if (fromUserName != null) 'fromUserName': fromUserName,
      if (channelId != null) 'channelId': channelId,
      if (adId != null) 'adId': adId,
      'timestamp': timestamp.toJson(),
      if (title != null) 'title': title,
      'text': text,
      if (link != null) 'link': link,
      'type': type.toJson(),
      'isRead': isRead,
    };
  }

  @override
  String toString() {
    return _i1.SerializationManager.encode(this);
  }
}

class _Undefined {}

class _AppNotificationImpl extends AppNotification {
  _AppNotificationImpl({
    int? id,
    int? toUserId,
    int? fromUserId,
    String? fromUserImage,
    String? fromUserName,
    int? channelId,
    int? adId,
    required DateTime timestamp,
    String? title,
    required String text,
    String? link,
    required _i2.NotificationType type,
    required bool isRead,
  }) : super._(
          id: id,
          toUserId: toUserId,
          fromUserId: fromUserId,
          fromUserImage: fromUserImage,
          fromUserName: fromUserName,
          channelId: channelId,
          adId: adId,
          timestamp: timestamp,
          title: title,
          text: text,
          link: link,
          type: type,
          isRead: isRead,
        );

  @override
  AppNotification copyWith({
    Object? id = _Undefined,
    Object? toUserId = _Undefined,
    Object? fromUserId = _Undefined,
    Object? fromUserImage = _Undefined,
    Object? fromUserName = _Undefined,
    Object? channelId = _Undefined,
    Object? adId = _Undefined,
    DateTime? timestamp,
    Object? title = _Undefined,
    String? text,
    Object? link = _Undefined,
    _i2.NotificationType? type,
    bool? isRead,
  }) {
    return AppNotification(
      id: id is int? ? id : this.id,
      toUserId: toUserId is int? ? toUserId : this.toUserId,
      fromUserId: fromUserId is int? ? fromUserId : this.fromUserId,
      fromUserImage:
          fromUserImage is String? ? fromUserImage : this.fromUserImage,
      fromUserName: fromUserName is String? ? fromUserName : this.fromUserName,
      channelId: channelId is int? ? channelId : this.channelId,
      adId: adId is int? ? adId : this.adId,
      timestamp: timestamp ?? this.timestamp,
      title: title is String? ? title : this.title,
      text: text ?? this.text,
      link: link is String? ? link : this.link,
      type: type ?? this.type,
      isRead: isRead ?? this.isRead,
    );
  }
}
