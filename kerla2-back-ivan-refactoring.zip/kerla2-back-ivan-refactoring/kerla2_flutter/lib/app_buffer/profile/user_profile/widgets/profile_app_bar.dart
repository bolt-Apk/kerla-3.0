import 'package:animated_size_and_fade/animated_size_and_fade.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_svg/svg.dart';
import 'package:kerla2_flutter/app_buffer/profile/notifications/notification_new_status_provider/notification_new_status_provider.dart';
import 'package:kerla2_flutter/auth/widgets/auth_bottom_sheet.dart';
import 'package:kerla2_flutter/main.dart';
import 'package:kerla2_flutter/router/router.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_app/nit_app.dart';
import 'package:nit_router/nit_router.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

import 'profile_app_bar_title.dart';

class ProfileAppbar extends ConsumerWidget implements PreferredSizeWidget {
  const ProfileAppbar.withProfileImage({
    super.key,
    required this.userId,
  })  : showProfileAppBarTitle = true,
        useIconThemeForIcons = true,
        iconButtonBackgroundOpacity = 0,
        crossAxisAlignment = CrossAxisAlignment.center;

  const ProfileAppbar.withoutProfileImage({
    super.key,
    required this.userId,
  })  : showProfileAppBarTitle = false,
        useIconThemeForIcons = false,
        iconButtonBackgroundOpacity = 0.4,
        crossAxisAlignment = CrossAxisAlignment.start;

  final int userId;
  final bool showProfileAppBarTitle;
  final bool useIconThemeForIcons;
  final double iconButtonBackgroundOpacity;
  final CrossAxisAlignment crossAxisAlignment;

  @override
  Size get preferredSize => const Size.fromHeight(50);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    const Color itemColor = ThemePrimaryColors.white;
    return Row(
      crossAxisAlignment: crossAxisAlignment,
      children: [
        if (context.canPop())
          IconButton.filledTonal(
            onPressed: () => context.pop(),
            style: IconButton.styleFrom(
              backgroundColor:
                  Colors.black.withOpacity(iconButtonBackgroundOpacity),
            ),
            color: context.theme.canvasColor,
            icon: Icon(
              Icons.arrow_back_ios_new,
              color: useIconThemeForIcons
                  ? context.theme.iconTheme.color
                  : itemColor,
            ),
          )
        else
          const Gap(8),
        Flexible(
          child: AnimatedSizeAndFade(
              sizeDuration: const Duration(milliseconds: 100),
              fadeDuration: const Duration(milliseconds: 100),
              fadeInCurve: Curves.linear,
              child:
                  //  true
                  //     ?
                  showProfileAppBarTitle
                      ? ProfileAppBarTitle(
                          userId: userId,
                        )
                      : const SizedBox.expand()
              // : AnimatedSizeAndFade(
              //     sizeDuration: const Duration(milliseconds: 100),
              //     fadeDuration: const Duration(milliseconds: 100),
              //     fadeInCurve: Curves.elasticIn,
              //     child: Container(
              //       height: 32,
              //       decoration: BoxDecoration(
              //         borderRadius: BorderRadius.circular(10),
              //         color: const Color(0xFFEEEEEE),
              //       ),
              //       child: TextField(
              //         textCapitalization: TextCapitalization.sentences,
              //         decoration: InputDecoration(
              //           enabledBorder: OutlineInputBorder(
              //             borderSide:
              //                 const BorderSide(color: Color(0xFFEEEEEE)),
              //             borderRadius: BorderRadius.circular(10),
              //           ),
              //           focusedBorder: OutlineInputBorder(
              //             borderSide:
              //                 const BorderSide(color: Color(0xFFEEEEEE)),
              //             borderRadius: BorderRadius.circular(10),
              //           ),
              //           contentPadding:
              //               const EdgeInsets.symmetric(horizontal: 8),
              //           hintText: "Введите текст",
              //         ),
              //       ),
              //     ),
              //   ),
              ),
        ),
        AnimatedCrossFade(
          // alignment: Alignment.topLeft,
          duration: const Duration(milliseconds: 100),
          firstChild: IconButton.filledTonal(
            style: IconButton.styleFrom(
              backgroundColor:
                  Colors.black.withOpacity(iconButtonBackgroundOpacity),
            ),
            color: itemColor,
            icon: SvgPicture.asset(
              AppIconsSvg.favorite,
              height: 24,
              width: 24,
              colorFilter: ColorFilter.mode(
                useIconThemeForIcons
                    ? context.theme.iconTheme.color ??
                        ThemePrimaryColors.background
                    : itemColor,
                BlendMode.srcIn,
              ),
            ),
            onPressed: () {
              //TODO: должно быть ref.requireLogin
              ref.signedIn
                  ? context.pushNamed(
                      MainAreaNavigationZone.favorites.name,
                    )
                  : Scaffold.of(context).showBottomSheet(
                      (context) => const AuthBottomSheet(),
                    );
            },
          ),

          secondChild: const SizedBox.shrink(),
          crossFadeState: CrossFadeState.showFirst,
          // true ? CrossFadeState.showFirst : CrossFadeState.showSecond,
        ),
        AnimatedCrossFade(
          duration: const Duration(milliseconds: 100),
          firstChild: IconButton.filledTonal(
            style: IconButton.styleFrom(
              backgroundColor:
                  Colors.black.withOpacity(iconButtonBackgroundOpacity),
            ),
            color: itemColor,
            icon: Badge(
              isLabelVisible: ref.watch(notificationNewStatusProvider) > 0,
              child: SvgPicture.asset(
                AppIconsSvg.notification,
                height: 24,
                width: 24,
                colorFilter: ColorFilter.mode(
                  useIconThemeForIcons
                      ? context.theme.iconTheme.color ??
                          ThemePrimaryColors.background
                      : itemColor,
                  BlendMode.srcIn,
                ),
              ),
            ),
            onPressed: () {
              //TODO: должно быть ref.requireLogin
              ref.signedIn
                  ? context.pushNamed(
                      MainAreaNavigationZone.notification.name,
                    )
                  : Scaffold.of(context).showBottomSheet(
                      (context) => const AuthBottomSheet(),
                    );
            },
          ),
          secondChild: const SizedBox.shrink(),
          crossFadeState: CrossFadeState.showFirst,
          // true ? CrossFadeState.showFirst : CrossFadeState.showSecond,
        ),
        AnimatedCrossFade(
          duration: const Duration(milliseconds: 100),
          firstChild: IconButton.filledTonal(
            style: IconButton.styleFrom(
              backgroundColor:
                  Colors.black.withOpacity(iconButtonBackgroundOpacity),
            ),
            color: itemColor,
            icon: Icon(
              context.theme.brightness == Brightness.dark
                  ? Icons.dark_mode
                  : Icons.light_mode,
              color: useIconThemeForIcons
                  ? context.theme.iconTheme.color ??
                      ThemePrimaryColors.background
                  : itemColor,
            ),
            onPressed: () {
              ref.read(themeNotifierProvider.notifier).toggleTheme();
            },
          ),
          secondChild: const SizedBox.shrink(),
          crossFadeState: CrossFadeState.showFirst,
          // true ? CrossFadeState.showFirst : CrossFadeState.showSecond,
        ),
      ],
    );
  }
}

// InkWell(
//   onTap: () {
//     setState(() {
//       isSearchFieldVisible = true;
//     });
//   },
//   child: Padding(
//     padding: const EdgeInsets.all(8.0),
//     child: AnimatedSwitcher(
//       duration: const Duration(milliseconds: 100),
//       child: isSearchFieldVisible
//           ? IconWithStatusDot(
//               svgIcon: AppIconsSvg.close,
//               iconColor: itemColor,
//             )
//           : IconWithStatusDot(
//               svgIcon: AppIconsSvg.search,
//               iconColor: itemColor,
//             ),
//     ),
//   ),
// ),
