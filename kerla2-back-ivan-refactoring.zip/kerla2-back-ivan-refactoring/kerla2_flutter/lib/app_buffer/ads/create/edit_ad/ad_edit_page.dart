import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/core/app_scaffold.dart';
import 'package:kerla2_flutter/router/router.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_riverpod_notifications/nit_riverpod_notifications.dart';
import 'package:nit_router/nit_router.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';
import '../create_ad/attributes/widgets/attribure_render.dart';
import '../create_ad/attributes/widgets/attribute_category.dart';
import '../create_ad/widget/create_ad_text_field.dart';
import '../create_ad/widget/selected_media_widget.dart';
import '../state/ad_create_state.dart';
import '../media/state/selected_media_state.dart';

class AdEditPage extends HookConsumerWidget {
  const AdEditPage({
    super.key,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final int? adId = ref.watchNavigationParam(AppNavigationParams.adId);
    final scrollController = useScrollController();

    return AppScaffold(
      backgroundColor: context.theme.scaffoldBackgroundColor,
      showBottomNavBar: false,
      appBar: AppBar(
        leading: IconButton(
          color: context.theme.iconTheme.color,
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: Text("Редактирование объявления",
            style: context.textTheme.headlineMedium),
        backgroundColor: context.theme.canvasColor,
        iconTheme: const IconThemeData(color: Colors.black),
        elevation: 1,
      ),
      body: Builder(builder: (context) {
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: SingleChildScrollView(
            controller: scrollController,
            child: HookConsumer(builder: (context, ref, child) {
              final adEditState =
                  ref.watch(createAdStateProvider(AdType.ad, adId: adId));

              final titleController =
                  useTextEditingController(text: adEditState.title);
              final descriptionController =
                  useTextEditingController(text: adEditState.description);

              return Column(
                children: [
                  CreateAdTextField(
                    symbolCount: 70,
                    hintText: "Пожалуйста, укажите заголовок",
                    title: "Заголовок",
                    controller: titleController,
                    minLines: 1,
                    maxLines: 3,
                  ),
                  CreateAdTextField(
                    symbolCount: 3000,
                    hintText: "Пожалуйста, укажите описание",
                    title: "Описание",
                    controller: descriptionController,
                    minLines: 2,
                    maxLines: 5,
                  ),
                  DecoratedBox(
                    decoration: BoxDecoration(
                      color: context.theme.canvasColor,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Padding(
                      padding: EdgeInsets.all(10.0),
                      child: AdSelectedMediaWidget(),
                    ),
                  ),
                  const Padding(
                    padding: EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 12,
                    ),
                    child: AttributeCategory(
                      title: 'Все категории',
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(12, 16, 12, 0),
                    child: ListView.builder(
                      // padding: const EdgeInsets.only(bottom: 0),
                      physics: const NeverScrollableScrollPhysics(),
                      shrinkWrap: true,
                      itemCount: adEditState.attributeValues?.length,
                      itemBuilder: (context, index) {
                        return AttributeRender(
                          attributeValue: adEditState.attributeValues![index],
                          onAttributeSave: (attribute) {
                            ref
                                .read(
                                    createAdStateProvider(AdType.ad, adId: adId)
                                        .notifier)
                                .setAttribute(attribute);
                          },
                        );
                      },
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 16),
                    child: MainButton(
                      buttonText: 'Сохранить',
                      onTap: () async {
                        FocusScope.of(context).unfocus();
                        String errorText = '';
                        if (titleController.text.isEmpty) {
                          errorText = 'Необходимо задать заголовок.';
                        } else if (descriptionController.text.isEmpty) {
                          errorText = 'Необходимо задать описание.';
                        } else if (titleController.text.trim().isEmpty ||
                            descriptionController.text.trim().isEmpty) {
                          errorText = 'Необходимо удалить все лишние пробелы.';
                        } else if (adEditState.attributeValues?.isEmpty ==
                            true) {
                          errorText = 'Необходимо заполнить все атрибуты.';
                        } else if (ref
                            .read(adMediaStateProvider(adId: adId))
                            .items
                            .isEmpty) {
                          errorText =
                              'Необходимо загрузить хотя бы одно изображение.';
                        } else if (errorText.isNotEmpty) {
                          ref.notifyUser(errorText);
                        } else {
                          final error = ref
                              .read(createAdStateProvider(AdType.ad, adId: adId)
                                  .notifier)
                              .saveTitleDescription(
                                title: titleController.text,
                                description: descriptionController.text,
                              );

                          if (error != null) {
                            ref.notifyUser(error);
                            return;
                          }
                          await ref
                              .read(adMediaStateProvider(adId: adId).notifier)
                              .startUploadMedia();

                          await ref
                              .read(createAdStateProvider(AdType.ad, adId: adId)
                                  .notifier)
                              .publishAd();

                          context.pop();
                        }
                      },
                    ),
                  ),
                ],
              );
            }),
          ),
        );
      }),
      // floatingActionButtonAnimator: FloatingActionButtonAnimator.scaling,
      // floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      // resizeToAvoidBottomInset: true,
      // floatingActionButton: Padding(
      //   padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      //   child: MainButton(
      //     buttonText: 'Сохранить',
      //     onTap: () async {
      //       FocusScope.of(context).unfocus();
      //       String errorText = '';
      //       if (titleController.text.isEmpty) {
      //         errorText = 'Необходимо задать заголовок.';
      //       } else if (descriptionController.text.isEmpty) {
      //         errorText = 'Необходимо задать описание.';
      //       } else if (titleController.text.trim().isEmpty ||
      //           descriptionController.text.trim().isEmpty) {
      //         errorText = 'Необходимо удалить все лишние пробелы.';
      //       } else if (adEditState.attributeValues?.isEmpty == true) {
      //         errorText = 'Необходимо заполнить все атрибуты.';
      //       } else if (ref
      //           .read(adMediaStateProvider(adId: adId))
      //           .items
      //           .isEmpty) {
      //         errorText = 'Необходимо загрузить хотя бы одно изображение.';
      //       } else if (errorText.isNotEmpty) {
      //         ref.notifyUser(errorText);
      //       } else {
      //         final error = ref
      //             .read(createAdStateProvider(adId: adId).notifier)
      //             .saveTitleDescription(
      //               title: titleController.text,
      //               description: descriptionController.text,
      //             );

      //         if (error != null) {
      //           ref.notifyUser(error);
      //           return;
      //         }
      //         await ref
      //             .read(adMediaStateProvider(adId: adId).notifier)
      //             .startUploadMedia(ref);

      //         await ref
      //             .read(createAdStateProvider(adId: adId).notifier)
      //             .publishAd();

      //         context.pop();
      //       }
      //     },
      //   ),
      // ),
    );
  }
}
