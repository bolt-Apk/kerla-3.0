import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_svg/svg.dart';
import 'package:kerla2_flutter/router/router.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:kerla2_flutter/common/user_profile_ref_extensions.dart';
import 'package:nit_router/nit_router.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class SubscriberWidget extends ConsumerWidget {
  const SubscriberWidget({
    super.key,
    required this.userId,
    // this.showButton = false,
  });

  // final UserInfoPublic user;
  // final bool showButton;

  final int userId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return ref.watchUserProfile(userId).nitWhen(
          childBuilder: (userProfile) => SizedBox(
            height: 60,
            child: ListTile(
              leading: SizedBox(
                width: 40,
                child: CircleAvatar(
                  backgroundColor: Colors.transparent,
                  child: ClipOval(
                    child: userProfile.imageUrl != null
                        ? CachedNetworkImage(
                            imageUrl: userProfile.imageUrl ?? '',
                          )
                        : SvgPicture.asset(AppIconsSvg.account),
                  ),
                ),
              ),
              onTap: () {
                context.pushNamed(
                  MainAreaNavigationZone.user.name,
                  pathParameters:
                      AppNavigationParams.userId.set(userProfile.userId),
                );
              },
              title: Text(
                userProfile.userName ?? '-',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              // TODO: вернуть
              // subtitle: state.userProfile.profileDescription != null
              //     ? Text(
              //         state.userProfile.profileDescription!,
              //         maxLines: 1,
              //         overflow: TextOverflow.ellipsis,
              //       )
              //     : const Text(""),
              // TODO: вернуть, вынести в отдельный виджет
              // trailing: showButton &&
              //         user.id != ref.signedInUser?.id &&
              //         ref.signedInUser?.id != null
              //     ? TextButton(
              //         onPressed: () async {
              //           if (user.isSubscribed == false) {
              //             await client.subscription.subscribe(
              //               userId: user.id!,
              //             );
              //           } else if (user.isSubscribed == true) {
              //             await client.subscription.unsubscribe(
              //               userId: user.id!,
              //             );
              //           }
              //           ref.invalidate(userProvider);
              //           ref.invalidate(getSubsProvider);
              //         },
              //         child: Text(
              //           user.isSubscribed == true
              //               ? 'Отписаться'
              //               : 'Подписаться',
              //         ),
              //       )
              //     : const SizedBox(),
            ),
          ),
        );
  }
}
