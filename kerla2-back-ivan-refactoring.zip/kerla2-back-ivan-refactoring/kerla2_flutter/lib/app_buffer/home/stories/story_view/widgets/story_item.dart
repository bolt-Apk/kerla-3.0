import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/app/favorites/favorite_button.dart';
import 'package:kerla2_flutter/app_buffer/chats_new/widgets/chat_list_card.dart';
import 'package:kerla2_flutter/app_buffer/home/stories/story_view/state/stories_state.dart';
import 'package:kerla2_flutter/app_buffer/home/stories/story_view/widgets/story_button.dart';
import 'package:kerla2_flutter/app_buffer/home/stories/story_view/widgets/story_description.dart';
import 'package:kerla2_flutter/app_buffer/home/stories/story_view/widgets/story_media.dart';
import 'package:kerla2_flutter/app_buffer/home/stories/story_view/widgets/story_overlay.dart';
import 'package:kerla2_flutter/common/is_my_profile.dart';
import 'package:kerla2_flutter/common/share.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_app/nit_app.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';
import 'package:share_plus/share_plus.dart';
import 'package:story_view/controller/story_controller.dart';

class UserStoryItem extends HookConsumerWidget {
  const UserStoryItem({
    super.key,
    required this.user,
    required this.storyController,
    required this.onNextPage,
    required this.onPreviousPage,
    this.singleStoryId,
  });

  final UserProfile user;
  final StoryController storyController;
  final VoidCallback onNextPage;
  final VoidCallback onPreviousPage;
  final int? singleStoryId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final storiesAsync = singleStoryId != null
        ? ref.watchOrFetchMaybeModelAsync<Ad>(
            singleStoryId!,
          )
        : ref.watch(userStoriesProvider(user.userId));

    return storiesAsync.nitWhen(
      childBuilder: (stories) {
        final List<Ad> storiesList = [];
        if (stories is Ad) {
          storiesList.add(stories);
        } else if (stories is List<Ad>) {
          storiesList.addAll(stories);
        }
        final filteredStories =
            storiesList.where((s) => s.media?.isNotEmpty == true).toList();

        if (filteredStories.isEmpty) {
          return const Center(child: Text('No stories available'));
        }

        final currentStoryId = useValueNotifier<int>(filteredStories.first.id!);
        final isDescriptionExpanded = useValueNotifier<bool>(false);

        return Stack(
          children: [
            StoryMedia(
              key: const ValueKey('story_media'),
              user: user,
              stories: filteredStories,
              controller: storyController,
              onStoryShow: (story) {
                currentStoryId.value = story.id!;
                isDescriptionExpanded.value = false;
              },
              onComplete: () {
                if (singleStoryId == null) {
                  onNextPage();
                } else {
                  context.pop();
                }
              },
            ),
            ValueListenableBuilder<int>(
              valueListenable: currentStoryId,
              builder: (context, storyId, _) {
                return ValueListenableBuilder<bool>(
                  valueListenable: isDescriptionExpanded,
                  builder: (context, expanded, __) {
                    final story =
                        filteredStories.firstWhere((s) => s.id == storyId);
                    return Stack(
                      children: [
                        StoryOverlay(
                          user: user,
                          story: story,
                          storyController: storyController,
                          onClose: () => context.pop(),
                        ),
                        Positioned(
                          bottom: 0,
                          left: 0,
                          right: 0,
                          child: StoryDescription(
                            story: story,
                            storyController: storyController,
                            isExpandedNotifier: isDescriptionExpanded,
                          ),
                        ),
                        AnimatedPositioned(
                          duration: const Duration(milliseconds: 200),
                          bottom: expanded ? 300 : 80,
                          right: 10,
                          child: Column(
                            children: [
                              if (ref.signedIn) ...[
                                FavoriteButton.stories(adId: story.id!),
                                const Gap(16),
                              ],
                              if (ref.signedIn &&
                                  !ref.isMyProfile(user.userId)) ...[
                                StoryFAB(
                                  icon: AppIconsSvg.send,
                                  tag: 'send',
                                  onTap: () async {
                                    final channelId = await ref.getAdChannel(
                                        story.id!, story.userId!);
                                    if (channelId != null && context.mounted) {
                                      context.goToChatByChannelId(
                                          channelId: channelId);
                                    }
                                  },
                                ),
                                const Gap(16),
                              ],
                              StoryFAB(
                                icon: AppIconsSvg.share,
                                tag: 'share',
                                onTap: () {
                                  SharePlus.instance.share(
                                    ShareParams(
                                      text: ShareType.ad.getShareLink(storyId),
                                    ),
                                  );
                                },
                              ),
                            ],
                          ),
                        ),
                      ],
                    );
                  },
                );
              },
            ),
          ],
        );
      },
    );
  }
}
