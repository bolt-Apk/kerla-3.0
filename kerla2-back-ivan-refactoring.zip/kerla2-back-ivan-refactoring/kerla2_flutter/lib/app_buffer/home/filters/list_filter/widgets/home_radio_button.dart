import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';

class HomeRadioButton extends StatelessWidget {
  const HomeRadioButton({
    super.key,
    required this.isSelected,
    required this.onTap,
    this.text,
  });

  final bool isSelected;
  final VoidCallback onTap;
  final String? text;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: isSelected
              ? ThemePrimaryColors.primary
              : Theme.of(context).canvasColor,
          borderRadius: BorderRadius.circular(8),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 10),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            isSelected
                ? SvgPicture.asset(
                    AppIconsSvg.closeRadioButton,
                    height: 20,
                    width: 20,
                  )
                : const SizedBox.shrink(),
            if (text != null)
              Text(text!, style: Theme.of(context).textTheme.titleLarge),
          ],
        ),
      ),
    );
  }
}
