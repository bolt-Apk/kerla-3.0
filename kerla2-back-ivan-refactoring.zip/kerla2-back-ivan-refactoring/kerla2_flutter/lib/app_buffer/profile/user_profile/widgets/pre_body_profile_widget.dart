import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerla2_flutter/common/user_profile_ref_extensions.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';
import 'package:url_launcher/url_launcher.dart';

class PreBodyProfileWidget extends ConsumerWidget {
  const PreBodyProfileWidget({
    super.key,
    required this.userId,
  });

  final int userId;

  // Функция для правильного форматирования url адреса
  Uri _parseLink(String link) {
    if (!link.startsWith('http://') && !link.startsWith('https://')) {
      return Uri.parse('https://$link');
    }
    return Uri.parse(link);
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return ref.watchUserProfile(userId).nitWhen(
          childBuilder: (userProfile) => userProfile.profileDescription == null
              ? const SizedBox.shrink()
              : AdditionalInfoWidget(
                  infoWidget: DecoratedBox(
                    decoration: BoxDecoration(color: context.theme.canvasColor),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        if (userProfile.profileDescription?.isEmpty != true)
                          Padding(
                            padding: const EdgeInsets.only(left: 100),
                            child: Container(
                              color: Colors.grey.withOpacity(0.15),
                              height: 1,
                              width: MediaQuery.sizeOf(context).width * 0.6,
                            ),
                          ),

                        if (userProfile.profileDescription?.isEmpty != true)
                          Material(
                            color: Theme.of(context).canvasColor,
                            child: InkWell(
                              onTap: () => showDialog(
                                context: context,
                                builder: (BuildContext context) {
                                  return AboutProfileDialog(
                                    text: userProfile.profileDescription!,
                                  );
                                },
                              ),
                              child: Padding(
                                padding: EdgeInsets.only(
                                    left: 16,
                                    top: 12,
                                    right: 8,
                                    bottom: userProfile.link != '' &&
                                            userProfile.link != null
                                        ? 0
                                        : 6),
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Expanded(
                                      child: Text(
                                        userProfile.profileDescription ?? '',
                                        overflow: TextOverflow.ellipsis,
                                        style: Theme.of(context)
                                            .textTheme
                                            .displayLarge,
                                        maxLines: 2,
                                      ),
                                    ),
                                    Text('Eще',
                                        style: Theme.of(context)
                                            .textTheme
                                            .headlineSmall),
                                  ],
                                ),
                              ),
                            ),
                          ),

                        if (userProfile.link != '' && userProfile.link != null)
                          Padding(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 16,
                              vertical: 6,
                            ),
                            child: InkWell(
                              onTap: () => launchUrl(
                                _parseLink(userProfile.link!),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(
                                    Icons.edit,
                                    size: 12,
                                    color: Theme.of(context).iconTheme.color,
                                  ),
                                  Flexible(
                                    child: Padding(
                                      padding: const EdgeInsets.only(left: 4),
                                      child: Text(
                                        userProfile.link ?? '',
                                        style: Theme.of(context)
                                            .textTheme
                                            .bodyLarge,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        // if (user.link != '' && user.link != null) const Divider()
                      ],
                    ),
                  ),
                ),
        );
  }
}
