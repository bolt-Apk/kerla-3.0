import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/app_buffer/chats_new/chat_list_page.dart';
import 'package:kerla2_flutter/app_buffer/chats_new/chat_view_block.dart';
import 'package:kerla2_flutter/app_buffer/chats_new/unread_provider/chat_unread_provider.dart';

import 'package:kerla2_flutter/app_buffer/home/stories/story_view/story_view_page.dart';
import 'package:nit_app/nit_app.dart';
import 'package:nit_router/nit_router.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

import '../app/favorites/favorite_page.dart';
import '../app_buffer/ads/create/publication_bottom_sheet.dart';
import '../app_buffer/profile/notifications/notification_page.dart';
import '../app_buffer/profile/profile_settings/profile_settings_page.dart';
import '../app_buffer/profile/user_profile/user_profile_page.dart';
import '../app_buffer/ads/representation/detail_page/ad_detail_page.dart';
import '../app_buffer/ads/create/create_ad/attributes/choose_attribute_page.dart';
import '../app_buffer/ads/create/create_ad/choose_category_page.dart';
import '../app_buffer/ads/create/create_ad/create_ad_page.dart';
import '../app_buffer/ads/create/create_story/confirm_story_page.dart';
import '../app_buffer/ads/create/create_story/create_story_page.dart';
import '../app_buffer/ads/create/edit_ad/ad_edit_page.dart';
import '../app_buffer/home/widgets/home_page.dart';
import '../app_buffer/ads/service/add_services_page.dart';
import '../app_buffer/ads/service/payment/widget/connect_business_services.dart';
import '../app_buffer/profile/subscribers/subscribers_page/subscribers_list_page.dart';
import '../auth/widgets/auth_bottom_sheet.dart';
import '../common/user_profile_ref_extensions.dart';
import '../ui_kit/ui_kit.dart';

// import '../auth/pages/choose_gender_page.dart';
// import '../auth/pages/enter_code_page.dart';
// import '../auth/pages/login_page.dart';
// import '../auth/pages/new_password_page.dart';
// import '../auth/pages/privacy_policy_page.dart';
// import '../auth/pages/register_page.dart';
// import '../auth/pages/reset_password_page.dart';

part 'menus/main_menu.dart';
part 'navigation_zones/ad_navigation_zone.dart';
part 'navigation_zones/main_area_navigation_zone.dart';
part 'navigation_zones/chat_navigation_zone.dart';
part 'utils/app_navigation_params.dart';
part 'utils/deep_links_handler.dart';

final routerProvider = nitRouterStateProvider(
  navigationZones: [
    MainAreaNavigationZone.values,
    AdNavigationZone.values,
    ChatNavigationZone.values,
    // AuthAreaNavigationZone.values,
  ],
  redirectsProvider: Provider<RedirectsStateModel>(
    (ref) {
      return RedirectsStateModel(
        redirects: ref.watchCurrentUserProfile != null
            ? {}
            : Map.fromEntries(
                <NavigationZoneRoute>[
                  MainAreaNavigationZone.profile,
                  MainAreaNavigationZone.settings,
                ].map(
                  (e) => MapEntry(
                    e,
                    MainAreaNavigationZone.homePage,
                  ),
                ),
              ),
      );
    },
  ),
);
