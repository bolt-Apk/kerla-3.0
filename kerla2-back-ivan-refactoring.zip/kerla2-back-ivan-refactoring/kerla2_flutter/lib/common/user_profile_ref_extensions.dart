import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/core/app_backend_filters.dart';
import 'package:nit_app/nit_app.dart';

import '../core/app_repository.dart';

extension UserProfileWidgetRefExtension on WidgetRef {
  UserProfile? get currentUserProfile => !signedIn
      ? null
      : watchModel(
          signedInUserId!,
          AppRepository.userProfileByUserId.descriptor,
        );

  AsyncValue<UserProfile> watchUserProfile(int userId) =>
      watchOrFetchModelAsync(
          userId, AppRepository.userProfileByUserId.descriptor);

  AsyncValue<UserProfile> watchUserProfileCustom(int userId) =>
      watchModelCustomAsync<UserProfile>(
        backendFilter: AppBackendFilter.userId.equals(userId),
      );

  UserProfile? get readCurrentUserProfile => !signedIn
      ? null
      : readModel(
          signedInUserId!,
          AppRepository.userProfileByUserId.descriptor,
        );
}

extension UserProfileRefExtension on Ref {
  UserProfile? get watchCurrentUserProfile => !signedIn
      ? null
      : watchModel(
          signedInUserId!,
          AppRepository.userProfileByUserId.descriptor,
        );

  UserProfile? get readCurrentUserProfile => !signedIn
      ? null
      : readModel(
          signedInUserId!,
          AppRepository.userProfileByUserId.descriptor,
        );
}
