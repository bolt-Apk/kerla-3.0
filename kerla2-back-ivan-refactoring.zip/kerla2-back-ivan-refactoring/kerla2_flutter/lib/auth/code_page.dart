import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerla2_flutter/auth/widgets/auth_bottom_sheet.dart';
import 'package:kerla2_flutter/auth/widgets/auth_header_widget.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_riverpod_notifications/nit_riverpod_notifications.dart';
import 'package:nit_router/nit_router.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';
import 'package:pin_code_fields/pin_code_fields.dart';

import '/router/navigation_zones/auth_navigation_zone.dart';
import 'state/auth_mode_enum.dart';
import 'state/auth_page_state.dart';

class CodePage extends ConsumerWidget {
  const CodePage({
    super.key,
    required this.mode,
  });

  final AuthModeEnum mode;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(authPageStateProvider);

    final scaffoldWidth = MediaQuery.sizeOf(context).width;

    return Column(
      children: [
        AuthHeaderWidget(mode: mode),
        Text('Введите код', style: context.textTheme.titleLarge),
        Padding(
          padding: const EdgeInsets.only(top: 8, bottom: 25),
          child: Text(
            'Отправили его на почту ${state.emailController.text}',
            style: context.textTheme.titleSmall,
            textAlign: TextAlign.center,
          ),
        ),
        PinCodeTextField(
          appContext: context,
          length: 6,
          controller: state.codeController,
          autoDisposeControllers: false,
          enableActiveFill: true,
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          enablePinAutofill: false,
          showCursor: false,
          keyboardType: TextInputType.text,
          onChanged: (value) {},
          textStyle: context.textTheme.headlineLarge,
          pinTheme: PinTheme(
            shape: PinCodeFieldShape.box,
            borderRadius: BorderRadius.circular(8),
            fieldHeight: scaffoldWidth * 0.15,
            fieldWidth: scaffoldWidth * 0.12,
            activeColor: context.theme.primaryColor,
            selectedColor: context.theme.primaryColor,
            inactiveColor: context.theme.primaryColor,
            activeFillColor: context.theme.canvasColor,
            selectedFillColor: context.theme.canvasColor,
            inactiveFillColor: context.theme.canvasColor,
          ),
        ),
        Button.text(
          title: 'Получить новый код',
          onPressed: () =>
              ref.read(authPageStateProvider.notifier).sendValidationCode(mode),
        ),
        const Gap(16),
        SizedBox(
          width: double.infinity,
          child: Button(
            title: 'Продолжить',
            onPressed: () async {
              await ref
                  .read(authPageStateProvider.notifier)
                  .processVerificationCode(mode)
                  .then((value) {
                if (value) {
                  switch (mode) {
                    case AuthModeEnum.registration:
                      if (context.mounted) {
                        context.pop(true);
                      }

                    case AuthModeEnum.recover:
                      ref
                          .read(authPageStateProvider.notifier)
                          .setPage(AuthAreaNavigationZone.recoverPassword);
                    default:
                      throw UnimplementedError();
                  }
                } else {
                  ref.notifyUser(
                    NitNotification.error('Неверный код, повторите попытку'),
                  );
                }
              });
            },
          ),
        ),
      ],
    );
  }
}
