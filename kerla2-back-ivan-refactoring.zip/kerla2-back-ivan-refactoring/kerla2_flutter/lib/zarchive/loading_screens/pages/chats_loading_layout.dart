// part of '../../ui_kit.dart';

// class ChatsLoadingLayout extends StatelessWidget {
//   const ChatsLoadingLayout({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return ListView(
//       children: [
//         ...List.generate(
//             7,
//             (i) => const ShimmerListTile(
//                   height: 90,
//                 ))
//       ],
//     );
//   }
// }
