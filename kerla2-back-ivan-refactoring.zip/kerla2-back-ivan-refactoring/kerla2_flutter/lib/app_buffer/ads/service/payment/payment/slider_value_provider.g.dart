// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'slider_value_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$sliderValueHash() => r'2da720019d408a634072b55d8ba56c0eb01daefe';

/// See also [SliderValue].
@ProviderFor(SliderValue)
final sliderValueProvider =
    AutoDisposeNotifierProvider<SliderValue, int>.internal(
  SliderValue.new,
  name: r'sliderValueProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$sliderValueHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$SliderValue = AutoDisposeNotifier<int>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
