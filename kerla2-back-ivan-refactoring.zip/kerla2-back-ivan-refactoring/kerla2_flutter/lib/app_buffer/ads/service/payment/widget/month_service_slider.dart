import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';

import '../payment/slider_value_provider.dart';

class MonthServiceSlider extends ConsumerStatefulWidget {
  const MonthServiceSlider({
    super.key,
    required this.height,
    required this.width,
  });

  final double height;
  final double width;

  @override
  ConsumerState<ConsumerStatefulWidget> createState() =>
      _AddServiceSliderState();
}

class _AddServiceSliderState extends ConsumerState<MonthServiceSlider> {
  int value = 1;
  double percentage = 0;
  double bar = 0;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onHorizontalDragStart: (details) {
        percentage = double.parse(
          (details.localPosition.dx / widget.width).toStringAsFixed(2),
        );

        bar = 1 / 11 * (percentage * 11).round();
        value = (bar * 11 + 1).round();

        if (value < 1) {
          value = 1;
        } else if (value > 12) {
          value = 12;
        }

        setState(() {});
        ref.read(sliderValueProvider.notifier).setValue(value);
      },
      onHorizontalDragUpdate: (details) {
        percentage = double.parse(
          (details.localPosition.dx / widget.width).toStringAsFixed(2),
        );

        bar = 1 / 11 * (percentage * 11).round();
        value = (bar * 11 + 1).round();

        if (value < 1) {
          value = 1;
        } else if (value > 12) {
          value = 12;
        }

        setState(() {});
        ref.read(sliderValueProvider.notifier).setValue(value);
      },
      child: Container(
        height: 4 * widget.height,
        width: widget.width,
        alignment: Alignment.center,
        color: Colors.transparent,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Stack(
              alignment: Alignment.center,
              children: [
                SizedBox(
                  width: widget.width,
                  height: 25,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        height: 20,
                        width: 70,
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.05),
                          borderRadius: BorderRadius.circular(3),
                        ),
                        alignment: Alignment.center,
                        child: Text(
                          '1 месяц',
                          style: TextStyle(
                            fontSize: 12,
                            color: Colors.black.withOpacity(0.4),
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                      ),
                      Container(
                        height: 20,
                        width: 70,
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.05),
                          borderRadius: BorderRadius.circular(3),
                        ),
                        alignment: Alignment.center,
                        child: Text(
                          '12 месяцев',
                          style: TextStyle(
                            fontSize: 12,
                            color: Colors.black.withOpacity(0.4),
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                AnimatedContainer(
                  duration: const Duration(milliseconds: 50),
                  curve: Curves.easeInOut,
                  width: widget.width,
                  height: 25,
                  alignment: FractionalOffset(
                    bar >= 0
                        ? bar <= 1
                            ? bar
                            : 1
                        : 0,
                    0.5,
                  ),
                  child: Container(
                    height: 20,
                    width: 75,
                    decoration: BoxDecoration(
                      color: Colors.blue,
                      borderRadius: BorderRadius.circular(3),
                    ),
                    alignment: Alignment.center,
                    child: Text(
                      '$value ${month(value)}',
                      style: const TextStyle(
                        fontSize: 12,
                        color: Colors.white,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(
              height: 8,
            ),
            Container(
              width: widget.width,
              height: widget.height,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(widget.width / 2),
                color: Colors.black.withOpacity(0.05),
              ),
              alignment: Alignment.centerLeft,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Align(
                    alignment: Alignment.centerLeft,
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 50),
                      curve: Curves.easeInOut,
                      width: bar >= 0
                          ? (widget.width * bar) +
                              (widget.height - widget.height * bar)
                          : widget.height,
                      height: widget.height,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(widget.width / 2),
                        color: Colors.blue,
                      ),
                      alignment: Alignment.centerRight,
                      child: Container(
                        height: widget.height,
                        width: widget.height,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: Colors.blue,
                            width: 3,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
