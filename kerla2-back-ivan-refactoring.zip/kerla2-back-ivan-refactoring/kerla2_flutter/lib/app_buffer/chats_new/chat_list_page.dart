import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerla2_flutter/app_buffer/chats_new/widgets/chat_list_card.dart';
import 'package:kerla2_flutter/core/app_backend_filters.dart';
import 'package:kerla2_flutter/core/app_scaffold.dart';
import 'package:nit_app/nit_app.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class ChatListPage extends ConsumerWidget {
  const ChatListPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return AppScaffold(
      appBar: AppBar(
        title: const Text('Чаты'),
      ),
      enableNotificationListeners: false,
      body: ref
          .watchEntityListCustomizedAsync<NitChatParticipant>(
            // backendFilter: AppBackendFilter.userId.equals(ref.signedInUserId!),
            entityListConfig: EntityListConfig(
                backendFilter: NitBackendFilter.and([
              AppBackendFilter.userId.equals(ref.signedInUserId!),
              AppBackendFilter.lastMessage.equals(null, negate: true),
              AppBackendFilter.isDeleted.equals(false),
            ])),
          )
          .nitWhenList(
            errorWidget: const Text('Не удалось загрузить чат поддержки'),
            loadingItemsCount: 5,
            loadingItem: NitDefaultModelsRepository.get<NitChatParticipant>(),
            childBuilder: (data) {
              // data.removeWhere((e) => e.isDeleted);
              data.sort((a, b) => b.lastMessageSentAt!.compareTo(a
                  .lastMessageSentAt!)); //TODO: почему так нужно? Сортировка меняется почему то при входе в чат
              if (data.isEmpty) {
                return const Center(
                  child: Text('Нет чатов'),
                );
              }
              return RefreshIndicator.adaptive(
                onRefresh: () async {
                  ref.read(globalRefreshTriggerProvider.notifier).state =
                      DateTime.now();
                },
                child: ListView.builder(
                  itemCount: data.length,
                  // separatorBuilder: (context, index) => Divider(
                  //   height: 5,
                  //   thickness: 1,
                  //   color: context.theme.scaffoldBackgroundColor,
                  // ),
                  itemBuilder: (context, index) {
                    return Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 4),
                      child: ChatListCard(
                        chatParticipant: data[index],
                      ),
                    );
                  },
                ),
              );
            },
          ),
    );
  }
}
