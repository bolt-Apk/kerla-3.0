// import 'package:flutter/material.dart';
// import 'package:flutter_riverpod/flutter_riverpod.dart';
// import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
// import 'package:nit_ui_kit/nit_ui_kit.dart';

// class ActiveServicesWidget extends ConsumerWidget {
//   const ActiveServicesWidget({super.key});

//   @override
//   Widget build(BuildContext context, WidgetRef ref) {
//     return const TextSettingsRow(
//       title: 'Активные услуги и бонусы',
//       subtitle: '',
//       editingBottomSheet: _ServiceBottomSheet(),
//     );
//   }
// }

// class _ServiceBottomSheet extends ConsumerWidget {
//   const _ServiceBottomSheet();

//   @override
//   Widget build(BuildContext context, WidgetRef ref) {
//     final state = ref.watch(serviceStateProvider);
//     return state.when(
//       error: (Object error, StackTrace stackTrace) {
//         return Text(error.toString());
//       },
//       loading: () => const SizedBox.shrink(),
//       data: (data) {
//         return DecoratedBox(
//           decoration: BoxDecoration(color: context.theme.canvasColor),
//           child: Padding(
//             padding: const EdgeInsets.symmetric(horizontal: 20),
//             child: Column(
//               mainAxisSize: MainAxisSize.min,
//               mainAxisAlignment: MainAxisAlignment.center,
//               children: [
//                 const LittleDivider(),
//                 if (data == null || data.isEmpty)
//                   Padding(
//                     padding: const EdgeInsets.symmetric(vertical: 12),
//                     child: SizedBox(
//                       width: double.infinity,
//                       child: Text(
//                         'У вас нет активных услуг',
//                         textAlign: TextAlign.center,
//                         style: context.textTheme.headlineMedium?.copyWith(
//                           fontWeight: FontWeight.w500,
//                         ),
//                       ),
//                     ),
//                   ),
//                 if (data != null && data.isNotEmpty)
//                   Text(
//                     'Активные услуги',
//                     style: context.textTheme.headlineMedium,
//                     textAlign: TextAlign.start,
//                   ),
//                 // if (data != null && data.isNotEmpty)
//                 //   Padding(
//                 //     padding: const EdgeInsets.only(bottom: 16),
//                 //     child: ListView.builder(
//                 //       physics: const NeverScrollableScrollPhysics(),
//                 //       shrinkWrap: true,
//                 //       itemCount: data.length,
//                 //       itemBuilder: (context, index) {
//                 //         return ServiceRow(
//                 //           imageAsset: data[index].type.image,
//                 //           buttonText: data[index].type.title,
//                 //           iconColor: data[index].type.title == 'Бизнес профиль'
//                 //               ? context.theme.iconTheme.color
//                 //               : null,
//                 //           type: data[index].type,
//                 //           endsAt: data[index].endsAt,
//                 //           isExistService: true,
//                 //         );
//                 //       },
//                 //     ),
//                 //   ),
//               ],
//             ),
//           ),
//         );
//       },
//     );
//   }
// }
