import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/app_buffer/ads/service/widget/add_service_slider.dart';
import 'package:kerla2_flutter/app_buffer/ads/service/state/service_state.dart';
import 'package:kerla2_flutter/common/kerla_service_title_extension.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

import 'add_service_checkbox.dart';

class ServiceRow extends ConsumerWidget {
  const ServiceRow.toggleable({
    super.key,
    this.adId,
    required this.serviceInfo,
  }) : toggleable = true;

  const ServiceRow.notToggleable({
    super.key,
    this.adId,
    required this.serviceInfo,
  }) : toggleable = false;

  final KerlaServiceInfo serviceInfo;
  final int? adId;
  final bool toggleable;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isEnabled =
        ref.read(serviceListStateProvider(adId).notifier).contains(serviceInfo);

    final endsTime = serviceInfo.endsAt;
    final freeEndsAt = serviceInfo.freeEndsAt;
    return Padding(
      padding: const EdgeInsets.all(4.0),
      child: Column(
        children: [
          ListTile(
            tileColor: context.theme.cardColor,
            onTap: () => ref
                .read(serviceListStateProvider(adId).notifier)
                .toggle(serviceInfo),
            leading: SvgPicture.asset(
              serviceInfo.type.image,
              height: 30,
              width: 30,
              // colorFilter: iconColor != null
              //     ? ColorFilter.mode(iconColor!, BlendMode.srcIn)
              //     : null,
            ),
            title: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(serviceInfo.type.title),
              ],
            ),
            trailing: toggleable
                ? Container(
                    constraints: const BoxConstraints(maxWidth: 100),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Text(
                          '${serviceInfo.cost ~/ 100} ₽',
                        ),
                        const SizedBox(width: 10),
                        AddServiceCheckbox(
                          state: isEnabled,
                          onTap: () {
                            ref
                                .read(serviceListStateProvider(adId).notifier)
                                .toggle(serviceInfo);
                          },
                        ),
                      ],
                    ),
                  )
                : null,
            subtitle: endsTime != null
                ? Text(
                    '${endsTime.getRemainingTimeDescription(title: 'Осталось: ${toggleable ? '\n' : ''}')}',
                  )
                : freeEndsAt != null
                    ? Text(
                        'Бесплатно до:\n${freeEndsAt.formatDate}',
                      )
                    : const SizedBox.shrink(),
          ),
          if (isEnabled && serviceInfo.freeEndsAt == null)
            AddServiceSlider(
              width: MediaQuery.sizeOf(context).width - 40,
              serviceInfo: serviceInfo,
              adId: adId,
            ),
        ],
      ),
    );
  }
}
