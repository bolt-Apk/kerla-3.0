// part of '../../ui_kit.dart';

// class HomeLoadingLayout extends StatelessWidget {
//   const HomeLoadingLayout({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return ListView(
//       children: [
//         const ShimmerHeader(),
//         const SizedBox(
//           height: 20,
//         ),
//         Row(
//           mainAxisAlignment: MainAxisAlignment.spaceAround,
//           children: [...List.generate(5, (i) => const ShimmerCircleAvatar())],
//         ),
//         const SizedBox(
//           height: 20,
//         ),
//         Row(
//           mainAxisAlignment: MainAxisAlignment.spaceAround,
//           children: [
//             ...List.generate(
//                 4, (i) => const ShimmerListTile(height: 30, width: 65))
//           ],
//         ),
//         const ShimmerListTile(height: 250),
//         Wrap(
//           children: [
//             ...List.generate(
//                 6, (i) => const ShimmerListTile(height: 250, width: 190))
//           ],
//         )
//       ],
//     );
//   }
// }
