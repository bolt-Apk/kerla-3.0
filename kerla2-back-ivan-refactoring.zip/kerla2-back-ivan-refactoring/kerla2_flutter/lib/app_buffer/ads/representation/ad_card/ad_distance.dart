import 'package:flutter/material.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class AdDistance extends StatelessWidget {
  const AdDistance({
    super.key,
    this.textColor,
    this.backgroundColor = const Color.fromRGBO(183, 183, 183, 0.2),
  });

  final Color? textColor;
  final Color backgroundColor;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
      decoration: BoxDecoration(
        borderRadius: const BorderRadius.all(
          Radius.circular(6),
        ),
        color: backgroundColor,
      ),
      child: Text(
        '50 KM',
        style: context.textTheme.displaySmall?.copyWith(
          color: textColor,
        ),
      ),
    );
  }
}
