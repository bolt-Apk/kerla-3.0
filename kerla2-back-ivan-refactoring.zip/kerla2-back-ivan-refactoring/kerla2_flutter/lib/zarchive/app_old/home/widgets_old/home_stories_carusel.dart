// import 'package:cached_network_image/cached_network_image.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_riverpod/flutter_riverpod.dart';
// import 'package:kerla2_flutter/router/router.dart';
// import 'package:marque_widget/marque_widget.dart';
// import 'package:nit_router/nit_router.dart';

// import '../../../zarchive/stories/state/stories_providers.dart';

// class HomeStoriesCarusel extends ConsumerWidget {
//   const HomeStoriesCarusel({
//     super.key,
//     required this.imageSize,
//   });

//   final double imageSize;

//   @override
//   Widget build(BuildContext context, WidgetRef ref) {
//     // final users = ref.watch(usersWithStoriesProvider);
//     // final isSubscribedAdsState = ref.watch(isSubscribedAds); //TODO: add user stories sort by subscription

//     return users.maybeWhen(
//       loading: () => const Center(child: CircularProgressIndicator()),
//       orElse: () => const Center(child: Text('Возникла какая-то ошибка')),
//       data: (usersWithStories) {
//         if (usersWithStories.isEmpty) {
//           return const SizedBox.shrink();
//         }
//         return Container(
//           color: Theme.of(context).scaffoldBackgroundColor,
//           padding: const EdgeInsets.only(left: 4),
//           height: imageSize + 40,
//           child: ListView.builder(
//             scrollDirection: Axis.horizontal,
//             itemCount: usersWithStories.length,
//             itemBuilder: (context, index) {
//               return InkWell(
//                 onTap: () {
//                   context.pushNamed(
//                     MainAreaNavigationZone.userStories.name,
//                     pathParameters: AppNavigationParams.userId
//                         .set(usersWithStories[index].id!),
//                   );
//                   // MainMenuNotifier().setActiveIndex(1);
//                 },
//                 child: Container(
//                   width: imageSize,
//                   padding:
//                       const EdgeInsets.symmetric(horizontal: 4, vertical: 16),
//                   child: Column(
//                     children: [
//                       Container(
//                         padding: const EdgeInsets.all(1),
//                         decoration: BoxDecoration(
//                           color: Colors.black.withOpacity(0.1),
//                           shape: BoxShape.circle,
//                         ),
//                         child: Container(
//                           decoration: BoxDecoration(
//                             border: Border.all(
//                               color: Theme.of(context).canvasColor,
//                               width: 4,
//                             ),
//                             shape: BoxShape.circle,
//                             image: DecorationImage(
//                               image: CachedNetworkImageProvider(
//                                 usersWithStories[index].imageUrl ?? '',
//                               ),
//                               fit: BoxFit.cover,
//                             ),
//                           ),
//                           height: imageSize - 20,
//                           width: imageSize - 20,
//                         ),
//                       ),
//                       const SizedBox(height: 8),
//                       if ((usersWithStories[index].userName?.length ?? 0) > 8)
//                         SizedBox(
//                           height: 14,
//                           child: MarqueeWidget(
//                             movingWidget: Text(
//                               usersWithStories[index].userName ?? '-',
//                               style: TextStyle(
//                                 color: Theme.of(context).primaryColorDark,
//                                 fontSize: 12,
//                                 fontWeight: FontWeight.w400,
//                               ),
//                             ),
//                             // blankSpace: 10.0,
//                             velocity: 5.0,
//                             // pauseAfterRound: const Duration(seconds: 5),
//                             // accelerationDuration: const Duration(seconds: 1),
//                             // decelerationDuration:
//                             //     const Duration(milliseconds: 500),
//                           ),
//                         )
//                       else
//                         Text(
//                           usersWithStories[index].userName ?? '-',
//                           maxLines: 1,
//                           overflow: TextOverflow.ellipsis,
//                           style: TextStyle(
//                             color: Theme.of(context).primaryColorDark,
//                             fontSize: 12,
//                             fontWeight: FontWeight.w400,
//                           ),
//                         ),
//                     ],
//                   ),
//                 ),
//               );
//             },
//           ),
//         );
//       },
//     );
//   }
// }
