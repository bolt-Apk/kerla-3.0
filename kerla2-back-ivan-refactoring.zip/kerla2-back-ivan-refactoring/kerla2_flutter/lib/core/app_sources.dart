import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:nit_app/nit_app.dart';

final regionsProvider = Provider((ref) => AppSources.instance.regions);

class AppSources {
  static final instance = AppSources._();
  AppSources._();

  late final List<Region> regions;
  late final List<AdCategory> categories;

  bool _isInitialized = false;

  Future<bool> init(WidgetRef ref) async {
    if (_isInitialized) {
      return true;
    }

    // final services = await client.adManagement.getAdPromotionPrices(adId: 15);
    regions = await ref
        .watch(entityManagerStateProvider<Region>()(const EntityListConfig())
            .future)
        .then(
          (res) => res.map((id) => ref.readModel<Region>(id)).toList(),
        );

    // client.region.getRegions();
    categories = _buildCategoryTree(await ref
        .watch(
            entityManagerStateProvider<AdCategory>()(const EntityListConfig())
                .future)
        .then(
          (res) => res.map((id) => ref.readModel<AdCategory>(id)).toList(),
        ));

    // await client.adCategory.getAdCategoryList();
    _isInitialized = true;
    return true;
  }

  bool isInitialized() => _isInitialized;

  List<AdCategory> _buildCategoryTree(List<AdCategory> categories) {
    // Создаем карту для быстрого доступа к категориям по id
    final Map<int, AdCategory> categoryMap = {
      for (var category in categories) category.id!: category
    };

    // Создаем список корневых категорий (без parentId)
    final List<AdCategory> rootCategories =
        categories.where((category) => category.parentId == null).toList();

    // Для каждой корневой категории строим дерево
    for (var i = 0; i < rootCategories.length; i++) {
      final rootCategory = rootCategories[i];
      final updatedRoot = _buildSubtree(rootCategory, categoryMap, null);
      rootCategories[i] = updatedRoot;
    }

    return rootCategories;
  }

  AdCategory _buildSubtree(AdCategory parent, Map<int, AdCategory> categoryMap,
      AdCategory? parentObj) {
    // Обновляем parent ссылку, если это не корень
    final parentWithParent =
        parentObj != null ? parent.copyWith(parent: parentObj) : parent;

    final children = categoryMap.values
        .where((category) => category.parentId == parent.id)
        .toList();

    if (children.isNotEmpty) {
      // Рекурсивно обновляем всех детей, передавая parentWithParent как parent
      final updatedChildren = children
          .map((child) => _buildSubtree(child, categoryMap, parentWithParent))
          .toList();
      // Создаем копию родительской категории с обновленными детьми
      final updatedParent =
          parentWithParent.copyWith(children: updatedChildren);
      categoryMap[parent.id!] = updatedParent;
      return updatedParent;
    }

    return parentWithParent;
  }
}
