import 'package:flutter/material.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_app/nit_app.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class HomeAttributeDialog extends StatelessWidget {
  const HomeAttributeDialog({
    super.key,
    required this.child,
    required this.onPressed,
  });

  final Widget child;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(color: context.theme.canvasColor),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          child,
          Padding(
            padding: const EdgeInsets.symmetric(
              vertical: 10,
              horizontal: 18,
            ),
            child: AuthExpandedElevatedButton(
              height: 55,
              onPressed: onPressed,
              child: Text('Применить',
                  style: context.textTheme.displayLarge
                      ?.copyWith(fontSize: 20, color: Colors.white)),
            ),
          ),
          const SizedBox(height: 10)
        ],
      ),
    );
  }
}
