// import 'package:flutter_riverpod/flutter_riverpod.dart';
// import 'package:nit_app/nit_app.dart';

// const adminScopeName = 'serverpod.admin';

// extension IsAdminWidgetRefExtension on WidgetRef {
//   bool get isAdmin =>
//       watch(nitSessionStateProvider).scopeNames.contains(adminScopeName);
// }

// extension IsAdminRefExtension on Ref {
//   bool get isAdmin =>
//       watch(nitSessionStateProvider).scopeNames.contains(adminScopeName);
// }
