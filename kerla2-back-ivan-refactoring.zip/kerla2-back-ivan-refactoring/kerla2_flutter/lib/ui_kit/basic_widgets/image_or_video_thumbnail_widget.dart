import 'package:flutter/material.dart';
import 'package:flutter_cache_manager/flutter_cache_manager.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:nit_app/nit_app.dart';

import 'package:video_thumbnail/video_thumbnail.dart';

final _videoCacheManager = CacheManager(
  Config(
    'videoThumbnailCache',
    stalePeriod: const Duration(days: 7),
    maxNrOfCacheObjects: 50,
  ),
);

class ImageOrVideoThumbnailWidget extends HookWidget {
  const ImageOrVideoThumbnailWidget({
    super.key,
    required this.url,
    required this.type,
  });

  final String url;
  final MediaType type;

  @override
  Widget build(BuildContext context) {
    if (type == MediaType.image) {
      return CachedNetworkImage(
        imageUrl: url,
        fit: BoxFit.cover,
        errorWidget: (context, url, error) => Container(
          color: Colors.grey[300],
          child: const Icon(Icons.error),
        ),
      );
    } else {
      final cacheFuture = useMemoized(() async {
        final fileInfo = await _videoCacheManager.getFileFromCache(url);
        if (fileInfo != null && fileInfo.file.existsSync()) {
          return fileInfo.file.path;
        } else {
          final file = await _videoCacheManager.getSingleFile(url);
          return file.path;
        }
      });

      final cacheSnapshot = useFuture(cacheFuture);

      if (cacheSnapshot.connectionState == ConnectionState.waiting) {
        return const Center(child: CircularProgressIndicator());
      }

      if (cacheSnapshot.hasError || !cacheSnapshot.hasData) {
        return Container(
          color: Colors.grey[300],
          child: const Icon(Icons.error),
        );
      }

      final videoPath = cacheSnapshot.data!;

      final thumbnailFuture = useMemoized(() => VideoThumbnail.thumbnailData(
            video: videoPath,
            imageFormat: ImageFormat.PNG,
            maxWidth: 128,
            quality: 25,
          ));

      final thumbnailSnapshot = useFuture(thumbnailFuture);

      if (thumbnailSnapshot.connectionState == ConnectionState.waiting) {
        return const Center(child: CircularProgressIndicator());
      }

      if (thumbnailSnapshot.hasData && thumbnailSnapshot.data != null) {
        return Image.memory(
          thumbnailSnapshot.data!,
          fit: BoxFit.cover,
        );
      } else if (thumbnailSnapshot.hasError) {
        return Container(
          color: Colors.grey[300],
          child: const Icon(Icons.error),
        );
      } else {
        return Container(
          color: Colors.grey[300],
          child: const Icon(Icons.videocam_off),
        );
      }
    }
  }
}
