import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_app/nit_app.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class ReportAdWidget extends ConsumerStatefulWidget {
  const ReportAdWidget({
    super.key,
    required this.adId,
  });

  final int adId;

  @override
  ConsumerState<ConsumerStatefulWidget> createState() => _ReportAdWidgetState();
}

class _ReportAdWidgetState extends ConsumerState<ReportAdWidget> {
  AdReportReason? _reportReason = AdReportReason.wrongCategory;

  void onSendReport(int adId, AdReportReason reportReason) async {
    final isReported = null !=
        await ref.saveModel(AdReport(
            complaint: _reportReason!,
            adId: widget.adId,
            accusedId: ref.signedInUserId!));
    // await client.report.adReport(widget.adId, _reportReason!);

    if (isReported) {
      Fluttertoast.showToast(
        msg: 'Жалоба принята',
        toastLength: Toast.LENGTH_LONG,
        gravity: ToastGravity.CENTER,
        backgroundColor: Colors.green,
        textColor: Colors.white,
        fontSize: 16.0,
      );
    }

    // TODO: как это может получиться?
    //  else {
    //   Fluttertoast.showToast(
    //     msg: 'Жалоба уже принята',
    //     toastLength: Toast.LENGTH_LONG,
    //     gravity: ToastGravity.CENTER,
    //     backgroundColor: Colors.red,
    //     textColor: Colors.white,
    //     fontSize: 16.0,
    //   );
    // }
    if (context.mounted) {
      Navigator.of(context).pop();
      Navigator.of(context).pop();
    }
  }

  Widget reportTitleWidget(AdReportReason reportReason) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          reportReason.title,
          style: const TextStyle(
            fontWeight: FontWeight.w500,
            fontSize: 15,
          ),
        ),
        Text(
          reportReason.description,
          maxLines: 3,
          style: TextStyle(
            fontSize: 15,
            fontWeight: FontWeight.w300,
            color: context.theme.primaryColorDark,
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.sizeOf(context);

    return SingleChildScrollView(
      child: ConstrainedBox(
        constraints: BoxConstraints(
          maxWidth: MediaQuery.sizeOf(context).width,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              title: const Text(
                'Пожаловаться на объявление',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w500,
                ),
              ),
              minLeadingWidth: 0,
              leading: SizedBox(
                width: 25,
                height: 25,
                child: IconButton(
                  padding: const EdgeInsets.all(0),
                  iconSize: 25,
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  icon: const Icon(
                    Icons.close,
                    color: Colors.black,
                  ),
                ),
              ),
            ),
            const Divider(),
            const ListTile(
              title: Padding(
                padding: EdgeInsets.symmetric(horizontal: 4),
                child: Text(
                  'Выберите причину жалобы',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 20, right: 10),
              child: Column(
                children: AdReportReason.values
                    .map(
                      (e) => Padding(
                        padding: const EdgeInsets.only(bottom: 15.0),
                        child: GestureDetector(
                          onTap: () => {
                            setState(
                              () {
                                _reportReason = e;
                              },
                            ),
                          },
                          child: Container(
                            color: Colors.transparent,
                            // height: 60,
                            width: size.width,
                            child: Row(
                              children: [
                                Container(
                                  height: 15,
                                  width: 15,
                                  decoration: BoxDecoration(
                                    color: _reportReason == e
                                        ? Colors.blue
                                        : context.theme.primaryColorDark
                                            .withOpacity(0.5),
                                    borderRadius: BorderRadius.circular(4),
                                  ),
                                ),
                                const SizedBox(
                                  width: 20,
                                ),
                                Expanded(
                                  child: reportTitleWidget(e),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    )
                    .toList(),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(25),
              child: MainButton(
                buttonText: 'Отправить',
                onTap: () async {
                  return onSendReport(widget.adId, _reportReason!);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
