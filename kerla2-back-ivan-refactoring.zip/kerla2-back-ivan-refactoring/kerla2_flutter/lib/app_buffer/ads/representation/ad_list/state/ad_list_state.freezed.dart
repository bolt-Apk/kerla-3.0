// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'ad_list_state.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$AdListData {
  PagingController<int, Ad> get controller =>
      throw _privateConstructorUsedError;
  Ad? get turboAd => throw _privateConstructorUsedError;
  int get pageKey => throw _privateConstructorUsedError;

  /// Create a copy of AdListData
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $AdListDataCopyWith<AdListData> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $AdListDataCopyWith<$Res> {
  factory $AdListDataCopyWith(
          AdListData value, $Res Function(AdListData) then) =
      _$AdListDataCopyWithImpl<$Res, AdListData>;
  @useResult
  $Res call({PagingController<int, Ad> controller, Ad? turboAd, int pageKey});
}

/// @nodoc
class _$AdListDataCopyWithImpl<$Res, $Val extends AdListData>
    implements $AdListDataCopyWith<$Res> {
  _$AdListDataCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of AdListData
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? controller = null,
    Object? turboAd = freezed,
    Object? pageKey = null,
  }) {
    return _then(_value.copyWith(
      controller: null == controller
          ? _value.controller
          : controller // ignore: cast_nullable_to_non_nullable
              as PagingController<int, Ad>,
      turboAd: freezed == turboAd
          ? _value.turboAd
          : turboAd // ignore: cast_nullable_to_non_nullable
              as Ad?,
      pageKey: null == pageKey
          ? _value.pageKey
          : pageKey // ignore: cast_nullable_to_non_nullable
              as int,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$AdListDataImplCopyWith<$Res>
    implements $AdListDataCopyWith<$Res> {
  factory _$$AdListDataImplCopyWith(
          _$AdListDataImpl value, $Res Function(_$AdListDataImpl) then) =
      __$$AdListDataImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({PagingController<int, Ad> controller, Ad? turboAd, int pageKey});
}

/// @nodoc
class __$$AdListDataImplCopyWithImpl<$Res>
    extends _$AdListDataCopyWithImpl<$Res, _$AdListDataImpl>
    implements _$$AdListDataImplCopyWith<$Res> {
  __$$AdListDataImplCopyWithImpl(
      _$AdListDataImpl _value, $Res Function(_$AdListDataImpl) _then)
      : super(_value, _then);

  /// Create a copy of AdListData
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? controller = null,
    Object? turboAd = freezed,
    Object? pageKey = null,
  }) {
    return _then(_$AdListDataImpl(
      controller: null == controller
          ? _value.controller
          : controller // ignore: cast_nullable_to_non_nullable
              as PagingController<int, Ad>,
      turboAd: freezed == turboAd
          ? _value.turboAd
          : turboAd // ignore: cast_nullable_to_non_nullable
              as Ad?,
      pageKey: null == pageKey
          ? _value.pageKey
          : pageKey // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$AdListDataImpl implements _AdListData {
  const _$AdListDataImpl(
      {required this.controller, this.turboAd, this.pageKey = 0});

  @override
  final PagingController<int, Ad> controller;
  @override
  final Ad? turboAd;
  @override
  @JsonKey()
  final int pageKey;

  @override
  String toString() {
    return 'AdListData(controller: $controller, turboAd: $turboAd, pageKey: $pageKey)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$AdListDataImpl &&
            (identical(other.controller, controller) ||
                other.controller == controller) &&
            (identical(other.turboAd, turboAd) || other.turboAd == turboAd) &&
            (identical(other.pageKey, pageKey) || other.pageKey == pageKey));
  }

  @override
  int get hashCode => Object.hash(runtimeType, controller, turboAd, pageKey);

  /// Create a copy of AdListData
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$AdListDataImplCopyWith<_$AdListDataImpl> get copyWith =>
      __$$AdListDataImplCopyWithImpl<_$AdListDataImpl>(this, _$identity);
}

abstract class _AdListData implements AdListData {
  const factory _AdListData(
      {required final PagingController<int, Ad> controller,
      final Ad? turboAd,
      final int pageKey}) = _$AdListDataImpl;

  @override
  PagingController<int, Ad> get controller;
  @override
  Ad? get turboAd;
  @override
  int get pageKey;

  /// Create a copy of AdListData
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$AdListDataImplCopyWith<_$AdListDataImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$GetAdParam {
  AdListType get adListType => throw _privateConstructorUsedError;
  int? get id => throw _privateConstructorUsedError;
  int? get currentAdId => throw _privateConstructorUsedError;

  /// Create a copy of GetAdParam
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $GetAdParamCopyWith<GetAdParam> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $GetAdParamCopyWith<$Res> {
  factory $GetAdParamCopyWith(
          GetAdParam value, $Res Function(GetAdParam) then) =
      _$GetAdParamCopyWithImpl<$Res, GetAdParam>;
  @useResult
  $Res call({AdListType adListType, int? id, int? currentAdId});
}

/// @nodoc
class _$GetAdParamCopyWithImpl<$Res, $Val extends GetAdParam>
    implements $GetAdParamCopyWith<$Res> {
  _$GetAdParamCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of GetAdParam
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? adListType = null,
    Object? id = freezed,
    Object? currentAdId = freezed,
  }) {
    return _then(_value.copyWith(
      adListType: null == adListType
          ? _value.adListType
          : adListType // ignore: cast_nullable_to_non_nullable
              as AdListType,
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int?,
      currentAdId: freezed == currentAdId
          ? _value.currentAdId
          : currentAdId // ignore: cast_nullable_to_non_nullable
              as int?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$GetAdParamImplCopyWith<$Res>
    implements $GetAdParamCopyWith<$Res> {
  factory _$$GetAdParamImplCopyWith(
          _$GetAdParamImpl value, $Res Function(_$GetAdParamImpl) then) =
      __$$GetAdParamImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({AdListType adListType, int? id, int? currentAdId});
}

/// @nodoc
class __$$GetAdParamImplCopyWithImpl<$Res>
    extends _$GetAdParamCopyWithImpl<$Res, _$GetAdParamImpl>
    implements _$$GetAdParamImplCopyWith<$Res> {
  __$$GetAdParamImplCopyWithImpl(
      _$GetAdParamImpl _value, $Res Function(_$GetAdParamImpl) _then)
      : super(_value, _then);

  /// Create a copy of GetAdParam
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? adListType = null,
    Object? id = freezed,
    Object? currentAdId = freezed,
  }) {
    return _then(_$GetAdParamImpl(
      adListType: null == adListType
          ? _value.adListType
          : adListType // ignore: cast_nullable_to_non_nullable
              as AdListType,
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int?,
      currentAdId: freezed == currentAdId
          ? _value.currentAdId
          : currentAdId // ignore: cast_nullable_to_non_nullable
              as int?,
    ));
  }
}

/// @nodoc

class _$GetAdParamImpl implements _GetAdParam {
  const _$GetAdParamImpl({required this.adListType, this.id, this.currentAdId});

  @override
  final AdListType adListType;
  @override
  final int? id;
  @override
  final int? currentAdId;

  @override
  String toString() {
    return 'GetAdParam(adListType: $adListType, id: $id, currentAdId: $currentAdId)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetAdParamImpl &&
            (identical(other.adListType, adListType) ||
                other.adListType == adListType) &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.currentAdId, currentAdId) ||
                other.currentAdId == currentAdId));
  }

  @override
  int get hashCode => Object.hash(runtimeType, adListType, id, currentAdId);

  /// Create a copy of GetAdParam
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$GetAdParamImplCopyWith<_$GetAdParamImpl> get copyWith =>
      __$$GetAdParamImplCopyWithImpl<_$GetAdParamImpl>(this, _$identity);
}

abstract class _GetAdParam implements GetAdParam {
  const factory _GetAdParam(
      {required final AdListType adListType,
      final int? id,
      final int? currentAdId}) = _$GetAdParamImpl;

  @override
  AdListType get adListType;
  @override
  int? get id;
  @override
  int? get currentAdId;

  /// Create a copy of GetAdParam
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$GetAdParamImplCopyWith<_$GetAdParamImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
