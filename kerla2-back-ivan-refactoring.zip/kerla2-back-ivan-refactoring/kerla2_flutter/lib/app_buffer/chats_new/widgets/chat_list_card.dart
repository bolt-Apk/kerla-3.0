import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/app_buffer/chats_new/widgets/chat_card/ad_chat_card.dart';
import 'package:kerla2_flutter/app_buffer/chats_new/widgets/chat_card/common_chat_card.dart';
import 'package:kerla2_flutter/app_buffer/chats_new/widgets/chat_card/delete_bottom_sheet.dart';
import 'package:kerla2_flutter/common/user_profile_ref_extensions.dart';
import 'package:kerla2_flutter/core/app_backend_filters.dart';
import 'package:kerla2_flutter/router/router.dart';
import 'package:kerla2_shared/kerla2_shared.dart';
import 'package:nit_app/nit_app.dart';
import 'package:nit_router/nit_router.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

extension ChatsBuildContextExtension on BuildContext {
  goToChatByChannelId({
    required int channelId,
  }) {
    pushNamed(
      ChatNavigationZone.chatByChannelId.name,
      pathParameters: AppNavigationParams.channelId.set(channelId),
    );
  }
}

extension ChatsWidgetRefExtension on WidgetRef {
  Future<int?> getPersonalChannel(int chatWithUserId) async {
    final channelName = ChatChannelNames.getPersonalChannelName(
        chatWithUserId, signedInUserId!);

    final channelId = (await readMaybeModelCustom<NitChatChannel>(
      backendFilter: AppBackendFilter.channel.equals(channelName),
    ))
        ?.id;

    return channelId;
  }

  Future<int?> getAdChannel(int adId, int chatWithUserId) async {
    final channelName = ChatChannelNames.getAdChannelName(
      adId,
      chatWithUserId,
      signedInUserId!,
    );

    final channelId = (await readMaybeModelCustom<NitChatChannel>(
      backendFilter: AppBackendFilter.channel.equals(channelName),
    ))
        ?.id;

    return channelId;
  }
}

class ChatListCard extends ConsumerWidget {
  const ChatListCard({
    super.key,
    required this.chatParticipant,
  });

  final NitChatParticipant chatParticipant;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return ref
        .watchModelCustomAsync<NitChatChannel>(
          backendFilter:
              AppBackendFilter.id.equals(chatParticipant.chatChannelId),
        )
        .nitWhen(
          loadingValue: NitDefaultModelsRepository.get<NitChatChannel>(),
          errorWidget: const Text('Не удалось загрузить канал чата'),
          childBuilder: (chatChannel) {
            final adId =
                ChatChannelNames.extractAdChannelData(chatChannel.channel)?.$1;
            final userId = ChatChannelNames.extractUserIds(chatChannel.channel)!
                .firstWhere(
              (element) => element != ref.signedInUserId,
            );

            return Material(
              color: context.theme.canvasColor,
              borderRadius: BorderRadius.circular(8),
              child: InkWell(
                onLongPress: () => showModalBottomSheet(
                  context: context,
                  builder: (context) {
                    return DeleteChatBottomSheet(
                      onDelete: () async {
                        await ref.deleteModel<NitChatChannel>(chatChannel);
                        ref.read(globalRefreshTriggerProvider.notifier).state =
                            DateTime.now();
                        if (context.mounted) {
                          context.pop();
                        }
                      },
                    );
                  },
                ),
                child: ref.watchUserProfile(userId).nitWhen(
                      loadingValue:
                          NitDefaultModelsRepository.get<UserProfile>(),
                      // errorWidget: const SizedBox(),
                      // Text(
                      //   'Не удалось загрузить пользователя чата $userId ${chatChannel.channel}',
                      // ),
                      childBuilder: (userProfile) {
                        return adId != null
                            ? ChatCardWithAd(
                                adId: adId,
                                chatParticipant: chatParticipant,
                                userProfile: userProfile,
                              )
                            : CommonChatCard(
                                chatParticipant: chatParticipant,
                                userProfile: userProfile,
                              );
                      },
                    ),
              ),
            );
          },
        );
  }
}
