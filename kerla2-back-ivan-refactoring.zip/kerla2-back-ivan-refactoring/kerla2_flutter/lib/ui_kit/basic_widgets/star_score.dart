part of '../ui_kit.dart';

class StarScore extends StatelessWidget {
  const StarScore({super.key});

  @override
  Widget build(BuildContext context) {
    return const Row(
      children: [
        Icon(
          Icons.star,
          size: 11,
          color: ThemePrimaryColors.filledStar,
        ),
        Icon(
          Icons.star,
          size: 11,
          color: ThemePrimaryColors.filledStar,
        ),
        Icon(
          Icons.star,
          size: 11,
          color: ThemePrimaryColors.filledStar,
        ),
        Icon(
          Icons.star,
          size: 11,
          color: ThemePrimaryColors.filledStar,
        ),
        Icon(
          Icons.star_border,
          size: 11,
        ),
      ],
    );
  }
}
