import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter/foundation.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/core/core.dart';
import 'package:nit_app/nit_app.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:story_view/story_view.dart';

part 'stories_state.g.dart';

final storiesControllerProvider = Provider<StoryController>((ref) {
  return StoryController();
});

@riverpod
Future<List<Ad>> userStories(Ref ref, int userId) async {
  try {
    final storyIds = await client.ad.getStoriesByUser(userId);
    final ads = await Future.wait(
        storyIds.map((id) async => await ref.readOrFetchModel<Ad>(id)));
    return ads;
  } catch (e) {
    debugPrint('Error fetching user stories: $e');
    return [];
  }
}
