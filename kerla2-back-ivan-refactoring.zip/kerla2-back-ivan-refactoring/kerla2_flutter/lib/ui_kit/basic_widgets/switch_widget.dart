part of '../ui_kit.dart';

class SwitchWidget extends StatefulWidget {
  const SwitchWidget({
    super.key,
    required this.isActive,
    this.onTap,
  });

  final bool isActive;
  final bool Function()? onTap;

  @override
  State<SwitchWidget> createState() => _SwitchWidgetState();
}

class _SwitchWidgetState extends State<SwitchWidget> {
  late bool active = widget.isActive;
  @override
  Widget build(BuildContext context) {
    return ToggleSwitch(
      initialLabelIndex: active ? 1 : 0,
      minHeight: 15,
      minWidth: 15,
      cornerRadius: 5.0,
      radiusStyle: true,
      activeBgColors: [
        [ThemePrimaryColors.primary.withOpacity(0.3)],
        const [ThemePrimaryColors.primary],
      ],
      inactiveBgColor: ThemePrimaryColors.primary.withOpacity(
        0.1,
      ),
      inactiveFgColor: Colors.white,
      totalSwitches: 2,
      onToggle: (index) {
        if (widget.onTap != null) {
          final res = widget.onTap!();
          setState(() {
            active = res;
          });
          return;
        }

        setState(() {
          active = !active;
        });
      },
    );
  }
}
