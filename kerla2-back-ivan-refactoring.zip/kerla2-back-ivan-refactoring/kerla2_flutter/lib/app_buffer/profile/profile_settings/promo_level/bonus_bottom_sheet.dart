import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/app_buffer/ads/service/widget/service_row.dart';
import 'package:kerla2_flutter/app_buffer/profile/profile_settings/promo_level/promo_level_state/promo_level_state.dart';
import 'package:kerla2_flutter/common/kerla_service_title_extension.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_router/nit_router.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class BonusBottomSheet extends HookConsumerWidget {
  const BonusBottomSheet({
    super.key,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return DecoratedBox(
      decoration: BoxDecoration(color: context.theme.canvasColor),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          ref.watch(promoLevelStateProvider).maybeWhen(
                data: (promoLevelModel) {
                  final bonusDuration = Duration(
                      hours: promoLevelModel.nextPromoLevel?.duration ?? 0);
                  return Column(
                    children: [
                      const Align(
                        alignment: Alignment.center,
                        child: LittleDivider(),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        child: promoLevelModel.currentPromoLevel == null
                            ? const Padding(
                                padding: EdgeInsets.all(8),
                                child: SizedBox(
                                  width: double.infinity,
                                  child: Center(
                                      child: Text(
                                          'Для начала активируйте промокод')),
                                ),
                              )
                            : Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Align(
                                    alignment: Alignment.center,
                                    child: Text(
                                      'Награды',
                                      style: context.textTheme.headlineMedium,
                                    ),
                                  ),
                                  Padding(
                                    padding:
                                        const EdgeInsets.symmetric(vertical: 8),
                                    child: Text(
                                      'Ваш текущий уровень: ${promoLevelModel.currentPromoLevel?.id}',
                                      style: context.textTheme.headlineMedium,
                                    ),
                                  ),
                                  if (!promoLevelModel.isLastLevel)
                                    Padding(
                                      padding: const EdgeInsets.only(top: 8),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          if (promoLevelModel.nextPromoLevel!
                                                      .requiredInvites -
                                                  promoLevelModel.countInvites >
                                              0)
                                            Text(
                                              'До следующего уровня необходимо пригласить ещё ${promoLevelModel.countToNewLevel} пользователей',
                                              style: context
                                                  .textTheme.headlineMedium
                                                  ?.copyWith(fontSize: 16),
                                            ),
                                          if (promoLevelModel.nextPromoLevel !=
                                              null)
                                            Padding(
                                              padding:
                                                  const EdgeInsets.symmetric(
                                                      vertical: 8),
                                              child: LinearProgressIndicator(
                                                value: promoLevelModel
                                                        .countInvites /
                                                    promoLevelModel
                                                        .nextPromoLevel!
                                                        .requiredInvites,
                                              ),
                                            ),
                                          const Divider(),
                                          Padding(
                                            padding:
                                                const EdgeInsets.only(top: 8),
                                            child: Text(
                                              'Награда за следующий уровень:',
                                              textAlign: TextAlign.start,
                                              style: context
                                                  .textTheme.headlineMedium
                                                  ?.copyWith(fontSize: 16),
                                            ),
                                          ),
                                          ListView.builder(
                                            shrinkWrap: true,
                                            itemCount: promoLevelModel
                                                .nextPromoLevel!
                                                .serviceId
                                                .length,
                                            physics:
                                                const NeverScrollableScrollPhysics(),
                                            itemBuilder: (context, index) {
                                              final promotion = promoLevelModel
                                                  .nextPromoLevel!
                                                  .serviceId[index];

                                              return ServiceRow.notToggleable(
                                                serviceInfo: KerlaServiceInfo(
                                                  type: promotion,
                                                  cost: 0,
                                                  title: promotion.title,
                                                ),
                                              );
                                            },
                                          ),
                                          Padding(
                                            padding: const EdgeInsets.all(4),
                                            child: Text(
                                              'Длительность бонусов ${bonusDuration.inDays} дн. ${bonusDuration.inHours.remainder(24)} ч. ${bonusDuration.inMinutes.remainder(60)} мин.',
                                            ),
                                          ),
                                          if (ref
                                              .read(promoLevelStateProvider
                                                  .notifier)
                                              .isAvailableNewLevel)
                                            Align(
                                              alignment: Alignment.center,
                                              child: TextButton(
                                                onPressed: () => ref
                                                    .read(
                                                        promoLevelStateProvider
                                                            .notifier)
                                                    .getNewLevel()
                                                    .then(
                                                      (value) => context.pop(),
                                                    ),
                                                child: const Text(
                                                    'Перейти на следующий уровень'),
                                              ),
                                            ),
                                        ],
                                      ),
                                    ),
                                  if (promoLevelModel.isLastLevel)
                                    const Text(
                                        'Вы достигли максимального уровня'),
                                ],
                              ),
                      ),
                    ],
                  );
                },
                orElse: () => const SizedBox.shrink(),
              ),
        ],
      ),
    );
  }
}
