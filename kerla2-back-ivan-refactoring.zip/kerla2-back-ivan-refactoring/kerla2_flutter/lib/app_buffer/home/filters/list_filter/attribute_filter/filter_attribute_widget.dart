import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/app_buffer/ads/create/state/ad_create_state.dart';
import 'package:kerla2_flutter/app_buffer/home/filters/list_filter/attribute_filter/state/filter_attribute_state.dart';
import 'package:kerla2_flutter/app_buffer/home/filters/list_filter/attribute_filter/widget/home_filters_inline_render.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class FilterAttributeWidget extends HookConsumerWidget {
  const FilterAttributeWidget({
    super.key,
    required this.category,
    required this.adListType,
  });

  final AdCategory category;
  final AdListType adListType;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return ref.watch(attributeStateProvider(category)).nitWhen(
          childBuilder: (attributeState) => ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: attributeState.length,
            itemBuilder: (context, index) {
              return Consumer(
                builder: (context, ref, child) {
                  print('1231231');
                  final adAttributeValues = attributeState
                      .map(
                        (e) => AdAttributeValue(
                          attributeId: e.id!,
                          attribute: e,
                          value: ref
                                  .watch(filterStateProvider(adListType)
                                      .select((state) => state.attributes))
                                  .firstWhereOrNull(
                                    (element) => element.attributeId == e.id,
                                  )
                                  ?.value ??
                              '',
                        ),
                      )
                      .toList();
                  return Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: FiltersInlineRender(
                      attributeValue: adAttributeValues[index],
                      userId: null,
                      onSave: (value) {
                        ref
                            .read(filterStateProvider(adListType).notifier)
                            .upsertAttribute(value);
                      },
                    ),
                  );
                },
              );
            },
          ),
        );
  }
}
