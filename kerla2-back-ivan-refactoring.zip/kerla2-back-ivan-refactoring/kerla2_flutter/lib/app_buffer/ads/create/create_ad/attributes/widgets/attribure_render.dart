import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/core/app_sources.dart';

import 'attribute_category.dart';
import 'attribute_drop_list.dart';
import 'attribute_input.dart';
import 'attribute_radio_button_list.dart';

class AttributeRender extends ConsumerWidget {
  const AttributeRender({
    super.key,
    required this.attributeValue,
    this.onAttributeSave,
    this.onCategorySave,
    // this.adId,
  });

  final AdAttributeValue attributeValue;
  final Function(AdAttributeValue)? onAttributeSave;
  final Function(AdCategory)? onCategorySave;
  // final int? adId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    if (attributeValue.attribute == null) {
      return const SizedBox();
    }
    return switch (attributeValue.attribute!.type) {
      AttributeType.category => AttributeCategory(
          title: attributeValue.attribute!.title,
        ),
      // AttributeType.color => AttributeChooseColor(
      //     attribute: attributeValue.attribute,
      //     title: attributeValue.attribute!.title,
      //     adId: adId,
      //   ),
      AttributeType.radioButton => AttributeRadioButtonList(
          attributeValue: attributeValue,
          onAcceptTap: onAttributeSave ?? (AdAttributeValue value) {},
        ),
      AttributeType.regionsDropdown => Consumer(
          builder: (context, ref, child) {
            final regions = ref.watch(regionsProvider);
            return AttributeDropList(
              attributeValue: attributeValue,
              title: attributeValue.attribute?.title,
              list: regions,
              isRegionDropDown: true,
              onAcceptTap: onAttributeSave ?? (AdAttributeValue value) {},
            );
          },
        ),
      AttributeType.valuesDropdown => AttributeDropList(
          attributeValue: attributeValue,
          list: attributeValue.attribute!.values,
          title: attributeValue.attribute?.title,
          onAcceptTap: onAttributeSave ?? (AdAttributeValue value) {},
        ),
      AttributeType.decimal => AttributeInput(
          attributeValue: attributeValue,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          onAccept: onAttributeSave ?? (AdAttributeValue value) {},
        ),
      AttributeType.number => AttributeInput(
          attributeValue: attributeValue,
          keyboardType: TextInputType.number,
          onAccept: onAttributeSave ?? (AdAttributeValue value) {},
        ),
      AttributeType.string => AttributeInput(
          attributeValue: attributeValue,
          onAccept: onAttributeSave ?? (AdAttributeValue value) {},
        ),
      // TODO: Handle this case.
      AttributeType.color => throw UnimplementedError(),
    };
  }
}
