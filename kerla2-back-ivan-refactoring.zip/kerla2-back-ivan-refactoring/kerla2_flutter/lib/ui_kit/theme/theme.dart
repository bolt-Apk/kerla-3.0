part of '../ui_kit.dart';

ThemeData lightMode = ThemeData(
    brightness: Brightness.light,
    fontFamily: 'Futura',
    // TODO: надо как-то внедрить в nit_router, сейчас там MaterialPage используется
    pageTransitionsTheme: const PageTransitionsTheme(builders: {
      TargetPlatform.iOS: SwipeablePageTransitionsBuilder(),
    }),
    useMaterial3: true,
    colorSchemeSeed: const Color.fromRGBO(1, 150, 162, 1), //primaryColor
    scaffoldBackgroundColor: const Color(0xFFF3F3F3), //grey color
    canvasColor: ThemePrimaryColors.white, //colorMainbackground
    primaryColorDark: const Color(0xff807C7C), // colorTextBlack
    secondaryHeaderColor: const Color.fromARGB(220, 228, 228, 228),
    dialogBackgroundColor: ThemePrimaryColors.white,
    bottomSheetTheme: const BottomSheetThemeData(
      backgroundColor: ThemePrimaryColors.white,
      modalBackgroundColor: ThemePrimaryColors.white,
      surfaceTintColor: ThemePrimaryColors.white,
    ),
    appBarTheme: const AppBarTheme(
      surfaceTintColor: Colors.white,
      backgroundColor: Colors.white,
    ),
    textTheme: TextTheme(
      displayLarge: GoogleFonts.roboto(
        // details1 done
        color: ThemePrimaryColors.background,
        fontWeight: FontWeight.w400,
        fontSize: 14,
      ),
      displayMedium: GoogleFonts.roboto(
        //details2 done
        color: const Color.fromARGB(255, 57, 57, 57),
        fontWeight: FontWeight.w400,
        fontSize: 10,
      ),
      displaySmall: GoogleFonts.roboto(
        //details3 done
        color: ThemePrimaryColors.background,
        fontSize: 10,
        fontWeight: FontWeight.w700,
      ),
      headlineLarge: _textTheme.headlineLarge!.copyWith(
        // h1 done
        color: ThemePrimaryColors.background,
      ),
      headlineMedium: _textTheme.headlineMedium!.copyWith(
        // h2 done
        color: ThemePrimaryColors.background,
      ),
      headlineSmall: GoogleFonts.tajawal(
        // h3 done
        color: ThemePrimaryColors.background,
        fontWeight: FontWeight.w900,
        fontSize: 16,
      ),
      titleLarge: GoogleFonts.rubik(
        // price
        color: ThemePrimaryColors.background,
        fontWeight: FontWeight.w600,
        fontSize: 16,
      ),
      titleMedium: GoogleFonts.roboto(
        // h4 done
        color: ThemePrimaryColors.background,
        fontWeight: FontWeight.w500,
        fontSize: 16,
      ),
      titleSmall: GoogleFonts.roboto(
        // h5 done
        color: ThemePrimaryColors.background,
        fontWeight: FontWeight.w500,
        fontSize: 12,
      ),
      bodyLarge: GoogleFonts.roboto(
        // link done
        color: const Color.fromRGBO(11, 69, 219, 1),
        fontWeight: FontWeight.w400,
        fontSize: 12,
      ),
      bodyMedium: _textTheme.bodyMedium!.copyWith(
        // textBase16 done
        color: ThemePrimaryColors.background,
      ),
      bodySmall: _textTheme.bodySmall!.copyWith(
        // body done
        color: ThemePrimaryColors.background,
      ),
      labelLarge: GoogleFonts.roboto(
        // adCardTitel done
        color: ThemePrimaryColors.background,
        fontWeight: FontWeight.w400,
        fontSize: 14,
      ),
      labelMedium: GoogleFonts.roboto(
        //details 4 done
        color: const Color.fromRGBO(128, 124, 124, 1),
        fontSize: 10,
      ),
      labelSmall: GoogleFonts.roboto(
        // details 5 done
        color: ThemePrimaryColors.background,
        fontWeight: FontWeight.w400,
        fontSize: 14,
      ),
    ),
    iconTheme: const IconThemeData(
      color: ThemePrimaryColors.background, // filledStar
    ),
    shadowColor: ThemePrimaryColors.background.withOpacity(0.5), //boxshadow

    elevatedButtonTheme: ElevatedButtonThemeData(
        style: ButtonStyle(
      textStyle: WidgetStateProperty.all<TextStyle?>(const TextStyle(
        color: ThemePrimaryColors.background,
        fontSize: 17,
      )),
      backgroundColor: WidgetStateProperty.resolveWith<Color>(
        (Set<WidgetState> states) {
          if (states.contains(WidgetState.pressed)) {
            return const Color.fromRGBO(1, 150, 162, 1);
          } else if (states.contains(WidgetState.disabled)) {
            return Colors.grey.shade300;
          }
          return const Color.fromRGBO(1, 150, 162, 1);
        },
      ),
      shape: WidgetStateProperty.all<RoundedRectangleBorder>(
        RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16.0),
        ),
      ),
      padding: ButtonStyleButton.allOrNull<EdgeInsetsGeometry>(
        const EdgeInsets.all(16),
      ),
      minimumSize: ButtonStyleButton.allOrNull<Size>(const Size.fromHeight(50)),
    ))
    // BoxShadow
    );

ThemeData darkMode = ThemeData(
    brightness: Brightness.dark,
    fontFamily: 'Futura',
    pageTransitionsTheme: const PageTransitionsTheme(builders: {
      TargetPlatform.iOS: SwipeablePageTransitionsBuilder(),
    }),
    useMaterial3: true,
    colorSchemeSeed: const Color.fromRGBO(1, 150, 162, 1), //primaryColor
    scaffoldBackgroundColor: const Color.fromARGB(255, 38, 38, 36),
    canvasColor: const Color.fromARGB(255, 20, 20, 18), // grey color
    primaryColorDark: const Color(0xFFCACACA), // colorTextBlack
    secondaryHeaderColor: const Color.fromARGB(255, 71, 71, 82),
    dialogBackgroundColor: ThemePrimaryColors.background,
    bottomSheetTheme: const BottomSheetThemeData(
      backgroundColor: ThemePrimaryColors.background,
      modalBackgroundColor: ThemePrimaryColors.background,
      surfaceTintColor: ThemePrimaryColors.background,
    ),
    appBarTheme: const AppBarTheme(
      surfaceTintColor: Colors.transparent,
      backgroundColor: Colors.black,
    ),
    textTheme: TextTheme(
      displayLarge: GoogleFonts.roboto(
        // details1 done for the buttons
        color: ThemePrimaryColors.white,
        fontWeight: FontWeight.w400,
        fontSize: 14,
      ),
      displayMedium: GoogleFonts.roboto(
        //details2 done
        color: const Color.fromARGB(255, 57, 57, 57),
        fontWeight: FontWeight.w400,
        fontSize: 10,
      ),
      displaySmall: GoogleFonts.roboto(
        //details3 done
        color: ThemePrimaryColors.white,
        fontSize: 10,
        fontWeight: FontWeight.w700,
      ),
      headlineLarge: _textTheme.headlineLarge!.copyWith(
        // h1 done
        color: ThemePrimaryColors.white,
      ),
      headlineMedium: _textTheme.headlineMedium!.copyWith(
        // h2 done for the page headers
        color: ThemePrimaryColors.white,
      ),
      headlineSmall: GoogleFonts.tajawal(
        // h3 done
        color: ThemePrimaryColors.white,
        fontWeight: FontWeight.w900,
        fontSize: 16,
      ),
      titleLarge: GoogleFonts.rubik(
        // price and for sub-headers
        color: ThemePrimaryColors.white,
        fontWeight: FontWeight.w600,
        fontSize: 16,
      ),
      titleMedium: GoogleFonts.roboto(
        // h4 done
        color: ThemePrimaryColors.white,
        fontWeight: FontWeight.w500,
        fontSize: 16,
      ),
      titleSmall: GoogleFonts.roboto(
        // h5 done
        color: ThemePrimaryColors.white,
        fontWeight: FontWeight.w500,
        fontSize: 12,
      ),
      bodyLarge: GoogleFonts.roboto(
        // link
        color: const Color.fromRGBO(11, 69, 219, 1),
        fontWeight: FontWeight.w400,
        fontSize: 12,
      ),
      bodyMedium: _textTheme.bodyMedium!.copyWith(
        // textBase16 done for the input text field
        color: ThemePrimaryColors.white,
      ),
      bodySmall: _textTheme.bodySmall!.copyWith(
        // body done
        color: ThemePrimaryColors.white,
      ),
      labelLarge: GoogleFonts.roboto(
        // adCardTitel
        color: ThemePrimaryColors.white,
        fontWeight: FontWeight.w400,
        fontSize: 14,
      ),
      labelMedium: GoogleFonts.roboto(
        //details 4 done
        color: const Color.fromARGB(255, 226, 226, 226),
        fontSize: 10,
      ),
      labelSmall: GoogleFonts.roboto(
        // details 5
        color: ThemePrimaryColors.white,
        fontWeight: FontWeight.w400,
        fontSize: 14,
      ),
    ),
    iconTheme: const IconThemeData(
      color: ThemePrimaryColors.white, // filledStar
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
        style: ButtonStyle(
      textStyle: WidgetStateProperty.all<TextStyle?>(const TextStyle(
        color: ThemePrimaryColors.white,
        fontSize: 17,
      )),
      backgroundColor: WidgetStateProperty.resolveWith<Color>(
        (Set<WidgetState> states) {
          if (states.contains(WidgetState.pressed)) {
            return const Color.fromRGBO(1, 150, 162, 1);
          } else if (states.contains(WidgetState.disabled)) {
            return Colors.grey.shade300;
          }
          return const Color.fromRGBO(1, 150, 162, 1);
        },
      ),
      shape: WidgetStateProperty.all<RoundedRectangleBorder>(
        RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16.0),
        ),
      ),
      padding: ButtonStyleButton.allOrNull<EdgeInsetsGeometry>(
        const EdgeInsets.all(16),
      ),
      minimumSize: ButtonStyleButton.allOrNull<Size>(const Size.fromHeight(50)),
    ))
    // BoxShadow
    );

const TextTheme _textTheme = TextTheme(
  headlineLarge: TextStyle(
    fontSize: 22,
    fontFamily: 'Futura Bold',
  ), // h1
  headlineMedium: TextStyle(
    fontSize: 18,
    fontFamily: 'Futura Bold',
  ), // h2 for page heads
  bodyMedium: TextStyle(fontSize: 16, fontFamily: 'Futura'), // textBase16
  bodySmall: TextStyle(
    fontSize: 12,
    fontFamily: 'Futura',
  ), // body
);
