import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';

import 'home_attribute_radio_button.dart';

class HomeAttributeRadioButtonList extends HookConsumerWidget {
  const HomeAttributeRadioButtonList({
    super.key,
    required this.attribute,
    required this.onRadioButtonTap,
    required this.valueNotifier,
    // required this.valueNotifier,
    this.text,
    this.onReset,
  });

  final String? text;
  // final ValueNotifier<String?> valueNotifier;
  final Attribute attribute;
  final Function(String) onRadioButtonTap;
  final ValueNotifier<String?> valueNotifier;
  final VoidCallback? onReset;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Container(
            height: 2,
            width: MediaQuery.sizeOf(context).width * 0.1,
            color: Colors.black.withOpacity(0.5),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Flexible(
                child: Row(
                  children: [
                    InkWell(
                      onTap: () => context.pop(),
                      child: const Icon(Icons.close),
                    ),
                    const SizedBox(width: 8),
                    Flexible(
                      child: Text(
                        '${attribute.title ?? ''} ${valueNotifier.value?.isEmpty ?? true ? '' : ':${valueNotifier.value}'}',
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              ),
              InkWell(
                onTap: () {
                  onReset != null ? onReset!() : null;
                  valueNotifier.value = '';
                },
                child: const Row(
                  children: [
                    SizedBox(width: 8),
                    Text("Сбросить"),
                  ],
                ),
              ),
            ],
          ),
        ),
        const Divider(
          height: 2,
        ),
        const SizedBox(height: 8),
        Expanded(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
            child: ListView.builder(
              itemCount: attribute.values!.length,
              itemBuilder: (BuildContext context, int index) {
                return HomeAttributeRadionButton(
                  isSelected: valueNotifier.value?.isEmpty ?? true
                      ? false
                      : valueNotifier.value == attribute.values![index],
                  onTap: () => {
                    valueNotifier.value = attribute.values![index],
                    onRadioButtonTap(attribute.values![index]),
                  },
                  text: attribute.values![index],
                );
              },
            ),
          ),
        ),
      ],
    );
  }
}
