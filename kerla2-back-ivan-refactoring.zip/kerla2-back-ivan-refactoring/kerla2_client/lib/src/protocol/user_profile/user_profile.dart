/* AUTOMATICALLY GENERATED CODE DO NOT MODIFY */
/*   To generate run: "serverpod generate"    */

// ignore_for_file: implementation_imports
// ignore_for_file: library_private_types_in_public_api
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: public_member_api_docs
// ignore_for_file: type_literal_in_constant_pattern
// ignore_for_file: use_super_parameters

// ignore_for_file: no_leading_underscores_for_library_prefixes
import 'package:serverpod_client/serverpod_client.dart' as _i1;
import '../protocol.dart' as _i2;

abstract class UserProfile implements _i1.SerializableModel {
  UserProfile._({
    this.id,
    bool? isAdmin,
    required this.userId,
    this.email,
    this.userName,
    this.gender,
    bool? isOnline,
    this.lastTimeOnline,
    this.profileDescription,
    this.link,
    this.businessEndsAt,
    this.imageUrl,
    this.backgroundImageUrl,
    this.city,
    this.phoneNumber,
    bool? isBlocked,
    bool? showPhone,
    bool? isSubscribed,
  })  : isAdmin = isAdmin ?? false,
        isOnline = isOnline ?? false,
        isBlocked = isBlocked ?? false,
        showPhone = showPhone ?? false,
        isSubscribed = isSubscribed ?? false;

  factory UserProfile({
    int? id,
    bool? isAdmin,
    required int userId,
    String? email,
    String? userName,
    _i2.UserGender? gender,
    bool? isOnline,
    DateTime? lastTimeOnline,
    String? profileDescription,
    String? link,
    DateTime? businessEndsAt,
    String? imageUrl,
    String? backgroundImageUrl,
    String? city,
    String? phoneNumber,
    bool? isBlocked,
    bool? showPhone,
    bool? isSubscribed,
  }) = _UserProfileImpl;

  factory UserProfile.fromJson(Map<String, dynamic> jsonSerialization) {
    return UserProfile(
      id: jsonSerialization['id'] as int?,
      isAdmin: jsonSerialization['isAdmin'] as bool,
      userId: jsonSerialization['userId'] as int,
      email: jsonSerialization['email'] as String?,
      userName: jsonSerialization['userName'] as String?,
      gender: jsonSerialization['gender'] == null
          ? null
          : _i2.UserGender.fromJson((jsonSerialization['gender'] as int)),
      isOnline: jsonSerialization['isOnline'] as bool,
      lastTimeOnline: jsonSerialization['lastTimeOnline'] == null
          ? null
          : _i1.DateTimeJsonExtension.fromJson(
              jsonSerialization['lastTimeOnline']),
      profileDescription: jsonSerialization['profileDescription'] as String?,
      link: jsonSerialization['link'] as String?,
      businessEndsAt: jsonSerialization['businessEndsAt'] == null
          ? null
          : _i1.DateTimeJsonExtension.fromJson(
              jsonSerialization['businessEndsAt']),
      imageUrl: jsonSerialization['imageUrl'] as String?,
      backgroundImageUrl: jsonSerialization['backgroundImageUrl'] as String?,
      city: jsonSerialization['city'] as String?,
      phoneNumber: jsonSerialization['phoneNumber'] as String?,
      isBlocked: jsonSerialization['isBlocked'] as bool,
      showPhone: jsonSerialization['showPhone'] as bool,
      isSubscribed: jsonSerialization['isSubscribed'] as bool?,
    );
  }

  /// The database id, set if the object has been inserted into the
  /// database or if it has been fetched from the database. Otherwise,
  /// the id will be null.
  int? id;

  bool isAdmin;

  int userId;

  String? email;

  String? userName;

  _i2.UserGender? gender;

  bool isOnline;

  DateTime? lastTimeOnline;

  String? profileDescription;

  String? link;

  DateTime? businessEndsAt;

  String? imageUrl;

  /// A URL to the user's profile background image.
  String? backgroundImageUrl;

  String? city;

  String? phoneNumber;

  bool isBlocked;

  bool showPhone;

  bool? isSubscribed;

  UserProfile copyWith({
    int? id,
    bool? isAdmin,
    int? userId,
    String? email,
    String? userName,
    _i2.UserGender? gender,
    bool? isOnline,
    DateTime? lastTimeOnline,
    String? profileDescription,
    String? link,
    DateTime? businessEndsAt,
    String? imageUrl,
    String? backgroundImageUrl,
    String? city,
    String? phoneNumber,
    bool? isBlocked,
    bool? showPhone,
    bool? isSubscribed,
  });
  @override
  Map<String, dynamic> toJson() {
    return {
      if (id != null) 'id': id,
      'isAdmin': isAdmin,
      'userId': userId,
      if (email != null) 'email': email,
      if (userName != null) 'userName': userName,
      if (gender != null) 'gender': gender?.toJson(),
      'isOnline': isOnline,
      if (lastTimeOnline != null) 'lastTimeOnline': lastTimeOnline?.toJson(),
      if (profileDescription != null) 'profileDescription': profileDescription,
      if (link != null) 'link': link,
      if (businessEndsAt != null) 'businessEndsAt': businessEndsAt?.toJson(),
      if (imageUrl != null) 'imageUrl': imageUrl,
      if (backgroundImageUrl != null) 'backgroundImageUrl': backgroundImageUrl,
      if (city != null) 'city': city,
      if (phoneNumber != null) 'phoneNumber': phoneNumber,
      'isBlocked': isBlocked,
      'showPhone': showPhone,
      if (isSubscribed != null) 'isSubscribed': isSubscribed,
    };
  }

  @override
  String toString() {
    return _i1.SerializationManager.encode(this);
  }
}

class _Undefined {}

class _UserProfileImpl extends UserProfile {
  _UserProfileImpl({
    int? id,
    bool? isAdmin,
    required int userId,
    String? email,
    String? userName,
    _i2.UserGender? gender,
    bool? isOnline,
    DateTime? lastTimeOnline,
    String? profileDescription,
    String? link,
    DateTime? businessEndsAt,
    String? imageUrl,
    String? backgroundImageUrl,
    String? city,
    String? phoneNumber,
    bool? isBlocked,
    bool? showPhone,
    bool? isSubscribed,
  }) : super._(
          id: id,
          isAdmin: isAdmin,
          userId: userId,
          email: email,
          userName: userName,
          gender: gender,
          isOnline: isOnline,
          lastTimeOnline: lastTimeOnline,
          profileDescription: profileDescription,
          link: link,
          businessEndsAt: businessEndsAt,
          imageUrl: imageUrl,
          backgroundImageUrl: backgroundImageUrl,
          city: city,
          phoneNumber: phoneNumber,
          isBlocked: isBlocked,
          showPhone: showPhone,
          isSubscribed: isSubscribed,
        );

  @override
  UserProfile copyWith({
    Object? id = _Undefined,
    bool? isAdmin,
    int? userId,
    Object? email = _Undefined,
    Object? userName = _Undefined,
    Object? gender = _Undefined,
    bool? isOnline,
    Object? lastTimeOnline = _Undefined,
    Object? profileDescription = _Undefined,
    Object? link = _Undefined,
    Object? businessEndsAt = _Undefined,
    Object? imageUrl = _Undefined,
    Object? backgroundImageUrl = _Undefined,
    Object? city = _Undefined,
    Object? phoneNumber = _Undefined,
    bool? isBlocked,
    bool? showPhone,
    Object? isSubscribed = _Undefined,
  }) {
    return UserProfile(
      id: id is int? ? id : this.id,
      isAdmin: isAdmin ?? this.isAdmin,
      userId: userId ?? this.userId,
      email: email is String? ? email : this.email,
      userName: userName is String? ? userName : this.userName,
      gender: gender is _i2.UserGender? ? gender : this.gender,
      isOnline: isOnline ?? this.isOnline,
      lastTimeOnline:
          lastTimeOnline is DateTime? ? lastTimeOnline : this.lastTimeOnline,
      profileDescription: profileDescription is String?
          ? profileDescription
          : this.profileDescription,
      link: link is String? ? link : this.link,
      businessEndsAt:
          businessEndsAt is DateTime? ? businessEndsAt : this.businessEndsAt,
      imageUrl: imageUrl is String? ? imageUrl : this.imageUrl,
      backgroundImageUrl: backgroundImageUrl is String?
          ? backgroundImageUrl
          : this.backgroundImageUrl,
      city: city is String? ? city : this.city,
      phoneNumber: phoneNumber is String? ? phoneNumber : this.phoneNumber,
      isBlocked: isBlocked ?? this.isBlocked,
      showPhone: showPhone ?? this.showPhone,
      isSubscribed: isSubscribed is bool? ? isSubscribed : this.isSubscribed,
    );
  }
}
