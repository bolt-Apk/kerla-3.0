import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class CounterButton extends StatelessWidget {
  final int count;
  final String label;
  final String routeName;
  final Map<String, String> pathParameters;

  const CounterButton({
    super.key,
    required this.count,
    required this.label,
    required this.routeName,
    required this.pathParameters,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      child: InkWell(
        onTap: () =>
            context.pushNamed(routeName, pathParameters: pathParameters),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                count.toString(),
                style: Theme.of(context).textTheme.titleMedium,
              ),
              const SizedBox(width: 4),
              Text(
                label,
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
