import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';

final adSortProvider =
    StateProvider.family<AdOrderBy, int?>((ref, userId) => AdOrderBy.dateDes);

extension AdOrderByExtension on AdOrderBy {
  String get localizedName {
    switch (this) {
      case AdOrderBy.dateDes:
        return 'Сначала новые';
      case AdOrderBy.dateAsc:
        return 'Сначала старые';
      case AdOrderBy.priceAsc:
        return 'Сначала дешёвые';
      case AdOrderBy.priceDes:
        return 'Сначала дорогие';
      case AdOrderBy.random:
        return 'Случайный';
    }
  }
}
