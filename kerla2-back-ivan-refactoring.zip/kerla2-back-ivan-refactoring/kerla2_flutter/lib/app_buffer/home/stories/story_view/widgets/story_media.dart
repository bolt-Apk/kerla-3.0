import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/core/core.dart';
import 'package:kerla2_flutter/core/view_session_id.dart';
import 'package:nit_app/nit_app.dart';
import 'package:story_view/story_view.dart';

class StoryMedia extends ConsumerWidget {
  const StoryMedia({
    super.key,
    required this.stories,
    required this.controller,
    required this.user,
    this.initialStoryId,
    this.onStoryShow,
    this.onComplete,
  });

  final List<Ad> stories;
  final StoryController controller;
  final UserProfile user;
  final int? initialStoryId;
  final Function(StoryItem)? onStoryShow;
  final Function()? onComplete;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return StoryView(
      storyItems: stories.where((s) => s.media?.isNotEmpty == true).map(
        (s) {
          final media = s.media!.first;
          debugPrint(media.publicUrl);
          return media.type == MediaType.image
              ? StoryItem.pageImage(
                  id: s.id!,
                  url: media.publicUrl,
                  controller: controller,
                  duration: const Duration(seconds: 15),
                )
              : StoryItem.pageVideo(
                  media.publicUrl,
                  id: s.id!,
                  controller: controller,
                  duration: Duration(
                    milliseconds: s.media!.first.duration ?? 15,
                  ),
                );
        },
      ).toList(),
      onStoryShow: onStoryShow,
      onStoryViewed: (storyId) {
        final sessionId = ref.read(viewSessionIdProvider);
        if (sessionId != const UuidValue.fromNamespace(Namespace.nil)) {
          client.ad.updateAdCounts(false, storyId, sessionId.uuid);
        }
      },
      controller: controller,
      onComplete: onComplete,
      onVerticalSwipeComplete: (direction) {
        if (direction == Direction.down) {
          Navigator.of(context).pop();
        }
      },
    );
  }
}
