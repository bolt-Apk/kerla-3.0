import 'package:flutter/material.dart';
import 'package:kerla2_flutter/router/router.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_router/nit_router.dart';

class NoAdsWidget extends StatelessWidget {
  const NoAdsWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        color: Theme.of(context).scaffoldBackgroundColor,
      ),
      child: Padding(
        padding:
            const EdgeInsets.only(top: 16, left: 16, right: 16, bottom: 16),
        child: Column(
          children: [
            Text(
              'Объявлений пока нет',
              style: Theme.of(context).textTheme.headlineLarge,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: Text(
                'Но это легко исправить - разместите первое объявление',
                style: Theme.of(context).textTheme.displayLarge,
                textAlign: TextAlign.center,
              ),
            ),
            MainButton(
              buttonText: 'Разместить объявление',
              boxHeight: 45,
              onTap: () => context.pushNamed(AdNavigationZone.createAd.name),
            ),
          ],
        ),
      ),
    );
  }
}
