import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/app/favorites/favorite_button.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_app/nit_app.dart';

import 'ad_more_info_button.dart';
import 'ad_price.dart';

class AdDetails extends ConsumerWidget {
  const AdDetails({
    super.key,
    required this.ad,
  });

  final Ad ad;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // final isFavorite = useState(ad.isFavourite);

    return Stack(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
          child: Column(
            // mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  AdPrice(price: ad.price ),
                  // const Spacer(),
                  // const Padding(
                  //   padding: EdgeInsets.only(right: 3),
                  //   child: AdDistance(),
                  // ),
                ],
              ),
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Text(
                  ad.title,
                  style: Theme.of(context).textTheme.labelLarge,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              const Spacer(),
              Row(
                children: [
                  const Icon(
                    Icons.location_on,
                    size: 10,
                  ),
                  const SizedBox(width: 4),
                  Text(
                    ad.region?.title ?? 'Не указано', 
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 10,
                      color: Color.fromRGBO(128, 124, 124, 1),
                    ),
                  ),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    ad.createdAt.toLocal().formatDate,
                    style: const TextStyle(
                      fontSize: 10,
                      color: Color.fromRGBO(142, 142, 142, 1),
                    ),
                  ),
                  AdMoreInfoButton(
                    ad: ad,
                    icon: Icons.more_vert,
                  ),
                ],
              ),
            ],
          ),
        ),
        Positioned(
          top: 0,
          right: 6,
          child: ref.signedIn
              ? FavoriteButton.wrappedInCommonButton(
                  adId: ad.id!,
                )
              : const SizedBox(),
        ),
      ],
    );
  }
}
