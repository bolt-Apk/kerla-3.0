part of '../ui_kit.dart';

class AppIconsSvg {
  AppIconsSvg._();

  static const String activeFavorite = 'assets/icons/active_favorite.svg';
  static const String arrowForAdPage = 'assets/icons/arrow_for_ad_page.svg';
  static const String chats = 'assets/icons/chats.svg';
  static const String chooseFromGalary = 'assets/icons/choose_from_galary.svg';
  static const String close = 'assets/icons/close.svg';
  static const String closeRadioButton = 'assets/icons/close_radio_button.svg';
  static const String comment = 'assets/icons/comment.svg';
  static const String delete = 'assets/icons/delete.svg';
  static const String edit = 'assets/icons/edit.svg';
  static const String favorite = 'assets/icons/favorite.svg';
  static const String filter = 'assets/icons/filter.svg';
  static const String man = 'assets/icons/man.svg';
  static const String more = 'assets/icons/more.svg';
  static const String navigation = 'assets/icons/navigation.svg';
  static const String notification = 'assets/icons/notification.svg';
  static const String phone = 'assets/icons/phone.svg';
  static const String photo = 'assets/icons/photo.svg';
  static const String picture = 'assets/icons/picture.svg';
  static const String search = 'assets/icons/search.svg';
  static const String selectFilter = 'assets/icons/select_filter.svg';
  static const String share = 'assets/icons/share.svg';
  static const String stack = 'assets/icons/stack.svg';
  static const String upload = 'assets/icons/upload.svg';
  static const String warning = 'assets/icons/warning.svg';
  static const String woman = 'assets/icons/woman.svg';
  static const String sort = 'assets/icons/sort.svg';
  static const String bell = 'assets/icons/bell_icon.svg';
  static const String account = 'assets/icons/account.svg';
  static const String save = 'assets/icons/save.svg';
  static const String send = 'assets/icons/send.svg';
}
