// import 'package:flutter/material.dart';
// import 'package:flutter_riverpod/flutter_riverpod.dart';
// import 'package:flutter_svg/svg.dart';
// import 'package:kerla2_client/kerla2_client.dart';
// import 'package:kerla2_flutter/router/router.dart';
// import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
// import 'package:nit_router/nit_router.dart';
// import 'package:nit_ui_kit/nit_ui_kit.dart';

// import '../../ad/state/ad/ad_state.dart';
// import '../state/categories_provider.dart';
// import '../state/home_filters_state.dart';
// import '../list_filter/widgets/home_radio_button.dart';
// import 'home_select_subcategory.dart';

// class HomeRadioButtonList extends ConsumerStatefulWidget {
//   const HomeRadioButtonList({
//     super.key,
//     this.userId,
//   });

//   @override
//   ConsumerState<ConsumerStatefulWidget> createState() =>
//       _HomeRadioButtonListState();

//   final int? userId;
// }

// class _HomeRadioButtonListState extends ConsumerState<HomeRadioButtonList> {
//   final Map<String, double> categoryScrollOffsets = {};
//   final scrollController = ScrollController();
//   double scrollPosition = 0.0;
//   @override
//   void initState() {
//     super.initState();
//     scrollController.addListener(() {
//       // Сохраняем позицию прокрутки
//       scrollPosition = scrollController.offset;
//     });
//   }

//   @override
//   void dispose() {
//     scrollController.dispose();
//     super.dispose();
//   }

//   @override
//   Widget build(BuildContext context) {
//     WidgetsBinding.instance.addPostFrameCallback((_) {
//       if (scrollController.hasClients) scrollController.jumpTo(scrollPosition);
//     });
//     List<AdCategory> categories;
//     if (widget.userId == null) {
//       categories = ref.read(categoriesProvider);
//     } else {
//       categories = ref
//               .watch(profileAdCategoriesProvider(widget.userId!))
//               .whenData((value) => value)
//               .value ??
//           [];
//     }

//     if (categories.isEmpty) {
//       return const SizedBox.shrink();
//     }

//     return Container(
//       height: 40,
//       padding: const EdgeInsets.symmetric(vertical: 4),
//       color: Theme.of(context).scaffoldBackgroundColor,
//       child: Row(
//         children: [
//           SelectFilterButton(
//             userId: widget.userId,
//           ),
//           const SizedBox(width: 10),
//           Expanded(
//             child: Builder(
//               builder: (context) {
//                 final state = ref.watch(
//                   homeFiltersStateProvider(isProfile: widget.userId != null),
//                 );

//                 // выбрана последняя категория
//                 if (state.categoryStack.lastOrNull?.children?.isEmpty == true) {
//                   return HomeSelectAttributes(userId: widget.userId);
//                 }

//                 // выбрана не последняя категория
//                 if (state.categoryStack.isNotEmpty) {
//                   return HomeSelectSubcategoryList(
//                     userId: widget.userId,
//                     initScrollOffset:
//                         categoryScrollOffsets[state.categoryStack.last.title] ??
//                             0,
//                     disposeCallback: (offset) {
//                       categoryScrollOffsets[state.categoryStack.last.title] =
//                           offset;
//                     },
//                     addNewSubcategoryCallback: (subCategoryTitle) {
//                       categoryScrollOffsets.putIfAbsent(
//                           subCategoryTitle, () => 0);
//                     },
//                     categoryName: state.categoryStack.last.title,
//                   );
//                 }

//                 if (widget.userId != null &&
//                     ref
//                         .watch(profileAdCategoriesProvider(widget.userId!))
//                         .isLoading) {
//                   const LinearProgressIndicator(
//                     color: ThemePrimaryColors.primary,
//                   );
//                 }

//                 //категория не выбрана
//                 return ListView.builder(
//                   controller: scrollController,
//                   scrollDirection: Axis.horizontal,
//                   itemCount: categories.length,
//                   itemBuilder: (BuildContext context, int index) {
//                     // final bool isSelected;
//                     // if (state.category != null) {
//                     //   isSelected = categories[index].id == state.category!.id;
//                     // } else {
//                     //   isSelected = false;
//                     // }
//                     return Padding(
//                       padding: const EdgeInsets.only(right: 10),
//                       child: HomeRadioButton(
//                         text: categories[index].title,
//                         isSelected: false,
//                         onTap: () {
//                           ref
//                               .read(
//                                 homeFiltersStateProvider(
//                                   isProfile: widget.userId != null,
//                                 ).notifier,
//                               )
//                               .addCategoryStack(categories[index]);
//                           // ref.invalidate(
//                           //   adListStateProvider(userId: widget.userId),
//                           // );
//                           categoryScrollOffsets.putIfAbsent(
//                               categories[index].title, () => 0);
//                         },
//                       ),
//                     );
//                   },
//                 );
//               },
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }

// class HomeSelectSubcategoryList extends ConsumerStatefulWidget {
//   const HomeSelectSubcategoryList({
//     super.key,
//     required this.userId,
//     required this.initScrollOffset,
//     required this.categoryName,
//     this.disposeCallback,
//     this.addNewSubcategoryCallback,
//   });

//   final int? userId;
//   final Function(double offset)? disposeCallback;
//   final Function(String)? addNewSubcategoryCallback;
//   final String categoryName;

//   final double initScrollOffset;

//   @override
//   ConsumerState<ConsumerStatefulWidget> createState() =>
//       _HomeSelectSubcategoryListState();
// }

// class _HomeSelectSubcategoryListState
//     extends ConsumerState<HomeSelectSubcategoryList> {
//   final scrollController = ScrollController();

//   @override
//   void initState() {
//     super.initState();
//     scrollController.addListener(() {
//       // Сохраняем позицию прокрутки
//       widget.disposeCallback!(scrollController.offset);
//     });
//   }

//   @override
//   Widget build(BuildContext context) {
//     WidgetsBinding.instance.addPostFrameCallback((_) {
//       if (scrollController.hasClients) {
//         scrollController.jumpTo(widget.initScrollOffset);
//       }
//     });
//     final state = ref.watch(
//       homeFiltersStateProvider(isProfile: widget.userId != null),
//     );

//     return Row(
//       children: [
//         SizedBox(
//           height: 40,
//           child: HomeRadioButton(
//             isSelected: true,
//             onTap: () {
//               ref
//                   .read(
//                     homeFiltersStateProvider(
//                       isProfile: widget.userId != null,
//                     ).notifier,
//                   )
//                   .popCategoryStack();
//               // ref.invalidate(
//               //   adListStateProvider(userId: widget.userId),
//               // );
//             },
//           ),
//         ),
//         const SizedBox(width: 10),
//         Expanded(
//           child: ListView.builder(
//             controller: scrollController,
//             scrollDirection: Axis.horizontal,
//             itemCount: state.categoryStack.last.children!.length,
//             itemBuilder: (BuildContext context, int index) {
//               return Padding(
//                 padding: const EdgeInsets.only(right: 10),
//                 child: HomeRadioButton(
//                   text: state.categoryStack.last.children![index].title,
//                   isSelected: false,
//                   onTap: () {
//                     ref
//                         .read(
//                           homeFiltersStateProvider(
//                             isProfile: widget.userId != null,
//                           ).notifier,
//                         )
//                         .addCategoryStack(
//                             state.categoryStack.last.children![index]);
//                     // ref.invalidate(
//                     //   adListStateProvider(userId: widget.userId),
//                     // );
//                     if (widget.addNewSubcategoryCallback != null) {
//                       widget.addNewSubcategoryCallback!(
//                           state.categoryStack.last.children![index].title);
//                     }
//                   },
//                 ),
//               );
//             },
//           ),
//         ),
//       ],
//     );
//   }
// }

// class SelectFilterButton extends ConsumerWidget {
//   const SelectFilterButton({super.key, required this.userId});
//   final int? userId;

//   @override
//   Widget build(BuildContext context, WidgetRef ref) {
//     final state =
//         ref.watch(homeFiltersStateProvider(isProfile: userId != null));
//     if (state.categoryStack.lastOrNull?.children?.isEmpty == true) {
//       return InkWell(
//         onTap: () {
//           debugPrint("AppIconsSvg.selectFilter tapped");
//           context.pushNamed(
//             MainAreaNavigationZone.chooseFilters.name,
//             extra: userId,
//           );
//         },
//         child: DecoratedBox(
//           decoration: BoxDecoration(
//             color: context.theme.canvasColor,
//             borderRadius: BorderRadius.circular(8),
//           ),
//           child: Padding(
//             padding: const EdgeInsets.only(top: 6, right: 4, left: 6),
//             child: SvgPicture.asset(
//               AppIconsSvg.selectFilter,
//               color: context.theme.iconTheme.color,
//             ),
//           ),
//         ),
//       );
//     }
//     return const SizedBox.shrink();
//   }
// }
