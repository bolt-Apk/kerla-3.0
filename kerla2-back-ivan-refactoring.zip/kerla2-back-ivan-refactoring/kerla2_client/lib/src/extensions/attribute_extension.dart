import 'package:kerla2_client/kerla2_client.dart';

extension AttributeExtension on Attribute {
  bool isEqual(Attribute otherAttribute) {
    return otherAttribute.id == id;
  }
}
