import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/core/core.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';

part 'service_state.g.dart';
part 'service_state.freezed.dart';

// @riverpod
// class ServiceState extends _$ServiceState {
//   @override
//   Future<List<KerlaServiceInfo>> build() async {
//     return await client.adManagement.getAdPromotionPrices();
//   }
// }

// @riverpod
// Future<List<KerlaServiceInfo>> serviceListState(Ref ref, {int? adId}) async {
//   return client.adManagement.getAdPromotionPrices(adId: adId);
// }

@riverpod
class ServiceListState extends _$ServiceListState {
  @override
  Future<ServiceStateModel> build(int? adId) async {
    if (adId == null) {
      return const ServiceStateModel(
        payableServices: [],
        freeServices: [],
        selectedServices: {},
      );
    }
    final services = await client.adManagement.getPayableServices(adId: adId);
    final freeServices = await client.adManagement.getFreeConnectableServices(
      adId: adId,
    );
    final selectedServices = <KerlaServiceInfo, int>{};

    //Для сторисов выбираем услугу сразу если она есть
    final allServices = [...services, ...freeServices];

    if (allServices.length == 1 &&
        allServices.first.type == KerlaServiceType.stories) {
      selectedServices.putIfAbsent(allServices.first, () => 1);
    }
    return ServiceStateModel(
      payableServices: services,
      freeServices: freeServices,
      selectedServices: selectedServices,
    );
  }

  void toggle(KerlaServiceInfo service) {
    final selectedItems =
        Map<KerlaServiceInfo, int>.from(state.value!.selectedServices);

    final isSelected = selectedItems.containsKey(service);

    if (isSelected) {
      selectedItems.remove(service);
    } else {
      selectedItems.putIfAbsent(service, () => 1);
    }

    state = AsyncData(state.value!.copyWith(selectedServices: selectedItems));
  }

  void updateDays(KerlaServiceInfo service, int days) {
    final selectedItems =
        Map<KerlaServiceInfo, int>.from(state.value!.selectedServices);

    if (selectedItems.containsKey(service)) {
      selectedItems[service] = days;
    } else {
      selectedItems.putIfAbsent(service, () => days);
    }

    state = AsyncData(state.value!.copyWith(selectedServices: selectedItems));
  }

  bool contains(KerlaServiceInfo service) {
    return state.value?.selectedServices.containsKey(service) ?? false;
  }

  List<KerlaService> getKerlaServices() {
    if (state.value == null) return [];

    final selectedItems = state.value!.selectedServices;
    final result = <KerlaService>[];

    for (final entry in selectedItems.entries) {
      final service = entry.key;
      final days = entry.value;
      final isFree = service.freeEndsAt != null;

      result.add(
        KerlaService(
          adId: adId,
          type: service.type,
          endsAt: isFree
              ? service.freeEndsAt!
              : DateTime.now().toUtc().add(Duration(days: days)),
          isFree: isFree,
          daysCount: days,
          price: service.cost,
        ),
      );
    }

    return result;
  }

  bool get allowFreeServices =>
      state.value?.selectedServices.isEmpty == true ||
      (state.value?.selectedServices.keys.any((element) => element.cost == 0) ??
          false);

  bool get allowPayableServices =>
      state.value?.selectedServices.isEmpty == true ||
      (state.value?.selectedServices.keys.any((element) => element.cost > 0) ??
          false);

  // Future<bool> saveServices() async {
  //   final result =
  //       await client.adManagement.upsertServicesTime(getKerlaServices(), adId);

  //   if (result) {
  //     ref.invalidate(getAdByIdProvider(adId));
  //   }
  //   return result;
  // }
}

@freezed
class ServiceStateModel with _$ServiceStateModel {
  const factory ServiceStateModel({
    required List<KerlaServiceInfo> payableServices,
    required List<KerlaServiceInfo> freeServices,
    @Default({}) Map<KerlaServiceInfo, int> selectedServices,
  }) = _ServiceStateModel;
}
