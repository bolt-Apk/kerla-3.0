part of '../ui_kit.dart';

class ThemeButtonStyle {
  final buttonStyle = ButtonStyle(
    textStyle: WidgetStateProperty.all<TextStyle?>(const TextStyle(
      color: ThemePrimaryColors.white,
      fontSize: 17,
    )),
    backgroundColor: WidgetStateProperty.resolveWith<Color>(
      (Set<WidgetState> states) {
        if (states.contains(WidgetState.pressed)) {
          return ThemePrimaryColors.primary;
        } else if (states.contains(WidgetState.disabled)) {
          return Colors.grey.shade300;
        }
        return ThemePrimaryColors.primary;
      },
    ),
    shape: WidgetStateProperty.all<RoundedRectangleBorder>(
      RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16.0),
      ),
    ),
    padding: ButtonStyleButton.allOrNull<EdgeInsetsGeometry>(
      const EdgeInsets.all(16),
    ),
    minimumSize: ButtonStyleButton.allOrNull<Size>(const Size.fromHeight(50)),
  );
}
