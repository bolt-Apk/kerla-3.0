import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerla2_flutter/router/navigation_zones/auth_navigation_zone.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_riverpod_notifications/nit_riverpod_notifications.dart';

import '../state/auth_mode_enum.dart';
import '../state/auth_page_state.dart';

class ProcessEmailButton extends ConsumerWidget {
  const ProcessEmailButton({
    super.key,
    required this.mode,
  });

  final AuthModeEnum mode;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return ConstrainedBox(
      constraints: const BoxConstraints(minWidth: 320),
      child: Button(
        title: switch (mode) {
          AuthModeEnum.registration => 'Зарегистрироваться',
          _ => 'Продолжить',
        },
        onPressed: () async {
          if (Form.of(context).validate() && context.mounted) {
            final userExist = await ref
                .read(authPageStateProvider.notifier)
                .processEmail(mode);
            if (userExist) {
              ref.read(authPageStateProvider.notifier).setPage(
                    //TODO: watch for this
                    switch (mode) {
                      AuthModeEnum.signIn ||
                      AuthModeEnum.registration =>
                        AuthAreaNavigationZone.signInPassword,
                      // AuthModeEnum.change =>
                      //   AuthAreaNavigationZone.changePassword,
                      AuthModeEnum.recover =>
                        AuthAreaNavigationZone.recoverCode,
                      _ => throw UnimplementedError(),
                    },
                  );
            } else {
              ref.notifyUser(
                NitNotification.error('Пользователь не найден'),
              );
            }
          }
        },
      ),
    );
  }
}
