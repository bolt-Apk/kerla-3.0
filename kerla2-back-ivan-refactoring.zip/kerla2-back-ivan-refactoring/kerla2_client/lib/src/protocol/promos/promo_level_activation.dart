/* AUTOMATICALLY GENERATED CODE DO NOT MODIFY */
/*   To generate run: "serverpod generate"    */

// ignore_for_file: implementation_imports
// ignore_for_file: library_private_types_in_public_api
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: public_member_api_docs
// ignore_for_file: type_literal_in_constant_pattern
// ignore_for_file: use_super_parameters

// ignore_for_file: no_leading_underscores_for_library_prefixes
import 'package:serverpod_client/serverpod_client.dart' as _i1;

/// Promocode level activation
abstract class PromoLevelActivation implements _i1.SerializableModel {
  PromoLevelActivation._({
    this.id,
    required this.userId,
    required this.promoLevelId,
    required this.activationDate,
  });

  factory PromoLevelActivation({
    int? id,
    required int userId,
    required int promoLevelId,
    required DateTime activationDate,
  }) = _PromoLevelActivationImpl;

  factory PromoLevelActivation.fromJson(
      Map<String, dynamic> jsonSerialization) {
    return PromoLevelActivation(
      id: jsonSerialization['id'] as int?,
      userId: jsonSerialization['userId'] as int,
      promoLevelId: jsonSerialization['promoLevelId'] as int,
      activationDate: _i1.DateTimeJsonExtension.fromJson(
          jsonSerialization['activationDate']),
    );
  }

  /// The database id, set if the object has been inserted into the
  /// database or if it has been fetched from the database. Otherwise,
  /// the id will be null.
  int? id;

  int userId;

  int promoLevelId;

  DateTime activationDate;

  PromoLevelActivation copyWith({
    int? id,
    int? userId,
    int? promoLevelId,
    DateTime? activationDate,
  });
  @override
  Map<String, dynamic> toJson() {
    return {
      if (id != null) 'id': id,
      'userId': userId,
      'promoLevelId': promoLevelId,
      'activationDate': activationDate.toJson(),
    };
  }

  @override
  String toString() {
    return _i1.SerializationManager.encode(this);
  }
}

class _Undefined {}

class _PromoLevelActivationImpl extends PromoLevelActivation {
  _PromoLevelActivationImpl({
    int? id,
    required int userId,
    required int promoLevelId,
    required DateTime activationDate,
  }) : super._(
          id: id,
          userId: userId,
          promoLevelId: promoLevelId,
          activationDate: activationDate,
        );

  @override
  PromoLevelActivation copyWith({
    Object? id = _Undefined,
    int? userId,
    int? promoLevelId,
    DateTime? activationDate,
  }) {
    return PromoLevelActivation(
      id: id is int? ? id : this.id,
      userId: userId ?? this.userId,
      promoLevelId: promoLevelId ?? this.promoLevelId,
      activationDate: activationDate ?? this.activationDate,
    );
  }
}
