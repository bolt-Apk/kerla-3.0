import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerla2_flutter/common/user_profile_extension.dart';
import 'package:kerla2_flutter/common/user_profile_ref_extensions.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class LastTimeOnlineInfo extends ConsumerWidget {
  const LastTimeOnlineInfo({
    super.key,
    required this.userId,
    required this.style,
  });

  final int userId;
  final TextStyle? style;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return ref.watchUserProfileCustom(userId).nitWhen(
          childBuilder: (userProfile) => Text(
            userProfile.lastTimeOnlineString,
            style: style,
          ),
        );
  }
}
