#import <Foundation/Foundation.h>
#import "PMConvertProtocol.h"

@interface PMConverter : NSObject <PMConvertProtocol>

@end
