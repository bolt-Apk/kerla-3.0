// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'stories_state.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$userStoriesHash() => r'55cca213855bce42e4ceed2a38162e293c33c5b4';

/// Copied from Dart SDK
class _SystemHash {
  _SystemHash._();

  static int combine(int hash, int value) {
    // ignore: parameter_assignments
    hash = 0x1fffffff & (hash + value);
    // ignore: parameter_assignments
    hash = 0x1fffffff & (hash + ((0x0007ffff & hash) << 10));
    return hash ^ (hash >> 6);
  }

  static int finish(int hash) {
    // ignore: parameter_assignments
    hash = 0x1fffffff & (hash + ((0x03ffffff & hash) << 3));
    // ignore: parameter_assignments
    hash = hash ^ (hash >> 11);
    return 0x1fffffff & (hash + ((0x00003fff & hash) << 15));
  }
}

/// See also [userStories].
@ProviderFor(userStories)
const userStoriesProvider = UserStoriesFamily();

/// See also [userStories].
class UserStoriesFamily extends Family<AsyncValue<List<Ad>>> {
  /// See also [userStories].
  const UserStoriesFamily();

  /// See also [userStories].
  UserStoriesProvider call(
    int userId,
  ) {
    return UserStoriesProvider(
      userId,
    );
  }

  @override
  UserStoriesProvider getProviderOverride(
    covariant UserStoriesProvider provider,
  ) {
    return call(
      provider.userId,
    );
  }

  static const Iterable<ProviderOrFamily>? _dependencies = null;

  @override
  Iterable<ProviderOrFamily>? get dependencies => _dependencies;

  static const Iterable<ProviderOrFamily>? _allTransitiveDependencies = null;

  @override
  Iterable<ProviderOrFamily>? get allTransitiveDependencies =>
      _allTransitiveDependencies;

  @override
  String? get name => r'userStoriesProvider';
}

/// See also [userStories].
class UserStoriesProvider extends AutoDisposeFutureProvider<List<Ad>> {
  /// See also [userStories].
  UserStoriesProvider(
    int userId,
  ) : this._internal(
          (ref) => userStories(
            ref as UserStoriesRef,
            userId,
          ),
          from: userStoriesProvider,
          name: r'userStoriesProvider',
          debugGetCreateSourceHash:
              const bool.fromEnvironment('dart.vm.product')
                  ? null
                  : _$userStoriesHash,
          dependencies: UserStoriesFamily._dependencies,
          allTransitiveDependencies:
              UserStoriesFamily._allTransitiveDependencies,
          userId: userId,
        );

  UserStoriesProvider._internal(
    super._createNotifier, {
    required super.name,
    required super.dependencies,
    required super.allTransitiveDependencies,
    required super.debugGetCreateSourceHash,
    required super.from,
    required this.userId,
  }) : super.internal();

  final int userId;

  @override
  Override overrideWith(
    FutureOr<List<Ad>> Function(UserStoriesRef provider) create,
  ) {
    return ProviderOverride(
      origin: this,
      override: UserStoriesProvider._internal(
        (ref) => create(ref as UserStoriesRef),
        from: from,
        name: null,
        dependencies: null,
        allTransitiveDependencies: null,
        debugGetCreateSourceHash: null,
        userId: userId,
      ),
    );
  }

  @override
  AutoDisposeFutureProviderElement<List<Ad>> createElement() {
    return _UserStoriesProviderElement(this);
  }

  @override
  bool operator ==(Object other) {
    return other is UserStoriesProvider && other.userId == userId;
  }

  @override
  int get hashCode {
    var hash = _SystemHash.combine(0, runtimeType.hashCode);
    hash = _SystemHash.combine(hash, userId.hashCode);

    return _SystemHash.finish(hash);
  }
}

mixin UserStoriesRef on AutoDisposeFutureProviderRef<List<Ad>> {
  /// The parameter `userId` of this provider.
  int get userId;
}

class _UserStoriesProviderElement
    extends AutoDisposeFutureProviderElement<List<Ad>> with UserStoriesRef {
  _UserStoriesProviderElement(super.provider);

  @override
  int get userId => (origin as UserStoriesProvider).userId;
}
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
