import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerla2_flutter/app_buffer/profile/profile_settings/widgets/edit_username_button.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';

import '../../profile_image/profile_image.dart';

class EditAvatarWidget extends ConsumerWidget {
  const EditAvatarWidget({
    super.key,
    required this.userId,
  });

  final int userId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return MainInfoWidget(
      imageWidget: ProfileImage.editable(
        userId: userId,
      ),
      infoWidget: Padding(
        padding: const EdgeInsets.only(left: 8),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(bottom: 3, top: 6),
              child: Text(
                'Имя пользователя',
                style: Theme.of(context).textTheme.displayLarge,
              ),
            ),
            EditUsernameButton(
              userId: userId,
            ),
          ],
        ),
      ),
    );
  }
}
