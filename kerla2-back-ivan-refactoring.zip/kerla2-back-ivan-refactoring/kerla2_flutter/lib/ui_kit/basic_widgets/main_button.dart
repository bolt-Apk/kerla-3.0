part of '../ui_kit.dart';

class MainButton extends StatelessWidget {
  const MainButton({
    super.key,
    required this.buttonText,
    required this.onTap,
    this.boxHeight,
    this.boxWidth,
    this.fontSize,
    this.isLoading = false,
  });

  final String buttonText;
  // final Color color;
  final VoidCallback onTap;
  final bool isLoading;
  final double? boxHeight;
  final double? boxWidth;
  final double? fontSize;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: boxHeight ?? 55,
      width: boxWidth,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
            backgroundColor: ThemePrimaryColors.primary,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(5),
            ),
            padding: const EdgeInsets.symmetric(vertical: 10)),
        // color: isLoading ? null : color,
        // borderRadius: BorderRadius.circular(5),
        onPressed: isLoading ? null : onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Center(
            child: isLoading
                ? const CircularProgressIndicator()
                : Text(
                    buttonText,
                    style: context.textTheme.displayLarge?.copyWith(
                      fontSize: fontSize ?? 20,
                      color: ThemePrimaryColors.white,
                    ),
                  ),
          ),
        ),
      ),
    );
  }
}

class Button extends StatelessWidget {
  final String? title;
  final Widget? child;
  final VoidCallback? onPressed;
  final bool isOutlined;
  final bool isFilled;
  final bool isError;
  final bool isSecondary;
  final IconData? icon;
  final bool enabled;
  final bool isTertiary;

  const Button({
    super.key,
    this.title,
    this.child,
    this.onPressed,
    this.icon,
    this.enabled = true,
  })  : isOutlined = false,
        isFilled = true,
        isError = false,
        isSecondary = false,
        isTertiary = false,
        assert(title != null || child != null);

  const Button.outlined({
    super.key,
    this.title,
    this.child,
    this.onPressed,
    this.icon,
    this.enabled = true,
  })  : isOutlined = true,
        isFilled = false,
        isError = false,
        isSecondary = false,
        isTertiary = false,
        assert(title != null || child != null);

  const Button.text({
    super.key,
    this.title,
    this.child,
    this.onPressed,
    this.icon,
    this.enabled = true,
  })  : isOutlined = false,
        isFilled = false,
        isError = false,
        isSecondary = false,
        isTertiary = false,
        assert(title != null || child != null);

  const Button.textError({
    super.key,
    this.title,
    this.child,
    this.onPressed,
    this.icon,
    this.enabled = true,
  })  : isOutlined = false,
        isFilled = false,
        isSecondary = false,
        isTertiary = false,
        isError = true;

  const Button.secondary({
    super.key,
    this.title,
    this.child,
    this.onPressed,
    this.icon,
    this.enabled = true,
  })  : isOutlined = false,
        isFilled = true,
        isSecondary = true,
        isTertiary = false,
        isError = false;

  const Button.tertiary({
    super.key,
    this.title,
    this.child,
    this.onPressed,
    this.icon,
    this.enabled = true,
  })  : isOutlined = false,
        isFilled = true,
        isSecondary = false,
        isTertiary = true,
        isError = false;

  @override
  Widget build(BuildContext context) {
    late final Color onButtonColor;
    if (isFilled) {
      if (isSecondary) {
        onButtonColor = context.colorScheme.onSecondaryContainer;
      } else if (isTertiary) {
        onButtonColor = context.colorScheme.onTertiaryFixed;
      } else {
        onButtonColor = context.colorScheme.onPrimary;
      }
    } else {
      if (isError) {
        onButtonColor = context.colorScheme.error;
      } else {
        onButtonColor = context.colorScheme.primary;
      }
    }
    late final Color buttonColor;
    if (isFilled) {
      if (isSecondary) {
        buttonColor = context.colorScheme.secondaryContainer;
      } else if (isTertiary) {
        buttonColor = context.colorScheme.tertiaryFixed;
      } else {
        buttonColor = context.colorScheme.primary;
      }
    } else {
      if (isError) {
        buttonColor = context.colorScheme.error;
      } else {
        buttonColor = Colors.transparent;
      }
    }
    final buttonChild = child ??
        Padding(
          padding: (isOutlined || isFilled)
              ? const EdgeInsets.symmetric(vertical: 10.0)
              : EdgeInsets.zero,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (icon != null) Icon(icon, color: onButtonColor),
              SizedBox(width: icon != null ? 3.0 : 0.0),
              Text(
                title!,
                style: context.textTheme.labelLarge!
                    .copyWith(color: onButtonColor),
              ),
            ],
          ),
        );

    final shape = RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(100.0),
    );
    if (isFilled) {
      return FilledButton(
        style: FilledButton.styleFrom(
          shape: shape,
          backgroundColor: buttonColor,
          foregroundColor:
              isSecondary ? context.colorScheme.onSecondaryContainer : null,
        ),
        onPressed: enabled ? onPressed : null,
        child: buttonChild,
      );
    } else if (isOutlined) {
      return OutlinedButton(
        style: OutlinedButton.styleFrom(
          side: BorderSide(
            color: context.colorScheme.primary,
            // width: 2.0,
          ),
          shape: shape,
        ),
        onPressed: enabled ? onPressed : null,
        child: buttonChild,
      );
    } else {
      return TextButton(
        onPressed: enabled ? onPressed : null,
        child: buttonChild,
      );
    }
  }
}
