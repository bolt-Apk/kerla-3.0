import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/core/core.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';

part 'promo_level_state.freezed.dart';
part 'promo_level_state.g.dart';

@riverpod
class PromoLevelState extends _$PromoLevelState {
  @override
  Future<PromoLevelModel> build() async {
    final nextPromoLevel = await client.promocode.getNextPromocodeLevel();
    final currentPromoLevel = await client.promocode.getCurrentPromocodeLevel();
    final countInvites = await client.promocode.getInvitesCount();
    return PromoLevelModel(
      currentPromoLevel: currentPromoLevel,
      nextPromoLevel: nextPromoLevel,
      countInvites: countInvites,
      isLastLevel: nextPromoLevel == null,
      countToNewLevel: nextPromoLevel == null
          ? -1
          : nextPromoLevel.requiredInvites - countInvites,
    );
  }

  bool get isAvailableNewLevel =>
      state.value!.countInvites >= state.value!.nextPromoLevel!.requiredInvites;

  Future<String?> getNewLevel() async {
    try {
      if (isAvailableNewLevel) {
        final nextPromoLevel = await client.promocode.acceptNewLevelBonus();
        return nextPromoLevel;
      }
    } catch (e) {
      return e.toString();
    }
    return null;
  }
}

@freezed
class PromoLevelModel with _$PromoLevelModel {
  const factory PromoLevelModel({
    required PromoLevel? currentPromoLevel,
    required PromoLevel? nextPromoLevel,
    required int countInvites,
    required int countToNewLevel,
    @Default(false) bool isAvailableNewLevel,
    @Default(false) bool isLastLevel,
  }) = _PromoLevelModel;
}
