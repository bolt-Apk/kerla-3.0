import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kerla2_flutter/app_buffer/ads/service/state/service_state.dart';
import 'package:kerla2_flutter/app_buffer/ads/service/widget/connect_services.dart';
import 'package:kerla2_flutter/app_buffer/ads/service/widget/service_row.dart';
import 'package:kerla2_flutter/core/app_scaffold.dart';
import 'package:kerla2_flutter/router/router.dart';
import 'package:nit_app/nit_app.dart';
import 'package:nit_router/nit_router.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class ConfirmStoryPage extends HookConsumerWidget {
  const ConfirmStoryPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final int adId = ref.watchNavigationParam(AppNavigationParams.adId)!;

    return AppScaffold(
      showBottomNavBar: false,
      backgroundColor: context.theme.scaffoldBackgroundColor,
      appBar: AppBar(
        automaticallyImplyLeading: false,
        elevation: 0,
        backgroundColor: context.theme.canvasColor,
        leading: IconButton(
          icon: Icon(
            Icons.close,
            color: context.theme.iconTheme.color,
          ),
          onPressed: () {
            context.goNamed(MainAreaNavigationZone.homePage.name);
          },
        ),
        title: Text(
          "Публикация истории",
          style: TextStyle(color: context.theme.iconTheme.color, fontSize: 17),
        ),
      ),
      body: ref.watch(serviceListStateProvider(adId)).nitWhen(
            errorWidget: const Text('Не удалось загрузить услуги'),
            loadingValue: NitDefaultModelsRepository.get<ServiceStateModel>(),
            childBuilder: (state) {
              return Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    ...state.freeServices
                        .map((service) => ServiceRow.notToggleable(
                              serviceInfo: service,
                              adId: adId,
                            )),
                    const Gap(20),
                    ...state.payableServices
                        .map((service) => ServiceRow.notToggleable(
                              serviceInfo: service,
                              adId: adId,
                            )),
                    ConnectService(
                      connectServiceType: ConnectServiceType.createStory,
                      adId: adId,
                    ),
                  ],
                ),
              );
            },
          ),
    );
  }
}
