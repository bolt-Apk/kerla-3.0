enum ShareType {
  ad,
  profile,
  story,
}

const String _link = "https://appkerla.github.io";

extension ShareTypeExtension on ShareType {
  String getShareLink(int shareId) {
    switch (this) {
      case ShareType.ad:
        return 'Смотри объявление в приложении КЕРЛА: $_link/ad/$shareId';
      case ShareType.profile:
        return '$_link/profile/$shareId';
      case ShareType.story:
        return 'Смотри объявление в приложении КЕРЛА: $_link/stories/$shareId';
    }
  }
}
