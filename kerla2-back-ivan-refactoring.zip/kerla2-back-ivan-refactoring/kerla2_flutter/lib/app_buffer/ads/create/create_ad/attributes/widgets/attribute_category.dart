import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/app_buffer/ads/create/state/ad_create_state.dart';
import 'package:kerla2_flutter/router/router.dart';
import 'package:nit_router/nit_router.dart';

class AttributeCategory extends ConsumerWidget {
  const AttributeCategory({
    super.key,
    this.title,
    // this.adId,
    this.onCategorySave,
  });

  final String? title;
  // final int? adId;
  final Function(AdCategory)? onCategorySave;
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final int? adId = ref.watchNavigationParam(AppNavigationParams.adId);
    final state = ref.read(createAdStateProvider(AdType.ad, adId: adId));
    // final editCategory = ref.watch(
    //   adEditStateProvider(adId: adId)
    //       .select((value) => value.value?.ad?.category?.title),
    // );

    final String? subCategoryText = state.category?.title;

    void onTap() {
      if (adId != null) {
        context.pushNamed(
          AdNavigationZone.chooseCategoryEditAd.name,
          pathParameters: AppNavigationParams.adId.set(adId),
        );
      } else {
        ref
            .read(createAdStateProvider(AdType.ad, adId: adId).notifier)
            .setCategory(null);
        Navigator.pop(context);
      }
    }

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Align(
            alignment: Alignment.centerLeft,
            child: Text(title ?? "",
                style: Theme.of(context).textTheme.titleLarge),
          ),
        ),
        if (adId == null)
          Container(
            height: 40,
            width: double.infinity,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(10),
            ),
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                if (state.category?.title != null)
                  Text(
                    state.category!.title,
                  ),
                GestureDetector(
                  onTap: () {
                    () => ref
                        .read(createAdStateProvider(AdType.ad, adId: adId)
                            .notifier)
                        .setCategory(null);
                    Navigator.pop(context);
                  },
                  child: const Icon(
                    Icons.clear,
                  ),
                ),
              ],
            ),
          ),
        const SizedBox(height: 10),
        Container(
          height: 40,
          width: double.infinity,
          decoration: BoxDecoration(
            color: Theme.of(context).canvasColor,
            borderRadius: BorderRadius.circular(10),
          ),
          padding: const EdgeInsets.symmetric(horizontal: 8),
          child: Align(
            alignment: Alignment.centerLeft,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                if (subCategoryText != null)
                  Text(
                    subCategoryText,
                  ),
                if (adId == null)
                  GestureDetector(
                    onTap: () => onTap(),
                    child: const Icon(
                      Icons.clear,
                    ),
                  ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 10),
      ],
    );
  }
}
