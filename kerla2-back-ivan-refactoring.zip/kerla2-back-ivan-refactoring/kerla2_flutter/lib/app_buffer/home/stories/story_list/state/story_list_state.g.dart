// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'story_list_state.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$storyListStateHash() => r'560e745cb3a163741718e701378b1af406e74289';

/// See also [StoryListState].
@ProviderFor(StoryListState)
final storyListStateProvider =
    AsyncNotifierProvider<StoryListState, List<UserProfile>>.internal(
  StoryListState.new,
  name: r'storyListStateProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$storyListStateHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$StoryListState = AsyncNotifier<List<UserProfile>>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
