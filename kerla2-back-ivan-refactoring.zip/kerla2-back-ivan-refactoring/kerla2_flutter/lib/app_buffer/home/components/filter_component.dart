import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/app_buffer/home/filters/list_filter/list_filter_widget.dart';

class FilterComponent extends HookWidget {
  const FilterComponent({
    super.key,
    required this.showFilters,
  });

  final bool showFilters;

  @override
  Widget build(BuildContext context) {
    final controller = useAnimationController(
      duration: const Duration(milliseconds: 200),
    );

    final animation = useMemoized(
      () => Tween<double>(begin: 0, end: 1).animate(
        CurvedAnimation(
          parent: controller,
          curve: Curves.easeInOut,
        ),
      ),
      [controller],
    );

    useEffect(() {
      if (showFilters) {
        controller.forward();
      } else {
        controller.reverse();
      }
      return null;
    }, [showFilters]);

    return AnimatedBuilder(
      animation: animation,
      builder: (context, child) {
        return Transform.translate(
          offset: Offset(0, (1 - animation.value) * -48),
          child: Opacity(
            opacity: animation.value,
            child: child,
          ),
        );
      },
      child: Container(
        height: 48,
        color: Theme.of(context).canvasColor,
        child: const Center(
          child: Padding(
            padding: EdgeInsets.only(left: 8, bottom: 4, top: 4),
            child: ListFilterWidget(adListType: AdListType.main),
          ),
        ),
      ),
    );
  }
}
