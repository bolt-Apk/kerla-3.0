/* AUTOMATICALLY GENERATED CODE DO NOT MODIFY */
/*   To generate run: "serverpod generate"    */

// ignore_for_file: implementation_imports
// ignore_for_file: library_private_types_in_public_api
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: public_member_api_docs
// ignore_for_file: type_literal_in_constant_pattern
// ignore_for_file: use_super_parameters

// ignore_for_file: no_leading_underscores_for_library_prefixes
import 'package:serverpod_client/serverpod_client.dart' as _i1;
import '../protocol.dart' as _i2;

abstract class AdAttributeValue implements _i1.SerializableModel {
  AdAttributeValue._({
    this.id,
    required this.attributeId,
    this.attribute,
    this.subAttributeId,
    required this.value,
  });

  factory AdAttributeValue({
    int? id,
    required int attributeId,
    _i2.Attribute? attribute,
    int? subAttributeId,
    required String value,
  }) = _AdAttributeValueImpl;

  factory AdAttributeValue.fromJson(Map<String, dynamic> jsonSerialization) {
    return AdAttributeValue(
      id: jsonSerialization['id'] as int?,
      attributeId: jsonSerialization['attributeId'] as int,
      attribute: jsonSerialization['attribute'] == null
          ? null
          : _i2.Attribute.fromJson(
              (jsonSerialization['attribute'] as Map<String, dynamic>)),
      subAttributeId: jsonSerialization['subAttributeId'] as int?,
      value: jsonSerialization['value'] as String,
    );
  }

  /// The database id, set if the object has been inserted into the
  /// database or if it has been fetched from the database. Otherwise,
  /// the id will be null.
  int? id;

  int attributeId;

  _i2.Attribute? attribute;

  int? subAttributeId;

  String value;

  AdAttributeValue copyWith({
    int? id,
    int? attributeId,
    _i2.Attribute? attribute,
    int? subAttributeId,
    String? value,
  });
  @override
  Map<String, dynamic> toJson() {
    return {
      if (id != null) 'id': id,
      'attributeId': attributeId,
      if (attribute != null) 'attribute': attribute?.toJson(),
      if (subAttributeId != null) 'subAttributeId': subAttributeId,
      'value': value,
    };
  }

  @override
  String toString() {
    return _i1.SerializationManager.encode(this);
  }
}

class _Undefined {}

class _AdAttributeValueImpl extends AdAttributeValue {
  _AdAttributeValueImpl({
    int? id,
    required int attributeId,
    _i2.Attribute? attribute,
    int? subAttributeId,
    required String value,
  }) : super._(
          id: id,
          attributeId: attributeId,
          attribute: attribute,
          subAttributeId: subAttributeId,
          value: value,
        );

  @override
  AdAttributeValue copyWith({
    Object? id = _Undefined,
    int? attributeId,
    Object? attribute = _Undefined,
    Object? subAttributeId = _Undefined,
    String? value,
  }) {
    return AdAttributeValue(
      id: id is int? ? id : this.id,
      attributeId: attributeId ?? this.attributeId,
      attribute:
          attribute is _i2.Attribute? ? attribute : this.attribute?.copyWith(),
      subAttributeId:
          subAttributeId is int? ? subAttributeId : this.subAttributeId,
      value: value ?? this.value,
    );
  }
}
