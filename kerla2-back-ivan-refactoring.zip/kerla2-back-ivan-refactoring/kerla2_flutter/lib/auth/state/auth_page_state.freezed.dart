// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'auth_page_state.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$AuthPageStateModel {
  TextEditingController get emailController =>
      throw _privateConstructorUsedError;
  TextEditingController get passwordController =>
      throw _privateConstructorUsedError;
  TextEditingController get confirmPasswordController =>
      throw _privateConstructorUsedError;
  TextEditingController get codeController =>
      throw _privateConstructorUsedError;
  TextEditingController get usernameController =>
      throw _privateConstructorUsedError;
  AuthAreaNavigationZone get currentPart => throw _privateConstructorUsedError;
  AuthAreaNavigationZone? get pastPart => throw _privateConstructorUsedError;
  ValueNotifier<UserGender?> get genderNotifier =>
      throw _privateConstructorUsedError;

  /// Create a copy of AuthPageStateModel
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $AuthPageStateModelCopyWith<AuthPageStateModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $AuthPageStateModelCopyWith<$Res> {
  factory $AuthPageStateModelCopyWith(
          AuthPageStateModel value, $Res Function(AuthPageStateModel) then) =
      _$AuthPageStateModelCopyWithImpl<$Res, AuthPageStateModel>;
  @useResult
  $Res call(
      {TextEditingController emailController,
      TextEditingController passwordController,
      TextEditingController confirmPasswordController,
      TextEditingController codeController,
      TextEditingController usernameController,
      AuthAreaNavigationZone currentPart,
      AuthAreaNavigationZone? pastPart,
      ValueNotifier<UserGender?> genderNotifier});
}

/// @nodoc
class _$AuthPageStateModelCopyWithImpl<$Res, $Val extends AuthPageStateModel>
    implements $AuthPageStateModelCopyWith<$Res> {
  _$AuthPageStateModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of AuthPageStateModel
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? emailController = null,
    Object? passwordController = null,
    Object? confirmPasswordController = null,
    Object? codeController = null,
    Object? usernameController = null,
    Object? currentPart = null,
    Object? pastPart = freezed,
    Object? genderNotifier = null,
  }) {
    return _then(_value.copyWith(
      emailController: null == emailController
          ? _value.emailController
          : emailController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      passwordController: null == passwordController
          ? _value.passwordController
          : passwordController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      confirmPasswordController: null == confirmPasswordController
          ? _value.confirmPasswordController
          : confirmPasswordController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      codeController: null == codeController
          ? _value.codeController
          : codeController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      usernameController: null == usernameController
          ? _value.usernameController
          : usernameController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      currentPart: null == currentPart
          ? _value.currentPart
          : currentPart // ignore: cast_nullable_to_non_nullable
              as AuthAreaNavigationZone,
      pastPart: freezed == pastPart
          ? _value.pastPart
          : pastPart // ignore: cast_nullable_to_non_nullable
              as AuthAreaNavigationZone?,
      genderNotifier: null == genderNotifier
          ? _value.genderNotifier
          : genderNotifier // ignore: cast_nullable_to_non_nullable
              as ValueNotifier<UserGender?>,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$AuthPageStateModelImplCopyWith<$Res>
    implements $AuthPageStateModelCopyWith<$Res> {
  factory _$$AuthPageStateModelImplCopyWith(_$AuthPageStateModelImpl value,
          $Res Function(_$AuthPageStateModelImpl) then) =
      __$$AuthPageStateModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {TextEditingController emailController,
      TextEditingController passwordController,
      TextEditingController confirmPasswordController,
      TextEditingController codeController,
      TextEditingController usernameController,
      AuthAreaNavigationZone currentPart,
      AuthAreaNavigationZone? pastPart,
      ValueNotifier<UserGender?> genderNotifier});
}

/// @nodoc
class __$$AuthPageStateModelImplCopyWithImpl<$Res>
    extends _$AuthPageStateModelCopyWithImpl<$Res, _$AuthPageStateModelImpl>
    implements _$$AuthPageStateModelImplCopyWith<$Res> {
  __$$AuthPageStateModelImplCopyWithImpl(_$AuthPageStateModelImpl _value,
      $Res Function(_$AuthPageStateModelImpl) _then)
      : super(_value, _then);

  /// Create a copy of AuthPageStateModel
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? emailController = null,
    Object? passwordController = null,
    Object? confirmPasswordController = null,
    Object? codeController = null,
    Object? usernameController = null,
    Object? currentPart = null,
    Object? pastPart = freezed,
    Object? genderNotifier = null,
  }) {
    return _then(_$AuthPageStateModelImpl(
      emailController: null == emailController
          ? _value.emailController
          : emailController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      passwordController: null == passwordController
          ? _value.passwordController
          : passwordController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      confirmPasswordController: null == confirmPasswordController
          ? _value.confirmPasswordController
          : confirmPasswordController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      codeController: null == codeController
          ? _value.codeController
          : codeController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      usernameController: null == usernameController
          ? _value.usernameController
          : usernameController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      currentPart: null == currentPart
          ? _value.currentPart
          : currentPart // ignore: cast_nullable_to_non_nullable
              as AuthAreaNavigationZone,
      pastPart: freezed == pastPart
          ? _value.pastPart
          : pastPart // ignore: cast_nullable_to_non_nullable
              as AuthAreaNavigationZone?,
      genderNotifier: null == genderNotifier
          ? _value.genderNotifier
          : genderNotifier // ignore: cast_nullable_to_non_nullable
              as ValueNotifier<UserGender?>,
    ));
  }
}

/// @nodoc

class _$AuthPageStateModelImpl
    with DiagnosticableTreeMixin
    implements _AuthPageStateModel {
  _$AuthPageStateModelImpl(
      {required this.emailController,
      required this.passwordController,
      required this.confirmPasswordController,
      required this.codeController,
      required this.usernameController,
      required this.currentPart,
      required this.pastPart,
      required this.genderNotifier});

  @override
  final TextEditingController emailController;
  @override
  final TextEditingController passwordController;
  @override
  final TextEditingController confirmPasswordController;
  @override
  final TextEditingController codeController;
  @override
  final TextEditingController usernameController;
  @override
  final AuthAreaNavigationZone currentPart;
  @override
  final AuthAreaNavigationZone? pastPart;
  @override
  final ValueNotifier<UserGender?> genderNotifier;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'AuthPageStateModel(emailController: $emailController, passwordController: $passwordController, confirmPasswordController: $confirmPasswordController, codeController: $codeController, usernameController: $usernameController, currentPart: $currentPart, pastPart: $pastPart, genderNotifier: $genderNotifier)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(DiagnosticsProperty('type', 'AuthPageStateModel'))
      ..add(DiagnosticsProperty('emailController', emailController))
      ..add(DiagnosticsProperty('passwordController', passwordController))
      ..add(DiagnosticsProperty(
          'confirmPasswordController', confirmPasswordController))
      ..add(DiagnosticsProperty('codeController', codeController))
      ..add(DiagnosticsProperty('usernameController', usernameController))
      ..add(DiagnosticsProperty('currentPart', currentPart))
      ..add(DiagnosticsProperty('pastPart', pastPart))
      ..add(DiagnosticsProperty('genderNotifier', genderNotifier));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$AuthPageStateModelImpl &&
            (identical(other.emailController, emailController) ||
                other.emailController == emailController) &&
            (identical(other.passwordController, passwordController) ||
                other.passwordController == passwordController) &&
            (identical(other.confirmPasswordController,
                    confirmPasswordController) ||
                other.confirmPasswordController == confirmPasswordController) &&
            (identical(other.codeController, codeController) ||
                other.codeController == codeController) &&
            (identical(other.usernameController, usernameController) ||
                other.usernameController == usernameController) &&
            (identical(other.currentPart, currentPart) ||
                other.currentPart == currentPart) &&
            (identical(other.pastPart, pastPart) ||
                other.pastPart == pastPart) &&
            (identical(other.genderNotifier, genderNotifier) ||
                other.genderNotifier == genderNotifier));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      emailController,
      passwordController,
      confirmPasswordController,
      codeController,
      usernameController,
      currentPart,
      pastPart,
      genderNotifier);

  /// Create a copy of AuthPageStateModel
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$AuthPageStateModelImplCopyWith<_$AuthPageStateModelImpl> get copyWith =>
      __$$AuthPageStateModelImplCopyWithImpl<_$AuthPageStateModelImpl>(
          this, _$identity);
}

abstract class _AuthPageStateModel implements AuthPageStateModel {
  factory _AuthPageStateModel(
          {required final TextEditingController emailController,
          required final TextEditingController passwordController,
          required final TextEditingController confirmPasswordController,
          required final TextEditingController codeController,
          required final TextEditingController usernameController,
          required final AuthAreaNavigationZone currentPart,
          required final AuthAreaNavigationZone? pastPart,
          required final ValueNotifier<UserGender?> genderNotifier}) =
      _$AuthPageStateModelImpl;

  @override
  TextEditingController get emailController;
  @override
  TextEditingController get passwordController;
  @override
  TextEditingController get confirmPasswordController;
  @override
  TextEditingController get codeController;
  @override
  TextEditingController get usernameController;
  @override
  AuthAreaNavigationZone get currentPart;
  @override
  AuthAreaNavigationZone? get pastPart;
  @override
  ValueNotifier<UserGender?> get genderNotifier;

  /// Create a copy of AuthPageStateModel
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$AuthPageStateModelImplCopyWith<_$AuthPageStateModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
