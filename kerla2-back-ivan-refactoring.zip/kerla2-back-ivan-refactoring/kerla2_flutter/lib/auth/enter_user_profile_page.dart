import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/auth/state/auth_page_state.dart';
import 'package:kerla2_flutter/auth/widgets/auth_header_widget.dart';
import 'package:kerla2_flutter/router/navigation_zones/auth_navigation_zone.dart';
import 'package:nit_riverpod_notifications/nit_riverpod_notifications.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';
import '../ui_kit/ui_kit.dart';
import 'state/auth_mode_enum.dart';
import 'widgets/gender_button.dart';

class EnterUserProfilePage extends HookConsumerWidget {
  const EnterUserProfilePage({
    super.key,
    required this.mode,
  });

  final AuthModeEnum mode;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(authPageStateProvider);
    final formKey = GlobalKey<FormState>();

    return Form(
      key: formKey,
      child: Column(
        children: [
          AuthHeaderWidget(
            mode: mode,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: TextEntryField(
              controller: state.usernameController,
              validator: (value) {
                //TODO: add here length validation
                if (value == null || value.isEmpty) {
                  return 'Поле не может быть пустым';
                }
                return null;
              },
              label: 'Имя пользователя',
            ),
          ),
          ValueListenableBuilder(
            valueListenable: state.genderNotifier,
            builder: (BuildContext context, UserGender? value, Widget? child) {
              return Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Expanded(
                    child: GenderButton(
                      userGenderNotifier: state.genderNotifier,
                      typeButton: UserGender.male,
                    ),
                  ),
                  const SizedBox(width: 15),
                  Expanded(
                    child: GenderButton(
                      userGenderNotifier: state.genderNotifier,
                      typeButton: UserGender.female,
                    ),
                  ),
                ],
              );
            },
          ),
          const Gap(8),
          Button(
            title: 'Продолжить',
            onPressed: () async {
              if (formKey.currentState!.validate()) {
                if (state.genderNotifier.value == null) {
                  //TODO: show validation error
                  return;
                }
                if (await ref
                    .read(authPageStateProvider.notifier)
                    .validateUsername()) {
                  switch (mode) {
                    case AuthModeEnum.oauth:
                      await ref
                          .read(authPageStateProvider.notifier)
                          .oauthRegistration()
                          .then((value) {
                        if (value) {
                          context.pop(true);
                        } else {
                          ref.notifyUser(
                            NitNotification.error(
                              'Ошибка регистрации',
                            ),
                          );
                        }
                      });
                      break;
                    case AuthModeEnum.registration:
                      ref
                          .read(authPageStateProvider.notifier)
                          .setPage(AuthAreaNavigationZone.registrationPassword);
                      break;
                    default:
                      UnimplementedError();
                  }
                }
              }
            },
          ),
          const SizedBox(
            height: 6,
          ),
        ],
      ),
    );
  }
}
