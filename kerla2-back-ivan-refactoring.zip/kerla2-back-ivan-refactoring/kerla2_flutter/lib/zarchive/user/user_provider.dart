// import 'package:riverpod_annotation/riverpod_annotation.dart';
// import 'package:serverpod_auth_client/module.dart';

// import '../../zarchive/session/serverpod_client.dart';

// part 'user_provider.g.dart';

// @riverpod
// Future<UserInfoPublic?> user(
//   UserRef ref, {
//   required int id,
// }) async {
//   final res = await client.users.getUserById(id);
//   return res;
// }
