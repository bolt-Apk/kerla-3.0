import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/core/app_sources.dart';

import '../../../../ads/create/create_ad/attributes/widgets/attribute_drop_list.dart';
import '../../../../ads/create/create_ad/attributes/widgets/attribute_input.dart';
import '../../../../ads/create/create_ad/attributes/widgets/attribute_radio_button_list.dart';
import '../../../../ads/create/create_ad/attributes/widgets/attribute_range_input.dart';

class FilterRender extends HookConsumerWidget {
  const FilterRender({
    super.key,
    required this.attributeValue,
    required this.onFilterSave,
    this.userId,
  });

  final AdAttributeValue attributeValue;
  final Function(AdAttributeValue) onFilterSave;
  final int? userId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return switch (attributeValue.attribute!.type) {
      AttributeType.category => const SizedBox.shrink(),
      AttributeType.color => const SizedBox(),
      AttributeType.radioButton => AttributeRadioButtonList(
          attributeValue: attributeValue,
          onAcceptTap: onFilterSave,
        ),
      AttributeType.regionsDropdown => Consumer(
          builder: (context, ref, child) {
            final regions = ref.read(regionsProvider);
            return AttributeDropList(
              attributeValue: attributeValue,
              title: attributeValue.attribute?.title,
              list: regions,
              isRegionDropDown: true,
              onAcceptTap: onFilterSave,
            );
          },
        ),
      AttributeType.valuesDropdown => Consumer(
          builder: (context, ref, child) {
            return AttributeDropList(
              attributeValue: attributeValue,
              list: attributeValue.attribute?.values,
              title: attributeValue.attribute?.title,
              onAcceptTap: onFilterSave,
            );
          },
        ),
      AttributeType.decimal => AttributeRangeInput(
          // attribute: attributeValue.attribute!,
          title: attributeValue.attribute!.title,
          suffixText: attributeValue.attribute!.suffixText,
          keyboardType: TextInputType.number,
          onSave: (value) => onFilterSave(
            attributeValue.copyWith(value: value),
          ),
          leftController: useTextEditingController(),
          rightController: useTextEditingController(),
        ),
      AttributeType.number => AttributeRangeInput(
          // attribute: attributeValue.attribute!,
          title: attributeValue.attribute!.title,
          suffixText: attributeValue.attribute!.suffixText,
          keyboardType: TextInputType.number,
          onSave: (value) => onFilterSave(
            attributeValue.copyWith(value: value),
          ),
          leftController: useTextEditingController(),
          rightController: useTextEditingController(),
        ),
      AttributeType.string => AttributeInput(
          attributeValue: attributeValue,
          onAccept: onFilterSave,
        ),
    };
  }
}
