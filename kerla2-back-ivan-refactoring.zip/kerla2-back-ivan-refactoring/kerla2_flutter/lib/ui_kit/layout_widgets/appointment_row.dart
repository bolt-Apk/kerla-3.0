part of '../ui_kit.dart';

// TODO: переименовать как-то
class AppointmentRow extends StatelessWidget {
  final String title;
  final String subtitle;
  final String iconName;
  final bool isActive;
  final bool Function()? onTap;

  const AppointmentRow({
    super.key,
    required this.title,
    required this.subtitle,
    required this.iconName,
    required this.isActive,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    print(isActive);
    return Row(
      children: [
        Expanded(
          child: SvgPicture.asset(
            iconName,
            height: 20,
            width: 20,
            colorFilter: ColorFilter.mode(
                context.theme.iconTheme.color!, BlendMode.srcIn),
          ),
        ),
        Expanded(
          flex: 5,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: Theme.of(context).textTheme.titleMedium,
              ),
              Text(subtitle),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: SwitchWidget(
            isActive: isActive,
            onTap: onTap,
          ),
        ),
      ],
    );
  }
}
