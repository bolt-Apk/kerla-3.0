/* AUTOMATICALLY GENERATED CODE DO NOT MODIFY */
/*   To generate run: "serverpod generate"    */

// ignore_for_file: implementation_imports
// ignore_for_file: library_private_types_in_public_api
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: public_member_api_docs
// ignore_for_file: type_literal_in_constant_pattern
// ignore_for_file: use_super_parameters

// ignore_for_file: no_leading_underscores_for_library_prefixes
import 'package:serverpod_client/serverpod_client.dart' as _i1;
import '../protocol.dart' as _i2;
import 'package:nit_tools_client/nit_tools_client.dart' as _i3;

abstract class Ad implements _i1.SerializableModel {
  Ad._({
    this.id,
    required this.title,
    required this.adType,
    required this.price,
    DateTime? createdAt,
    required this.description,
    int? visitCount,
    this.isFavourite,
    this.onlyForGender,
    this.userId,
    this.userProfile,
    this.category,
    this.attributeValues,
    this.media,
    this.region,
    this.promotions,
    required this.status,
  })  : createdAt = createdAt ?? DateTime.now(),
        visitCount = visitCount ?? 0;

  factory Ad({
    int? id,
    required String title,
    required _i2.AdType adType,
    required int price,
    DateTime? createdAt,
    required String description,
    int? visitCount,
    bool? isFavourite,
    _i2.UserGender? onlyForGender,
    int? userId,
    _i2.UserProfile? userProfile,
    _i2.AdCategory? category,
    List<_i2.AdAttributeValue>? attributeValues,
    List<_i3.NitMedia>? media,
    _i2.Region? region,
    List<_i2.KerlaService>? promotions,
    required _i2.AdStatus status,
  }) = _AdImpl;

  factory Ad.fromJson(Map<String, dynamic> jsonSerialization) {
    return Ad(
      id: jsonSerialization['id'] as int?,
      title: jsonSerialization['title'] as String,
      adType: _i2.AdType.fromJson((jsonSerialization['adType'] as String)),
      price: jsonSerialization['price'] as int,
      createdAt:
          _i1.DateTimeJsonExtension.fromJson(jsonSerialization['createdAt']),
      description: jsonSerialization['description'] as String,
      visitCount: jsonSerialization['visitCount'] as int,
      isFavourite: jsonSerialization['isFavourite'] as bool?,
      onlyForGender: jsonSerialization['onlyForGender'] == null
          ? null
          : _i2.UserGender.fromJson(
              (jsonSerialization['onlyForGender'] as int)),
      userId: jsonSerialization['userId'] as int?,
      userProfile: jsonSerialization['userProfile'] == null
          ? null
          : _i2.UserProfile.fromJson(
              (jsonSerialization['userProfile'] as Map<String, dynamic>)),
      category: jsonSerialization['category'] == null
          ? null
          : _i2.AdCategory.fromJson(
              (jsonSerialization['category'] as Map<String, dynamic>)),
      attributeValues: (jsonSerialization['attributeValues'] as List?)
          ?.map(
              (e) => _i2.AdAttributeValue.fromJson((e as Map<String, dynamic>)))
          .toList(),
      media: (jsonSerialization['media'] as List?)
          ?.map((e) => _i3.NitMedia.fromJson((e as Map<String, dynamic>)))
          .toList(),
      region: jsonSerialization['region'] == null
          ? null
          : _i2.Region.fromJson(
              (jsonSerialization['region'] as Map<String, dynamic>)),
      promotions: (jsonSerialization['promotions'] as List?)
          ?.map((e) => _i2.KerlaService.fromJson((e as Map<String, dynamic>)))
          .toList(),
      status: _i2.AdStatus.fromJson((jsonSerialization['status'] as String)),
    );
  }

  /// The database id, set if the object has been inserted into the
  /// database or if it has been fetched from the database. Otherwise,
  /// the id will be null.
  int? id;

  String title;

  _i2.AdType adType;

  int price;

  DateTime createdAt;

  String description;

  int visitCount;

  bool? isFavourite;

  _i2.UserGender? onlyForGender;

  int? userId;

  _i2.UserProfile? userProfile;

  _i2.AdCategory? category;

  List<_i2.AdAttributeValue>? attributeValues;

  List<_i3.NitMedia>? media;

  _i2.Region? region;

  List<_i2.KerlaService>? promotions;

  _i2.AdStatus status;

  Ad copyWith({
    int? id,
    String? title,
    _i2.AdType? adType,
    int? price,
    DateTime? createdAt,
    String? description,
    int? visitCount,
    bool? isFavourite,
    _i2.UserGender? onlyForGender,
    int? userId,
    _i2.UserProfile? userProfile,
    _i2.AdCategory? category,
    List<_i2.AdAttributeValue>? attributeValues,
    List<_i3.NitMedia>? media,
    _i2.Region? region,
    List<_i2.KerlaService>? promotions,
    _i2.AdStatus? status,
  });
  @override
  Map<String, dynamic> toJson() {
    return {
      if (id != null) 'id': id,
      'title': title,
      'adType': adType.toJson(),
      'price': price,
      'createdAt': createdAt.toJson(),
      'description': description,
      'visitCount': visitCount,
      if (isFavourite != null) 'isFavourite': isFavourite,
      if (onlyForGender != null) 'onlyForGender': onlyForGender?.toJson(),
      if (userId != null) 'userId': userId,
      if (userProfile != null) 'userProfile': userProfile?.toJson(),
      if (category != null) 'category': category?.toJson(),
      if (attributeValues != null)
        'attributeValues':
            attributeValues?.toJson(valueToJson: (v) => v.toJson()),
      if (media != null) 'media': media?.toJson(valueToJson: (v) => v.toJson()),
      if (region != null) 'region': region?.toJson(),
      if (promotions != null)
        'promotions': promotions?.toJson(valueToJson: (v) => v.toJson()),
      'status': status.toJson(),
    };
  }

  @override
  String toString() {
    return _i1.SerializationManager.encode(this);
  }
}

class _Undefined {}

class _AdImpl extends Ad {
  _AdImpl({
    int? id,
    required String title,
    required _i2.AdType adType,
    required int price,
    DateTime? createdAt,
    required String description,
    int? visitCount,
    bool? isFavourite,
    _i2.UserGender? onlyForGender,
    int? userId,
    _i2.UserProfile? userProfile,
    _i2.AdCategory? category,
    List<_i2.AdAttributeValue>? attributeValues,
    List<_i3.NitMedia>? media,
    _i2.Region? region,
    List<_i2.KerlaService>? promotions,
    required _i2.AdStatus status,
  }) : super._(
          id: id,
          title: title,
          adType: adType,
          price: price,
          createdAt: createdAt,
          description: description,
          visitCount: visitCount,
          isFavourite: isFavourite,
          onlyForGender: onlyForGender,
          userId: userId,
          userProfile: userProfile,
          category: category,
          attributeValues: attributeValues,
          media: media,
          region: region,
          promotions: promotions,
          status: status,
        );

  @override
  Ad copyWith({
    Object? id = _Undefined,
    String? title,
    _i2.AdType? adType,
    int? price,
    DateTime? createdAt,
    String? description,
    int? visitCount,
    Object? isFavourite = _Undefined,
    Object? onlyForGender = _Undefined,
    Object? userId = _Undefined,
    Object? userProfile = _Undefined,
    Object? category = _Undefined,
    Object? attributeValues = _Undefined,
    Object? media = _Undefined,
    Object? region = _Undefined,
    Object? promotions = _Undefined,
    _i2.AdStatus? status,
  }) {
    return Ad(
      id: id is int? ? id : this.id,
      title: title ?? this.title,
      adType: adType ?? this.adType,
      price: price ?? this.price,
      createdAt: createdAt ?? this.createdAt,
      description: description ?? this.description,
      visitCount: visitCount ?? this.visitCount,
      isFavourite: isFavourite is bool? ? isFavourite : this.isFavourite,
      onlyForGender:
          onlyForGender is _i2.UserGender? ? onlyForGender : this.onlyForGender,
      userId: userId is int? ? userId : this.userId,
      userProfile: userProfile is _i2.UserProfile?
          ? userProfile
          : this.userProfile?.copyWith(),
      category:
          category is _i2.AdCategory? ? category : this.category?.copyWith(),
      attributeValues: attributeValues is List<_i2.AdAttributeValue>?
          ? attributeValues
          : this.attributeValues?.map((e0) => e0.copyWith()).toList(),
      media: media is List<_i3.NitMedia>?
          ? media
          : this.media?.map((e0) => e0.copyWith()).toList(),
      region: region is _i2.Region? ? region : this.region?.copyWith(),
      promotions: promotions is List<_i2.KerlaService>?
          ? promotions
          : this.promotions?.map((e0) => e0.copyWith()).toList(),
      status: status ?? this.status,
    );
  }
}
