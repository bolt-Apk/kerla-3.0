import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerla2_flutter/router/router.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_router/nit_router.dart';
import 'package:wechat_assets_picker/wechat_assets_picker.dart';

import '../../create_ad/widget/asset_item.dart';
import '../state/selected_media_state.dart';

class Asset extends ConsumerWidget {
  const Asset({
    super.key,
    required this.assetEntity,
  });

  final AssetEntity assetEntity;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final int? adId = ref.watchNavigationParam(AppNavigationParams.adId);
    final selectedAssets = ref.watch(adMediaStateProvider(adId: adId));
    final isContains = selectedAssets.items
        .any((e) => e.isAsset && e.asAsset().id == assetEntity.id);

    return GestureDetector(
      onTap: () => ref
          .read(adMediaStateProvider(adId: adId).notifier)
          .toggleItem(MediaOrAssetWrapper(assetEntity)),
      child: Stack(
        children: [
          AnimatedPadding(
            duration: const Duration(milliseconds: 100),
            padding: EdgeInsets.all(
              isContains ? 10 : 0,
            ),
            child: AssetItem(assetEntity: assetEntity),
          ),
          Positioned.fill(
            child: Align(
              alignment: Alignment.topRight,
              child: AnimatedPadding(
                duration: const Duration(milliseconds: 100),
                padding: EdgeInsets.all(
                  isContains ? 15 : 10,
                ),
                child: Container(
                  width: 25,
                  height: 25,
                  decoration: BoxDecoration(
                    color: isContains
                        ? ThemePrimaryColors.primary
                        : Colors.black12,
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: Colors.white,
                      width: 2,
                    ),
                  ),
                  child: Center(
                    child: Text(
                      "${selectedAssets.items.indexWhere((e) => e.isAsset && e.asAsset().id == assetEntity.id) + 1}",
                      style: TextStyle(
                        color: isContains ? Colors.white : Colors.transparent,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
