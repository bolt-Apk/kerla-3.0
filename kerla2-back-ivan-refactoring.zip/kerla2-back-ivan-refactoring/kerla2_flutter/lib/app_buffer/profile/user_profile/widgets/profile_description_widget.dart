import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_svg/svg.dart';
import 'package:kerla2_flutter/app_buffer/chats_new/widgets/chat_button.dart';
import 'package:kerla2_flutter/app_buffer/profile/user_online/last_time_online_info.dart';
import 'package:kerla2_flutter/common/is_my_profile.dart';
import 'package:kerla2_flutter/common/user_profile_ref_extensions.dart';
import 'package:kerla2_flutter/router/router.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:kerla2_shared/kerla2_shared.dart';
import 'package:nit_app/nit_app.dart';
import 'package:nit_router/nit_router.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

import '../../profile_image/profile_image.dart';

class ProfileDescriptionWidget extends ConsumerWidget {
  const ProfileDescriptionWidget({
    super.key,
    required this.userId,
  });

  final int userId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // final userStory = ref.watch(userStoriesProvider(id: userId));

    return MainInfoWidget(
      imageWidget: ProfileImage(
        // onAvatarTap: () {
        // TODO: вернуть
        // if (ref.isMyProfile(userId) &&
        //     userStory.asData?.value.isNotEmpty == true) {
        //   context.pushNamed(
        //     MainAreaNavigationZone.singleUserStorie.name,
        //     pathParameters: AppNavigationParams.userId.set(userId),
        //   );
        // }
        // },
        userId: userId,
      ),
      infoWidget: Row(
        children: [
          Flexible(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Consumer(
                  builder: (context, ref, child) =>
                      ref.watchUserProfile(userId).nitWhen(
                            childBuilder: (userProfile) => Text(
                              '@${userProfile.userName}',
                              style: context.textTheme.titleMedium
                                  ?.copyWith(fontSize: 20),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    if (ref.isMyProfile(userId))
                      Material(
                        color: Theme.of(context).canvasColor,
                        child: InkWell(
                          onTap: () => context.pushNamed(
                            MainAreaNavigationZone.settings.name,
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Row(
                              children: [
                                SvgPicture.asset(
                                  AppIconsSvg.edit,
                                  colorFilter: ColorFilter.mode(
                                    context.theme.iconTheme.color!,
                                    BlendMode.srcIn,
                                  ),
                                  height: 12,
                                  width: 12,
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(
                                    left: 4,
                                  ),
                                  child: Text(
                                    'Редактировать профиль',
                                    style: Theme.of(context)
                                        .textTheme
                                        .displayLarge
                                        ?.copyWith(
                                          fontSize: 12,
                                        ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      )
                    else
                      LastTimeOnlineInfo(
                        userId: userId,
                        style: context.textTheme.displayLarge,
                      )
                    // const StarScore(),
                  ],
                ),
              ],
            ),
          ),
          // Spacer(),
          if (ref.signedIn && !ref.isMyProfile(userId))
            ChatButton(
              userId: userId,
              chatChannelType: ChatChannelType.personal,
            ),
        ],
      ),
    );
  }
}
