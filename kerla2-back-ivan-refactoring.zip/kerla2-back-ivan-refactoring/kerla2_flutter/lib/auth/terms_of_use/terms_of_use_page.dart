import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kerla2_flutter/auth/state/auth_page_state.dart';
import 'package:kerla2_flutter/core/app_scaffold.dart';
import 'package:kerla2_flutter/router/navigation_zones/auth_navigation_zone.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

import 'state/privacy_policy_provider.dart';

class TermsOfUsePage extends ConsumerWidget {
  const TermsOfUsePage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return AppScaffold(
      body: DecoratedBox(
        decoration: BoxDecoration(
          color: context.theme.canvasColor,
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 22),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Пользовательское соглашение',
                style: Theme.of(context).textTheme.headlineMedium?.copyWith(),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 20, bottom: 15),
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(5),
                    color: context.theme.scaffoldBackgroundColor,
                  ),
                  child: SizedBox(
                    height: 350,
                    child: ListView(
                      physics: const BouncingScrollPhysics(),
                      shrinkWrap: true,
                      children: [
                        Padding(
                          padding: const EdgeInsets.symmetric(
                            vertical: 15,
                            horizontal: 10,
                          ),
                          child: Consumer(
                            builder: (_, ref, __) {
                              final privacyText =
                                  ref.watch(privacyPolicyProvider);
                              return privacyText.when(
                                data: (text) => Text(
                                  text,
                                  style:
                                      context.textTheme.titleMedium?.copyWith(
                                    fontSize: 13,
                                  ),
                                ),
                                error: (err, stack) => Text('Error: $err'),
                                loading: () =>
                                    const CircularProgressIndicator(),
                              );
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              MainButton(
                boxHeight: 51,
                onTap: () => ref
                    .read(authPageStateProvider.notifier)
                    .setPage(AuthAreaNavigationZone.auth),
                buttonText: 'Хорошо',
              ),
            ],
          ),
        ),
      ),
    );
  }
}
