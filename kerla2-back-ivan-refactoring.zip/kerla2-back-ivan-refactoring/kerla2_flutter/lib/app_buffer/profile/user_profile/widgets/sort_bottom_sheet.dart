import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/app_buffer/profile/user_profile/widgets/sort/state/ad_sort_state.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_router/nit_router.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

import 'sort/sort_row.dart';

class SortBottomSheet extends HookConsumerWidget {
  const SortBottomSheet({super.key, required this.userId});

  final int userId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final order = useState<AdOrderBy>(AdOrderBy.dateDes);
    final notifier = ref.read(adSortProvider(userId).notifier);

    useEffect(() {
      order.value = ref.read(adSortProvider(userId));
      return null;
    }, [ref]);
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  CommonButton(
                    action: () => context.pop(),
                    child: const Icon(Icons.close),
                  ),
                  const Gap(8),
                  const Text('Сначала показать'),
                ],
              ),
              CommonButton(
                action: () {
                  order.value = AdOrderBy.dateDes;
                  notifier.state = order.value;
                },
                child: const Row(
                  children: [
                    Icon(Icons.replay),
                    Gap(8),
                    Text("Сбросить"),
                  ],
                ),
              ),
            ],
          ),
        ),
        const Divider(
          height: 2,
        ),
        const Gap(5),
        SortRow(
          type: AdOrderBy.dateDes,
          checkedValue: order,
        ),
        SortRow(
          type: AdOrderBy.dateAsc,
          checkedValue: order,
        ),
        SortRow(
          type: AdOrderBy.priceAsc,
          checkedValue: order,
        ),
        SortRow(
          type: AdOrderBy.priceDes,
          checkedValue: order,
        ),
        const Spacer(),
        Padding(
          padding: const EdgeInsets.symmetric(
            vertical: 12,
            horizontal: 18,
          ),
          child: Consumer(
            builder: (context, ref, child) {
              return AuthExpandedElevatedButton(
                height: 50,
                child: const Text(
                  'Применить',
                  style: TextStyle(
                    color: Colors.white,
                  ),
                ),
                onPressed: () {
                  notifier.state = order.value;
                  context.pop();
                },
              );
            },
          ),
        ),
      ],
    );
  }
}
