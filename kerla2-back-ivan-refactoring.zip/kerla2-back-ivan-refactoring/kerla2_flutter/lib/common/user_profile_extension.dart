import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/common/business_extension.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';

extension UserProfileExtension on UserProfile {
  bool isBusiness(WidgetRef ref) =>
      ref.businessEndsAt(userId)?.compareTo(DateTime.now()) == 1;

  String businessEndsAtString(WidgetRef ref) => ref.businessEndsAt(userId) == null
      ? 'Не выбрано'
      : DateFormat('dd-MM-yyyy – kk:mm').format(
          ref.businessEndsAt(userId)!.toLocal(),
        );

  String get lastTimeOnlineString => isOnline
      ? 'В сети'
      : lastTimeOnline != null
          ? 'Был${gender == UserGender.female ? 'а' : ''} в сети ${lastTimeOnline!.formatLastTimeOnlineDate}'
          : lastTimeOnline?.formatLastTimeOnlineDate ?? 'Не в сети';

  // String get lastTimeOnlineString => isOnline
  //     ? 'В сети'
  //     : lastTimeOnline != null
  //         ? 'Был${gender == UserGender.female ? 'а' : ''} в сети ${lastTimeOnline!.formatLastTimeOnlineDate}'
  //         : lastTimeOnline?.formatLastTimeOnlineDate ?? 'Не в сети';
}
