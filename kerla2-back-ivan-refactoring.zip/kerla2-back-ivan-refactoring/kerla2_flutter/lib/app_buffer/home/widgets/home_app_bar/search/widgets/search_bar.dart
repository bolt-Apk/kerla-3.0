import 'dart:async';

import 'package:animated_size_and_fade/animated_size_and_fade.dart';
import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/app_buffer/home/filters/list_filter/attribute_filter/state/filter_attribute_state.dart';
import 'package:kerla2_flutter/app_buffer/home/widgets/home_app_bar/search/providers.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class SearchBarWidget extends HookConsumerWidget {
  const SearchBarWidget({
    super.key,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final controller = useTextEditingController();
    controller.text = ref.watch(searchString);
    final searchTabStateValue = ref.watch(searchTabState);
    final debounce = useRef<Timer?>(null);

    void onSearchChanged(String value) {
      if (debounce.value?.isActive ?? false) debounce.value?.cancel();

      debounce.value = Timer(const Duration(milliseconds: 500), () {
        if (searchTabStateValue == SearchState.account) {
          ref.read(searchString.notifier).state = value;
        } else {
          ref
              .read(filterStateProvider(AdListType.main).notifier)
              .updateSearchString(value);
        }
      });
    }

    return AnimatedSizeAndFade(
      sizeDuration: const Duration(milliseconds: 100),
      fadeDuration: const Duration(milliseconds: 100),
      fadeInCurve: Curves.elasticIn,
      child: Container(
        height: 32,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: context.colorScheme.surface,
        ),
        child: TextField(
          style: context.textTheme.displayLarge?.copyWith(fontSize: 16),
          controller: controller,
          cursorColor: context.colorScheme.onSurface,
          onChanged: onSearchChanged,
          decoration: InputDecoration(
            enabledBorder: OutlineInputBorder(
              borderSide: BorderSide(
                color: context.colorScheme.surface,
              ),
              borderRadius: BorderRadius.circular(10),
            ),
            focusedBorder: OutlineInputBorder(
              borderSide: BorderSide(
                color: context.colorScheme.surface,
              ),
              borderRadius: BorderRadius.circular(10),
            ),
            contentPadding: const EdgeInsets.symmetric(horizontal: 8),
            hintText: searchTabStateValue == SearchState.account
                ? "Поиск пользователей"
                : "Поиск объявлений",
          ),
        ),
      ),
    );
  }
}
