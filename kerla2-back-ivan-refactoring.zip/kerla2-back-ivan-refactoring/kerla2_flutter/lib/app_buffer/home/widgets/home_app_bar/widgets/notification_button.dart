import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_svg/svg.dart';
import 'package:kerla2_flutter/app_buffer/profile/notifications/notification_new_status_provider/notification_new_status_provider.dart';
import 'package:kerla2_flutter/auth/widgets/auth_bottom_sheet.dart';
import 'package:kerla2_flutter/router/router.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_app/nit_app.dart';
import 'package:nit_router/nit_router.dart';

class NotificationButton extends ConsumerWidget {
  const NotificationButton({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return InkWell(
      onTap: () {
        if (ref.signedIn) {
          context.pushNamed(MainAreaNavigationZone.notification.name);
        } else {
          context.showAuthBottomSheet();
        }
      },
      child: Stack(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: SvgPicture.asset(
              AppIconsSvg.notification,
              height: 18,
              width: 18,
              colorFilter: ColorFilter.mode(
                Theme.of(context).iconTheme.color ?? Colors.black,
                BlendMode.srcIn,
              ),
            ),
          ),
          if (ref.watch(notificationNewStatusProvider) > 0)
            const Positioned(
              right: 8,
              top: 8,
              child: CircleAvatar(
                radius: 3,
                backgroundColor: Colors.red,
              ),
            ),
        ],
      ),
    );
  }
}
