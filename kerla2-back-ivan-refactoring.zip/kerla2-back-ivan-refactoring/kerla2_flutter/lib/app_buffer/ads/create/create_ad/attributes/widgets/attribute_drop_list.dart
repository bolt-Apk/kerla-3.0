import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';

import '../../../../../home/filters/list_filter/widgets/home_attribute_dialog.dart';
import '../../../../../home/filters/list_filter/widgets/home_filter_bottom_sheet.dart';
import '../../../../../home/filters/list_filter/widgets/home_filter_drop_down_row_widget.dart';

class AttributeDropList extends HookConsumerWidget {
  const AttributeDropList({
    super.key,
    required this.attributeValue,
    required this.onAcceptTap,
    this.adId,
    this.title,
    this.list,
    this.isRegionDropDown = false,
  });

  final AdAttributeValue attributeValue;
  final int? adId;
  final String? title;
  final List<dynamic>? list;
  final bool isRegionDropDown;
  final Function(AdAttributeValue) onAcceptTap;

  // void saveDropDownAttribute({
  //   required WidgetRef ref,
  //   required Attribute attribute,
  //   required String? savedValue,
  //   List<dynamic>? values,
  //   int? userId,
  //   int? adId,
  //   bool isFilter = false,
  //   bool isRegionDropDown = false,
  // }) {
  //   if (savedValue != null) {
  //     //edit ad
  //     if (adId != null) {
  //       ref.read(adEditStateProvider(adId: adId).notifier).updateAttributeValue(
  //             attribute.id!,
  //             attribute.subAttributeId != null,
  //             savedValue,
  //           );
  //       //filter ads
  //     } else if (isFilter) {
  //       ref
  //           .read(
  //             homeFiltersStateProvider(
  //               isProfile: userId != null,
  //             ).notifier,
  //           )
  //           .setAttribute<String>(
  //             AdAttributeValue(
  //               attributeId: attribute.id!,
  //               value: savedValue,
  //             ),
  //           );
  //     }
  //     //create ad
  //     else {
  //       ref
  //           .read(
  //             adCreateStateProvider(isStory: false).notifier,
  //           )
  //           .setAttribute(
  //             attribute,
  //             savedValue,
  //           );
  //     }
  //   } else {
  //     debugPrint('nothing to save');
  //   }
  // }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final values = isRegionDropDown
        ? list?.map((e) => e.title as String).toList() as List<String>
        : attributeValue.attribute!.values!;

    // final int attributeId =
    //     attributeValue.attribute?.subAttributeId ?? attributeValue.attributeId;

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Align(
            alignment: Alignment.centerLeft,
            child: Text(
              title ?? '',
              style: Theme.of(context).textTheme.titleLarge,
            ),
          ),
        ),
        Container(
          height: 40,
          decoration: BoxDecoration(
            color: Theme.of(context).canvasColor,
            borderRadius: BorderRadius.circular(10),
          ),
          child: TextField(
            style: Theme.of(context).textTheme.bodyMedium,
            readOnly: true,
            decoration: const InputDecoration(
              border: InputBorder.none,
              contentPadding: EdgeInsets.symmetric(horizontal: 8),
            ),
            controller: TextEditingController(text: attributeValue.value),
            onTap: () => showModalBottomSheet(
              context: context,
              isScrollControlled: true,
              builder: (BuildContext context) {
                return HookBuilder(
                  builder: (context) {
                    final filterValueNotifier = useState('');
                    final currentValue = useState(attributeValue.value);
                    final filtredValues = [];
                    filtredValues.addAll(
                      values.where(
                        (element) => element.toLowerCase().contains(
                            filterValueNotifier.value.toLowerCase().trim()),
                      ),
                    );
                    return SizedBox(
                      height:
                          MediaQuery.sizeOf(context).height - kToolbarHeight,
                      child: HomeAttributeDialog(
                        onPressed: () {
                          // final value = ref
                          //     .read(
                          //       attributeDropDownValueProvider(
                          //         attributeId,
                          //         isSubAttribute,
                          //       ),
                          //     )
                          //     .pinValue!;
                          onAcceptTap(
                            attributeValue.copyWith(value: currentValue.value),
                          );
                          Navigator.of(context).pop();
                        },
                        child: FilterBottomSheet(
                          attribute: Attribute(
                            type: AttributeType.valuesDropdown,
                            id: attributeValue.attributeId,
                            values: attributeValue.attribute?.values,
                            title: title,
                          ),
                          body: SizedBox(
                            height: MediaQuery.sizeOf(context).height -
                                kToolbarHeight -
                                200,
                            child: ListView.builder(
                              itemCount: filtredValues.length,
                              shrinkWrap: true,
                              itemBuilder: (context, index) {
                                return HomeFilterDropDownRow(
                                  attribute: attributeValue.attribute!,
                                  value: filtredValues[index],
                                  values: values,
                                  valueNotifier: currentValue,
                                );
                              },
                            ),
                          ),
                          onReset: () =>
                              onAcceptTap(attributeValue.copyWith(value: '')),
                          filterValueNotifier: filterValueNotifier,
                        ),
                      ),
                    );
                  },
                );
              },
            ).then(
              (value) {
                debugPrint('attribute value: $attributeValue closed');
              },
            ),
          ),
        ),
        const SizedBox(height: 10),
      ],
    );
  }
}
