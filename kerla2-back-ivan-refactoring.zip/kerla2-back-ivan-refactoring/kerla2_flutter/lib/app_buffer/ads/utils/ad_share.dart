import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:kerla2_flutter/app/profile/settings/widgets/edit_phone_widget.dart';
import 'package:kerla2_flutter/app_buffer/chats_new/widgets/chat_list_card.dart';
import 'package:kerla2_flutter/common/share.dart';
import 'package:kerla2_flutter/common/user_profile_ref_extensions.dart';
import 'package:kerla2_flutter/core/app_backend_filters.dart';
import 'package:nit_app/nit_app.dart';
import 'package:nit_router/nit_router.dart';
import 'package:share_plus/share_plus.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class AdShareState {
  AdShareState(
    this.context,
    this.adId,
  );

  final BuildContext context;
  final int adId;

  void showGeneralShareBottomSheet() {
    Consumer(builder: (context, ref, child) {
      if (!ref.signedIn) {
        Share.share(
          ShareType.ad.getShareLink(adId),
        );
      }
      return const SizedBox();
    });

    showModalBottomSheet(
        context: context,
        builder: (c) {
          return SafeArea(
            child: SizedBox(
              width: double.infinity,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextButton(
                    onPressed: () {
                      showChatShareBottomSheet();
                    },
                    child: const Text('В чате'),
                  ),
                  TextButton(
                    onPressed: () {
                      Share.share(
                        ShareType.ad.getShareLink(adId),
                      );
                    },
                    child: const Text('Ссылкой'),
                  ),
                ],
              ),
            ),
          );
        });
  }

  void showChatShareBottomSheet() {
    showModalBottomSheet(
        context: context,
        builder: (c) {
          return Consumer(builder: (context, ref, child) {
            return ref
                .watchEntityListAsync<NitChatParticipant>(
                  backendFilter: NitBackendFilter.and([
                    AppBackendFilter.userId.equals(ref.signedInUserId!),
                    AppBackendFilter.lastMessage.equals(null, negate: true),
                    AppBackendFilter.isDeleted.equals(false),
                  ]),
                )
                .nitWhenList(
                  loadingItemsCount: 1,
                  errorWidget: const Text('Не удалось загрузить чат поддержки'),
                  childBuilder: (data) {
                    if (data.isEmpty) {
                      return const Padding(
                        padding: EdgeInsets.symmetric(vertical: 20),
                        child: Text('У вас нет чатов'),
                      );
                    }
                    return Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: ListView.builder(
                        shrinkWrap: true,
                        itemCount: data.length,
                        itemBuilder: (context, index) {
                          final chatParticipant = data[index];

                          return Row(
                            children: [
                              Flexible(
                                child: ChatListCard(
                                    chatParticipant: chatParticipant),
                              ),
                              // const Spacer(),
                              HookBuilder(
                                builder: (context) {
                                  final sentChannelId = useState<Set<int>>({});
                                  final isSent = sentChannelId.value
                                      .contains(chatParticipant.id!);
                                  return TextButton(
                                    onPressed: () async {
                                      if (isSent) {
                                        context.pop();
                                        context.pop();
                                        context.goToChatByChannelId(
                                            channelId:
                                                chatParticipant.chatChannelId);
                                        return;
                                      }

                                      await ref.saveModel<NitChatMessage>(
                                        NitChatMessage(
                                          userId: ref.signedInUserId!,
                                          chatChannelId:
                                              chatParticipant.chatChannelId,
                                          text: 'Объявление',
                                          sentAt: DateTime.now(),
                                          customMessageType: CustomMessageType(
                                            type: 'adMessage',
                                            additionalModelId: adId,
                                          ),
                                        ),
                                      );

                                      sentChannelId.value = {
                                        ...sentChannelId.value,
                                        chatParticipant.id!
                                      };
                                    },
                                    child: isSent
                                        ? const Text('Перейти в чат')
                                        : const Text('Отправить'),
                                  );
                                },
                              ),
                            ],
                          );
                        },
                      ),
                    );
                  },
                );
          });
        });
  }
}
