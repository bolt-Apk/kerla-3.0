//
//  PMImport.h
//  Pods
//

#ifndef PMImport_h
#define PMImport_h

#if TARGET_OS_OSX
#import <FlutterMacOS/FlutterMacOS.h>
#elif TARGET_OS_IOS
#import <Flutter/Flutter.h>
#endif

#endif /* PMImport_h */
