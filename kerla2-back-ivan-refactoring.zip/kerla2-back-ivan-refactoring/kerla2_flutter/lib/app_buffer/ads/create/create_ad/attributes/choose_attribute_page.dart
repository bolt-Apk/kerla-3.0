import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/app_buffer/ads/create/media/state/selected_media_state.dart';
import 'package:kerla2_flutter/core/app_scaffold.dart';
import 'package:kerla2_flutter/router/router.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';
import 'package:nit_riverpod_notifications/nit_riverpod_notifications.dart';
import 'package:nit_router/nit_router.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

import 'widgets/attribure_render.dart';
import '../../state/ad_create_state.dart';

class ChooseAttributePage extends HookConsumerWidget {
  const ChooseAttributePage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final attributes = ref
            .watch(createAdStateProvider(AdType.ad))
            .attributeValues
            ?.where((attr) => attr.attribute?.type != AttributeType.category)
            .toList() ??
        [];
    final isLoading = useState(false);

    return GestureDetector(
      onTap: () => FocusManager.instance.primaryFocus?.unfocus(),
      child: PopScope(
        canPop: false,
        child: AppScaffold(
          showBottomNavBar: false,
          backgroundColor: context.theme.scaffoldBackgroundColor,
          appBar: AppBar(
            automaticallyImplyLeading: false,
            elevation: 0,
            backgroundColor: context.theme.appBarTheme.backgroundColor,
            leading: IconButton(
              icon: Icon(
                Icons.arrow_back,
                color: context.theme.iconTheme.color,
              ),
              onPressed: () {
                //TODO: add here clear of values
                Navigator.pop(context);
              },
            ),
            title: Text(
              "Уточнить",
              style: TextStyle(
                color: context.theme.iconTheme.color,
                fontSize: 17,
              ),
            ),
          ),
          body: Padding(
            padding: const EdgeInsets.only(left: 12, right: 12, bottom: 80),
            child: ListView.builder(
              itemCount: attributes.length,
              itemBuilder: (context, index) {
                return Consumer(
                  builder: (context, ref, child) {
                    return AttributeRender(
                      attributeValue: attributes[index],
                      onAttributeSave: (attribute) {
                        ref
                            .read(
                              createAdStateProvider(AdType.ad).notifier,
                            )
                            .setAttribute(attribute);
                      },
                    );
                  },
                );
              },
            ),
          ),
          floatingActionButton: Consumer(
            builder: (context, ref, child) {
              final mediaState = ref.watch(adMediaStateProvider(adId: null));
              final loadedCount = mediaState.loadedCount ?? 0;
              final totalCount = mediaState.items.length;

              return AnimatedSwitcher(
                duration: const Duration(milliseconds: 300),
                transitionBuilder: (Widget child, Animation<double> animation) {
                  return FadeTransition(opacity: animation, child: child);
                },
                child: mediaState.isUploading
                    ? Container(
                        key: const ValueKey('uploading_status'),
                        padding: const EdgeInsets.all(8.0),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const SizedBox(height: 16),
                            Text(
                              'Загрузка медиа... ($loadedCount/$totalCount)',
                              style: context.textTheme.titleMedium,
                            ),
                          ],
                        ),
                      )
                    : Padding(
                        key: const ValueKey('publish_button'),
                        padding: const EdgeInsets.all(8.0),
                        child: MainButton(
                          isLoading: isLoading.value,
                          buttonText: 'Опубликовать',
                          onTap: () async {
                            isLoading.value = true;

                            if (attributes
                                .every((element) => element.value.isNotEmpty)) {
                              await ref
                                  .read(
                                    createAdStateProvider(AdType.ad).notifier,
                                  )
                                  .publishAd()
                                  .then(
                                (adId) {
                                  if (adId == null) {
                                    if (context.mounted) {
                                      ref.notifyUser(
                                        'Не удалось создать объявление',
                                      );
                                    }
                                  } else {
                                    if (context.mounted) {
                                      context.goNamed(
                                        AdNavigationZone.addService.name,
                                        pathParameters:
                                            AppNavigationParams.adId.set(adId),
                                      );
                                    }
                                  }
                                },
                              );
                            } else {
                              ref.notifyUser(
                                'Необходимо заполнить все поля.',
                              );
                            }
                            isLoading.value = false;
                          },
                        ),
                      ),
              );
            },
          ),
          floatingActionButtonLocation:
              FloatingActionButtonLocation.centerFloat,
          floatingActionButtonAnimator: FloatingActionButtonAnimator.scaling,
        ),
      ),
    );
  }
}
