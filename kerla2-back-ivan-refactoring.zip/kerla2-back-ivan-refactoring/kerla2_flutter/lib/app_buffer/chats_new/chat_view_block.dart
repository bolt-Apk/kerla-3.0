import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/app_buffer/chats_new/widgets/ad/ad_preview_widget.dart';
import 'package:kerla2_flutter/app_buffer/chats_new/widgets/chat_app_bar.dart';
import 'package:kerla2_flutter/app_buffer/chats_new/widgets/chat_theme.dart';
import 'package:kerla2_flutter/core/app_backend_filters.dart';

import 'package:kerla2_flutter/router/router.dart';
import 'package:kerla2_shared/kerla2_shared.dart';
import 'package:nit_app/nit_app.dart';
import 'package:nit_router/nit_router.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

import 'widgets/ad/ad_message.dart';

class ChatViewBlock extends HookConsumerWidget {
  const ChatViewBlock({
    super.key,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final channelId = ref.watchNavigationParam(
      AppNavigationParams.channelId,
    );

    return ref
        .watchModelCustomAsync<NitChatChannel>(
      backendFilter: AppBackendFilter.id.equals(channelId),
    )
        .nitWhen(
      childBuilder: (chatChannel) {
        final adId =
            ChatChannelNames.extractAdChannelData(chatChannel.channel)?.$1;
        return Scaffold(
          // showBottomNavBar: false,
          appBar: ChatAppBar(chatChannel: chatChannel),
          body: ChatTheme(
            data: whatsAppChatTheme(context),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (adId != null)
                  Padding(
                    padding: const EdgeInsets.all(10),
                    child: AdPreviewWidget(adId: adId),
                  ),
                // Divider(
                //   thickness: 1,
                //   color: context.theme.secondaryHeaderColor,
                // ),
                Expanded(
                  child: NitChatView(
                    chatId: chatChannel.id!,
                    customMessageBuilders: {
                      'adMessage': (message) {
                        if (message.customMessageType!.additionalModelId ==
                            null) {
                          return const Text(
                              'ERROR: adMessage without additionalModelId');
                        }
                        return ref
                            .watchOrFetchMaybeModelAsync<Ad>(
                                message.customMessageType!.additionalModelId!)
                            .nitWhen(childBuilder: (ad) {
                          if (ad == null) {
                            return const SizedBox.shrink();
                          }
                          return AdMessage(
                            ad: ad,
                          );
                        });
                      }
                    },
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
