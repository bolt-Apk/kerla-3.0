part of '../ui_kit.dart';

// TODO: переписать, используя DRY
// в date_extension есть pluralize
String day(int num) {
  if (num % 100 ~/ 10 == 1) {
    return 'дней';
  } else if (num % 10 == 1) {
    return 'день';
  } else if (num % 10 >= 2 && num % 10 <= 4) {
    return 'дня';
  } else {
    return 'дней';
  }
}

String month(int num) {
  if (num % 100 ~/ 10 == 1) {
    return 'месяцев';
  } else if (num % 10 == 1) {
    return 'месяц';
  } else if (num % 10 >= 2 && num % 10 <= 4) {
    return 'месяца';
  } else {
    return 'месяцев';
  }
}

String ads(int num) {
  if (num % 100 ~/ 10 == 1) {
    return 'объявлений';
  } else if (num % 10 == 1) {
    return 'объявление';
  } else if (num % 10 >= 2 && num % 10 <= 4) {
    return 'объявления';
  } else {
    return 'объявлений';
  }
}
