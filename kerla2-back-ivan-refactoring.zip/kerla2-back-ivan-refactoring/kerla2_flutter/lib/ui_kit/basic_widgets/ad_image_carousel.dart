part of '../ui_kit.dart';

class AdImageCarousel extends StatefulWidget {
  const AdImageCarousel({
    super.key,
    required this.urls,
    required this.imageHeight,
    required this.borderRadius,
    this.zoomable = false,
    this.needBlur = false,
    this.isLimitDots = false,
  });

  final List<NitMedia> urls;
  final double imageHeight;
  final BorderRadiusGeometry borderRadius;
  final bool needBlur;
  final bool zoomable;
  final bool isLimitDots;

  @override
  State<AdImageCarousel> createState() => _AdImageCarouselState();
}

class _AdImageCarouselState extends State<AdImageCarousel> {
  int _current = 0;
  final CarouselSliderController _controller = CarouselSliderController();
  PageController? zoomPageController;

  // @override
  // void initState() {
  //   super.initState();
  //   zoomPageController?.addListener(() {
  //     setState(() {
  //       _current = zoomPageController!.page!.toInt();
  //     });
  //   });
  // }

  Widget imageWidget(NitMedia media) => ImageOrVideoThumbnailWidget(
        url: media.publicUrl,
        type: media.type,
      );

  Widget blurWidget(NitMedia media) => SizedBox(
        height: double.infinity,
        width: double.infinity,
        child: ImageFiltered(
          imageFilter: ImageFilter.blur(
            sigmaX: 10,
            sigmaY: 10,
            tileMode: TileMode.repeated,
          ),
          child: imageWidget(media),
        ),
      );

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: widget.zoomable
          ? () async {
              showGeneralDialog(
                context: context,
                barrierColor: Colors.grey.shade900.withOpacity(0.95),
                barrierDismissible: false,
                transitionDuration: const Duration(milliseconds: 100),
                barrierLabel: 'Dialog',
                pageBuilder: (BuildContext context, _, __) {
                  zoomPageController = PageController(initialPage: _current);
                  return Dismissible(
                    direction: DismissDirection.vertical,
                    onDismissed: Navigator.of(context).pop,
                    key: const Key("key"),
                    child: SafeArea(
                      child: SizedBox.expand(
                        child: Container(
                          color: Colors.transparent,
                          child: PhotoViewGallery.builder(
                            wantKeepAlive: true,
                            allowImplicitScrolling: true,
                            itemCount: widget.urls.length,
                            pageController: zoomPageController,
                            builder: (context, index) {
                              return PhotoViewGalleryPageOptions(
                                filterQuality: FilterQuality.low,
                                imageProvider: CachedNetworkImageProvider(
                                  widget.urls[index].publicUrl,
                                ),
                                minScale:
                                    PhotoViewComputedScale.contained * 0.8,
                                maxScale: PhotoViewComputedScale.covered * 2,
                                tightMode: true,
                              );
                            },
                            onPageChanged: (index) {
                              _current = index;
                              _controller.jumpToPage(index);
                            },
                            scrollPhysics: const BouncingScrollPhysics(),
                            backgroundDecoration: const BoxDecoration(
                              color: Colors.transparent,
                            ),
                          ),
                        ),
                      ),
                    ),
                  );
                },
              );
            }
          : null,
      child: Stack(
        children: [
          ClipRRect(
            borderRadius: widget.borderRadius,
            child: Container(
              alignment: Alignment.center,
              child: CarouselSlider(
                disableGesture: false,
                items: widget.urls
                    .take(widget.needBlur ? 1 : widget.urls.length)
                    .map(
                  (item) {
                    return Builder(
                      builder: (BuildContext context) {
                        return Stack(
                          children: [
                            widget.needBlur
                                ? Align(child: imageWidget(item))
                                : blurWidget(item),
                            widget.needBlur
                                ? blurWidget(item)
                                : Align(child: imageWidget(item)),
                          ],
                        );
                      },
                    );
                  },
                ).toList(),
                carouselController: _controller,
                options: CarouselOptions(
                  height: widget.imageHeight,
                  viewportFraction: 1,
                  onPageChanged: (index, reason) {
                    setState(() {
                      _current = index;
                    });
                  },
                ),
              ),
            ),
          ),
          if (!widget.needBlur)
            Positioned(
              bottom: 10,
              left: 0,
              right: 0,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: widget.urls
                    .asMap()
                    .entries
                    .take(widget.isLimitDots ? 15 : widget.urls.length)
                    .map((entry) {
                  return GestureDetector(
                    onTap: () => _controller.animateToPage(entry.key),
                    child: Container(
                      width: 6,
                      height: 6,
                      margin: const EdgeInsets.symmetric(horizontal: 2.0),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.white
                            .withOpacity(_current == entry.key ? 1 : 0.5),
                      ),
                    ),
                  );
                }).toList(),
              ),
            ),
        ],
      ),
    );
  }
}
