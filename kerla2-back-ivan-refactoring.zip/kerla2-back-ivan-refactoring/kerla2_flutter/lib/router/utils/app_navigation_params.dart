part of '../router.dart';

enum AppNavigationParams<T> with NavigationParamsMixin<T> {
  adId<int>(),
  userId<int>(),
  userProfileId<int>(),
  channelId<int>(),
  chatId<int>(),
  storyId<int>(),
}
