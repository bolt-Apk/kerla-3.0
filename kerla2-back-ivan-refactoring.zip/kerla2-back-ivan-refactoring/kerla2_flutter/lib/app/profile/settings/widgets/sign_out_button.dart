import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:nit_app/nit_app.dart';

class SignOutButton extends ConsumerWidget {
  const SignOutButton({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return TextButton(
      onPressed: () async {
        await ref.read(nitSessionStateProvider.notifier).signOut();
      },
      // onLongPress: () async {
      //   final result = await CapchaDialog.showCapchaDialog(context);
      //   if (result == true && context.mounted) {
      //     context.pushNamed(
      //       MainAreaNavigationZone.paymentsStatus.name,
      //     );
      //   }
      // },
      child: Text(
        'Выйти из профиля',
        style: Theme.of(context).textTheme.displayLarge,
      ),
    );
  }
}
