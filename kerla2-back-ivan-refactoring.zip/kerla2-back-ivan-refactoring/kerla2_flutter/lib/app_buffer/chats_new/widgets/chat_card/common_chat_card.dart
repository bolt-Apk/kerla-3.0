import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:kerla2_client/kerla2_client.dart';
import 'package:kerla2_flutter/app_buffer/chats_new/widgets/chat_card/message_counter.dart';
import 'package:kerla2_flutter/app_buffer/chats_new/widgets/chat_list_card.dart';
import 'package:kerla2_flutter/app_buffer/profile/profile_image/profile_image.dart';
import 'package:nit_app/nit_app.dart';
import 'package:nit_ui_kit/nit_ui_kit.dart';

class CommonChatCard extends ConsumerWidget {
  const CommonChatCard({
    super.key,
    required this.chatParticipant,
    required this.userProfile,
  });

  final NitChatParticipant chatParticipant;
  final UserProfile userProfile;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return InkWell(
      onTap: () {
        context.goToChatByChannelId(
          channelId: chatParticipant.chatChannelId,
        );
        // if (chatParticipant.unreadCount > 0) {
        //   ref.saveModel(chatParticipant.copyWith(unreadCount: 0));
        // }
      },
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ProfileImage(
              userId: userProfile.userId,
              size: 48,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        userProfile.userName ?? '',
                        style: context.textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.clip,
                      ),
                      const SizedBox(height: 4),
                      Text(
                        chatParticipant.lastMessage ?? '',
                        style: context.textTheme.bodyMedium?.copyWith(
                          color: context.theme.hintColor,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.clip,
                      ),
                    ],
                  ),
                  const Spacer(),
                  if (chatParticipant.lastMessageSentAt != null)
                    Text(
                      DateFormat('d MMMM', 'ru').format(
                        chatParticipant.lastMessageSentAt!.toLocal(),
                      ),
                      style: context.textTheme.labelSmall?.copyWith(
                        fontSize: 14,
                        color: context.theme.primaryColorDark,
                      ),
                    ),
                ],
              ),
            ),
            NewMessageCounter(chatParticipant: chatParticipant),
          ],
        ),
      ),
    );
  }
}
