part of '../router.dart';

enum ChatNavigationZone implements NavigationZoneRoute {
  chats(
    SimpleNavigationRouteDescriptor(
      page: ChatListPage(),
    ),
  ),
  // chatByUserId(
  //   ParameterizedNavigationRouteDescriptor(
  //     page: ChatViewBlock(),
  //     parameter: AppNavigationParams.userId,
  //     parent: chats,
  //   ),
  // ),
  chatByChannelId(
    ParameterizedNavigationRouteDescriptor(
      page: ChatViewBlock(),
      parameter: AppNavigationParams.channelId,
      parent: chats,
    ),
  ),
  // chatByAdId(
  //   ParameterizedNavigationRouteDescriptor(
  //     page: ChatViewBlock(),
  //     parameter: AppNavigationParams.adId,
  //     parent: chats,
  //   ),
  // ),
  ;

  @override
  final NavigationRouteDescriptor descriptor;

  const ChatNavigationZone(this.descriptor);

  @override
  String get root => '';

  // TODO: вернуть
  // @override
  // Page<dynamic> pageBuilder(BuildContext context, GoRouterState state) {
  //   return navigationPageBuilder(
  //     context: context,
  //     state: state,
  //     route: route,
  //     wrapper: (Widget child) => DoubleBackToExit(
  //       enabled: route.parent == null && !Platform.isIOS,
  //       snackBarMessage: 'Нажмите ещё раз, чтобы выйти',
  //       child: child,
  //     ),
  //   );
  // }
}
