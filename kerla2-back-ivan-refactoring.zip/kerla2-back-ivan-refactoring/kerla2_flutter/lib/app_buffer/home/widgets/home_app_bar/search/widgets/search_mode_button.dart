import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kerla2_flutter/app_buffer/home/widgets/home_app_bar/search/providers.dart';
import 'package:kerla2_flutter/ui_kit/ui_kit.dart';

class SearchIconMode extends ConsumerWidget {
  const SearchIconMode({
    super.key,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final searchTabStateValue = ref.watch(searchTabState);
    return InkWell(
      onTap: () {
        ref.read(searchTabState.notifier).state =
            searchTabStateValue == SearchState.account
                ? SearchState.ads
                : SearchState.account;
        ref.read(searchString.notifier).state = '';
      },
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: AnimatedSwitcher(
          duration: const Duration(milliseconds: 100),
          child: searchTabStateValue == SearchState.ads
              ? SvgPicture.asset(
                  AppIconsSvg.account,
                  colorFilter: ColorFilter.mode(
                    Theme.of(context).iconTheme.color ?? Colors.black,
                    BlendMode.srcIn,
                  ),
                  height: 18,
                  width: 18,
                )
              : SvgPicture.asset(
                  AppIconsSvg.picture, // TODO: implement ad icon
                  colorFilter: ColorFilter.mode(
                    Theme.of(context).iconTheme.color ?? Colors.black,
                    BlendMode.srcIn,
                  ),
                  height: 18,
                  width: 18,
                ),
        ),
      ),
    );
  }
}
